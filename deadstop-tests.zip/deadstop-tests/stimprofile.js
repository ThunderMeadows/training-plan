// STIMULUS PROFILE (2026-09-03, his direction: "mid-range and dynamic flexion and anti-extension
// - these are huge examples of scientific advances I want incorporated in the entire engine").
//
// Muscle names cannot tell good programming from redundancy. A mid-range curl beside a
// stretched-position curl is two different stimuli; a rear-delt machine beside a rear-delt fly is
// the same thing twice. The engine now carries a profile per movement - where peak tension sits
// (long / mid / short) and, for the trunk, what is actually being resisted.
//
// The tagging is biomechanics and it is defensible. The rule built ON it - that varied profiles
// beat repeated ones at matched volume - is INFERENCE, not a demonstrated result, so the engine
// prefers and reports but never overrules. This harness pins both halves: the distinctions have
// to be real, AND the engine must not start rewriting his programming over them.
const { JSDOM } = require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const dom=new JSDOM(fs.readFileSync(f,'utf8'),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/',
  beforeParse(w){
    w.AudioContext=function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
    w.alert=()=>{};
  }});
const w=dom.window,D=w.document,EV=e=>w.eval(e);
let bad=0; const chk=(l,ok,d)=>{ if(!ok) bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&d?'  <-- '+d:''}`); };

setTimeout(async()=>{
  console.log(`\n--- ${L}: the engine knows what kind of work it is, not just which muscle ---`);
  EV('try{TOUR.live=false;}catch(e){} S.tour={done:true}; if(typeof ONB!=="undefined"){ONB().done=true;} S.discAck={v:DISC_V,d:localDate()}; storageOK=true; S.maxes={squat:327,bench:225,dead:405,ohp:145,row:170,pull:225}; save();');

  // --- 1. the distinctions have to be real ------------------------------------
  chk('the pair he binned reads as one stimulus, not two',
      EV('stimSame("Reverse Pec Deck","Rear Delt Fly")')===true, 'the engine still thinks they differ');
  chk('a stretched curl and a mid-range curl read as different work',
      EV('stimSame("Incline DB Curl","Straight Bar Curl")')===false
        && EV('stimWords("Incline DB Curl")')==='stretched'
        && EV('stimWords("Straight Bar Curl")')==='mid-range',
      EV('stimWords("Incline DB Curl")')+' vs '+EV('stimWords("Straight Bar Curl")'));
  chk('dynamic flexion and an anti-extension hold read as different work',
      EV('stimSame("Hanging Leg Raises","Plank")')===false
        && EV('stimWords("Hanging Leg Raises")')==='dynamic flexion'
        && EV('stimWords("Plank")')==='anti-extension',
      EV('stimWords("Hanging Leg Raises")')+' vs '+EV('stimWords("Plank")'));
  chk('seated and lying leg curls are not the same hamstring stimulus',
      EV('stimSame("Seated Leg Curl","Lying Leg Curl")')===false,
      'the hip-flexed and hip-extended curls read alike');
  chk('two chest presses are still just two chest presses, not a fault',
      EV('stimSame("Bench Press","Incline Bench Press")')===true,
      'these are both mid-range and honestly ARE the same profile - the engine may say so, but nothing may act on it for programmed work');

  // --- 2. an untagged movement asserts NOTHING --------------------------------
  chk('an unknown movement never claims to match anything',
      EV('stimSame("Not A Real Movement","Bench Press")')===false
        && EV('stimSame("Not A Real Movement","Also Not Real")')===false);
  chk('and an unknown movement has no words put in its mouth',
      EV('stimWords("Not A Real Movement")')==='' && EV('stimOf("Not A Real Movement")')===null);

  // --- 3. coverage: a thin table makes the whole feature quietly useless -------
  const cov=JSON.parse(EV(`(function(){ var n=0,t=0,miss=[];
    EXLIB.forEach(function(r){ t++; if(STIM[r[0]]) n++; else miss.push(r[0]); });
    return JSON.stringify({n:n,t:t,miss:miss}); })()`));
  chk('nearly every movement in the library is tagged', cov.n/cov.t>=0.95,
      cov.n+'/'+cov.t+' tagged, missing: '+cov.miss.join(', '));

  // --- 4. the fill prefers a stimulus the week does not already have ----------
  // This only BITES when the muscle is trained on another day of the week: c186 means a fill
  // always targets a muscle with no direct work TODAY, so if the week has none either, every
  // candidate is novel and the preference is a no-op. Scanning the default plan therefore proved
  // nothing - it passed with the preference deleted. Built explicitly instead.
  const sdCands=JSON.parse(EV(`JSON.stringify((VOL_PICK.sdelt||[]).filter(function(n){ return !!libRow(n); }).map(function(n){ return [n, stimKey(n)]; }))`));
  chk('(fixture) side delts offer two genuinely different stimuli to choose between',
      sdCands.length>=2 && new Set(sdCands.map(x=>x[1])).size>=2,
      'candidates: '+JSON.stringify(sdCands));
  const shortFirst = sdCands.length && sdCands[0][1]===EV('stimKey("Lateral Raises")');
  chk('(fixture) and the staple order would pick the SHORTENED one by default',
      shortFirst, 'first candidate is '+(sdCands[0]||[])[0]+' - this check cannot detect a lost preference');
  const picked=EV(`(function(){
    // side delts already trained shortened earlier in the week, and still under target
    var seen=stimSeen('sdelt');
    var cands=(VOL_PICK.sdelt||[]).filter(function(n){ return !!libRow(n); });
    var fake={}; fake[stimKey('Lateral Raises')]=6;      // the week's existing shortened work
    var fresh=cands.filter(function(n){ var k=stimKey(n); return k && !fake[k]; });
    return JSON.stringify({would:(fresh[0]||cands[0]), staple:cands[0], seenReal:Object.keys(seen)});
  })()`);
  const pk=JSON.parse(picked);
  chk('with the week already shortened for that muscle, the fill reaches for the other profile',
      pk.would!==pk.staple && EV('stimWords('+JSON.stringify(pk.would)+')')==='stretched',
      'it would still add '+pk.would+' beside existing shortened work');
  // The SHIPPED preference, called directly. Driving this through sessPickExercise proved
  // nothing: with a normal plan the fill picker only ever reaches tibialis, which has a single
  // option, so the preference never fires and the break that deletes it sails through. Reading
  // the function's source for the word "fresh" was no better - the word survives the break.
  EV(`window.__s0=stimSeen; stimSeen=function(m){ var o={}, k=stimKey('Lateral Raises'); if(k) o[k]=6; return o; };`);
  const pref=EV(`stimPreferred('sdelt', ['Lateral Raises','Cable Lateral Raise'])`);
  const prefNone=EV(`stimPreferred('sdelt', ['Lateral Raises'])`);
  EV('stimSeen=window.__s0;');
  chk('with the week already shortened, the shipped picker reaches for the other profile',
      pref==='Cable Lateral Raise', 'it chose '+pref+' beside existing shortened work');
  chk('and with nothing else on offer it still returns the staple rather than nothing',
      prefNone==='Lateral Raises', 'it returned '+prefNone);
  chk('the fill picker routes through that same preference',
      EV('String(sessPickExercise).indexOf("stimPreferred")>-1'),
      'sessPickExercise no longer calls stimPreferred');

  // --- 4b. the holes the profile audit found, kept closed -------------------
  // Tagging the library exposed muscles the card could REPORT on but had nothing to offer
  // against: every rear-delt movement trained shortened, every front-delt one mid-range, glutes
  // had nothing lengthened, traps had nothing but shrugs. Four movements were added to close
  // them. Pinned here so a later library edit cannot quietly reopen a gap and leave the coverage
  // flag shouting about something the card cannot fix.
  const gapMus=['rdelt','fdelt','glutes','traps'];
  let reopened=[];
  gapMus.forEach(m=>{
    const r=EV(`(function(){
      var c=(VOL_PICK[${JSON.stringify(m)}]||[]).filter(function(n){ return !!libRow(n); });
      var k={}; c.forEach(function(n){ var kk=stimKey(n); if(kk) k[kk]=1; });
      return JSON.stringify({n:c.length, stims:Object.keys(k)});
    })()`);
    const o=JSON.parse(r);
    if(o.stims.length<2) reopened.push(m+' offers only ['+o.stims.join(', ')+']');
  });
  chk('every muscle whose stimulus hole was closed still offers a real choice',
      reopened.length===0, reopened.join(' | '));
  chk('and the rear delts specifically have something lengthened to reach for',
      EV(`(VOL_PICK.rdelt||[]).some(function(n){ var s=stimOf(n); return !!libRow(n) && s && s.pos==='long'; })`),
      'every rear-delt option is shortened again - the c187 flag would have nothing to offer');

  // --- 5. the coverage flag reports, and only when it means something ---------
  EV("S.day='PLAN'; render();");
  const flagged=[...D.querySelectorAll('.vol-note')].map(x=>x.textContent.trim()).filter(t=>/^all /.test(t));
  chk('a muscle whose week sits in one stimulus is called out on the volume rows',
      flagged.length>0, 'nothing flagged at all - the report is not reaching the screen');
  // Asserted against a LITERAL, not against STIM_MIN_SETS: the first version compared sets to
  // the very constant under test, so setting the constant to 0 made the check trivially true and
  // it passed with the evidence floor deleted.
  const thin=EV(`(function(){ var out=[];
    Object.keys(ANA_TGT||{}).forEach(function(m){ var o=stimOneSided(m); if(o && o.sets<6) out.push(m+'='+o.sets); });
    return JSON.stringify(out); })()`);
  chk('it stays quiet about a muscle with too little work to judge', JSON.parse(thin).length===0, thin);
  chk('the evidence floor is still set to a number worth having', EV('STIM_MIN_SETS')>=4,
      'STIM_MIN_SETS is '+EV('STIM_MIN_SETS')+' - one or two sets is not a pattern');

  // --- 6. it REPORTS, it does not reshape -------------------------------------
  const before=EV(`JSON.stringify(PLAN.days.map(function(d){ return effectiveExercises(d.code).map(function(x){ return x.name+':'+x.sets; }); }))`);
  EV(`Object.keys(ANA_TGT||{}).forEach(function(m){ try{ stimOneSided(m); }catch(e){} }); render();`);
  const after=EV(`JSON.stringify(PLAN.days.map(function(d){ return effectiveExercises(d.code).map(function(x){ return x.name+':'+x.sets; }); }))`);
  chk('reading the coverage flag never changes a single prescribed set', before===after,
      'the plan moved just from being inspected');

  console.log('  problems:', bad); process.exit(bad?1:0);
},1500);
