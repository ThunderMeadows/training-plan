// His rule, 2026-09-06: "Make sure that all training in the past does not change due to
// revisions of the application because thats exactly what happened when i made the bb row a
// main lift and assessed. The change edited past training when it should have left it alone."
//
// What c203 did to his 20 Aug pull session, read straight off his backup: Barbell Row was
// inserted at the top of every pull day, so the finished session re-rendered with "Barbell Row
// 4 sets @155" - a movement he has never performed, wearing the four sets he did on Cable Rows -
// and every movement below it shifted down one, showing today's weights instead of the 140 he
// actually lifted. Face Pulls, which he did, showed 0 sets.
//
// Root cause: a past day was never stored. It was REBUILT on every visit from the live program
// plus set state keyed by position. The freeze in S.froze was written for this rule and only
// ever froze the athlete's own additions and removals - the base plan, the order, the loads and
// the sets as performed were all still live.
//
// Now a session banks its shape into its own log and a finished session renders from that and
// nothing else. This file does what he did: bank a real session through the real path, then
// revise the program every way a build or an athlete can - insert a main lift at the front,
// move a max, reorder, remove, add - and open the finished session again. It must not move.
const {JSDOM}=require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const raw=fs.readFileSync(f,'utf8');
const d=new JSDOM(raw,{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/'});
const w=d.window,EV=e=>w.eval(e);
const safe=(e,fb)=>{ try{ return EV(e); }catch(err){ return (fb===undefined)?('ERR '+err.message):fb; } };
w.AudioContext=function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
let bad=0; const chk=(l,ok,dd)=>{ if(!ok)bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&dd?'  <-- '+dd:''}`);};
const errs=[]; w.addEventListener('error',e=>errs.push(String(e.message)));
w.addEventListener('unhandledrejection',e=>errs.push(String(e.reason&&e.reason.message||e.reason)));
const sleep=ms=>new Promise(r=>setTimeout(r,ms));

// what the day on screen says, movement by movement: name, weight shown, sets logged
const READ=`(function(){
  var d=dayObj(); return d.exercises.map(function(ex,i){
    var st=S.data[exKey(i)]; var n=st? (st.sets||[]).filter(function(s){ return s.st!=='pend'; }).length : 0;
    var wv=null; try{ wv=curLoad(ex, st); }catch(e){}
    return {n:ex.name, w:wv, sets:n};
  });
})`;

setTimeout(async ()=>{
  console.log(`\n--- ${L}: a banked session is a document ---`);
  EV('try{TOUR.live=false;}catch(e){} S.tour={done:true}; if(typeof ONB!=="undefined"){ONB().done=true;} S.discAck={v:DISC_V,d:localDate()}; storageOK=true; save(); render();');
  EV(`window.__read=${READ};`);

  // ---- 1. train and bank a real session through the real path -------------------
  const live=safe(`(function(){ var n=nextSession(); if(n){ S.day=n.code; S.week=n.week; } save(); render();
     return {code:S.day, week:S.week}; })()`,{});
  // distinctive weights and set counts so drift is visible: 100,110,120... and 2,3,4... sets
  const before=safe(`(function(){
    var dd=dayObj();
    dd.exercises.forEach(function(ex,i){ var st=exState(i,ex);
      st.w=100+i*10;
      var n=Math.min(st.sets.length, 2+i);
      st.sets.forEach(function(s2,j){ if(j<n){ s2.st='done'; s2.reps=5; s2.rir=2; s2.w=100+i*10; } });
    });
    save(); return __read();
  })()`,[]);
  chk('(fixture) a live session with distinctive weights and set counts', before.length>=4 && before[0].w===100 && before[1].sets===3,
      JSON.stringify(before).slice(0,160));
  let banked=null, bankErr=null;
  try{ banked=await EV('saveSessionLog(true)'); }catch(e){ bankErr=String(e&&e.message||e); }
  chk('the session banks through the real path', banked===true && !bankErr, bankErr||('returned '+banked));
  await sleep(60);
  const key=safe('curLOGP()+S.when.date+"-"+S.day+"-W"+S.week+"B"+cyc()','');
  const stored=safe(`JSON.parse(localStorage.getItem("nsc:${key}")||"{}")`,{});
  chk('the log carries the session\u2019s shape', Array.isArray(stored.shape) && stored.shape.length===before.length,
      'shape='+JSON.stringify(stored.shape||null).slice(0,120));
  chk('the shape records the weight used and every set as performed',
      Array.isArray(stored.shape) && stored.shape[0] && stored.shape[0].w===100 && stored.shape[1] && stored.shape[1].sets.filter(s=>s.st!=='pend').length===3,
      JSON.stringify((stored.shape||[])[1]||null).slice(0,160));
  chk('the report is still there beside it', typeof stored.report==='string' && stored.report.length>20, 'no report');

  // ---- 2. leave, then come back to it as a finished session ----------------------
  await EV('refreshLogs()'); await sleep(80);
  EV(`S.day=${JSON.stringify(live.code)}; S.week=${live.week}; render();`);
  chk('(fixture) the banked session is now being visited', safe('isVisiting()',false)===true, 'not visiting');
  const visit0=safe('__read()',[]);
  chk('a finished session shows what was done', JSON.stringify(visit0)===JSON.stringify(before),
      'drift before any revision: '+JSON.stringify(visit0).slice(0,160));

  // ---- 3. HIS CASE: a build inserts a main lift at the top of the day --------------
  const first=before[0].n;
  safe(`(function(){
    var p=PLAN.days.find(function(x){ return x.code===${JSON.stringify(live.code)}; });
    p.exercises.unshift({name:'Audit Row', sets:4, reps:'5', rir:'2', rest:'3:00', load:'155', loadNum:155, maxKey:'row', pct:[0.65,0.7,0.75,0.8,0.85,0.5], wk:[125,135,145,155,165,95], primary:true});
    _docMemo=null; render(); return 1;
  })()`);
  const visit1=safe('__read()',[]);
  console.log(`    program revised: "Audit Row" inserted at the top of day ${live.code}`);
  chk('the finished session does not grow a movement it never had',
      !visit1.some(x=>x.n==='Audit Row'), 'the new main lift appeared in a session logged before it existed');
  chk('every movement keeps its own sets and its own weight',
      JSON.stringify(visit1)===JSON.stringify(before),
      'was '+JSON.stringify(before).slice(0,120)+' now '+JSON.stringify(visit1).slice(0,120));

  // ---- 4. a max moves - the weights on a finished session do not -----------------
  safe(`(function(){ Object.keys(S.maxes||{}).forEach(function(k){ S.maxes[k]=(S.maxes[k]||100)+60; });
    try{ applyMaxesToPlan(); }catch(e){} _docMemo=null; render(); return 1; })()`);
  const visit2=safe('__read()',[]);
  chk('moving every max by 60 lb leaves the finished session\u2019s weights alone',
      JSON.stringify(visit2.map(x=>x.w))===JSON.stringify(before.map(x=>x.w)),
      'weights now '+JSON.stringify(visit2.map(x=>x.w)));

  // ---- 5. the athlete edits the day - reorder, remove, add --------------------------
  safe(`(function(){
    var c=${JSON.stringify(live.code)};
    var names=dayOrderNames(c); if(typeof moveInDay==='function' && names.length>2) moveInDay(c, names.length-1, 0);
    if(!S.outs) S.outs={}; if(!S.outs[c]) S.outs[c]=[]; S.outs[c].push(${JSON.stringify(first)});
    try{ libAdd('Plank', c); }catch(e){}
    _docMemo=null; render(); return 1;
  })()`);
  const visit3=safe('__read()',[]);
  chk('reordering, removing and adding on the plan leave the finished session untouched',
      JSON.stringify(visit3)===JSON.stringify(before),
      'now '+JSON.stringify(visit3).slice(0,160));
  chk('the removed movement is not shown as skipped in a session where it was done',
      safe(`!isOut(${JSON.stringify(first)})`,false), 'a later removal rewrote a finished session');

  // ---- 6. the live path is untouched --------------------------------------------
  const nxt=safe(`(function(){ var n=nextSession(); if(!n) return null; S.day=n.code; S.week=n.week; render();
    var dd=dayObj(); var st=exState(0, dd.exercises[0]);
    return {doc:!!docRef(), isDoc:!!dd.doc, keyed:exKey(0), hasRow:dd.exercises.some(function(e){ return e.name==='Audit Row'; }), pend:(st.sets||[]).every(function(s){ return s.st==='pend'; })};
  })()`,null);
  chk('the next live session is live, not a document', nxt && !nxt.doc && !nxt.isDoc && /^\\d+c\\|/.test(nxt.keyed), JSON.stringify(nxt));
  chk('and it DOES see the revised program - the future is the program\u2019s to change', nxt && (nxt.hasRow || nxt.n===undefined), JSON.stringify(nxt));
  chk('its sets start pending like any live session', nxt && nxt.pend===true, JSON.stringify(nxt));

  // ---- 7. a session logged before the shape existed -------------------------------
  safe(`(function(){ var k=${JSON.stringify(key)}; var v=JSON.parse(localStorage.getItem("nsc:"+k)); delete v.shape;
    localStorage.setItem("nsc:"+k, JSON.stringify(v)); delete logCache[k]; _docMemo=null; return 1; })()`);
  await EV('refreshLogs()'); await sleep(80);
  EV(`S.day=${JSON.stringify(live.code)}; S.week=${live.week}; _docMemo=null; render();`);
  await sleep(120); EV('render();');
  const oldTxt=String(safe('document.getElementById("app").textContent',''));
  chk('an old log without a shape is not reconstructed as a document', safe('docRef()===null',false), 'docRef found a shape that is not there');
  chk('it says so, and shows the banked report beside the day',
      /Logged before this version/.test(oldTxt) && /SESSION REPORT/.test(oldTxt), 'no notice or no report on a pre-shape session');

  // ---- 7b. v217: a pre-shape log gets its shape back from its own report ---------------
  // His question: "My past still shows bb row. Is that something that ill have to keep?" No.
  // report() writes a fixed format the card controls; reading it back is transcription.
  const bf=safe(`(function(){ var k=${JSON.stringify(key)};
    var v=JSON.parse(localStorage.getItem("nsc:"+k)); delete v.shape; delete v.shape_src;
    localStorage.setItem("nsc:"+k, JSON.stringify(v)); delete logCache[k]; delete S.docBackfill; _docMemo=null; return v.report.split("\\n").length; })()`,0);
  await EV('refreshLogs()'); await sleep(60);
  const nBf=await EV('docBackfill()'); await sleep(60);
  const rebuilt=safe(`JSON.parse(localStorage.getItem("nsc:"+${JSON.stringify(key)}))`,{});
  chk('the backfill rebuilds a shape-less log from its report', nBf===1 && Array.isArray(rebuilt.shape) && rebuilt.shape.length===before.length && rebuilt.shape_src==='report', 'backfilled '+nBf+', shape '+JSON.stringify(rebuilt.shape||null).slice(0,80));
  chk('and it says exactly what was done - weights and sets as banked',
      rebuilt.shape && rebuilt.shape[0].w===100 && rebuilt.shape[1].sets.filter(s=>s.st!=='pend').length===3 && rebuilt.shape[0].n===before[0].n,
      JSON.stringify((rebuilt.shape||[])[0]||null).slice(0,120));
  chk('it runs once per build, not on every open', await EV('docBackfill()')===0, 'ran again');
  EV(`S.day=${JSON.stringify(live.code)}; S.week=${live.week}; _docMemo=null; render();`); await sleep(150); EV('_docMemo=null; render();');
  const rv=safe('__read()',[]);
  chk('the rebuilt session renders as a document, matching the original', JSON.stringify(rv)===JSON.stringify(before), 'now '+JSON.stringify(rv).slice(0,140));
  chk('and says it was rebuilt from the report', /Rebuilt from the session report/.test(String(safe('document.getElementById("app").textContent',''))), 'no note');
  // a report the parser cannot read is left alone - nothing is invented
  safe(`(function(){ var k=${JSON.stringify(key)}; var v=JSON.parse(localStorage.getItem("nsc:"+k)); delete v.shape; delete v.shape_src;
    v.report=v.report.replace(/^([A-Z][^:]{2,40}) (\\S+): (.*)$/m, "$1 $2: 10@2, banana, 10@2"); localStorage.setItem("nsc:"+k, JSON.stringify(v)); delete logCache[k]; delete S.docBackfill; return 1; })()`);
  await EV('refreshLogs()'); await sleep(60); await EV('docBackfill()'); await sleep(40);
  const left=safe(`JSON.parse(localStorage.getItem("nsc:"+${JSON.stringify(key)}))`,{});
  chk('a report with a line it cannot read is left alone, shape-less', !left.shape, 'the parser invented a shape from a line it did not understand');
  // parser vectors from the report grammar
  chk('the report grammar is read exactly',
      safe(`(function(){
        var NL=String.fromCharCode(10), OK=String.fromCharCode(0x2713), DOT=String.fromCharCode(0xb7);
        var sh=shapeFromReport(['SESSION REPORT '+DOT+' Block 1',
          'Bench Press 245: '+OK+', 10@2, 8!, ?, '+DOT+' | wts 245/245/245/245/245 | rest 2:10',
          'Incline DB Press 60/hand: 10, 10 [adjusted from 55]',
          'Machine Row 120: 8@2 [sub for Barbell Row]',
          'Plank BW: 0:45',
          'Face Pulls: not done',
          'Notes: felt good',
          '('+OK+' = as prescribed)',
          'Cardio: none'].join(NL));
        if(!sh || sh.length!==5) return 'lines '+(sh&&sh.length);
        var b=sh[0], i=sh[1], r=sh[2], p=sh[3], f=sh[4];
        return b.n==='Bench Press' && b.w===245 && b.sets.length===5
          && b.sets[0].st==='hit' && b.sets[1].reps===10 && b.sets[1].rir===2 && b.sets[2].reps===8 && b.sets[2].g===true && b.sets[3].st==='done' && b.sets[3].reps===null && b.sets[4].st==='pend'
          && i.ph===true && i.w===60 && r.n==='Barbell Row' && r.sub==='Machine Row' && r.w===120
          && p.w===null && p.load==='BW' && p.sets[0].reps===45
          && f.n==='Face Pulls' && f.sets.length===0;
      })()`,false)===true, safe('JSON.stringify(shapeFromReport("Bench Press 245: \u2713, 10@2"))'));

  // ---- 8. the weekly counts and the state file are not polluted ----------------------
  chk('document keys are not counted as new work',
      safe(`(function(){ var n=0; Object.keys(S.data).forEach(function(k){ if(k.indexOf('doc|')===0) (S.data[k].sets||[]).forEach(function(s){ if(s.st!=='pend') n++; }); });
        var ws=weekSets(cyc(), ${live.week}); return ws>0 && ws<=${before.reduce((a,x)=>a+x.sets,0)}+0; })()`,false),
      'weekSets grew from document entries');
  chk('no runtime errors anywhere on the path', errs.length===0, errs.join(' | '));

  console.log(`\nproblems: ${bad}`);
  process.exit(bad? 1:0);
},1800);
