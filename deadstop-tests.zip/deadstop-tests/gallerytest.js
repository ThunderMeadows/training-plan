// THE GALLERY (2026-09-02): every banked session's wrap-up, reopenable and shareable later.
// Built only from stored data. This banks a session, then verifies the gallery lists it, the
// overlay reopens it with the right numbers, a past-day share paints THAT day, and - the
// part he asked to be sure of - the live share path is unaffected.
const {JSDOM}=require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const d=new JSDOM(fs.readFileSync(f,'utf8'),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/'});
const w=d.window,EV=e=>w.eval(e);
w.AudioContext=function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
let bad=0; const chk=(l,ok,dd)=>{ if(!ok)bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&dd?'  <-- '+dd:''}`);};
setTimeout(async ()=>{
  console.log(`\n--- ${L}: the gallery ---`);
  EV('try{TOUR.live=false;}catch(e){} S.tour={done:true}; if(typeof ONB!=="undefined"){ONB().done=true;} S.discAck={v:DISC_V,d:localDate()}; storageOK=true; S.maxes={squat:327,bench:225,dead:405,ohp:145,row:170,pull:225}; save(); render();');
  chk('an empty history shows no gallery', EV('galleryHTML()')==='', 'gallery with nothing in it');
  // a PAST session, a week ago, straight into the stores banking writes to
  const past=EV(`(function(){ var y=new Date(shiftDate()+'T12:00:00'); y.setDate(y.getDate()-7);
    return new Date(y.getTime()-y.getTimezoneOffset()*60000).toISOString().slice(0,10); })()`);
  EV(`histPush('Bench Press', {d:'${past}', w:225, sets:[8,8,8], ws:[225,225,225], e1:285});
      histPush('Barbell Row', {d:'${past}', w:185, sets:[10,10], ws:[185,185], e1:246});
      S.prs=(S.prs||[]).concat([{d:'${past}',ex:'Bench Press',kind:'weight',val:225,prev:215}]); save();`);
  const sn=JSON.parse(EV(`JSON.stringify(sessionSnapshot('${past}'))`));
  chk('a snapshot is built from stored data', !!sn, 'null');
  chk('with the right set count', sn && sn.sets===5, sn&&sn.sets);
  chk('and the right tonnage', sn && sn.ton===225*24+185*20, sn&&sn.ton);
  chk('and the record', sn && sn.prs.length===1 && sn.prs[0].val===225, JSON.stringify(sn&&sn.prs));
  chk('and a row per movement', sn && sn.rows.length===2 && sn.rows[0][1].indexOf('3 \u00d7 8')===0, JSON.stringify(sn&&sn.rows));
  chk('the gallery lists it', EV('galleryHTML()').indexOf('data-galopen="'+past+'"')>=0, 'not listed');
  // the gallery lives inside the "Past sessions" fold now (c165) - closed by default, opened by a tap
  chk('the calendar tab carries the gallery behind its fold', EV('S.day="CAL"; render(); !!document.querySelector("[data-foldtog=gallery]")'), 'no fold on CAL');
  EV('document.querySelector("[data-foldtog=gallery]").click();');
  chk('opening the fold shows the gallery', EV('!!document.getElementById("gallery")'), 'gallery missing after open');
  chk('the day strip links the last session', EV('S.day=PLAN.days[0].code; render(); !!document.querySelector("#calStrip [data-galopen]")'), 'no strip link');
  // reopen it
  EV(`document.querySelector("#calStrip [data-galopen]").click();`);
  const ov=EV('(document.getElementById("galGate")||{textContent:""}).textContent');
  chk('the wrap-up reopens', ov.length>0, 'no overlay');
  chk('with the record shown', ov.indexOf('Bench Press weight 225')>=0, 'record missing');
  chk('and the movements', ov.indexOf('Barbell Row')>=0, 'movements missing');
  chk('it is lockfree (a banked day cannot eat it)', EV('document.getElementById("galGate").className.indexOf("lockfree")>=0'), 'guard would swallow it');
  // a past-day share paints THAT day, not today
  EV('SHARE_SNAP=sessionSnapshot("'+past+'");');
  const painted=await new Promise(res=>{ EV(`window.__paint=null; (function(){ var drawn=[];
    var orig=HTMLCanvasElement.prototype.getContext;
    HTMLCanvasElement.prototype.getContext=function(){ var c=orig.apply(this,arguments); if(c&&!c.__t){ c.__t=1; var ft=c.fillText; c.fillText=function(t){ drawn.push(String(t)); return ft.apply(c,arguments); }; } return c; };
    shareCardPaint(function(){ window.__paint=drawn.join('\\n'); }, null, null); })();`);
    let tries=0; const iv=setInterval(()=>{ const p=EV('window.__paint'); if(p!=null||++tries>40){ clearInterval(iv); res(p||''); } },100); });
  chk('the past-day share carries that date', painted.indexOf(past)>=0, 'date missing from sheet');
  chk('and that day\'s movements', painted.indexOf('Barbell Row')>=0, 'movements missing from sheet');
  chk('and that day\'s record', /225/.test(painted), 'record missing from sheet');
  EV('SHARE_SNAP=null;');
  // THE LIVE PATH IS UNTOUCHED: today's share must still read today
  EV(`(function(){ var dd=dayObj(); var st=exState(0,dd.exercises[0]); st.sets.forEach(function(s2){ s2.st='hit'; s2.reps=5; s2.rir=2; }); save(); })();`);
  const live=await new Promise(res=>{ EV(`window.__paint2=null; (function(){ var drawn=[];
    var orig=HTMLCanvasElement.prototype.getContext;
    HTMLCanvasElement.prototype.getContext=function(){ var c=orig.apply(this,arguments); if(c&&!c.__u){ c.__u=1; var ft=c.fillText; c.fillText=function(t){ drawn.push(String(t)); return ft.apply(c,arguments); }; } return c; };
    shareCardPaint(function(){ window.__paint2=drawn.join('\\n'); }, null, null); })();`);
    let tries=0; const iv=setInterval(()=>{ const p=EV('window.__paint2'); if(p!=null||++tries>40){ clearInterval(iv); res(p||''); } },100); });
  const todayName=EV('dayObj().exercises[0].name');
  chk('with no snapshot the share is today\'s, unchanged', live.indexOf(todayName)>=0 && live.indexOf(past)<0, 'live share contaminated');
  chk('SHARE_SNAP is null on the live path', EV('SHARE_SNAP===null'), 'snapshot leaked');
  EV('var g=document.getElementById("galGate"); g&&g.remove();');
  console.log('  problems: '+bad); process.exit(bad?1:0);
},1700);
