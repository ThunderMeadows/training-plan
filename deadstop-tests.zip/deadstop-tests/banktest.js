// FIELD CRASH 2026-09-02, c144: banking a session threw "undefined is not an object
// (evaluating 'S.painLog.filter')" from report(). c131 removed the pain feature and its boot
// cleanup DELETES S.painLog - which armed a leftover .filter that had been silent while the
// key was always an array. Three sweeps missed it because no test ever BANKED a session.
// This one does, end to end.
const {JSDOM}=require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const raw=fs.readFileSync(f,'utf8');
const d=new JSDOM(raw,{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/'});
const w=d.window,EV=e=>w.eval(e);
w.AudioContext=function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
let bad=0; const chk=(l,ok,dd)=>{ if(!ok)bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&dd?'  <-- '+dd:''}`);};
const errs=[]; w.addEventListener('error',e=>errs.push(String(e.message)));
w.addEventListener('unhandledrejection',e=>errs.push(String(e.reason&&e.reason.message||e.reason)));
setTimeout(async ()=>{
  console.log(`\n--- ${L}: banking a session end to end ---`);
  EV('try{TOUR.live=false;}catch(e){} S.tour={done:true}; if(typeof ONB!=="undefined"){ONB().done=true;} S.discAck={v:DISC_V,d:localDate()}; storageOK=true; save(); render();');
  // the exact field condition: the pain key is absent, as boot leaves it
  chk('boot leaves no pain log behind', EV('S.painLog===undefined'), 'key present');
  // report() must survive that on its own
  let rep=null, threw=null;
  try{ rep=EV('report()'); }catch(e){ threw=String(e&&e.message||e); }
  chk('report() runs with no pain log', !threw && typeof rep==='string' && rep.length>0, threw||'empty report');
  chk('and the report says nothing about pain', !/PAIN FLAG/i.test(rep||''), 'pain line still printed');
  // log real sets, then bank
  EV(`(function(){ var dd=dayObj(); dd.exercises.forEach(function(ex,i){ var st=exState(i,ex);
        st.sets.forEach(function(s2){ s2.st='hit'; s2.reps=5; s2.rir=2; }); }); save(); })();`);
  let banked=null, bankErr=null;
  try{ banked=await EV('saveSessionLog(true)'); }catch(e){ bankErr=String(e&&e.message||e); }
  chk('the session banks without throwing', banked===true && !bankErr, bankErr||('returned '+banked));
  chk('no error surfaced to the error handler', errs.length===0, errs.join(' | '));
  const key=EV('curLOGP()+S.when.date+"-"+S.day+"-W"+S.week+"B"+cyc()');
  chk('the log key is actually written', EV('localStorage.getItem("nsc:'+key+'")!==null'), 'nothing stored under '+key);
  chk('the day is locked after banking', EV('!!(S.locked && S.locked[cyc()+"|"+S.week+"|"+S.day])'), 'not locked');
  chk('the stored report is the real report', (EV('JSON.parse(localStorage.getItem("nsc:'+key+'")).report')||'').length>20, 'thin report');
  // and the whole card still renders afterwards
  let rendered=true; try{ EV('render();'); }catch(e){ rendered=false; }
  chk('the card renders after banking', rendered && errs.length===0, errs.join(' | '));
  console.log('  problems: '+bad); process.exit(bad?1:0);
},1600);
