// Bulk announces releases (2026-09-02, his ask).
//
// WHATSNEW had not been fed since August 22 and its sheet never fired, so nobody was told about
// anything. Now every noticeable build gets an entry with a `bulk:` line, and Bulk delivers it
// as a letter - once, ever, per release, to athletes who have used the card before. A brand-new
// athlete gets nothing: there is nothing to catch up on. And the sheet must not ALSO pop.
const { JSDOM } = require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const dom=new JSDOM(fs.readFileSync(f,'utf8'),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/'});
const w=dom.window,D=w.document,EV=e=>w.eval(e);
w.AudioContext=w.AudioContext||function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};

setTimeout(()=>{
  console.log(`\n--- ${L}: Bulk announces releases ---`);
  let bad=0; const chk=(l,ok,d)=>{ if(!ok) bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&d?'  <-- '+d:''}`); };
  EV('try{TOUR.live=false;}catch(e){} S.tour={done:true}; if(typeof ONB!=="undefined"){ONB().done=true;} S.discAck={v:DISC_V,d:localDate()}; storageOK=true;');

  const top=EV('WHATSNEW[0].build');
  chk('the newest release entry is dated and sits at the top', /^\d{4}\.\d{2}\.\d{2}/.test(top), top);
  const dates=JSON.parse(EV('JSON.stringify(WHATSNEW.map(function(x){return x.build;}))'));
  chk('entries are newest-first, so catch-up order is trustworthy',
      dates.every((d,i)=>i===0||dates[i-1]>=d), dates.join(' , '));
  chk('and it carries a letter in Bulk\'s voice', EV('typeof WHATSNEW[0].bulk')==='string' && EV('WHATSNEW[0].bulk.length')>80);
  const txt=EV('WHATSNEW[0].bulk');
  // the letter has to be about THIS entry, not boilerplate: it shares real words with the
  // title/items the athlete can also read, whatever the release happens to be about
  const words=EV("(WHATSNEW[0].title+' '+(WHATSNEW[0].items||[]).join(' ')).toLowerCase().split(/[^a-z]+/).filter(function(x){return x.length>4;})");
  const shared=words.filter(x=>txt.toLowerCase().indexOf(x)>-1);
  chk('the letter is about this release, not boilerplate', shared.length>=3,
      'shares only ['+shared.join(', ')+'] with its own title and items');
  const prev=EV('WHATSNEW[1].bulk||""');
  chk('the earlier release still carries its own letter', prev.length>80 && prev!==txt,
      'previous letter is '+prev.length+' chars'+(prev===txt?' and identical to the newest':''));
  chk('and keeps it to one screen, not a manual', txt.length<900, txt.length+' chars');

  // a brand-new athlete: nothing to catch up on
  EV("S.mail=[]; S.mailSent={}; S.seenBuild=null; S.wnOpen=false; whatsNewBoot();");
  chk('a brand-new athlete gets no update letter', EV('mailBox().length')===0 && EV('S.seenBuild')===top);

  // a returning athlete from before this release
  EV("S.mail=[]; S.mailSent={}; S.seenBuild=WHATSNEW[1].build; S.wnOpen=false; whatsNewBoot();");
  const box=JSON.parse(EV('JSON.stringify(mailBox())'));
  chk('a returning athlete one release behind gets exactly one letter', box.length===1 && box[0].id==='update-'+top, JSON.stringify(box.map(x=>x.id)));
  chk('it is the Bulk letter, unread, with a face', box[0] && box[0].txt===txt && box[0].read===false && !!box[0].face);
  chk('the old sheet does NOT also pop', EV('S.wnOpen')!==true);
  chk('and the release is marked seen', EV('S.seenBuild')===top);
  chk('the header badge counts it', EV('mailUnread()')===1);

  // once, ever - through the ledger, so clearing the box does not resend
  EV("whatsNewBoot(); mailSweep();");
  chk('a second boot does not send it again', EV("mailBox().filter(function(x){ return x.id==='update-'+WHATSNEW[0].build; }).length")===1);
  EV("S.mail=[]; whatsNewBoot(); mailSweep();");
  chk('clearing the mailbox does not bring it back', EV("mailBox().filter(function(x){ return x.id==='update-'+WHATSNEW[0].build; }).length")===0,
      'the send ledger is being bypassed');

  // an athlete two releases behind gets both, oldest first
  EV("S.mail=[]; S.mailSent={}; S.seenBuild='nothing-like-this'; whatsNewBoot();");
  const ids=JSON.parse(EV('JSON.stringify(mailBox().map(function(x){return x.id;}))'));
  chk('an athlete several releases behind gets each one, oldest first',
      ids.length===EV('WHATSNEW.length') && ids[ids.length-1]==='update-'+top, ids.join(','));

  // an entry with no bulk line still gets delivered, from its title and items
  EV("WHATSNEW.unshift({build:'9999.01.01', date:'9999-01-01', title:'A test release', items:['first thing','second thing']}); S.mail=[]; S.mailSent={}; S.seenBuild=WHATSNEW[1].build; whatsNewBoot();");
  const fb=JSON.parse(EV('JSON.stringify(mailBox())'));
  chk('an entry without a bulk line is still delivered, read from title and items',
      fb.length===1 && /A test release/.test(fb[0].txt) && /first thing/.test(fb[0].txt));
  EV("WHATSNEW.shift();");

  console.log('  problems:', bad);
  process.exit(bad?1:0);
},1500);
