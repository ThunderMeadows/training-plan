// FIELD BUG 2026-09-02 (v189): "+ set" did nothing. c130's session-length trim popped any
// untouched trailing set on the next render, including the one the athlete had just added.
// The suite tested the button's presence and never its EFFECT. This runs the flow.
const {JSDOM}=require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const d=new JSDOM(fs.readFileSync(f,'utf8'),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/'});
const w=d.window,EV=e=>w.eval(e);
w.AudioContext=function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
let bad=0; const chk=(l,ok,dd)=>{ if(!ok)bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&dd?'  <-- '+dd:''}`);};
setTimeout(()=>{
  console.log(`\n--- ${L}: adding and removing a set ---`);
  EV('try{TOUR.live=false;}catch(e){} S.tour={done:true}; if(typeof ONB!=="undefined"){ONB().done=true;} S.discAck={v:DISC_V,d:localDate()}; storageOK=true; save(); render();');
  const before=Number(EV('(function(){ var dd=dayObj(); return exState(0,dd.exercises[0]).sets.length; })()'));
  chk('the add-set control is on the card', EV('document.querySelectorAll("[data-addset]").length')>0, 'no button');
  // press it exactly as the UI does
  EV('document.querySelector("[data-addset]").click();');
  const afterClick=Number(EV('(function(){ var dd=dayObj(); return exState(0,dd.exercises[0]).sets.length; })()'));
  chk('the set is added', afterClick===before+1, before+' -> '+afterClick);
  // the render that used to eat it
  EV('render();');
  const afterRender=Number(EV('(function(){ var dd=dayObj(); return exState(0,dd.exercises[0]).sets.length; })()'));
  chk('and SURVIVES a re-render', afterRender===before+1, before+' -> '+afterClick+' -> '+afterRender);
  EV('render(); render();');
  chk('and repeated renders', Number(EV('(function(){ var dd=dayObj(); return exState(0,dd.exercises[0]).sets.length; })()'))===before+1, 'lost on later render');
  chk('it survives a save/load round trip', EV('(function(){ save(); var k="nsc:"+(typeof curSKEY==="function"? curSKEY():SKEY); var j=JSON.parse(localStorage.getItem(k)); var dd=dayObj(); var key=exKey(0); return (j.data[key]&&j.data[key].sets.length)==='+(before+1)+'; })()'), 'not persisted');
  chk('the added set is flagged as the athlete\'s', EV('(function(){ var dd=dayObj(); var s2=exState(0,dd.exercises[0]).sets; return !!s2[s2.length-1].added; })()'), 'no added flag');
  // two in a row
  EV('document.querySelector("[data-addset]").click(); render();');
  chk('a second added set also holds', Number(EV('(function(){ var dd=dayObj(); return exState(0,dd.exercises[0]).sets.length; })()'))===before+2, 'second add lost');
  // the minus button still removes them
  EV('if(document.querySelector("[data-subset]")) document.querySelector("[data-subset]").click(); render();');
  chk('the minus button still removes an added set', Number(EV('(function(){ var dd=dayObj(); return exState(0,dd.exercises[0]).sets.length; })()'))===before+1, 'minus broken');
  // a LOGGED set is never trimmed either
  EV(`(function(){ var dd=dayObj(); var st=exState(0,dd.exercises[0]); st.sets.forEach(function(s2){ s2.st='hit'; s2.reps=5; s2.rir=2; }); save(); render(); })();`);
  chk('logged sets are never trimmed', Number(EV('(function(){ var dd=dayObj(); return exState(0,dd.exercises[0]).sets.length; })()'))===before+1, 'logged work lost');
  console.log('  problems: '+bad); process.exit(bad?1:0);
},1600);
