// His ask, 2026-09-06: "Anytime i close out the app it keeps the user on the same page they
// where on when they closed it. Can you automatically place them on their training day
// instead?"
//
// syncToNext() had always brought a stale day pointer forward on open, but it was written never
// to leave a tab - so a card closed on Rate reopened on Rate. landOnTraining() now runs in front
// of it at boot and on a return from long enough in the background to be a new visit. What this
// file holds, by real reboot (a second window over the same storage) and real visibility events:
//   - closed on a tab, reopened: the training day
//   - closed on a finished session, reopened: the next session, not the finished one
//   - a session in progress is never abandoned - not by a reboot, not by a resume
//   - a short look at another app moves nothing; a long one lands on the training day
//   - focus is only touched when the day actually changed
const {JSDOM}=require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const raw=fs.readFileSync(f,'utf8');
const AC=function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
let bad=0; const chk=(l,ok,dd)=>{ if(!ok)bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&dd?'  <-- '+dd:''}`);};
const errs=[];
const sleep=ms=>new Promise(r=>setTimeout(r,ms));

function bootWith(store){
  const d=new JSDOM(raw,{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/',
    beforeParse(win){ Object.keys(store||{}).forEach(k=>win.localStorage.setItem(k, store[k])); win.AudioContext=AC; }});
  d.window.addEventListener('error',e=>errs.push(String(e.message)));
  return d.window;
}
function dump(w){ const o={}; for(let i=0;i<w.localStorage.length;i++){ const k=w.localStorage.key(i); o[k]=w.localStorage.getItem(k); } return o; }
const EVf=w=>e=>{ try{ return w.eval(e); }catch(err){ return 'ERR '+err.message; } };
function setHidden(w, hidden){
  Object.defineProperty(w.document,'hidden',{configurable:true,get:()=>hidden});
  Object.defineProperty(w.document,'visibilityState',{configurable:true,get:()=>hidden?'hidden':'visible'});
  w.document.dispatchEvent(new w.Event('visibilitychange'));
}

setTimeout(async ()=>{
  console.log(`\n--- ${L}: the card opens on the training day ---`);
  // ---- a card with a plan and onboarding done ------------------------------------
  let w=bootWith({}); await sleep(1500); let EV=EVf(w);
  EV('try{TOUR.live=false;}catch(e){} S.tour={done:true}; if(typeof ONB!=="undefined"){ONB().done=true;} S.discAck={v:DISC_V,d:localDate()}; storageOK=true; save(); render();');
  const live=EV('(function(){ var n=nextSession(); return n? {code:n.code, week:n.week} : null; })()');
  chk('(fixture) the card has a live session', live && live.code, JSON.stringify(live));

  // ---- 1. closed on a tab, reopened ---------------------------------------------
  EV('S.day="RATE"; save();');
  let w2=bootWith(dump(w)); await sleep(2200); let E2=EVf(w2);
  chk('closed on the Rate tab, it reopens on the training day',
      E2('S.day')===live.code && E2('S.week')===live.week, 'reopened on '+E2('S.day')+' W'+E2('S.week'));
  chk('and the training day actually renders',
      /Bench|Squat|Row|Press|Deadlift|Pull/.test(String(E2('document.getElementById("app").textContent'))), 'no session on screen');
  ['YOU','CAL','PLAN','LIB'].forEach(t=>{
    EV(`S.day=${JSON.stringify(t)}; save();`);
    const wx=bootWith(dump(w)); const Ex=EVf(wx);
    setTimeout(()=>{},0);
    // sync-ish: wait via a small loop
    const p=new Promise(r=>setTimeout(r,2200));
    p.then(()=>{ chk(`closed on ${t}, it reopens on the training day`, Ex('S.day')===live.code, 'reopened on '+Ex('S.day')); });
  });
  await sleep(2500);

  // ---- 2. closed on a finished session, reopened ---------------------------------
  EV(`S.day=${JSON.stringify(live.code)}; S.week=${live.week}; render();
      (function(){ var dd=dayObj(); dd.exercises.forEach(function(ex,i){ var st=exState(i,ex); st.sets.forEach(function(s2){ s2.st='hit'; s2.reps=5; s2.rir=2; }); }); save(); })();`);
  await EV('saveSessionLog(true)'); await sleep(80);
  const after=EV('(function(){ var n=nextSession(); return n? {code:n.code, week:n.week} : null; })()');
  chk('(fixture) the session banked and the pointer has a next session', after && after.code && after.code!==live.code, JSON.stringify(after));
  EV(`S.day=${JSON.stringify(live.code)}; S.week=${live.week}; save();`);   // close it while reviewing the finished day
  let w3=bootWith(dump(w)); await sleep(2200); let E3=EVf(w3);
  chk('closed while reviewing a finished session, it reopens on the NEXT session',
      E3('S.day')===after.code, 'reopened on '+E3('S.day')+' (finished was '+live.code+')');

  // ---- 3. a session in progress is never abandoned ---------------------------------
  E3(`(function(){ var dd=dayObj(); var st=exState(0, dd.exercises[0]); st.sets[0].st='hit'; st.sets[0].reps=5; st.sets[0].rir=2; S.focus=2; save(); })()`);
  const midDay=E3('S.day'), midFocus=E3('S.focus');
  let w4=bootWith(dump(w3)); await sleep(2200); let E4=EVf(w4);
  chk('a reboot mid-session lands right back on that session', E4('S.day')===midDay && E4('S.week')===E3('S.week'), 'moved to '+E4('S.day'));
  chk('and does not move the focus on a day it did not change', E4('S.focus')===midFocus, 'focus '+E4('S.focus')+' was '+midFocus);
  // and by resume, after a long time away
  E4('landHiddenAt=Date.now()-45*60*1000;');
  setHidden(w4,false); await sleep(50);
  chk('a 45-minute absence mid-session still lands on that session', E4('S.day')===midDay && E4('S.focus')===midFocus, 'moved to '+E4('S.day')+' focus '+E4('S.focus'));

  // ---- 4. resume from a tab: short glance stays, long absence lands -----------------
  E4('S.day="RATE"; save(); render();');
  setHidden(w4,true); await sleep(20);
  E4('landHiddenAt=Date.now()-5*60*1000;');                 // five minutes in another app
  setHidden(w4,false); await sleep(50);
  chk('five minutes in another app leaves the Rate tab where it was', E4('S.day')==='RATE', 'moved to '+E4('S.day'));
  setHidden(w4,true); await sleep(20);
  E4('landHiddenAt=Date.now()-45*60*1000;');                // three quarters of an hour
  setHidden(w4,false); await sleep(80);
  chk('forty-five minutes away brings the card back to the training day', E4('S.day')===midDay, 'still on '+E4('S.day'));

  // ---- 5. the block is spent: a tab still lands somewhere sane ----------------------
  // the block's clock runs from its earliest log, so plant one ten weeks back
  E4(`(function(){ var d=new Date(); d.setDate(d.getDate()-70); var iso=d.toISOString().slice(0,10);
     localStorage.setItem('nsc:'+curLOGP()+iso+'-'+PLAN.days[0].code+'-W1B'+cyc(), JSON.stringify({date:iso,time:'09:00',day:PLAN.days[0].code,week:1,report:'SESSION REPORT'}));
     S.day="CAL"; save(); })()`);
  await E4('refreshLogs()'); await sleep(60);
  chk('(fixture) with the block spent there is no next session', E4('nextSession()===null'), 'nextSession still returns one, timeWeek='+E4('timeWeek()'));
  let w5=bootWith(dump(w4)); await sleep(2200); let E5=EVf(w5);
  chk('with the block spent, a tab still reopens on a training day rather than a tab',
      E5('PLAN.days.some(function(d){ return d.code===S.day; })'), 'reopened on '+E5('S.day'));

  chk('no runtime errors across five boots', errs.length===0, errs.slice(0,3).join(' | '));
  console.log(`\nproblems: ${bad}`);
  process.exit(bad? 1:0);
},100);
