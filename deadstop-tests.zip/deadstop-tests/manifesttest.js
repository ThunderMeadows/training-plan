// Chrome will not offer to install an app whose page does not link a manifest. This shipped
// missing for the entire life of the card: the file was there, correct, and unreferenced.
const fs=require('fs'); const path=require('path');
const f=process.argv[2], L=process.argv[3]||f;
const src=fs.readFileSync(f,'utf8');
const dir=path.dirname(f);
let bad=0; const chk=(l,ok,d)=>{ if(!ok) bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&d?'  <-- '+d:''}`); };
console.log(`\n--- ${L}: installable on Android ---`);
const m=/<link[^>]+rel=["']manifest["'][^>]*>/i.exec(src);
chk('page links a manifest', !!m, 'Chrome will never offer Install');
let href=null;
if(m){ const h=/href=["']([^"']+)["']/i.exec(m[0]); href=h&&h[1]; chk('link has an href', !!href); }
if(href){
  const p=path.join(dir, href);
  chk('the manifest it points at exists', fs.existsSync(p), href+' not found beside the page');
  if(fs.existsSync(p)){
    let j=null; try{ j=JSON.parse(fs.readFileSync(p,'utf8')); }catch(e){}
    chk('manifest is valid JSON', !!j);
    if(j){
      chk('has a name', !!(j.name||j.short_name));
      chk('has a start_url', !!j.start_url);
      chk('display is standalone-ish', ['standalone','fullscreen','minimal-ui'].indexOf(j.display)>-1, j.display);
      const icons=j.icons||[];
      const has=(sz)=>icons.some(i=>String(i.sizes||'').split(/\s+/).indexOf(sz)>-1 && /png/i.test(i.type||''));
      chk('has a 192px png icon', has('192x192'));
      chk('has a 512px png icon', has('512x512'), 'Chrome requires one for install');
      chk('has a maskable icon', icons.some(i=>/maskable/.test(i.purpose||'')));
      icons.forEach(i=>{ if(i.src && !/^data:/.test(i.src) && !fs.existsSync(path.join(dir,i.src)))
        { console.log('  FAIL  icon missing from deploy: '+i.src); bad++; } });
    }
  }
}
chk('service worker is registered', /serviceWorker\.register/.test(src));
const sw=path.join(dir,'sw.js');
if(fs.existsSync(sw)) chk('service worker handles fetch', /addEventListener\(\s*['"]fetch['"]/.test(fs.readFileSync(sw,'utf8')),
  'Chrome requires a fetch handler to consider the app installable');
chk('the install prompt is captured', /beforeinstallprompt/.test(src));

// --- shared-link identity + home-screen icon (2026-09-02) ---
// A shared card used to render as a bare URL: no title, no image, no description. The card
// has a share sheet, so the link has to arrive looking like something.
const head=src.slice(0, src.indexOf('</head>')>0? src.indexOf('</head>') : 8000);
const canon=(src.match(/const CANON_URL = '([^']+)'/)||[])[1]||null;
chk('the page describes itself', /<meta name="description" content="[^"]{40,}"/.test(head), 'no description tag');
chk('a shared link carries a title', /og:title" content="Deadstop/.test(head), 'no og:title');
chk('and a preview image', /og:image" content="https:[^"]+icon-512\.png"/.test(head), 'no og:image');
chk('and points at the canonical home', (head.match(/og:url" content="([^"]+)"/)||[])[1]===canon, 'og:url != CANON_URL');
chk('canonical link matches too', (head.match(/rel="canonical" href="([^"]+)"/)||[])[1]===canon, 'canonical mismatch');
chk('the home-screen icon is a PNG, not an SVG data URI',
    /apple-touch-icon" sizes="180x180" href="apple-touch-icon\.png"/.test(head)
      && !/apple-touch-icon" href="data:image\/svg/.test(head),
    'an SVG data URI is overriding the real PNG');
if(href && fs.existsSync(path.join(dir,href))){
  const j2=JSON.parse(fs.readFileSync(path.join(dir,href),'utf8'));
  chk('the manifest describes the app', !!(j2.description && j2.description.length>20), 'no manifest description');
  chk('manifest declares language and categories', j2.lang==='en' && Array.isArray(j2.categories) && j2.categories.length>0, JSON.stringify({lang:j2.lang,cat:j2.categories}));
}
console.log('  problems:', bad);
process.exit(bad?1:0);
