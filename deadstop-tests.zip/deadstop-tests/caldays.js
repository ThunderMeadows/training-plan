// THE CALENDAR SHOWS WHAT WAS TRAINED, AND THE SPLASH IS LAID OUT (2026-09-04, both field-caught
// in one message, along with a third he reported that could not be reproduced).
//
// 1. CALENDAR. `calKeyDate` sliced `LOGP.length` - 12 characters for 'nova-sc-log:'. The Training
//    Card's personal logs live under TLOGP ('tc-log:', 7). Chopping 12 off 7 ate five characters
//    of the date, the split gave 4 parts instead of 5, every key returned null, and the month drew
//    blank. Silently wrong for every Training Card athlete since the two cards were split apart.
//    Nothing caught it because `caltest` builds its fixtures through the card's own writers and
//    checks the projection - it never asserted that a REAL banked key parses back out.
// 2. SPLASH. A CSS line shipped in c195 forced .bs-word and .bs-line from absolute to relative,
//    which put them into #bootSplash's flex row beside the mark and pushed the logo half off the
//    left edge. Mine, and visible on the first boot after the deploy.
const { JSDOM } = require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const dom=new JSDOM(fs.readFileSync(f,'utf8'),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/',
  beforeParse(w){
    w.AudioContext=function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
    w.alert=()=>{};
  }});
const w=dom.window,D=w.document,EV=e=>w.eval(e);
let bad=0; const chk=(l,ok,d)=>{ if(!ok) bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&d?'  <-- '+d:''}`); };

setTimeout(async()=>{
  console.log(`\n--- ${L}: a banked day shows on the calendar, and the splash is laid out ---`);
  EV('try{TOUR.live=false;}catch(e){} S.tour={done:true}; if(typeof ONB!=="undefined"){ONB().done=true;} S.discAck={v:DISC_V,d:localDate()}; storageOK=true; S.maxes={squat:327,bench:225,dead:405,ohp:145,row:170,pull:225}; save();');

  // --- 1. a REAL key, made by the card's own writer, parses back out ---------------
  EV("S.day=PLAN.days[0].code; render();");
  EV(`(function(){ var d=dayObj(); d.exercises.forEach(function(ex,i){ var st=exState(i,ex);
        st.sets.forEach(function(s){ s.st='hit'; s.t=Date.now()-60000; }); }); save(); })()`);
  await EV(`(async function(){ try{ await bankSession(); }catch(e){ try{ await saveSessionLog(); }catch(e2){} } })()`).catch(()=>{});
  const keys=JSON.parse(EV('JSON.stringify(logKeys)'));
  chk('(fixture) banking wrote a log key', keys.length>0, 'nothing banked');
  chk('the key the card actually writes parses back into a date',
      EV('JSON.stringify(calKeyDate(logKeys[0]))')!=='null',
      'calKeyDate('+JSON.stringify(keys[0])+') -> null, so the calendar has nothing to draw');
  chk('and it parses to TODAY, not a mangled date',
      EV('(calKeyDate(logKeys[0])||{}).d')===EV('shiftDate()'),
      'got '+EV('JSON.stringify((calKeyDate(logKeys[0])||{}).d)')+', wanted '+EV('shiftDate()'));
  chk('the calendar index contains that day', EV('Object.keys(calIndex()).indexOf(shiftDate())>-1'),
      'calIndex keys: '+EV('JSON.stringify(Object.keys(calIndex()))'));
  chk('and the code trained is on it', JSON.stringify(EV('JSON.stringify((calIndex()[shiftDate()]||{}).days||[])'))!==JSON.stringify('[]'),
      EV('JSON.stringify(calIndex()[shiftDate()]||null)'));

  // every namespace the card can write under, not just the one this fixture happened to use
  const forms={'tc-log:2026-09-04-A-W1B1':'2026-09-04','nova-sc-log:2026-09-04-B-W2B1':'2026-09-04',
               'nova-sc-log:athlete7:2026-09-04-C-W1B2':'2026-09-04'};
  // JSON.stringify(undefined) comes back as the literal `undefined`, which JSON.parse throws on -
  // so on a BROKEN build this check killed the harness before the splash checks ever ran, and
  // the splash half looked like it passed. Coerce to null inside the page instead.
  let mis=[];
  Object.keys(forms).forEach(k=>{ const got=EV('JSON.stringify(((calKeyDate('+JSON.stringify(k)+')||{}).d)||null)');
    if(JSON.parse(got)!==forms[k]) mis.push(k+' -> '+got); });
  chk('every log namespace the card writes under parses', mis.length===0, mis.join(' | '));

  // the two that survive the old slice by luck must keep working
  chk('sessionLogged still finds the banked session', EV('sessionLogged(S.week, PLAN.days[0].code)')===true);
  chk('cycleHasLogs still sees the block has logs', EV('cycleHasLogs()')===true);

  // --- 2. the splash: the mark is the only thing in the flex row ------------------
  // NOT via getComputedStyle: jsdom ignores specificity for these, reporting `absolute` on the
  // BROKEN build too, so a computed-style check here can never fail and is decorative. The
  // cascade is what a real browser acts on, so the cascade is what gets read. .bs-word and
  // .bs-line are absolute by design; any rule that makes them relative drops them into
  // #bootSplash's flex row beside the mark and shoves the logo off the left edge.
  const posRules=JSON.parse(EV(`(function(){ var out=[];
    for(const sh of document.styleSheets){ let rs=[]; try{ rs=[...sh.cssRules]; }catch(e){}
      rs.forEach(function(r){ if(r.selectorText && r.style && r.style.position)
        out.push({sel:r.selectorText, pos:r.style.position}); }); }
    return JSON.stringify(out); })()`));
  chk('(fixture) the splash rules are readable from the sheet',
      posRules.some(r=>/bs-word|bs-line|bs-wrap/.test(r.sel)), 'no bs-* position rules found at all');
  const inflow=posRules.filter(r=>/\.bs-word|\.bs-line/.test(r.sel) && r.pos!=='absolute');
  chk('nothing pulls the splash word or line into the flex row beside the logo',
      inflow.length===0,
      inflow.map(r=>r.sel+' sets position:'+r.pos).join(' | '));
  const wrapRel=posRules.some(r=>/\.bs-wrap/.test(r.sel) && r.pos==='relative');
  chk('the mark still gets its own stacking context above the seasonal art', wrapRel,
      'no rule gives .bs-wrap position:relative - holiday art would draw over the logo');
  D.querySelectorAll('#bootSplash').forEach(x=>x.remove());

  console.log('  problems:', bad); process.exit(bad?1:0);
},1500);
