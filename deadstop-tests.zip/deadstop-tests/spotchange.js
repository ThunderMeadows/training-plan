// The reported bug: pick a tint, then pick Amber. The bear must change ON THE SPOT.
// Asserts the inline filter is always an explicit value - never removed - so the
// compositor gets a value-to-value change it will actually repaint.
const { JSDOM } = require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3];
const dom=new JSDOM(fs.readFileSync(f,'utf8'),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://thundermeadows.github.io/'});
const w=dom.window,D=w.document,EV=e=>w.eval(e);
w.AudioContext=w.AudioContext||function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
const click=el=>el.dispatchEvent(new w.MouseEvent('click',{bubbles:true,cancelable:true,view:w}));
setTimeout(()=>{
  console.log(`\n--- ${L}: does the bear change on the spot? ---`);
  EV('try{TOUR.live=false;}catch(e){} S.tour={done:true}; render();');
  EV('try{ SET_OPEN=true; settingsSync(); }catch(e){}');
  if(!D.querySelector('[data-gbflav]')) EV("S.day='MAX'; render();");
  const host=D.getElementById('gbHost');
  const order=['cherry','amber','grape','amber','clear','amber'];
  let bad=0;
  for(const id of order){
    click(D.querySelector('[data-gbflav="'+id+'"]'));
    const inline=host.style.filter, name=EV('gbFlavour().n'), tint=EV('gbFlavour().f');
    const assigned = inline!=='';                       // never a removal
    const tintOK = tint==='none' ? !/hue-rotate|saturate\(0/.test(inline) : inline.indexOf(tint)===0;
    const shadowOK = /drop-shadow/.test(inline);
    if(!assigned||!tintOK||!shadowOK) bad++;
    console.log(`  tap ${name.padEnd(15)} inline="${inline||'(REMOVED)'}"`);
    console.log(`      assigned=${assigned?'yes':'NO'}  tint=${tintOK?'ok':'STALE'}  shadow=${shadowOK?'ok':'LOST'}`);
  }
  console.log('  problems:', bad);
  process.exit(bad?1:0);
},1500);
