// BUILD / CACHE SYNC (2026-09-03).
// His standing rule: every build bumps BUILD and the service worker cache. If BUILD moves and
// the cache name does not, the app is published but nobody's phone fetches it - the old copy
// keeps serving from cache and the deploy silently does nothing. That failure is invisible from
// the outside, which is exactly the kind CI should be catching rather than a person remembering.
//
// This reads the sw.js sitting BESIDE the card, so it only has an opinion about a real deploy
// layout. Run against the lite master - which has no siblings - it says so and passes, the same
// way it would for any card that does not ship a service worker.
const fs=require('fs'), path=require('path');
const f=process.argv[2], L=process.argv[3]||f;
let bad=0; const chk=(l,ok,d)=>{ if(!ok) bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&d?'  <-- '+d:''}`); };

console.log(`\n--- ${L}: the published build is the one phones will actually fetch ---`);

const html=fs.readFileSync(f,'utf8');
const bm=html.match(/const BUILD = '([^']+)'/);
chk('the card declares a BUILD', !!bm, 'no BUILD constant found');

const swPath=path.join(path.dirname(path.resolve(f)),'sw.js');
if(!fs.existsSync(swPath)){
  console.log('  (no sw.js beside this card - nothing to check)');
  console.log('  problems:', bad); process.exit(bad?1:0);
}
const sw=fs.readFileSync(swPath,'utf8');
const cm=sw.match(/CACHE\s*=\s*'([^']+)'/);
chk('the service worker names a cache', !!cm, 'no CACHE constant in sw.js');

if(bm && cm){
  const build=bm[1], cache=cm[1];
  chk('the cache name carries this build, so the update actually reaches a phone',
      cache.indexOf(build)>-1,
      `BUILD is ${build} but the cache is ${cache} - phones would keep serving the old copy`);
}

// The manifest and the page should agree about where this thing lives, or an installed
// shortcut and a fresh visit end up on different copies.
const mfPath=path.join(path.dirname(path.resolve(f)),'manifest.json');
if(fs.existsSync(mfPath)){
  let mf=null; try{ mf=JSON.parse(fs.readFileSync(mfPath,'utf8')); }catch(e){}
  chk('the manifest parses', !!mf, 'manifest.json is not valid JSON');
  if(mf) chk('the manifest names a start URL and a scope', !!(mf.start_url && mf.scope),
      'start_url='+mf.start_url+' scope='+mf.scope);
}

console.log('  problems:', bad); process.exit(bad?1:0);
