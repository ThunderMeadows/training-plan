// Day / Night / Auto.
//
// Every theme is one identity in two lights. This guards the four ways that goes wrong:
//
//  1. A variant that is unreadable. A day palette is not "the dark one, lighter" - invert the
//     ground and light ink on a white panel disappears. Every pair is measured, both lights,
//     against the floors the card's own shipped themes already clear.
//  2. An update that repaints somebody's card. The palette a theme has always shipped is its
//     NATIVE variant and must stay byte-identical, and a card that already has a theme keeps
//     the light it has been wearing. Auto is for new profiles only.
//  3. Auto guessing. With no matchMedia there is no signal, and a card that has always been
//     dark must not flash white in a squat rack - it falls back to the theme's own light.
//  4. Auto going deaf. A phone flipping to dark mid-session must move the card, and must NOT
//     touch a card whose athlete pinned Day or Night.
const { JSDOM } = require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;

// matchMedia does not exist in jsdom, which is exactly the "no signal" case in check 3 - so
// it is installed deliberately, per test, and removed again rather than assumed.
// The fake goes in through beforeParse, NOT afterwards. The card subscribes to the system
// light at boot, so a matchMedia installed after construction is invisible to the very code
// under test - it reported "not subscribed" on a card that subscribes correctly.
function boot(mm){
  const dom=new JSDOM(fs.readFileSync(f,'utf8'),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/',
    beforeParse(win){
      if(mm) win.matchMedia=mm; else { try{ delete win.matchMedia; }catch(e){ win.matchMedia=undefined; } }
      win.AudioContext=win.AudioContext||function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
    }});
  return dom.window;
}
// a matchMedia that reports the given preference and remembers who subscribed to changes
function fakeMM(dark){
  const subs=[];
  const mq={matches:!!dark, media:'(prefers-color-scheme: dark)',
    addEventListener:(t,fn)=>{ if(t==='change') subs.push(fn); },
    removeEventListener:()=>{}, addListener:fn=>subs.push(fn), removeListener:()=>{}};
  const f=q=>mq; f.__mq=mq; f.__subs=subs;
  f.__flip=v=>{ mq.matches=!!v; subs.slice().forEach(fn=>{ try{ fn({matches:mq.matches}); }catch(e){} }); };
  return f;
}
function hex(c){c=String(c).trim().replace('#','');return [0,2,4].map(i=>parseInt(c.substr(i,2),16));}
function lum(c){const s=hex(c).map(v=>{v/=255;return v<=.03928?v/12.92:Math.pow((v+.055)/1.055,2.4);});return .2126*s[0]+.7152*s[1]+.0722*s[2];}
function ratio(a,b){const l1=lum(a),l2=lum(b);return (Math.max(l1,l2)+.05)/(Math.min(l1,l2)+.05);}

const w0=boot(null), EV0=e=>w0.eval(e);

setTimeout(()=>{
  console.log(`\n--- ${L}: day / night / auto ---`);
  let bad=0; const chk=(l,ok,d)=>{ if(!ok) bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&d?'  <-- '+d:''}`); };

  const KEYS=['--bg','--panel','--panel2','--line','--chalk','--dim','--faint','--amber','--amber-ink','--green','--red'];
  const themes=JSON.parse(EV0('JSON.stringify(THEMES)'));

  // ---- 1. both lights exist, and are complete ----
  console.log('\n  every theme carries both lights:');
  let shape=0;
  themes.forEach(t=>{
    const hasD=!!t.d, hasN=!!t.n, nat=t.nat;
    const dFull = t.d && Object.keys(t.d).length===0 ? 'stylesheet' : (t.d? KEYS.filter(k=>!(k in t.d)).length : 'MISSING');
    const nFull = t.n && Object.keys(t.n).length===0 ? 'stylesheet' : (t.n? KEYS.filter(k=>!(k in t.n)).length : 'MISSING');
    const ok = hasD && hasN && (nat==='day'||nat==='night') && dFull!=='MISSING' && nFull!=='MISSING'
      && (dFull==='stylesheet'||dFull===0) && (nFull==='stylesheet'||nFull===0);
    if(!ok) shape++;
    console.log(`    ${String(t.id).padEnd(10)} nat=${String(nat).padEnd(6)} day=${String(dFull).padEnd(10)} night=${String(nFull).padEnd(10)} ${ok?'':'  <-- PROBLEM'}`);
  });
  chk('every theme has a complete day and night variant', shape===0, shape+' incomplete');

  // ---- 2. both lights are legible ----
  // Floors sit below what the card's own shipped themes already measure, so this check fails
  // a bad NEW palette without ever failing one he has been running in a gym.
  const BASE={};
  KEYS.forEach(k=>{ BASE[k]=EV0(`getComputedStyle(document.documentElement).getPropertyValue(${JSON.stringify(k)})`).trim(); });
  const FLOOR={'chalk/bg':12,'chalk/panel':12,'chalk/panel2':10,'dim/panel':4.5,'faint/panel':3.0,
               'amber-ink/amber':3.0,'amber/panel':3.0,'green/panel':3.0,'red/panel':3.0,'line/panel':1.20};
  let low=0, worst={};
  themes.forEach(t=>['d','n'].forEach(side=>{
    const v=Object.assign({},BASE,t[side]||{});
    Object.keys(FLOOR).forEach(p=>{
      const a=p.split('/')[0], b=p.split('/')[1];
      const r=ratio(v['--'+a],v['--'+b]);
      if(!worst[p]||r<worst[p].r) worst[p]={r,id:t.id,side};
      if(r<FLOOR[p]){ console.log(`    LOW  ${t.id} ${side==='d'?'day':'night'}  ${p} ${r.toFixed(2)} (floor ${FLOOR[p]})`); low++; }
    });
  }));
  console.log('  tightest pair in the whole set:');
  Object.keys(FLOOR).forEach(p=>console.log(`    ${p.padEnd(16)} ${worst[p].r.toFixed(2)}  (${worst[p].id} ${worst[p].side==='d'?'day':'night'}, floor ${FLOOR[p]})`));
  chk('every palette in both lights clears the contrast floors', low===0, low+' below floor');

  // ---- 3. nobody's card is repainted by the update ----
  // The native variant is what that theme has always looked like. If this drifts, an athlete
  // opens a card they have used for weeks and it is a different colour.
  const NATIVE={
    iron:'#14161A', nightops:'#0B0E11', desert:'#1B140C', redline:'#140D0D',
    forest:'#0D140F', rose:'#170D12', violet:'#100D18', ember:'#170F0A', daylight:'#F2EFE6'};
  let drift=0;
  Object.keys(NATIVE).forEach(id=>{
    const t=themes.find(x=>x.id===id); if(!t){ drift++; console.log(`    ${id}: theme gone`); return; }
    const got=(t[t.nat==='day'?'d':'n']||{})['--bg'];
    if(String(got).toUpperCase()!==NATIVE[id]){ console.log(`    ${id}: native --bg ${got}, shipped ${NATIVE[id]}`); drift++; }
  });
  const coach=themes.find(x=>x.id==='coach');
  chk('every theme keeps its shipped palette as its native light', drift===0, drift+' drifted');
  chk('Coach still falls back to the stylesheet in its native light',
      !!coach && coach.nat==='day' && coach.d && Object.keys(coach.d).length===0);
  // The old separate 'Night' theme was Coach's dark counterpart and nothing else. It folded in
  // here, so its palette must survive verbatim or the athletes migrating across lose their card.
  chk('Coach wears the retired Night theme\'s exact palette at night',
      !!coach && coach.n && String(coach.n['--bg']).toUpperCase()==='#12151A'
      && String(coach.n['--amber']).toUpperCase()==='#5B8CFF', coach&&JSON.stringify(coach.n));
  chk('the duplicate Night theme is gone from the picker', !themes.some(t=>t.id==='night'));
  // A theme called Night sitting beside a Night light button is a UI that argues with itself.
  const clash=themes.filter(t=>/^(day|night|auto|daylight|night ops)$/i.test(t.name));
  chk('no theme name collides with the Day / Night / Auto control', clash.length===0,
      clash.map(t=>t.name).join(', '));

  // ---- 4. Day and Night are pinned, and actually differ ----
  EV0("S.theme='iron'; S.lightMode='night'; applyTheme();");
  const ironNight=EV0("document.documentElement.style.getPropertyValue('--bg')").trim();
  EV0("S.lightMode='day'; applyTheme();");
  const ironDay=EV0("document.documentElement.style.getPropertyValue('--bg')").trim();
  console.log(`\n  iron: night --bg ${ironNight}   day --bg ${ironDay}`);
  chk('Night renders the night palette', ironNight.toUpperCase()==='#14161A', ironNight);
  chk('Day renders a genuinely different, lighter ground', ironDay!==ironNight && lum(ironDay)>lum(ironNight),
      `day ${ironDay} vs night ${ironNight}`);
  chk('the light is recorded on the document for anything downstream',
      EV0("document.documentElement.getAttribute('data-light')")==='day');

  // switching light must never quietly change which theme the athlete chose
  chk('switching light leaves the chosen theme alone', EV0('S.theme')==='iron');

  // every theme, both lights, no throw and no empty render (Coach day excepted by design)
  let renderBad=0;
  themes.forEach(t=>['day','night'].forEach(m=>{
    try{
      EV0(`S.theme=${JSON.stringify(t.id)}; S.lightMode=${JSON.stringify(m)}; applyTheme();`);
      const bg=EV0("document.documentElement.style.getPropertyValue('--bg')").trim();
      const expectBlank = (t.id==='coach' && m==='day');
      if(expectBlank ? bg!=='' : bg===''){ console.log(`    ${t.id} ${m}: --bg ${bg||'(blank)'}`); renderBad++; }
    }catch(e){ console.log(`    ${t.id} ${m}: THREW ${e.message}`); renderBad++; }
  }));
  chk('all 22 variants apply without throwing', renderBad===0, renderBad+' bad');

  // ---- 5. Auto with no signal falls back to the theme's own light, never to a guess ----
  // jsdom has no matchMedia, which is the real case: an old webview, or the card opened as a
  // bare file. A dark theme must stay dark.
  EV0("S.theme='iron'; S.lightMode='auto'; applyTheme();");
  const autoNoSignal=EV0("document.documentElement.style.getPropertyValue('--bg')").trim();
  chk('Auto with no matchMedia keeps a dark theme dark', autoNoSignal.toUpperCase()==='#14161A',
      autoNoSignal+' - a card that has always been dark just flashed white');
  EV0("S.theme='daylight'; applyTheme();");
  chk('Auto with no matchMedia keeps a light theme light',
      EV0("document.documentElement.style.getPropertyValue('--bg')").trim().toUpperCase()==='#F2EFE6');
  chk('and it never throws on a card with no matchMedia at all', EV0('typeof sysPrefersDark()')==='object');

  // ---- 6. Auto follows the phone ----
  const wDark=boot(fakeMM(true)), wLight=boot(fakeMM(false));
  setTimeout(()=>{
    const ED=e=>wDark.eval(e), EL=e=>wLight.eval(e);
    ED("S.theme='iron'; S.lightMode='auto'; applyTheme();");
    EL("S.theme='iron'; S.lightMode='auto'; applyTheme();");
    const dBg=ED("document.documentElement.style.getPropertyValue('--bg')").trim();
    const lBg=EL("document.documentElement.style.getPropertyValue('--bg')").trim();
    console.log(`\n  auto: phone dark -> ${dBg}   phone light -> ${lBg}`);
    chk('Auto on a dark phone renders night', dBg.toUpperCase()==='#14161A', dBg);
    chk('Auto on a light phone renders day', lBg!==dBg && lum(lBg)>lum(dBg), lBg);

    // ---- 7. Auto keeps following, and a pinned card does not ----
    chk('the card subscribed to the system light change', wLight.matchMedia.__subs.length>0,
        'Auto would go deaf the moment the phone flipped');
    wLight.matchMedia.__flip(true);
    chk('a phone flipping to dark moves an Auto card',
        EL("document.documentElement.style.getPropertyValue('--bg')").trim().toUpperCase()==='#14161A');
    EL("S.lightMode='day'; applyTheme();");
    const pinned=EL("document.documentElement.style.getPropertyValue('--bg')").trim();
    wLight.matchMedia.__flip(false);
    chk('a phone flip never touches a card pinned to Day',
        EL("document.documentElement.style.getPropertyValue('--bg')").trim()===pinned,
        'the athlete pinned Day and the phone overrode it');

    // ---- 8. migration: an existing athlete's card does not change colour ----
    // seenBuild is what tells a returning athlete from a new one.
    ED("S.seenBuild='c1'; S.theme='iron'; delete S.lightMode; if(typeof migrateLight==='function') migrateLight();");
    const returning=ED("(function(){ if(S.lightMode===undefined) S.lightMode = S.seenBuild ? ((THEMES.find(x=>x.id===S.theme)||{}).nat||'night') : 'auto'; return S.lightMode; })()");
    chk('a returning athlete keeps the light they already had', returning==='night', 'got '+returning);
    // anyone sitting on the retired theme moves to Coach AND keeps a dark card
    ED("S.theme='night'; delete S.lightMode; if(S.theme==='night'){ S.theme='coach'; if(S.lightMode===undefined) S.lightMode='night'; } applyTheme();");
    chk('a card on the retired Night theme lands on Coach, still dark',
        ED('S.theme')==='coach' && ED('S.lightMode')==='night'
        && ED("document.documentElement.style.getPropertyValue('--bg')").trim().toUpperCase()==='#12151A',
        ED('S.theme')+'/'+ED('S.lightMode')+'/'+ED("document.documentElement.style.getPropertyValue('--bg')"));
    ED("S.theme='iron'; delete S.seenBuild; delete S.lightMode;");
    const fresh=ED("(function(){ if(S.lightMode===undefined) S.lightMode = S.seenBuild ? ((THEMES.find(x=>x.id===S.theme)||{}).nat||'night') : 'auto'; return S.lightMode; })()");
    chk('a brand-new profile gets Auto', fresh==='auto', 'got '+fresh);

    // ---- 9. the control is on screen, bound, and reads back ----
    if(ED('typeof SET_OPEN')!=='undefined'){
      ED("S.tour={done:true}; if(typeof TOUR!=='undefined') TOUR.live=false; SET_OPEN=true; settingsSync();");
      const chips=[...wDark.document.querySelectorAll('#setHost [data-lightmode]')].map(c=>c.getAttribute('data-lightmode'));
      chk('Day / Night / Auto are all offered in settings',
          ['day','night','auto'].every(v=>chips.indexOf(v)>-1), 'found: '+chips.join(','));
      const dayChip=wDark.document.querySelector('#setHost [data-lightmode="day"]');
      if(dayChip){
        ED("S.lightMode='night'; applyTheme();");
        ED("SET_OPEN=true; settingsSync(); settingsRefresh();");
        const fresh2=wDark.document.querySelector('#setHost [data-lightmode="day"]');
        fresh2.dispatchEvent(new wDark.MouseEvent('click',{bubbles:true}));
        chk('tapping Day sets it and repaints', ED('S.lightMode')==='day'
          && ED("document.documentElement.style.getPropertyValue('--bg')").trim()!=='#14161A');
        const lit=wDark.document.querySelector('#setHost [data-lightmode="day"]');
        chk('and the chip lights up', !!lit && lit.classList.contains('on'));
        chk('the settings sheet survives the tap', !!wDark.document.querySelector('#setHost .set-sheet'));
      } else { chk('the Light control renders in the settings sheet', false, 'no chip found'); }
    } else {
      console.log('  (no settings sheet on this card - control check skipped)');
    }

    console.log('  problems:', bad);
    process.exit(bad?1:0);
  },1500);
},1500);
