// Pick a flavour, then RELOAD the app with the same storage and see what the bear comes back as.
const { JSDOM } = require('jsdom'); const fs=require('fs');
const file=process.argv[2], L=process.argv[3];
const html=fs.readFileSync(file,'utf8');
const AC=function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};

function boot(seed){
  return new Promise(res=>{
    const dom=new JSDOM(html,{runScripts:'dangerously',pretendToBeVisual:true,url:'https://thundermeadows.github.io/',
      beforeParse(w){ w.AudioContext=AC;
        if(seed) for(const [k,v] of Object.entries(seed)) { try{ w.localStorage.setItem(k,v); }catch(e){} } }});
    setTimeout(()=>res(dom),1600);
  });
}
const dump=w=>{const o={};for(let i=0;i<w.localStorage.length;i++){const k=w.localStorage.key(i);o[k]=w.localStorage.getItem(k);}return o;};

const PICK=process.argv[4]||'grape';
(async()=>{
  console.log(`\n--- ${L}: does '${PICK}' survive a reload? ---`);
  let dom=await boot(null); let w=dom.window, EV=e=>w.eval(e);
  console.log('  ST_MODE:', EV('typeof ST_MODE!=="undefined"?ST_MODE:"?"'), '| storage keys at boot:', w.localStorage.length);
  EV("try{TOUR.live=false;}catch(e){} S.tour={done:true};");
  // drive it the way a finger does: open the gear, real-click the flavour chip
  EV('render();');
  // gear sheet on the Training Card, inline You/MAX screen on the Session Card
  EV('try{ SET_OPEN=true; settingsSync(); }catch(e){}');
  if(!w.document.querySelector('[data-gbflav]')) EV("S.day='MAX'; render();");
  const chip=w.document.querySelector('[data-gbflav="'+PICK+'"]');
  console.log('  surface:', w.document.querySelector('#setHost [data-gbflav]')?'gear sheet':'inline You/MAX');
  console.log('  '+PICK+' chip found:', !!chip);
  chip.dispatchEvent(new w.MouseEvent('click',{bubbles:true,cancelable:true,view:w}));
  console.log('  in-memory S.gbFlav after click:', EV('S.gbFlav'));
  await new Promise(r=>setTimeout(r,400));
  const seed=dump(w);
  console.log('  picked grape, saved. keys now:', Object.keys(seed).length);
  const blob=Object.entries(seed).find(([k,v])=>v&&v.indexOf('gbFlav')>-1);
  console.log('  gbFlav present in stored blob:', !!blob, blob?`(key ${blob[0]})`:'');
  if(blob) console.log('  stored value:', JSON.parse(blob[1]).gbFlav);
  dom.window.close();

  console.log('  ...reloading with that storage...');
  let d2=await boot(seed); let w2=d2.window, EV2=e=>w2.eval(e);
  console.log('  after reload  S.gbFlav:', EV2('S.gbFlav'));
  console.log('  after reload gbFlavour():', EV2('gbFlavour().id'), '/', EV2('gbFlavour().n'));
  // the part that actually matters: what the BEAR looks like, not what S says
  const host=w2.document.getElementById('gbHost');
  const want=EV2('gbFlavour().f');
  const got=host? (host.style.filter||'(none)') : '(no bear)';
  console.log('  bear filter applied :', got);
  console.log('  bear filter expected:', want);
  // the flavour filter now COMPOSES the drop shadow rather than replacing it, so the applied
  // value is the tint plus the shadow - assert the tint is present, not that it stands alone
  // Amber is no longer a removal - it assigns the bare shadow - so every flavour must come
  // back with an explicit inline value, tinted or not
  const ok = host && /drop-shadow/.test(got) && (want==='none' ? !/hue-rotate/.test(got) : got.indexOf(want)===0);
  console.log('  BEAR MATCHES SAVED CHOICE:', !!ok, want==='none'?'(untinted base bear)':'(tint + shadow)');
  console.log('  problems:', ok?0:1);
  process.exit(ok?0:1);
})();
