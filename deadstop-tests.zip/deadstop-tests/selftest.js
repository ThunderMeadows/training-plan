// The self-test must be genuinely safe: read-only apart from its own namespaced key, never
// probing quota, and refusing to run when it could disturb a session.
const { JSDOM } = require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const src=fs.readFileSync(f,'utf8');
const dom=new JSDOM(src,{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/'});
const w=dom.window,D=w.document,EV=e=>w.eval(e);
w.AudioContext=w.AudioContext||function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
setTimeout(async ()=>{
  console.log(`\n--- ${L}: the self-test ---`);
  let bad=0; const chk=(l,ok,d)=>{ if(!ok) bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&d?'  <-- '+d:''}`); };
  EV('try{TOUR.live=false;}catch(e){} try{S.tour={done:true};}catch(e){}');
  for(const fn of ['coachIdle','ONB_ACTIVE','isStartMode']) EV(`if(typeof ${fn}==="function") ${fn}=function(){return false;};`);
  EV('S.maxes={squat:327,bench:225,dead:405,ohp:145,pull:225}; render();');

  // the destructive risk: it must never write anywhere near the athlete's state
  const body=src.slice(src.indexOf('function selfTestRun'), src.indexOf('function selfTestText'));
  chk('writes only to its own key', /stSet\(ST_KEY/.test(body) && !/stSet\(\s*(SKEY|curSKEY)/.test(body),
      'a stray write here would overwrite the athlete history');
  chk('and deletes it again', /stDel\(ST_KEY\)/.test(body));
  chk('never probes quota by filling storage', !/while\s*\(|for\s*\(;;\)/.test(body),
      'writing until failure IS the failure on a full phone');
  chk('every check is wrapped', (body.match(/try\{/g)||[]).length >= 5);

  // it must stand down when running could disturb the session
  const i=EV(`(function(){var d=dayObj();for(var k=0;k<d.exercises.length;k++){if(d.exercises[k].loadNum!=null) return k;}return -1;})()`);
  EV(`(function(){var ex=dayObj().exercises[${i}],st=exState(${i},ex);
      st.sets.forEach(function(s){s.st='pend';delete s.t;});
      st.sets[0].st='hit'; st.sets[0].t=Date.now()-2000; save();})()`);
  chk('stands down during a rest', !!EV('selfTestBusy()'), 'would fire audio into a live countdown');
  EV(`(function(){var st=exState(${i},dayObj().exercises[${i}]); st.sets[0].t=Date.now()-9*60*1000; save();})()`);
  chk('stands down mid-session', !!EV('selfTestBusy()'), 'part-logged session');
  EV(`(function(){var st=exState(${i},dayObj().exercises[${i}]);
      st.sets.forEach(function(s){s.st='pend';delete s.t;}); save();})()`);
  chk('runs when the coast is clear', !EV('selfTestBusy()'));

  // and it must actually produce results without disturbing state
  const before=EV('JSON.stringify(S.data)');
  const rows=await new Promise(res=>{ w.selfTestRun(r=>res(r)); setTimeout(()=>res(null),3000); });
  chk('produces results', !!rows && rows.length>=5, rows? rows.length+' checks' : 'timed out');
  if(rows) rows.forEach(r=>console.log(`         ${r.ok?'ok  ':'FAIL'} ${r.name} - ${r.note}`));
  chk('session untouched by running it', EV('JSON.stringify(S.data)')===before);
  chk('results attach to the problem report', /selfTestText\(\)/.test(src));
  console.log('  problems:', bad);
  process.exit(bad?1:0);
},1500);
