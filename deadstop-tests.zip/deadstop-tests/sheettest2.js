// PRINT SHEET vs THE LIVE CARD (his ask 2026-09-02: "must be identical"). For the current week,
// every printed row is compared to what the card actually prescribes on that day: same
// movements in the same order (swaps and removals honoured), same set count (session-length
// additions and athlete-added sets included), same reps, same load, same rest.
const {JSDOM}=require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const d=new JSDOM(fs.readFileSync(f,'utf8'),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/'});
const w=d.window,EV=e=>w.eval(e);
w.AudioContext=function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
let bad=0; const chk=(l,ok,dd)=>{ if(!ok)bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&dd?'  <-- '+dd:''}`);};
setTimeout(()=>{
  console.log(`\n--- ${L}: the print sheet is the card ---`);
  EV('try{TOUR.live=false;}catch(e){} S.tour={done:true}; if(typeof ONB!=="undefined"){ONB().done=true;} S.discAck={v:DISC_V,d:localDate()}; storageOK=true; S.maxes={squat:327,bench:225,dead:405,ohp:145,row:170,pull:225}; save(); render();');
  // make the live card interesting: a swap, a removal, an athlete-added set, target on
  EV(`(function(){ var codes=PLAN.days.map(function(x){return x.code;}); S.day=codes[0]; S.week=2; save(); render();
    var dd=dayObj();
    var st1=exState(1,dd.exercises[1]); st1.sets.push({st:'pend',reps:null,rir:null,added:true});
    var st2=exState(2,dd.exercises[2]); st2.sub='Cable Fly'; st2.w=45;
    var last=dd.exercises[dd.exercises.length-1]; if(!S.outs[S.day]) S.outs[S.day]=[]; S.outs[S.day].push(last.name);
    save(); render(); })();`);
  // what the card prescribes today, row by row
  const live=JSON.parse(EV(`JSON.stringify((function(){ var dd=dayObj(); var rows=[];
    dd.exercises.forEach(function(ex,i){ if(isOut(ex.name)) return; var st=exState(i,ex);
      rows.push({name:(st.sub||ex.name), sets:st.sets.length, reps:String(exReps(ex)), load:(st.sub? subLoad(ex,st) : curLoad(ex,st)), rest:String(exRest(ex)||'')}); });
    return rows; })())`));
  chk('the live day has rows to compare', live.length>2, live.length);
  // what the sheet prints for this week, this day
  EV('printWeek(S.week);');
  const sheet=JSON.parse(EV(`JSON.stringify((function(){ var host=document.getElementById('printSheet'); var out=[];
    var secs=host.querySelectorAll('section.sh-day'); var sec=null;
    for(var i=0;i<secs.length;i++){ if(secs[i].querySelector('h2').textContent.trim().indexOf(S.day)===0){ sec=secs[i]; break; } }
    if(!sec) return out;
    sec.querySelectorAll('tbody tr').forEach(function(tr){ var td=tr.querySelectorAll('td');
      out.push({name:tr.querySelector('.nm').textContent.trim(), sets:+td[1].textContent, reps:td[2].textContent.trim(), loadTxt:td[4].textContent.trim(), rest:(td[5]&&td[5].className==='c-r')? td[5].textContent.trim():null}); });
    return out; })())`));
  chk('the sheet has a section for today', sheet.length>0, 'no section for '+EV('S.day'));
  chk('same number of movements (removals honoured)', sheet.length===live.length, sheet.length+' printed vs '+live.length+' live');
  const n=Math.min(sheet.length, live.length); let mism=[];
  for(let i=0;i<n;i++){
    const a=live[i], b=sheet[i];
    if(a.name!==b.name) mism.push('#'+(i+1)+' name: live "'+a.name+'" vs sheet "'+b.name+'"');
    if(a.sets!==b.sets) mism.push('#'+(i+1)+' '+a.name+' sets: live '+a.sets+' vs sheet '+b.sets);
    if(a.reps!==b.reps) mism.push('#'+(i+1)+' '+a.name+' reps: live '+a.reps+' vs sheet '+b.reps);
    if(typeof a.load==='number'){ const shown=EV('WV('+a.load+')'); if(String(b.loadTxt).indexOf(String(shown))<0) mism.push('#'+(i+1)+' '+a.name+' load: live '+shown+' vs sheet "'+b.loadTxt+'"'); }
    if(a.rest && b.rest!==null && a.rest!==b.rest) mism.push('#'+(i+1)+' '+a.name+' rest: live '+a.rest+' vs sheet '+b.rest);
  }
  chk('every movement matches by name and order (swaps honoured)', !mism.some(m=>/name:/.test(m)), mism.filter(m=>/name:/.test(m)).slice(0,3).join(' | '));
  chk('every set count matches (target growth + added sets)', !mism.some(m=>/sets:/.test(m)), mism.filter(m=>/sets:/.test(m)).slice(0,3).join(' | '));
  chk('every rep prescription matches', !mism.some(m=>/reps:/.test(m)), mism.filter(m=>/reps:/.test(m)).slice(0,3).join(' | '));
  chk('every load matches', !mism.some(m=>/load:/.test(m)), mism.filter(m=>/load:/.test(m)).slice(0,3).join(' | '));
  chk('the sheet prints rest', sheet.every(r=>r.rest!==null), 'no rest column');
  chk('every rest matches', !mism.some(m=>/rest:/.test(m)), mism.filter(m=>/rest:/.test(m)).slice(0,3).join(' | '));
  const sp=EV('JSON.stringify(dayObj().sessPlan||null)');
  const fin=JSON.parse(sp)&&JSON.parse(sp).fin;
  if(fin) chk('the session-length finisher is on the sheet', EV('document.getElementById("printSheet").textContent').indexOf('finisher')>=0, 'finisher missing');
  EV('var h=document.getElementById("printSheet"); h&&h.remove(); document.body.classList.remove("printing");');
  // ---- 2026-09-03: paper has no engine, so accessories must climb on the sheet ----
  // In the app an accessory goes up from logged sets. On paper there are no logs, and the
  // sheet used to print the same number for five weeks. Future weeks now project the climb.
  try{
    EV('S.week=1;');
    const acc=JSON.parse(EV(`JSON.stringify((function(){ var out=[]; PLAN.days.forEach(function(d){ d.exercises.forEach(function(ex){
        if(!ex.maxKey && !ex.pct && typeof ex.loadNum==='number' && ex.loadNum>0 && !isHoldEx(ex) && !isOut(ex.name)) out.push({n:ex.name, rows:planLoadsRow(ex)}); }); }); return out; })())`));
    const flat=acc.filter(e=>Number(e.rows[4])<=Number(e.rows[0]));
    chk('every loaded accessory climbs by week 5 on the sheet', acc.length>0 && flat.length===0, flat.map(e=>e.n+' '+e.rows.join('/')).slice(0,3).join(' | '));
    const wild=acc.filter(e=>Number(e.rows[4])>Number(e.rows[0])*1.5);
    chk('and never climbs more than the app would (small steps, not leaps)', wild.length===0, wild.map(e=>e.n+' '+e.rows.join('/')).slice(0,2).join(' | '));
    const off=acc.filter(e=>{ const base=EV(`(function(){ var ex=null; PLAN.days.forEach(function(d){ d.exercises.forEach(function(x){ if(x.name===${JSON.stringify(e.n)}) ex=ex||x; }); }); S.week=1; return String(WV(baseLoad(ex))); })()`); return e.rows[0]!==base; });
    chk('the current week still prints exactly what the card prescribes', off.length===0, off.map(e=>e.n+' '+e.rows[0]).slice(0,3).join(' | '));
    chk('the sheet tells a paper athlete the climb rule', /climb in the later weeks/.test(EV('printPlanHTML()')));
  }catch(e){ chk('accessory climb check ran', false, e.message); }
  console.log('  problems: '+bad); process.exit(bad?1:0);
},1700);
