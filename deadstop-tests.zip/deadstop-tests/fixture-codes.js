// SECURITY 2026-09-10 (finding D1 from the second review). This archive used to ship
// access-codes.json: 253 PLAINTEXT codes including the admin code, whose fingerprints matched
// the shipped card exactly. They were real credentials. And the deploy instructions said to put
// this archive at the root of a public repo, in the same commit as the app - which would publish
// the very codes the card keeps as one-way hashes in its source.
//
// The tests never needed the real ones. They need A code the card under test will accept, and
// the card accepts anything whose fingerprint is in ACCESS_CODES. So: invent codes here, compute
// their fingerprints with the card's own salt and normalisation, and write them into the card's
// ACCESS_CODES (and its pool) inside the test window. Same code path, same assertions, no
// secrets in the repo.
//
// If you ever need to test against the real production codes, drop the real access-codes.json
// beside this file locally - loadCodes() prefers it when present - and never commit it. It is
// in .gitignore for that reason.
const fs=require('fs'), path=require('path'), crypto=require('crypto');

const SALT='deadstop-access-v1';                 // must match ACCESS_SALT in the card
const norm=c=>String(c||'').replace(/[^A-Za-z0-9]/g,'').toUpperCase();
const fp=c=>crypto.createHash('sha256').update(SALT+'|'+norm(c)).digest('hex');

// deterministic, obviously-fake codes: same every run, so a failure is reproducible
function mk(tag, i){
  const s=crypto.createHash('sha256').update('deadstop-test-fixture|'+tag+'|'+i).digest('hex').toUpperCase();
  const body=s.replace(/[^0-9A-HJ-NP-Z]/g,'').slice(0,8);   // no I/O/L, like the real format
  return 'TEST-'+body.slice(0,4)+'-'+body.slice(4,8);
}

function synth(){
  const athlete={code:mk('athlete',0)}, coach={code:mk('coach',0)}, admin={code:mk('admin',0)};
  // same SHAPE as production - four dated batches, 200 athlete and 50 coach in total - so the
  // pool-accounting assertions still mean something. None of the values is real.
  const spec=[['2026Q4','2027-03-31',50,13],['2027Q1','2027-06-30',50,13],
              ['2027Q2','2027-09-30',50,12],['2027Q3','2027-12-31',50,12]];
  const batches=spec.map(([id,exp,na,nc],b)=>({ id, exp,
    athlete:Array.from({length:na},(_,i)=>mk('b'+b+'a',i)),
    coach:Array.from({length:nc},(_,i)=>mk('b'+b+'c',i)) }));
  return {athlete, coach, admin, batches, __synthetic:true};
}

// Real file if it happens to be here (local only), otherwise synthetic.
function loadCodes(){
  try{
    const p=path.join(__dirname,'access-codes.json');
    if(fs.existsSync(p)){
      const d=JSON.parse(fs.readFileSync(p,'utf8'));
      if(d && d.athlete && d.coach) return d;
    }
  }catch(e){}
  return synth();
}

// Teach the card in this window to accept the fixture codes. Called after boot, before any
// code is entered. Rewrites ACCESS_CODES with entries in the card's own shape, and rebuilds the
// pool so admin issuing works - the real pool is encrypted under the real admin code and cannot
// be opened with a fixture one.
function installCodes(E, CODES){
  if(!CODES || !CODES.__synthetic) return false;   // real codes: the card already knows them
  const rows=[
    {h:fp(CODES.athlete.code), role:'athlete', days:90, v:1, exp:'2026-12-31'},
    {h:fp(CODES.coach.code),   role:'coach',   days:90, v:1, exp:'2026-12-31'},
    {h:fp(CODES.admin.code),   role:'admin',   days:365, v:1, exp:'2027-09-08'}
  ];
  (CODES.batches||[]).forEach(b=>{
    (b.athlete||[]).forEach(c=>rows.push({h:fp(c), role:'athlete', days:90, v:2, exp:b.exp, p:1, b:b.id}));
    (b.coach||[]).forEach(c=>rows.push({h:fp(c), role:'coach', days:90, v:2, exp:b.exp, p:1, b:b.id}));
  });
  const pool={batches:(CODES.batches||[]).map(b=>({id:b.id, exp:b.exp, athlete:b.athlete.slice(), coach:b.coach.slice()}))};
  // Re-encrypt under the fixture admin code with the card's own scheme: a SHA-256 keystream
  // keyed on 'deadstop-pool-v1|<normalised admin code>', XORed over 32-byte blocks. Overriding
  // poolOpen() instead would have been simpler and wrong - it bypassed the very lock that
  // accesstest asserts on (a wrong key must open nothing, a forged role must stay locked), so
  // eight real security checks went green against a stub. Encrypt, and the real path runs.
  const enc=(obj, adminCode)=>{
    const K=crypto.createHash('sha256').update('deadstop-pool-v1|'+norm(adminCode)).digest('hex');
    const pt=Buffer.from(JSON.stringify(obj),'utf8');
    const out=Buffer.alloc(pt.length);
    for(let i=0;i<pt.length;i+=32){
      const ks=crypto.createHash('sha256').update(K+'|'+(i/32)).digest();
      for(let j=0;j<32 && i+j<pt.length;j++) out[i+j]=pt[i+j]^ks[j];
    }
    return out.toString('hex');
  };
  const r=E('(function(){ try{'
    +'ACCESS_CODES='+JSON.stringify(rows)+';'
    +'ACCESS_POOL_ENC='+JSON.stringify(enc(pool, CODES.admin.code))+';'
    +'return true; }catch(e){ return "ERR "+e.message; } })()');
  return r===true;
}

module.exports={SALT, norm, fp, loadCodes, installCodes, synth};
