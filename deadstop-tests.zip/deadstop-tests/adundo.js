// PER-ITEM ADAPT UNDO (2026-09-03).
//
// Four things now move a max on their own - a layoff cut, a stall reset, the rate mover, and a
// probation step. Undo used to reverse only the most recent PASS, so a change you disagreed with
// became unreachable the moment another landed on top of it. With four writers that happens fast.
//
// The panel had two other faults found at the same time: it only ever drew the batch sharing the
// newest date, so everything older sat in S.adLog unseen; and `prov` / `provok` had no row at all,
// which made every probation step from c184 invisible in the one place that is supposed to say
// what the card did.
//
// Out-of-order undo cannot promise a clean restore, and this pins what it does promise: if
// nothing moved the lift since, the old number goes back exactly; if something did, the DIFFERENCE
// that entry made is removed and the later changes are kept.
const { JSDOM } = require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const dom=new JSDOM(fs.readFileSync(f,'utf8'),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/',
  beforeParse(w){
    w.AudioContext=function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
    w.alert=()=>{};
  }});
const w=dom.window,D=w.document,EV=e=>w.eval(e);
let bad=0; const chk=(l,ok,d)=>{ if(!ok) bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&d?'  <-- '+d:''}`); };

// two passes on one lift: the rate mover raises it, then a stall cuts it
const stack = `S.maxes.bench=300; S.mxProv={}; S.adNew=0; S.adLog=[
  {kind:'rate',  lift:'bench', from:300, to:310, d:'2026-09-01', why:'climbing on your own numbers'},
  {kind:'stall', lift:'bench', from:310, to:285, d:'2026-09-03', why:'three sessions without progress'}
]; S.maxes.bench=285; save(); S.day='PLAN'; render();`;

setTimeout(async()=>{
  console.log(`\n--- ${L}: any change the card made can be put back, not just the last one ---`);
  EV('try{TOUR.live=false;}catch(e){} S.tour={done:true}; if(typeof ONB!=="undefined"){ONB().done=true;} S.discAck={v:DISC_V,d:localDate()}; storageOK=true; S.maxes={squat:327,bench:225,dead:405,ohp:145,row:170,pull:225}; save();');

  // --- the older entry is reachable at all ------------------------------------
  EV(stack);
  const html=EV('adaptHTML()');
  chk('(fixture) two passes on the same lift, on different days', EV('S.adLog.length')===2);
  chk('an older change is still shown, not just the newest pass',
      (html.match(/data-adundo/g)||[]).length===2,
      'the panel offers '+((html.match(/data-adundo/g)||[]).length)+' undo controls for 2 entries');

  // --- clean restore: nothing has moved the lift since ------------------------
  EV(stack);
  EV('adaptUndoOne(1);');   // the newest, whose `to` is still the current max
  chk('putting back an untouched change restores the old number exactly',
      EV('S.maxes.bench')===310, 'bench is '+EV('S.maxes.bench')+', wanted 310');
  chk('and the entry is marked rather than deleted, so the record survives',
      EV('S.adLog.length')===2 && !!EV('S.adLog[1].undone'),
      'log length '+EV('S.adLog.length')+', undone='+EV('JSON.stringify(S.adLog[1].undone)'));
  chk('a change already put back cannot be put back twice',
      EV('adaptUndoOne(1)')===false && EV('S.maxes.bench')===310,
      'bench moved again to '+EV('S.maxes.bench'));

  // --- out of order: the later change is kept ---------------------------------
  EV(stack);
  EV('adaptUndoOne(0);');   // the OLDER +10, with a -25 stacked on top of it
  chk('putting back an older change removes its effect and keeps the later one',
      EV('S.maxes.bench')===275,
      'bench is '+EV('S.maxes.bench')+', wanted 275 (285 with the +10 taken back out)');
  chk('and the change that was NOT put back is still standing',
      !EV('S.adLog[1].undone') && !!EV('S.adLog[0].undone'),
      'the wrong entry was marked');

  // --- probation steps are visible and reversible -----------------------------
  EV(`S.maxes.bench=300; S.mxProv={bench:{tested:325,from:290,floor:290,since:'2026-09-01',start:310}};
      S.adLog=[{kind:'prov', lift:'bench', from:310, to:300, d:'2026-09-03', why:'the tested max has not held'}];
      save(); render();`);
  const ph=EV('adaptHTML()');
  chk('a probation step is shown in the panel at all', /310/.test(ph) && /data-adundo/.test(ph),
      'prov rows render as nothing - the c184 steps were invisible here');
  EV('adaptUndoOne(0);');
  chk('putting a trial step back restores the max', EV('S.maxes.bench')===310, 'bench is '+EV('S.maxes.bench'));
  chk('and re-arms the trial rather than declaring the max proven',
      EV('S.mxProv.bench.since')===EV('shiftDate()'),
      'since is '+EV('JSON.stringify((S.mxProv.bench||{}).since)'));

  // --- what is honestly NOT reversible ----------------------------------------
  EV(`S.adLog=[{kind:'volume', muscle:'chest', dir:1, from:12, d:'2026-09-03', why:'recovering well'}]; render();`);
  const vh=EV('adaptHTML()');
  chk('a volume reshape is shown but offers no undo it cannot honour',
      !/data-adundo/.test(vh) && /Plan tab/.test(vh),
      'a volume drift was offered an undo it has no clean inverse for');

  // --- the batch button still works -------------------------------------------
  EV(stack);
  EV('adaptUndo();');
  chk('the batch button still puts back a whole pass',
      !!EV('S.adLog[1].undone') && EV('S.maxes.bench')===310,
      'bench '+EV('S.maxes.bench')+', newest undone='+EV('JSON.stringify(S.adLog[1].undone)'));

  // --- and the control is actually wired, not just rendered -------------------
  EV(stack);
  // the adapt panel lives inside the volume screen, which is the PLAN tab - not RATE. The first
  // version of this check looked on RATE, found nothing, and would have reported a wiring fault
  // that did not exist.
  EV("S.day='PLAN'; render();");
  const btn=D.querySelector('[data-adundo]');
  chk('(fixture) the undo control reaches the screen', !!btn, 'no [data-adundo] rendered on the PLAN tab');
  if(btn){
    btn.dispatchEvent(new w.MouseEvent('click',{bubbles:true}));
    await new Promise(r=>setTimeout(r,40));
    chk('tapping it actually puts the change back', EV('(S.adLog||[]).some(function(x){ return !!x.undone; })'),
        'the tap did nothing - rendered but not wired');
  }

  console.log('  problems:', bad); process.exit(bad?1:0);
},1500);
