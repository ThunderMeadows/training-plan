// Every button in the settings sheet: does it do something, and can you SEE what it did?
// Field-caught: the problem report opened behind the sheet that launched it.
const { JSDOM } = require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const src=fs.readFileSync(f,'utf8');
const dom=new JSDOM(src,{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/'});
const w=dom.window,D=w.document,EV=e=>w.eval(e);
w.AudioContext=w.AudioContext||function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
const click=el=>el&&el.dispatchEvent(new w.MouseEvent('click',{bubbles:true,cancelable:true,view:w}));
const z=el=>{ try{ return parseInt(w.getComputedStyle(el).zIndex,10)||0; }catch(e){ return 0; } };

setTimeout(()=>{
  console.log(`\n--- ${L}: settings buttons ---`);
  let bad=0; const chk=(l,ok,d)=>{ if(!ok) bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&d?'  <-- '+d:''}`); };
  EV('try{TOUR.live=false;}catch(e){} try{S.tour={done:true};}catch(e){}');
  for(const fn of ['coachIdle','ONB_ACTIVE','isStartMode']) EV(`if(typeof ${fn}==="function") ${fn}=function(){return false;};`);
  EV('S.maxes={squat:327,bench:225,dead:405,ohp:145,pull:225}; render();');
  EV('SET_OPEN=true; settingsSync();');
  const sheet=D.querySelector('#setHost .hw-wrap');
  chk('settings open', !!sheet);
  const sheetZ=z(sheet);
  console.log(`  settings sheet sits at z-index ${sheetZ}`);

  // anything the sheet can launch must land ABOVE it
  const launches=[
    ['Report a problem','reportBtn','.rpt-wrap'],
  ];
  launches.forEach(([name,id,sel])=>{
    const b=D.getElementById(id);
    if(!b){ console.log(`  --    ${name}: not on this card`); return; }
    click(b);
    const panel=D.querySelector(sel);
    chk(`${name} opens`, !!panel, 'nothing appeared');
    if(panel){
      const pz=z(panel);
      chk(`${name} sits above the sheet`, pz>sheetZ, `panel ${pz} vs sheet ${sheetZ} - hidden behind it`);
      const closer=panel.querySelector('[data-rptclose]')||panel;
      click(closer);
    }
  });

  // every control in the sheet must be bound to something
  EV('SET_OPEN=true; settingsSync();');
  const ctrls=[...D.querySelectorAll('#setHost .set-body [data-thm],#setHost .set-body [data-lightmode],#setHost .set-body [data-fnt],'
    +'#setHost .set-body [data-tsz],#setHost .set-body [data-uimode],#setHost .set-body [data-radj],'
    +'#setHost .set-body [data-kaon],#setHost .set-body [data-snd],#setHost .set-body [data-tone],'
    +'#setHost .set-body [data-brth],#setHost .set-body [data-jump],#setHost .set-body [data-gbflav]')];
  const unbound=ctrls.filter(c=>!c.onclick);
  chk('every chip is wired', unbound.length===0, unbound.length+' with no handler');

  // the data buttons all exist and are bound
  ['backupBtn','restoreBtn','restorePasteBtn','reportBtn','selfTestBtn'].forEach(id=>{
    const el=D.getElementById(id);
    if(!el){ console.log(`  --    #${id} not on this card`); return; }
    chk(`#${id} is wired`, !!el.onclick, 'present but does nothing');
  });

  // nothing in the sheet should be sitting under the bear or the help card
  const bearZ=z(D.getElementById('gbHost'))||80;
  chk('the sheet covers the bear', sheetZ>bearZ, `sheet ${sheetZ} vs bear ${bearZ}`);
  console.log(`  runtime errors: ${EV('(typeof ERR_LOG!=="undefined"?ERR_LOG.length:"n/a")')}`);
  console.log('  problems:', bad);
  process.exit(bad?1:0);
},1500);
