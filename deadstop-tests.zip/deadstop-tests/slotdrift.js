// FIELD 2026-09-06, from his own backup. His "hard sets per week" chart read 123 / 109 / 94
// while his session reports for the same three weeks said 120 / 137 / 91. Week 2 was short by
// 28 real sets: day F held 26 logged sets in the report and NOTHING in the card's set state,
// and day C was missing exactly the six sets of the two hip machines he had added that week.
//
// Set state is keyed by an exercise's POSITION in the day, and four paths change a day's shape.
// Two of them maintained those positions wrongly:
//   - deleting an added movement computed its slot from planDay().exercises.length - the RAW
//     plan - while the day on screen has already had S.outs taken out of it. One removal in
//     that day and the arithmetic is off by one, so the delete-and-slide ran from the wrong
//     slot and walked over the logged sets of whatever was really there.
//   - and it only ever touched exKey(), which is the CURRENT week, so every already-logged
//     week kept its old positions while the day got shorter.
//   - removing a plan movement, restoring it, and adding one touched no set data at all.
//
// This is not a chart bug. blockSuccess() reads the same slots to judge whether prescribed reps
// were hit, and that feeds max progression: a slot off by one credits one movement's reps to
// another lift. So the checks below are about set data landing on the right exercise, in every
// week, through every path that can reshape a day.
const {JSDOM}=require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const d=new JSDOM(fs.readFileSync(f,'utf8'),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/'});
const w=d.window,EV=e=>w.eval(e);
const safe=(e,fb)=>{ try{ return EV(e); }catch(err){ return (fb===undefined)?('ERR '+err.message):fb; } };
w.AudioContext=function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
let bad=0; const chk=(l,ok,dd)=>{ if(!ok)bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&dd?'  <-- '+dd:''}`);};

// Lay three weeks of logged sets on one day, one distinctive set-count per exercise so any
// drift shows up as a number landing on the wrong movement.

// Everything below goes through the REAL controls, by click, not through any helper this build
// happens to have. The first cut of this file called dayReshape() directly - which does not
// exist on the build being tested for a regression, so the call threw, the catch handed back a
// fallback, and the checks passed on the broken card while proving nothing. Same vacuous-pass
// trap sharetest was carrying. If a control cannot be found, that is a FAILURE here, not a skip.
const TAP = `(function(sel){
  var el=document.querySelector(sel);
  if(!el) return 'NO CONTROL '+sel;
  el.dispatchEvent(new window.MouseEvent('click',{bubbles:true}));
  return 'ok';
})`;
const REMOVE = `(function(code, name){
  // The x lives on the deck (the whole-day overview), and a FUTURE week is read-only - "look,
  // don't touch" - so a tap there does nothing at all. The first cut of this file edited from
  // week 3 of a fresh card, got silently refused, and then reported that nothing had drifted.
  // Edits happen on the live day, the way an athlete makes them; the seeded history spans
  // weeks 1-3 so the remap still has to reach every one of them.
  S.day=code; S.week=__liveWeek; S.view='deck'; render();
  var d=dayObj(), i=d.exercises.findIndex(function(e){ return e.name===name; });
  if(i<0) return 'NOT IN DAY '+name;
  var sel='[data-exout="'+i+'"]';
  var r1=__tap(sel); if(r1!=='ok') return r1;   // arms it
  var r2=__tap(sel); if(r2!=='ok') return r2;   // confirms
  return 'ok';
})`;
const RESTORE = `(function(code, name){
  // Restore renders on the focused exercise row, not on the deck, and only when that row IS
  // the out movement - so put the focus there first, the way tapping it does.
  S.day=code; S.week=__liveWeek; S.view='rows';
  var d=dayObj(), i=d.exercises.findIndex(function(e){ return e.name===name; });
  if(i<0) return 'NOT IN DAY '+name;
  S.focus=i; render();
  return __tap('[data-restore="'+name.replace(/"/g,'')+'"]');
})`;

const SEED = `(function(code){
  S.data={}; S.dpark={};
  var names=dayOrderNames(code);
  var map={};
  [1,2,3].forEach(function(wk){
    names.forEach(function(nm,i){
      var n=i+2;                                  // 2,3,4,5... unique per position
      S.data['1c|'+wk+'|'+code+'|'+i]={sets:Array.from({length:n},function(){ return {st:'hit',reps:5,rir:2}; }),
                                       w:null, feel:null, open:-1, wopen:false, sub:null};
      map[wk+'|'+nm]=n;
    });
  });
  save();
  return {names:names, map:map};
})`;

// what sets does each MOVEMENT hold now, in the given week?
const READ = `(function(code, wk){
  var names=dayOrderNames(code), out={};
  names.forEach(function(nm,i){
    var st=S.data['1c|'+wk+'|'+code+'|'+i];
    out[nm]=st? (st.sets||[]).filter(function(s){ return s.st!=='pend'; }).length : 0;
  });
  return out;
})`;

setTimeout(()=>{
  console.log(`\n--- ${L}: logged sets follow their exercise ---`);
  EV('try{TOUR.live=false;}catch(e){} S.tour={done:true}; if(typeof ONB!=="undefined"){ONB().done=true;} S.discAck={v:DISC_V,d:localDate()}; storageOK=true; save();');
  EV(`window.__tap=${TAP}; window.__seed=${SEED}; window.__read=${READ};`);
  EV(`window.__remove=${REMOVE}; window.__restore=${RESTORE};`);

  // The edits have to happen on the LIVE session. A day the card has not reached yet renders
  // "Coming up - look, don't touch" and refuses every control, so an earlier cut of this file
  // tapped a read-only screen, was silently ignored, and then reported that nothing drifted.
  const live=safe(`(function(){
    var n=(typeof nextSession==='function')? nextSession() : null;
    if(n){ S.day=n.code; S.week=n.week; }
    window.__liveWeek=S.week;
    return {code:S.day, week:S.week, preview:(typeof isPreviewing==='function'? isPreviewing():null)};
  })()`,{});
  chk('(fixture) the test is standing on a live session, not a preview',
      live.code && live.preview!==true, JSON.stringify(live));
  const code=live.code||safe('dayCodes()[0]','A');
  const seeded=safe(`__seed(${JSON.stringify(code)})`,{});
  chk('(fixture) three weeks of sets are on the day, one count per movement',
      seeded.names && seeded.names.length>=4, JSON.stringify(seeded).slice(0,120));

  // ---- 1. remove a PLAN movement from the middle -----------------------------
  const victim = seeded.names[1];
  const after = safe(`(function(){
    S.day=${JSON.stringify(code)};
    var r=__remove(${JSON.stringify(code)}, ${JSON.stringify(victim)});
    if(r!=='ok') return {err:r};
    return {w1:__read(${JSON.stringify(code)},1), w2:__read(${JSON.stringify(code)},2), w3:__read(${JSON.stringify(code)},3)};
  })()`,{err:'threw'});
  chk('(fixture) the remove control was found and pressed for real', !after.err, after.err);
  const drifted=[];
  [1,2,3].forEach(wk=>{
    const got=after['w'+wk]||{};
    Object.keys(got).forEach(nm=>{ if(seeded.map[wk+'|'+nm]!==got[nm]) drifted.push(`w${wk} ${nm}: had ${seeded.map[wk+'|'+nm]}, now ${got[nm]}`); });
  });
  console.log(`    removed ${JSON.stringify(victim)} from the middle of day ${code}`);
  chk('every remaining movement keeps its own sets, in every week',
      drifted.length===0, drifted.slice(0,4).join(' | '));

  // ---- 2. the week counts do not fall because a plan was edited ---------------
  const counts=safe(`JSON.stringify([weekSets(1,1),weekSets(1,2),weekSets(1,3)])`,'[]');
  const want=safe(`(function(){ var n=0; var names=Object.keys(${JSON.stringify(seeded.map)});
    return JSON.stringify([1,2,3].map(function(wk){ var t=0;
      names.forEach(function(k){ if(k.indexOf(wk+'|')===0) t+=${JSON.stringify(seeded.map)}[k]; }); return t; })); })()`,'[]');
  console.log(`    weekly counts after the edit: ${counts}  (work actually logged: ${want})`);
  chk('"hard sets per week" still reports the work that was done', counts===want,
      'editing today\u2019s plan rewrote what happened weeks ago');

  // ---- 3. restore brings the movement AND its sets back -----------------------
  const back=safe(`(function(){
    var r=__restore(${JSON.stringify(code)}, ${JSON.stringify(victim)});
    if(r!=='ok') return {err:r};
    return {w1:__read(${JSON.stringify(code)},1), w2:__read(${JSON.stringify(code)},2), w3:__read(${JSON.stringify(code)},3)};
  })()`,{err:'threw'});
  chk('(fixture) the restore control was found and pressed for real', !back.err, back.err);
  const lost=[];
  [1,2,3].forEach(wk=>{
    const got=back['w'+wk]||{};
    Object.keys(seeded.map).forEach(k=>{
      if(k.indexOf(wk+'|')!==0) return;
      const nm=k.slice(String(wk).length+1);
      if(got[nm]!==seeded.map[k]) lost.push(`w${wk} ${nm}: was ${seeded.map[k]}, back as ${got[nm]}`);
    });
  });
  chk('restoring a removed movement brings its own logged sets back with it',
      lost.length===0, lost.slice(0,4).join(' | '));

  // ---- 4. his exact case: a day with BOTH a removal and an added movement -----
  // The off-by-one only bites when planDay().exercises.length and the visible day disagree,
  // which is what a removal does. Then deleting the added movement ran from the wrong slot.
  const his=safe(`(function(){
    var c=${JSON.stringify(code)};
    S.day=c; S.outs={}; S.customs={}; S.order={}; S.data={}; S.dpark={};
    var add='Plank';
    if(typeof libAdd!=='function') return {err:'no libAdd'};
    libAdd(add, c);                                    // his added movement
    var r=__remove(c, ${JSON.stringify(seeded.names[0])});   // and his removed one
    if(r!=='ok') return {err:r};
    var pre=__seed(c);                                 // seed against the shape he trained
    var r2=__remove(c, add);                           // now delete the added movement
    if(r2!=='ok') return {err:r2};
    var got=__read(c,2), drift=[];
    Object.keys(got).forEach(function(nm){ if(pre.map['2|'+nm]!==got[nm]) drift.push(nm+': '+pre.map['2|'+nm]+' -> '+got[nm]); });
    return {drift:drift, names:pre.names.length};
  })()`,{err:'threw'});
  chk('(fixture) his exact day shape was built through the real controls', !his.err, his.err);
  chk('deleting an added movement from a day that also has one removed leaves the rest alone',
      his.drift && his.drift.length===0, (his.drift||[]).slice(0,5).join(' | '));

  // ---- 4b. THE FIELD CASE, exactly ------------------------------------------
  // What actually triggered it in his card: an ADDED movement that has been DRAGGED into the
  // middle of the day. S.order decides where it sits, but the delete branch computed its slot
  // as planDay().exercises.length + its index in the customs list - the end of the day. So it
  // deleted whatever was really at that slot and slid every movement after it down one. On his
  // day F, Lying Leg Curl sits at position 3 of 9. Measured on the shipped build: three
  // movements each inherited their neighbour's logged sets.
  const dragged=safe(`(function(){
    var n=nextSession(); S.day=n.code; S.week=n.week; var c=S.day;
    S.outs={}; S.customs={}; S.order={}; S.data={}; S.dpark={};
    if(typeof libAdd!=='function' || typeof moveInDay!=='function') return {err:'no add/drag api'};
    libAdd('Plank', c);
    var names=dayOrderNames(c);
    var from=names.indexOf('Plank');
    if(from<0) return {err:'the added movement is not in the day'};
    moveInDay(c, from, 2);                      // drag it into the middle
    names=dayOrderNames(c);
    if(names.indexOf('Plank')!==2) return {err:'drag did not land it mid-day'};
    var before={};
    names.forEach(function(nm,i){
      S.data['1c|'+S.week+'|'+c+'|'+i]={sets:Array.from({length:i+2},function(){ return {st:'hit',reps:5,rir:2}; })};
      before[nm]=i+2; });
    var logged=0; Object.keys(before).forEach(function(k){ logged+=before[k]; });
    S.view='deck'; render();
    var di=dayObj().exercises.findIndex(function(e){ return e.name==='Plank'; });
    if(di<0) return {err:'no delete control for the added movement'};
    [1,2].forEach(function(){ var el=document.querySelector('[data-exout="'+di+'"]');
      if(el) el.dispatchEvent(new window.MouseEvent('click',{bubbles:true})); });
    if((custList(c)||[]).some(function(x){ return x.name==='Plank'; })) return {err:'the delete did not go through'};
    var after={}, drift=[];
    dayOrderNames(c).forEach(function(nm,i){ var st=S.data['1c|'+S.week+'|'+c+'|'+i];
      after[nm]=st? (st.sets||[]).filter(function(x){ return x.st!=='pend'; }).length : 0; });
    Object.keys(after).forEach(function(nm){ if(before[nm]!==after[nm]) drift.push(nm+': '+before[nm]+' -> '+after[nm]); });
    return {drift:drift, logged:logged, counted:weekSets(1,S.week)};
  })()`,{err:'threw'});
  chk('(fixture) an added movement was dragged mid-day and deleted for real', !dragged.err, dragged.err);
  chk('deleting a movement dragged into the middle leaves every other movement\u2019s sets alone',
      dragged.drift && dragged.drift.length===0, (dragged.drift||[]).join(' | '));
  chk('and the week still counts every set that was performed',
      dragged.counted===dragged.logged, 'logged '+dragged.logged+', counted '+dragged.counted);

  // ---- 5. nothing is ever written onto another movement's line ---------------
  chk('no movement ever inherits another movement\u2019s sets',
      safe(`(function(){
        var c=${JSON.stringify(code)};
        S.day=c; S.outs={}; S.customs={}; S.order={}; S.data={}; S.dpark={};
        var pre=__seed(c), names=pre.names.slice();
        for(var k=1;k<=3;k++){ if(names[k]) { var r=__remove(c, names[k]); if(r!=='ok') return false; } }
        var got=__read(c,1), bad=0;
        Object.keys(got).forEach(function(nm){ if(got[nm] && pre.map['1|'+nm]!==got[nm]) bad++; });
        return bad===0;
      })()`,false),
      'a surviving movement is showing a count that was not its own');

  // ---- 6. the park cannot grow without limit --------------------------------
  chk('the park is bounded',
      safe(`(function(){
        S.dpark={};
        for(var i=0;i<DPARK_MAX+120;i++) dparkPut('1c|1|Z','mv'+i,{sets:[{st:'hit'}]});
        return Object.keys(S.dpark).length<=DPARK_MAX;
      })()`,false), safe('Object.keys(S.dpark||{}).length')+' parked entries');

  chk('a mangled park does not break the counts',
      safe(`(function(){ S.dpark='nonsense'; var a=weekSets(1,1); S.dpark=[1,2]; var b=weekSets(1,1);
        S.dpark={'x':{sets:null}}; var c2=weekSets(1,1);
        return isFinite(a)&&isFinite(b)&&isFinite(c2); })()`,false), 'weekSets threw on a bad park');

  console.log(`\nproblems: ${bad}`);
  process.exit(bad? 1:0);
},2600);
