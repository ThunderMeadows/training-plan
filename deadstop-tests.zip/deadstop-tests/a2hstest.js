// Install guidance must match the phone in the athlete's hand. Field-caught twice: Android
// users were shown Safari and a Share button, which reads as "this app does not support me".
const { JSDOM } = require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const dom=new JSDOM(fs.readFileSync(f,'utf8'),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/'});
const w=dom.window;
w.AudioContext=w.AudioContext||function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
setTimeout(()=>{
  console.log(`\n--- ${L}: install guidance per device ---`);
  let bad=0;
  const CASES=[
   ['Pixel Chrome','Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 Chrome/126 Mobile Safari/537.36',5,412,['android-chrome']],
   ['Samsung Internet','Mozilla/5.0 (Linux; Android 13; SM-S911B) AppleWebKit/537.36 SamsungBrowser/23.0 Mobile Safari/537.36',5,412,['android-samsung']],
   ['Android Firefox','Mozilla/5.0 (Android 13; Mobile; rv:127.0) Gecko/127.0 Firefox/127.0',5,412,['android-other']],
   ['Android desktop-mode, Linux UA','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/126 Safari/537.36',5,412,['unknown-mobile']],
   ['Android desktop-mode, Mac UA','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 Chrome/126 Safari/537.36',5,412,['unknown-mobile']],
   ['iPhone Safari','Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 Version/17.5 Mobile Safari/604.1',5,390,['ios-safari']],
   ['iPad Safari','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 Version/17.5 Safari/605.1.15',5,1024,['ipad-safari']],
   ['Desktop Mac','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 Version/17.5 Safari/605.1.15',0,1600,['desktop']],
  ];
  for(const [n,ua,mtp,iw,want] of CASES){
    Object.defineProperty(w.navigator,'userAgent',{value:ua,configurable:true});
    Object.defineProperty(w.navigator,'maxTouchPoints',{value:mtp,configurable:true});
    Object.defineProperty(w.navigator,'userAgentData',{value:undefined,configurable:true});
    if(mtp) w.document.ontouchend=null; else delete w.document.ontouchend;
    Object.defineProperty(w,'innerWidth',{value:iw,configurable:true});
    const got=w.eval('a2hsPlatform()');
    const ok=want.indexOf(got)>-1;
    if(!ok) bad++;
    console.log(`  ${ok?'ok  ':'FAIL'}  ${n.padEnd(32)} -> ${got}${ok?'':'  <-- wanted '+want.join('/')}`);
    // and an Android device must never be told to use Safari
    if(/Android|desktop-mode/.test(n)){
      const steps=JSON.stringify(w.eval(`JSON.stringify(A2HS_STEPS[${JSON.stringify(got)}].steps)`));
      if(/Safari/.test(steps) && got!=='unknown-mobile'){ console.log('        <-- Android shown Safari steps'); bad++; }
    }
  }
  console.log('  problems:', bad);
  process.exit(bad?1:0);
},1400);
