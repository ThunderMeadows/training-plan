// FOUND BY SECOND REVIEW 2026-09-10 (findings A, B, C). Three defects, one story: the backup
// and restore paths told the athlete things that were not true.
//
// A. restoreBackup() never checked a single stSet() result, and save() throws the result away.
//    With every write failing, the card still said "Backup restored".
// B. Undo restored S only. A restore also writes SESSION LOGS - overwriting days you had and
//    adding days you did not - and undo left every one of them in place.
// C. backupAll() called markBackedUp() as its first statement. Cancel the share sheet and
//    S.lastBackup still moved to today, silencing the "back up" reminder for a week on the
//    strength of a backup that never happened.
//
// What this holds: a failing write is reported, not swallowed; undo puts the session logs back
// as well as the state; and a backup is marked done only where something actually landed.
const {JSDOM}=require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const raw=fs.readFileSync(f,'utf8');
const AC=function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
let bad=0; const chk=(l,ok,d)=>{ if(ok!==true)bad++; if(typeof ok==='string'&&ok.slice(0,3)==='ERR') d=ok; console.log(`  ${ok===true?'ok  ':'FAIL'}  ${l}${ok!==true&&d?'  <-- '+d:''}`); };
function boot(){
  const w=new JSDOM(raw,{runScripts:'dangerously',pretendToBeVisual:true,url:'https://thundermeadows.github.io/',beforeParse(win){ win.AudioContext=AC; }}).window;
  return {w, E:e=>{try{return w.eval(e);}catch(err){return 'ERR '+err.message;}}, A:async e=>{try{return await w.eval('(async()=>{'+e+'})()');}catch(err){return 'ERR '+err.message;}}};
}
const neutral=c=>{ c.E("for(var i=0,fs=['coachIdle','ONB_ACTIVE','isStartMode'];i<fs.length;i++){ try{ if(typeof window[fs[i]]==='function') window[fs[i]]=function(){return false;}; }catch(e){} }"); c.E("try{TOUR.live=false;}catch(e){} S.tour={done:true}; S.access={role:'coach',until:'2027-12-31'};"); };
const toast=c=>c.E("(document.getElementById('toast')||{}).textContent||''");
const restore=async(c,payload)=>{ c.E("window.__pl="+JSON.stringify(payload)+";");
  return await c.A("await restoreBackup({ text: async function(){ return window.__pl; } }); return true;"); };

(async()=>{
  console.log(`\n--- ${L}: the backup never claims more than happened ---`);

  // ---------- A: a restore whose writes all fail must say so ----------
  console.log('\n[A] every write failing');
  let c=boot(); await sleep(1900); neutral(c);
  c.E("S.maxes={squat:100}; save();");
  c.E("window.__realSet=stSet; stSet=async function(){ return false; };");   // storage refuses everything
  await restore(c, JSON.stringify({v:1, exported:'2026-09-01', S:{maxes:{squat:999}}, logs:{'tc-log:2026-09-01-A-W1B0':'{\"date\":\"2026-09-01\"}'}}));
  await sleep(300);
  const tA=toast(c);
  chk('the card does NOT report a clean restore', !/^Backup restored/.test(tA), 'toast: "'+tA+'"');
  chk('it names the failure', /INCOMPLETE|could not be written/i.test(tA), 'toast: "'+tA+'"');
  c.E("stSet=window.__realSet;");

  // ---------- A2: a clean restore still reports success ----------
  console.log('\n[A2] a restore that works');
  c=boot(); await sleep(1900); neutral(c);
  await restore(c, JSON.stringify({v:1, exported:'2026-09-01', S:{maxes:{squat:333}}, logs:{}}));
  await sleep(300);
  chk('state came across', c.E("S.maxes&&S.maxes.squat")===333, 'squat='+c.E('S.maxes&&S.maxes.squat'));
  chk('no false alarm on a good restore', !/INCOMPLETE/i.test(toast(c)), 'toast: "'+toast(c)+'"');

  // ---------- B: undo puts the session logs back ----------
  console.log('\n[B] undo restores logs, not just state');
  c=boot(); await sleep(1900); neutral(c);
  const KEEP='tc-log:2026-09-05-B-W1B0', ADDED='tc-log:2026-08-01-A-W1B0';
  await c.A("await stSet('"+KEEP+"', JSON.stringify({date:'2026-09-05', mine:true}));");
  c.E("S.maxes={squat:222}; save();");
  await c.A("await refreshLogs();");
  chk('fixture: the athlete has their own session', (await c.A("return await stGet('"+KEEP+"');")).indexOf('mine')>=0, 'missing');
  const payload=JSON.stringify({v:1, exported:'2026-08-02', S:{maxes:{squat:111}},
    logs:{ [KEEP]:JSON.stringify({date:'2026-09-05', theirs:true}), [ADDED]:JSON.stringify({date:'2026-08-01', theirs:true}) }});
  await restore(c, payload); await sleep(300);
  chk('after restore, their day was overwritten', (await c.A("return await stGet('"+KEEP+"');")).indexOf('theirs')>=0, 'not overwritten');
  chk('and a day they never trained was added', (await c.A("return await stGet('"+ADDED+"');"))!=null, 'not added');
  // fire the undo the same way the toast button does
  // press the real Undo button that undoToast() appends
  const fired=c.E("(function(){ var b=document.querySelector('#toast button.toast-undo'); if(b){ b.click(); return true; } return false; })()");
  chk('the undo button is on screen', fired===true, 'no button.toast-undo in the toast');
  // its handler is async - a storage write per touched key. A fixed sleep is a guess that holds
  // on an idle core and fails at -j 4; poll for the observable result instead.
  for(let i=0;i<120;i++){
    const v=await c.A("return await stGet('"+KEEP+"');");
    if(typeof v==='string' && v.indexOf('mine')>=0) break;
    await sleep(100);
  }
  const backK=await c.A("return await stGet('"+KEEP+"');");
  const backA=await c.A("return await stGet('"+ADDED+"');");
  chk('undo put their own session back', typeof backK==='string' && backK.indexOf('mine')>=0, 'got '+String(backK).slice(0,60));
  chk('undo removed the session the restore added', backA==null, 'still there: '+String(backA).slice(0,60));
  chk('undo put the state back too', c.E("S.maxes&&S.maxes.squat")===222, 'squat='+c.E('S.maxes&&S.maxes.squat'));

  // ---------- C: a cancelled backup is not a backup ----------
  console.log('\n[C] cancelled, downloaded, copied');
  c=boot(); await sleep(1900); neutral(c);
  c.E("S.lastBackup=null; save();");
  c.E("navigator.canShare=function(){return true;}; navigator.share=async function(){ var e=new Error('x'); e.name='AbortError'; throw e; }; window.File=function(parts){ this.name='x'; };");
  await c.A("await backupAll();");
  chk('cancelling the share sheet does NOT mark a backup', c.E("S.lastBackup")==null, 'lastBackup='+c.E('S.lastBackup'));
  chk('and the athlete is told nothing was saved', /cancelled/i.test(toast(c)), 'toast: "'+toast(c)+'"');
  chk('so the reminder still shows', c.E("backupDue()")===true || c.E("!S.lastBackup"), 'reminder suppressed');
  c.E("navigator.share=async function(){ return true; };");
  await c.A("await backupAll();");
  chk('a share that resolves DOES mark it', c.E("S.lastBackup")!=null, 'lastBackup still null');

  console.log('\nproblems: '+bad); process.exit(bad?1:0);
})();
