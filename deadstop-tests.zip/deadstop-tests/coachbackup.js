// AUDIT 2026-09-10. The FAQ: "A backup taken while coaching carries everyone." It carried one
// drawer. Roster athletes live under SKEY+':a:'+id and LOGP+id+':' and backupAll never read
// either - a coach who lost the phone lost every athlete, told all along they were backed up.
// And S is whichever drawer is OPEN, so a backup taken inside an athlete's drawer held that
// athlete's state where the coach's should be.
//
// What this holds: a coach backup carries the owner's state and sessions, the roster, and every
// athlete's state and sessions; it does so from INSIDE a drawer too; a full wipe followed by a
// restore brings everyone back into their own slot; the owner lands in the owner's slot even
// when restoring from inside a drawer; and a v1 (solo) backup still restores.
const {JSDOM}=require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const raw=fs.readFileSync(f,'utf8');
const AC=function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
let bad=0; const chk=(l,ok,d)=>{ if(ok!==true)bad++; if(typeof ok==='string'&&ok.slice(0,3)==='ERR') d=ok; console.log(`  ${ok===true?'ok  ':'FAIL'}  ${l}${ok!==true&&d?'  <-- '+d:''}`); };
function boot(){
  const w=new JSDOM(raw,{runScripts:'dangerously',pretendToBeVisual:true,url:'https://thundermeadows.github.io/',beforeParse(win){ win.AudioContext=AC; }}).window;
  return {w, E:e=>{try{return w.eval(e);}catch(err){return 'ERR '+err.message;}}, A:async e=>{try{return await w.eval('(async()=>{'+e+'})()');}catch(err){return 'ERR '+err.message;}}};
}
const neutral=c=>{ c.E("for(var i=0,fs=['coachIdle','ONB_ACTIVE','isStartMode'];i<fs.length;i++){ try{ if(typeof window[fs[i]]==='function') window[fs[i]]=function(){return false;}; }catch(e){} }"); c.E("try{TOUR.live=false;}catch(e){} S.tour={done:true}; S.access={role:'coach',until:'2027-12-31'}; save();"); };
async function seedCoach(c){
  c.E("S.maxes={squat:220,bench:210}; S.profile={name:'Coach'}; save();");
  c.E("ROSTER.mode='coach'; ROSTER.athletes=[{id:'a1',name:'Bucky'},{id:'a2',name:'Sis'}]; ROSTER.active=null; rosterSave();");
  await c.A("await stSet(SKEY+':a:a1', JSON.stringify({maxes:{squat:300}, profile:{name:'Bucky'}}));");
  await c.A("await stSet(SKEY+':a:a2', JSON.stringify({maxes:{squat:185}, profile:{name:'Sis'}}));");
  await c.A("await stSet(LOGP+'a1:2026-09-01-A-W1B0', JSON.stringify({date:'2026-09-01', ex:[{n:'Squat'}]}));");
  await c.A("await stSet(LOGP+'a2:2026-09-02-A-W1B0', JSON.stringify({date:'2026-09-02', ex:[{n:'Bench'}]}));");
  await c.A("await stSet(TLOGP+'2026-09-03-B-W1B0', JSON.stringify({date:'2026-09-03', ex:[{n:'Row'}]}));");
  await c.A("await refreshLogs();");
}
async function capture(c){
  c.E("window.__payload=null; window.File=function(parts){ window.__payload=parts.join(''); this.name='x'; }; navigator.canShare=function(){return true;}; navigator.share=async function(){};");
  await c.A("await backupAll();");
  return c.E("window.__payload");
}
async function restoreFrom(c,payload){
  c.E("window.__pl="+JSON.stringify(payload)+";");
  return await c.A("await restoreBackup({ text: async function(){ return window.__pl; } }); return true;");
}
(async()=>{
  console.log(`\n--- ${L}: a coach backup carries everyone ---`);

  console.log('\n[1] what a coach backup contains');
  let c=boot(); await sleep(1900); neutral(c); await seedCoach(c);
  let p=await capture(c);
  chk('backupAll produced a file', typeof p==='string' && p.length>100, 'no payload');
  let o={}; try{ o=JSON.parse(p); }catch(e){}
  chk('payload is v2', o.v===2, 'v='+o.v);
  chk('carries the owner state (coach squat 220)', !!(o.S&&o.S.maxes&&o.S.maxes.squat===220), JSON.stringify(o.S&&o.S.maxes));
  chk('carries the owner sessions, and only those', Object.keys(o.logs||{}).length===1 && Object.keys(o.logs)[0].indexOf('2026-09-03')>=0, JSON.stringify(Object.keys(o.logs||{})));
  chk('carries the roster', typeof o.roster==='string' && o.roster.indexOf('Bucky')>=0, 'roster='+String(o.roster).slice(0,60));
  chk('carries both athlete drawers', !!(o.drawers&&o.drawers.a1&&o.drawers.a2), JSON.stringify(Object.keys(o.drawers||{})));
  chk('a1 state came across (squat 300)', !!(o.drawers&&o.drawers.a1&&/300/.test(o.drawers.a1.S||'')), '');
  chk('a1 sessions came across', !!(o.drawers&&o.drawers.a1&&Object.keys(o.drawers.a1.logs||{}).length===1), JSON.stringify(o.drawers&&o.drawers.a1&&Object.keys(o.drawers.a1.logs||{})));
  chk('a2 sessions came across', !!(o.drawers&&o.drawers.a2&&Object.keys(o.drawers.a2.logs||{}).length===1), '');

  console.log('\n[2] taken from INSIDE an athlete drawer');
  await c.A("await rosterSwitch('a1');");
  chk('fixture: the coach is inside Bucky', c.E("ROSTER.active==='a1' && S.maxes.squat===300"), 'active='+c.E('ROSTER.active')+' squat='+c.E('S.maxes.squat'));
  p=await capture(c); try{ o=JSON.parse(p); }catch(e){ o={}; }
  chk('the owner slot still holds the COACH, not Bucky', !!(o.S&&o.S.maxes&&o.S.maxes.squat===220), 'owner squat='+(o.S&&o.S.maxes&&o.S.maxes.squat));
  chk('and Bucky is in his own drawer', !!(o.drawers&&o.drawers.a1&&/300/.test(o.drawers.a1.S||'')), '');
  await c.A("await rosterSwitch(null);");

  console.log('\n[3] wipe everything, restore, everyone comes back');
  const keep=p;
  c=boot(); await sleep(1900); neutral(c);
  chk('fixture: fresh card has no roster and no athletes', c.E("ROSTER.mode!=='coach' && !(ROSTER.athletes||[]).length"), 'mode='+c.E('ROSTER.mode'));
  await restoreFrom(c,keep); await sleep(400);
  chk('owner state restored (squat 220)', c.E("S.maxes && S.maxes.squat===220"), 'squat='+c.E('S.maxes&&S.maxes.squat'));
  chk('roster restored in coach mode with both athletes', c.E("ROSTER.mode==='coach' && (ROSTER.athletes||[]).length===2"), 'mode='+c.E('ROSTER.mode')+' n='+c.E('(ROSTER.athletes||[]).length'));
  const a1=await c.A("var v=await stGet(SKEY+':a:a1'); return v? JSON.parse(v).maxes.squat : null;");
  chk('Bucky\'s drawer restored (squat 300)', a1===300, 'got '+a1);
  const a1logs=await c.A("return (await stList(LOGP+'a1:')).length;");
  chk('Bucky\'s sessions restored', a1logs===1, 'got '+a1logs);
  const a2logs=await c.A("return (await stList(LOGP+'a2:')).length;");
  chk('Sis\'s sessions restored', a2logs===1, 'got '+a2logs);
  chk('the restore report counts the athletes', /2 athletes/.test(c.E('S.restoreNote||""')), c.E('S.restoreNote'));
  await c.A("await rosterSwitch('a1');");
  chk('and the coach can open Bucky and see his numbers', c.E("S.maxes.squat===300"), 'squat='+c.E('S.maxes.squat'));
  await c.A("await rosterSwitch(null);");

  console.log('\n[4] a v1 solo backup still restores');
  c=boot(); await sleep(1900); neutral(c);
  const v1=JSON.stringify({v:1, exported:'2026-09-01', S:{maxes:{bench:185}, profile:{name:'Solo'}}, logs:{}});
  await restoreFrom(c,v1); await sleep(300);
  chk('v1 restores the state', c.E("S.maxes && S.maxes.bench===185"), 'bench='+c.E('S.maxes&&S.maxes.bench'));
  chk('and leaves the roster alone', c.E("ROSTER.mode!=='coach'"), 'mode='+c.E('ROSTER.mode'));

  console.log('\nproblems: '+bad); process.exit(bad?1:0);
})();
