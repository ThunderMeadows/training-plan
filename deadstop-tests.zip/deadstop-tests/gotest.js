// Every shortcut must actually land. A "take me there" that opens the wrong screen, or points
// at a selector that no longer exists, is worse than telling the athlete to go look.
const { JSDOM } = require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const dom=new JSDOM(fs.readFileSync(f,'utf8'),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://thundermeadows.github.io/'});
const w=dom.window,D=w.document,EV=e=>w.eval(e);
w.AudioContext=w.AudioContext||function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
D.defaultView.HTMLElement.prototype.scrollIntoView=function(){};
setTimeout(async ()=>{
  console.log(`\n--- ${L}: help shortcuts land where they promise ---`);
  let bad=0;
  EV('try{TOUR.live=false;}catch(e){} try{S.tour={done:true};}catch(e){}');
  for(const fn of ['coachIdle','ONB_ACTIVE','isStartMode']) EV(`if(typeof ${fn}==="function") ${fn}=function(){return false;};`);
  EV('S.maxes={squat:327,bench:225,dead:405,ohp:145,pull:225}; render();');
  const keys=JSON.parse(EV('JSON.stringify(Object.keys(GB_GO))'));
  console.log('  shortcuts defined:', keys.length);
  for(const k of keys){
    // a shortcut this card does not carry must not be OFFERED - skipping it here is only
    // correct because the card hides its button too, which is asserted below
    if(!EV(`gbGoAvail(${JSON.stringify(k)})`)){ console.log(`  --    ${k.padEnd(9)} not on this card (button hidden)`); continue; }
    EV(`gbGo(${JSON.stringify(k)});`);
    await new Promise(r=>setTimeout(r,120));
    const sel=EV(`GB_GO[${JSON.stringify(k)}].sel`);
    const scoped=EV(`(function(){var sc=document.querySelector('#setHost .set-body');
      return !!((sc&&sc.querySelector(${JSON.stringify(sel)}))||document.querySelector(${JSON.stringify(sel)}));})()`);
    const flashed=D.querySelectorAll('.gb-goflash').length>0;
    const ok=scoped;
    if(!ok) bad++;
    console.log(`  ${ok?'ok  ':'FAIL'}  ${k.padEnd(9)} -> ${sel}${ok?(flashed?'  (found, pulsed)':'  (found)'):'  <-- NOTHING THERE'}`);
    EV("document.querySelectorAll('.gb-goflash').forEach(function(e){e.classList.remove('gb-goflash');});");
  }
  // a shortcut must also close the bear's card on its way out
  EV('gbPose(); gbGo("sound");');
  await new Promise(r=>setTimeout(r,120));
  const gone=!D.getElementById('gbHelp');
  if(!gone) bad++;
  console.log(`  ${gone?'ok  ':'FAIL'}  the help card gets out of the way`);
  // every declared shortcut must be reachable from a question
  const used=JSON.parse(EV('JSON.stringify(gbHelpItems().filter(function(x){return x[2];}).map(function(x){return x[2];}))'));
  const orphan=keys.filter(k=>used.indexOf(k)<0);
  console.log(`  questions offering a shortcut: ${used.length}`);
  if(orphan.length) console.log('  (declared but unused: '+orphan.join(', ')+')');
  // and nothing unavailable may still render a button
  EV('gbPose();');
  const shown=[...D.querySelectorAll('#gbHelp [data-ghgo]')].map(b=>b.dataset.ghgo);
  const dead=shown.filter(k=>!EV(`gbGoAvail(${JSON.stringify(k)})`));
  if(dead.length){ console.log('  FAIL  dead button offered: '+dead.join(', ')); bad++; }
  EV('gbDock();');
  const bogus=used.filter(k=>keys.indexOf(k)<0);
  if(bogus.length){ console.log('  FAIL  question points at an undefined shortcut: '+bogus.join(', ')); bad++; }
  console.log(`  runtime errors: ${EV('(typeof ERR_LOG!=="undefined"?ERR_LOG.length:"n/a")')}`);
  console.log('  problems:', bad);
  process.exit(bad?1:0);
},1500);
