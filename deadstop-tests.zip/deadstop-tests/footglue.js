// iOS keyboard/zoom shrinks and pans the visual viewport; a fixed bottom bar must follow the
// VISIBLE bottom, not the layout bottom (field bug: deck bar floating mid-page on scroll).
const {JSDOM}=require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const dom=new JSDOM(fs.readFileSync(f,'utf8'),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/',
  beforeParse(w){
    const ls={resize:[],scroll:[]};
    w.visualViewport={ offsetTop:0, height:w.innerHeight,
      addEventListener:(t,fn)=>{ (ls[t]=ls[t]||[]).push(fn); },
      __fire:(t)=>{ (ls[t]||[]).forEach(fn=>fn()); } };
  }});
const w=dom.window,EV=e=>w.eval(e);
w.AudioContext=function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
let bad=0; const chk=(l,ok,d)=>{ if(!ok)bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&d?'  <-- '+d:''}`); };
setTimeout(()=>{
  console.log(`\n--- ${L}: fixed bars follow the visible viewport ---`);
  EV('try{TOUR.live=false;}catch(e){} S.tour={done:true}; render();');
  const foot=()=>EV('(document.querySelector(".footer")||{style:{}}).style.transform||""');
  chk('bar untouched while viewports agree', foot()==='', foot());
  // keyboard up: visual viewport shrinks by 320 and pans down 40
  EV('visualViewport.height=window.innerHeight-320; visualViewport.offsetTop=40; visualViewport.__fire("resize");');
  setTimeout(()=>{
    const t1=foot();
    chk('bar glued to visible bottom when keyboard shrinks the viewport', t1==='translateY(-280px)', t1);
    // keyboard down: viewports agree again
    EV('visualViewport.height=window.innerHeight; visualViewport.offsetTop=0; visualViewport.__fire("resize");');
    setTimeout(()=>{
      chk('glue released when viewports agree again', foot()==='', foot());
      console.log('  problems: '+bad); process.exit(bad?1:0);
    },120);
  },120);
},1500);
