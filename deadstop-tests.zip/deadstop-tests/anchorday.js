// A session in progress does not change under the athlete's feet.
// FIELD 2026-09-02: he trained bench at 200 under a cut max; the update's repair pass restored
// the max mid-day; the header read 215 and "+ set" added a set at 215 beside five done at 200.
const { JSDOM } = require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const dom=new JSDOM(fs.readFileSync(f,'utf8'),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/'});
const w=dom.window,D=w.document,EV=e=>w.eval(e);
w.AudioContext=w.AudioContext||function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
setTimeout(()=>{
  console.log(`\n--- ${L}: a session in progress keeps its loads ---`);
  let bad=0; const chk=(l,ok,d)=>{ if(!ok) bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&d?'  <-- '+d:''}`); };
  EV('try{TOUR.live=false;}catch(e){} S.tour={done:true}; if(typeof ONB!=="undefined"){ONB().done=true;} S.discAck={v:DISC_V,d:localDate()}; storageOK=true; S.data={};');
  // a main lift with a percentage on the current day
  const found=EV(`(function(){ var d=dayObj(); for(var i=0;i<d.exercises.length;i++){ var ex=d.exercises[i]; if(ex.maxKey && ex.pct && ex.loadNum!=null) return JSON.stringify({i:i,k:ex.maxKey,name:ex.name}); } return null; })()`);
  if(!found){ console.log('  (no percentage main lift on today\'s day - nothing to anchor)'); process.exit(0); }
  const {i,k,name}=JSON.parse(found);
  EV(`S.maxes[${JSON.stringify(k)}]=230; render();`);
  const cut=EV(`(function(){ var ex=dayObj().exercises[${i}]; return curLoad(ex, exState(${i},ex)); })()`);
  console.log(`  ${name}: prescribed ${cut} under a max of 230`);
  // log two sets at that weight through the card's own stamp
  EV(`(function(){ var ex=dayObj().exercises[${i}], st=exState(${i},ex);
      st.sets[0].st='hit'; st.sets[0].reps=5; stampPerf(ex,st,st.sets[0]);
      st.sets[1].st='hit'; st.sets[1].reps=5; stampPerf(ex,st,st.sets[1]); save(); })()`);
  chk('logged sets are stamped with the weight lifted', EV(`exState(${i},dayObj().exercises[${i}]).sets[0].w`)===cut);
  // the max moves mid-day (repair pass, rate move, assessment)
  EV(`S.maxes[${JSON.stringify(k)}]=250; render();`);
  const now=EV(`(function(){ var ex=dayObj().exercises[${i}]; return curLoad(ex, exState(${i},ex)); })()`);
  chk('the header still shows what the session is being lifted at', now===cut, `header ${now}, sets done at ${cut}`);
  // + set, through the real control
  const btn=D.querySelector('[data-addset="'+i+'"]');
  chk('the + set control is on screen', !!btn);
  if(btn){ btn.dispatchEvent(new w.MouseEvent('click',{bubbles:true}));
    const n=EV(`exState(${i},dayObj().exercises[${i}]).sets.length`);
    const shown=EV(`(function(){ var ex=dayObj().exercises[${i}], st=exState(${i},ex); var s=st.sets[st.sets.length-1]; return (s.w!=null)? s.w : curLoad(ex,st); })()`);
    chk('an added set shows the same weight as the sets already done', shown===cut, `added set ${shown}, sets done at ${cut}`);
  }
  // the athlete's own adjustment still wins
  EV(`exState(${i},dayObj().exercises[${i}]).w=185;`);
  chk('an explicit weight adjustment still overrides everything', EV(`(function(){ var ex=dayObj().exercises[${i}]; return curLoad(ex, exState(${i},ex)); })()`)===185);
  EV(`exState(${i},dayObj().exercises[${i}]).w=null;`);
  // an exercise with nothing logged yet follows the live max, as it always did
  EV(`S.data={}; render();`);
  const fresh=EV(`(function(){ var ex=dayObj().exercises[${i}]; return curLoad(ex, exState(${i},ex)); })()`);
  chk('an exercise with nothing logged still prescribes from the live max', fresh>cut, `${fresh} vs ${cut}`);
  // legacy: logged sets with no stamp fall through
  EV(`(function(){ var ex=dayObj().exercises[${i}], st=exState(${i},ex); st.sets[0].st='hit'; st.sets[0].reps=5; st.sets[0].w=null; })()`);
  chk('a pre-stamp legacy log falls through to the live prescription', EV(`(function(){ var ex=dayObj().exercises[${i}]; return curLoad(ex, exState(${i},ex)); })()`)===fresh);
  // ---- FIELD 2026-09-02, the lateral raise: an ACCESSORY under a READINESS change ----
  // Prescribed 20/hand, trained at 20, then the readiness check-in scored yellow: readyMult
  // 0.925 -> 18.5 -> dumbbell-rounded 17.5 on the header and on the added set. Different
  // trigger from the bench, same fault: the session re-prescribing from live inputs.
  EV('S.data={}; S.ready={date:shiftDate(),sleep:8,sore:1,stress:1}; render();');
  chk('the fixture starts on a genuinely green day', EV('readyMult()')===1, 'readyMult '+EV('readyMult()'));
  const acc=EV(`(function(){ var d=dayObj(); for(var i=0;i<d.exercises.length;i++){ var ex=d.exercises[i];
      if(!ex.maxKey && !ex.pct && ex.loadNum!=null && !isOut(ex.name)) return JSON.stringify({i:i,name:ex.name}); } return null; })()`);
  if(acc){
    const A=JSON.parse(acc);
    const before=EV(`(function(){ var ex=dayObj().exercises[${A.i}]; return curLoad(ex, exState(${A.i},ex)); })()`);
    console.log(`  ${A.name}: prescribed ${before} on a green day`);
    EV(`(function(){ var ex=dayObj().exercises[${A.i}], st=exState(${A.i},ex);
        st.sets[0].st='hit'; st.sets[0].reps=12; stampPerf(ex,st,st.sets[0]);
        st.sets[1].st='hit'; st.sets[1].reps=12; stampPerf(ex,st,st.sets[1]); save(); })()`);
    EV('S.ready={date:shiftDate(),sleep:6,sore:3,stress:4}; render();');   // the check-in, answered late
    const rm=EV('readyMult()');
    const hdr=EV(`(function(){ var ex=dayObj().exercises[${A.i}]; return curLoad(ex, exState(${A.i},ex)); })()`);
    chk('readiness now scales loads (the fixture is real)', rm<1, 'readyMult '+rm);
    chk('an accessory header holds what was lifted after a late readiness check-in', hdr===before, `header ${hdr}, sets done at ${before}`);
    const b2=D.querySelector('[data-addset="'+A.i+'"]');
    if(b2){ b2.dispatchEvent(new w.MouseEvent('click',{bubbles:true}));
      const shown=EV(`(function(){ var ex=dayObj().exercises[${A.i}], st=exState(${A.i},ex); var s=st.sets[st.sets.length-1]; return (s.w!=null)? s.w : curLoad(ex,st); })()`);
      chk('and + set on the accessory matches the sets done, not the scaled-down number', shown===before, `added ${shown}, done at ${before}`); }
    EV('S.data={}; render();');
    const fresh=EV(`(function(){ var ex=dayObj().exercises[${A.i}]; return curLoad(ex, exState(${A.i},ex)); })()`);
    chk('an accessory with nothing logged still follows readiness, as designed', fresh<before, `${fresh} vs ${before}`);
  } else console.log('  (no loaded accessory on today\'s day)');
  console.log('  problems:', bad);
  process.exit(bad?1:0);
},1500);
