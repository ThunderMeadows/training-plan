// A logged set is history. Changing the exercise weight later must not rewrite what earlier
// sets were performed at, nor what carries forward to the next session.
// Drives the real set chips - the weight is stamped by the logging handler, not by the harness.
const { JSDOM } = require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const dom=new JSDOM(fs.readFileSync(f,'utf8'),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://thundermeadows.github.io/'});
const w=dom.window,D=w.document,EV=e=>w.eval(e);
w.AudioContext=w.AudioContext||function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
const click=el=>el.dispatchEvent(new w.MouseEvent('click',{bubbles:true,cancelable:true,view:w}));
setTimeout(async()=>{
  console.log(`\n--- ${L}: a logged set keeps the weight it was done at ---`);
  EV('try{TOUR.live=false;}catch(e){} try{S.tour={done:true};}catch(e){}');
  for(const fn of ['coachIdle','ONB_ACTIVE','isStartMode']) EV(`if(typeof ${fn}==="function") ${fn}=function(){return false;};`);
  EV('S.maxes={squat:327,bench:225,dead:405,ohp:145,pull:225}; render();');
  const i=EV(`(function(){var d=dayObj();for(var k=0;k<d.exercises.length;k++){if(d.exercises[k].loadNum!=null) return k;}return -1;})()`);
  if(i<0){ console.log('  (no numeric exercise)  problems: 0'); process.exit(0); }
  const nm=EV(`dayObj().exercises[${i}].name`);
  const plan=EV(`baseLoad(dayObj().exercises[${i}])`);
  EV(`(function(){var st=exState(${i},dayObj().exercises[${i}]); delete st.w;
     st.sets.forEach(function(s){s.st='pend';delete s.w;delete s.t;}); save(); render(); return 1;})()`);
  console.log(`  ${nm}: plan ${plan} lb`);
  let bad=0;
  // Log three sets by tapping the real chips. Between sets, push the previous set's timestamp
  // back so its rest has elapsed - otherwise the mid-rest guard correctly asks for a second
  // tap, which is the guard working, not a fault. Real time passing is what the harness is
  // standing in for here.
  for(let j=0;j<3;j++){
    const chip=D.querySelector(`.set[data-ex="${i}"][data-set="${j}"]`);
    if(!chip){ console.log('  chip '+j+' missing'); bad++; break; }
    click(chip); EV('render();');
    EV(`(function(){var st=exState(${i},dayObj().exercises[${i}]);
       if(st.sets[${j}].t) st.sets[${j}].t=Date.now()-6*60*1000; save(); render(); return 1;})()`);
  }
  const stamped=JSON.parse(EV(`JSON.stringify((function(){var st=exState(${i},dayObj().exercises[${i}]);
    return st.sets.slice(0,3).map(function(s){return s.w==null?'unstamped':s.w;});})())`));
  console.log('  three sets logged, stamped at:', stamped.join(', '));
  if(stamped.some(v=>v!==plan)){ console.log('    <-- sets did not record the weight they were done at'); bad++; }
  // now drop the exercise weight for the remaining set
  const drop=EV(`(function(){var ex=dayObj().exercises[${i}],st=exState(${i},ex);
    st.w=Math.max(0, curLoad(ex,st)-wStepLb(ex.barbell)*2); save(); render(); return st.w;})()`);
  console.log('  dropped the weight to      :', drop);
  const after=JSON.parse(EV(`JSON.stringify((function(){var st=exState(${i},dayObj().exercises[${i}]);
    return st.sets.slice(0,3).map(function(s){return s.w==null?'unstamped':s.w;});})())`));
  console.log('  the three logged sets still:', after.join(', '), after.every(v=>v===plan)?'(history intact)':'<-- HISTORY REWRITTEN');
  if(!after.every(v=>v===plan)) bad++;
  console.log('  prescription still         :', EV(`baseLoad(dayObj().exercises[${i}])`), '(never editable)');
  if(EV(`baseLoad(dayObj().exercises[${i}])`)!==plan) bad++;
  // finish the last set at the new weight; that is what should carry forward
  const last=EV(`(function(){var st=exState(${i},dayObj().exercises[${i}]);return st.sets.length-1;})()`);
  const lastChip=D.querySelector(`.set[data-ex="${i}"][data-set="${last}"]`);
  if(lastChip){ click(lastChip); EV('render();'); }
  EV('S.lastPerf={}; S.when={date:"2026-08-28",time:""}; recordPerf();');
  const carried=EV(`(function(){var lp=S.lastPerf[${JSON.stringify(nm)}];return lp?lp.w:null;})()`);
  console.log('  carried to next session    :', carried, carried===drop?'(the weight settled on)':'<-- wanted '+drop);
  if(carried!==drop) bad++;
  // FIELD 2026-09-02: the header load on a VISITED day re-prescribed from live maxes and
  // today's readiness. Sets kept their stamp; the line above them did not.
  const chk=(l,ok,d)=>{ if(!ok) bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&d?'  <-- '+d:''}`); };
  try{
    EV("__twH=timeWeek; timeWeek=function(){return 1;}; S.week=1; S.splitMode='guided'; logKeys=[]; syncToNext(); render();");
    const bi=EV("dayObj().exercises.findIndex(function(e){ return e.maxKey==='bench'; })");
    if(bi>=0){
      // no exercise override: that is the path that leaked. Earlier in this harness bench has
      // one set, and it would mask the bug - the check passed on the OLD code until this line.
      EV(`S.maxes.bench=230; S.data={}; exState(${bi},dayObj().exercises[${bi}]).w=null;`);
      const at=EV(`curLoad(dayObj().exercises[${bi}], exState(${bi},dayObj().exercises[${bi}]))`);
      EV(`(function(){ var d=dayObj(); d.exercises.forEach(function(ex,k){ var st=exState(k,ex); st.sets.forEach(function(s){ s.st='hit'; s.reps=5; s.rir=2; stampPerf(ex,st,s); }); }); })();`);
      await EV('saveSessionLog(true)');
      EV("S.maxes.bench=250; render();");
      const now=EV(`curLoad(dayObj().exercises[${bi}], exState(${bi},dayObj().exercises[${bi}]))`);
      chk('a visited day\'s header load is what was lifted, not what today\'s maxes would prescribe',
          EV('isVisiting()')===true && now===at, `lifted at ${at}, header now reads ${now}`);
    }
    EV("timeWeek=__twH;");
  }catch(e){ chk('visited-day header load check ran', false, e.message); }
  console.log('  problems:', bad);
  process.exit(bad?1:0);
},1500);
