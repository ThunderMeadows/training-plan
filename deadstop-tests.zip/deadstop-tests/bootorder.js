// Boot order (2026-09-01): the disclaimer is acknowledged FIRST; the install sheet and the
// tour wait behind it and then still run. Shipped at z-index 215, the install sheet (400)
// covered the gate on a fresh phone - so "add to home screen" was the first thing an athlete
// met and the disclaimer was acknowledged by nobody.
const {JSDOM}=require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const raw=fs.readFileSync(f,'utf8');
const d=new JSDOM(raw,{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/'});
const w=d.window,EV=e=>w.eval(e);
w.AudioContext=function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
let bad=0; const chk=(l,ok,dd)=>{ if(!ok)bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&dd?'  <-- '+dd:''}`); };
const z=(re)=>{ const m=raw.match(re); return m? +m[1] : null; };
setTimeout(()=>{
  console.log(`\n--- ${L}: boot order, disclaimer first ---`);
  const zg=z(/\.disc-wrap\{position:fixed;inset:0;z-index:(\d+)/);
  const za=z(/#a2hsSheet\{position:fixed;inset:0;z-index:(\d+)/);
  const zs=z(/#bootSplash\{position:fixed;inset:0;z-index:(\d+)/);
  chk('gate outranks the install sheet', zg>za, `gate ${zg} vs install ${za}`);
  chk('splash still covers the gate', zs>zg, `splash ${zs} vs gate ${zg}`);
  chk('the add-to-home-screen flow still exists', /function a2hsShow/.test(raw) && /function a2hsDue/.test(raw), 'install flow missing');
  // a fresh phone: install is due, disclaimer unacknowledged
  EV('try{TOUR.live=false;}catch(e){} delete S.discAck; S.tour={done:false}; save();');
  chk('unacknowledged disclaimer is pending', EV('discPending()'), 'not pending');
  EV('a2hsDue=function(){ return true; }; window.__shown=0; a2hsShow=function(){ window.__shown++; };');
  EV('DISC_QUEUE=null; bootDisc(); try{ if(a2hsDue()){ if(discPending()) DISC_QUEUE=function(){ if(a2hsDue()) a2hsShow(); }; else a2hsShow(); } }catch(e){}');
  chk('install sheet does NOT jump the gate', EV('window.__shown')===0, EV('window.__shown')+' shown early');
  chk('gate is on screen', EV('!!document.getElementById("discGate")'), 'gate absent');
  EV('document.getElementById("discOk").click();');
  chk('install sheet runs once the disclaimer is acknowledged', EV('window.__shown')===1, EV('window.__shown'));
  chk('gate closed after acknowledgment', EV('!document.getElementById("discGate")'), 'gate stuck');
  // re-reading from settings must not re-fire queued prompts
  EV('window.__shown=0; DISC_QUEUE=function(){ window.__shown++; }; bootDisc(true); document.getElementById("discOk").click();');
  chk('settings re-read does not re-fire install', EV('window.__shown')===0, EV('window.__shown'));
  // --- FIELD BUG 2026-09-02 (Android): the accept button was unreachable ---
  // A row flex with align-items:center plus overflow-y:auto overflows in BOTH directions when
  // the content is taller than the screen, and the overflow cannot be scrolled to. On short
  // viewports and at large system display sizes, "I understand" sat in dead space.
  const gateCss=(raw.match(/\.disc-wrap\{[^}]*\}/)||[''])[0];
  const innerCss=(raw.match(/\.disc-inner\{[^}]*\}/)||[''])[0];
  chk('the gate scrolls', /overflow-y:\s*auto/.test(gateCss), gateCss.slice(0,80));
  chk('and does NOT centre with align-items (unreachable overflow)', !/align-items:\s*center/.test(gateCss), 'align-items:center + overflow = dead space');
  chk('it centres with margin:auto on the child instead', /margin:\s*auto/.test(innerCss), innerCss.slice(0,80));
  chk('the accept control is a real button', /<button type="button" class="daybtn" id="discOk"/.test(raw), 'still a div');
  chk('with a thumb-sized tap target', /#discOk\{[^}]*min-height:\s*4[0-9]px/.test(raw), 'no min-height');
  // it still works when pressed
  EV('delete S.discAck; DISC_QUEUE=null; save(); bootDisc();');
  chk('pressing it acknowledges', (function(){ EV('document.getElementById("discOk").click();'); return EV('!document.getElementById("discGate") && !!S.discAck'); })(), 'press did nothing');
  // and by keyboard, for anyone who cannot tap it
  EV('delete S.discAck; DISC_QUEUE=null; save(); bootDisc();');
  EV('(function(){ var b=document.getElementById("discOk"); var ev=new window.KeyboardEvent("keydown",{key:"Enter",bubbles:true}); b.dispatchEvent(ev); })();');
  chk('and by keyboard', EV('!document.getElementById("discGate") && !!S.discAck'), 'keyboard path dead');
  // --- second field report (Training Card): the accept must survive ANY document-level guard ---
  EV('delete S.discAck; DISC_QUEUE=null; save(); bootDisc();');
  // simulate a hostile guard that swallows every click at document capture, like a stuck tour
  EV('window.__hostile=function(ev){ ev.stopImmediatePropagation(); ev.preventDefault(); }; document.addEventListener("click", window.__hostile, true);');
  EV('document.getElementById("discOk").dispatchEvent(new window.MouseEvent("click",{bubbles:true,cancelable:true}));');
  chk('the accept lands even when a document guard swallows clicks', EV('!document.getElementById("discGate") && !!S.discAck'), 'swallowed');
  EV('document.removeEventListener("click", window.__hostile, true);');
  // and it is idempotent - a double tap cannot double-fire the queue
  EV('delete S.discAck; DISC_QUEUE=null; save(); bootDisc(); window.__q=0; DISC_QUEUE=function(){ window.__q++; };');
  EV('discAccept(); discAccept(); discAccept();');
  chk('accepting is idempotent', EV('window.__q')===1, EV('window.__q')+' queue runs');
  console.log('  problems: '+bad); process.exit(bad?1:0);
},1500);
