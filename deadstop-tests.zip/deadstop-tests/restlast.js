// NO REST CLOCK AFTER THE LAST SET (2026-09-03, field, with a photo: "This is the last set done
// sheet. It's still counting down even if there isn't a set to follow.")
//
// The rest clock paces the gap between sets of the same exercise. After the last set of an
// exercise there is no next set of it, so the countdown was pacing nothing - and it would still
// beep a ten-second warning and shout GO for a set that did not exist, and the "still resting"
// tap-guard would scold the athlete for starting the NEXT exercise inside a window that was
// never real. The screen printed "last set done. Next exercise when ready" and counted down
// anyway.
//
// Both halves are pinned: after the last set the screen is a DONE state with no clock, no beeps,
// no extension, and no scolding on the next exercise - AND a rest between sets of the same
// exercise, or between superset partners, still counts down exactly as before.
const { JSDOM } = require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const dom=new JSDOM(fs.readFileSync(f,'utf8'),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/',
  beforeParse(w){
    w.AudioContext=function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
    w.alert=()=>{};
  }});
const w=dom.window,D=w.document,EV=e=>w.eval(e);
let bad=0; const chk=(l,ok,d)=>{ if(!ok) bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&d?'  <-- '+d:''}`); };
const chip=()=>D.getElementById('restTick');
const txt=()=>(chip()||{textContent:''}).textContent.replace(/\s+/g,' ').trim();

setTimeout(async()=>{
  console.log(`\n--- ${L}: a countdown only when there is a set to count down to ---`);
  EV('try{TOUR.live=false;}catch(e){} S.tour={done:true}; if(typeof ONB!=="undefined"){ONB().done=true;} S.discAck={v:DISC_V,d:localDate()}; storageOK=true; S.maxes={squat:327,bench:225,dead:405,ohp:145,row:170,pull:225}; S.sound=true; S.restMin=null; S.restDismiss=null; S.pairs={}; save();');
  EV("S.splitMode='open'; S.locked={}; S.day=PLAN.days[0].code; render();");

  // pick an exercise with 2+ sets and no superset partner
  const pick=EV(`(function(){ var d=dayObj(); for(var i=0;i<d.exercises.length;i++){ var st=exState(i,d.exercises[i]); if(st.sets.length>=2 && !isOut(d.exercises[i].name)) return JSON.stringify({i:i, n:st.sets.length, name:d.exercises[i].name}); } return null; })()`);
  const ex=JSON.parse(pick||'null');
  chk('(fixture) an exercise with more than one set to work with', !!ex, 'none found');
  if(!ex){ console.log('  problems:', bad+1); process.exit(1); }

  // --- MID-EXERCISE: a set logged with sets still to come -> real countdown --------
  EV(`(function(){ var d=dayObj(), st=exState(${ex.i}, d.exercises[${ex.i}]);
      st.sets.forEach(function(s){ s.st='pend'; delete s.t; });
      st.sets[0].st='hit'; st.sets[0].t=Date.now()-5000; save(); render(); paintRest(true); })()`);
  chk('(fixture) after set 1 of '+ex.n+', the card knows a set is still to come', EV('(typeof restIsLast==="function")? restIsLast(lastCompletion()) : null')===false,
      'the card cannot tell a last set from a middle one');
  const mid=txt();
  chk('between sets the rest still counts down', /\d:\d\d/.test(mid) && !/Done/.test(mid), mid.slice(0,80));
  chk('and still offers +30s', !!chip().querySelector('[data-restext]'), 'no extension offered mid-exercise');
  chk('and the still-resting guard still protects the NEXT set of the same exercise',
      EV(`(function(){ var b=lastCompletion(); return !!(b && (Date.now()-b.t) < b.target*1000 && !((typeof restIsLast==="function")? restIsLast(b) : false)); })()`));

  // --- LAST SET: nothing left in this exercise -> done state --------------------
  EV(`(function(){ var d=dayObj(), st=exState(${ex.i}, d.exercises[${ex.i}]);
      st.sets.forEach(function(s){ s.st='hit'; s.t=Date.now()-60000; });
      st.sets[st.sets.length-1].t=Date.now()-5000; save(); render(); paintRest(true); })()`);
  chk('(fixture) after the last set, the card knows nothing follows in this exercise', EV('(typeof restIsLast==="function")? restIsLast(lastCompletion()) : null')===true,
      'the card cannot tell a last set from a middle one');
  const last=txt();
  chk('after the last set the screen says Done, not a countdown', /Done/.test(last) && !/\d:\d\d PRESCRIBED/i.test(last), last.slice(0,100));
  chk('no rest clock is running', !/^\s*\d:\d\d/.test(last) && !/\bREST \u00b7/.test(last), last.slice(0,60));
  chk('no +30s - there is nothing to extend', !chip().querySelector('[data-restext]'), 'an extension is offered after the last set');
  chk('no ten-second warning glow either', !chip().classList.contains('soon'));
  chk('the fix-it panel for the set just logged is still there', !!chip().querySelector('[data-restrep]'), 'reps editor missing on the done screen');
  chk('and the way forward is still offered', !!chip().querySelector('[data-restnext]'), 'no Next exercise control');
  chk('no beeps are booked for a set that does not exist', EV('schedB && schedB.nodes ? schedB.nodes.length : 0')===0,
      EV('schedB.nodes.length')+' oscillators scheduled');

  // --- the next exercise is not scolded ------------------------------------------
  const nxt=JSON.parse(EV(`(function(){ var d=dayObj(); for(var i=${ex.i}+1;i<d.exercises.length;i++){ if(!isOut(d.exercises[i].name)){ var st=exState(i,d.exercises[i]); if(st.sets.some(function(s){return s.st==='pend';})) return JSON.stringify({i:i}); } } return null; })()`)||'null');
  if(nxt){
    EV('S.restDismiss=null; S.focus='+nxt.i+'; render();');
    const before=EV(`exState(${nxt.i}, dayObj().exercises[${nxt.i}]).sets.filter(function(s){return s.st==='hit';}).length`);
    const btn=D.querySelector('[data-ex="'+nxt.i+'"][data-set="0"], .set[data-ex="'+nxt.i+'"]');
    if(btn){ btn.dispatchEvent(new w.MouseEvent('click',{bubbles:true})); await new Promise(r=>setTimeout(r,60)); }
    const after=EV(`exState(${nxt.i}, dayObj().exercises[${nxt.i}]).sets.filter(function(s){return s.st==='hit';}).length`);
    chk('the first set of the next exercise logs on one tap - no "still resting" scolding',
        !btn || after===before+1, btn? 'still '+after+' logged; the tap was swallowed by the rest guard' : '(no set button found to tap)');
  }

  // --- a superset partner with a set pending is NOT last ----------------------------
  if(ex.i+1<EV('dayObj().exercises.length')){
    EV(`(function(){ S.pairs=S.pairs||{}; S.pairs[S.day]=[${ex.i}];
      var d=dayObj(), a=exState(${ex.i}, d.exercises[${ex.i}]), b2=exState(${ex.i}+1, d.exercises[${ex.i}+1]);
      a.sets.forEach(function(s){ s.st='hit'; s.t=Date.now()-60000; }); a.sets[a.sets.length-1].t=Date.now()-5000;
      b2.sets.forEach(function(s){ s.st='pend'; delete s.t; });
      save(); render(); paintRest(true); })()`);
    chk('a superset partner with work left keeps the countdown - that rest is real',
        EV('(typeof restIsLast==="function")? restIsLast(lastCompletion()) : null')===false && /\d:\d\d/.test(txt()),
        'superset hand-off read as last: '+txt().slice(0,60));
    EV('S.pairs={}; save();');
  }

  console.log('  problems:', bad); process.exit(bad?1:0);
},1500);
