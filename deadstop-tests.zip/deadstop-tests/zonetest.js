// The drop zone must match gbInZone() exactly - a target that does not match the test is a
// target that lies - and it must never outlive the drag.
const { JSDOM } = require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const dom=new JSDOM(fs.readFileSync(f,'utf8'),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://thundermeadows.github.io/'});
const w=dom.window,D=w.document,EV=e=>w.eval(e);
w.AudioContext=w.AudioContext||function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
setTimeout(()=>{
  console.log(`\n--- ${L}: the drop zone ---`);
  let bad=0; const chk=(l,ok,d)=>{ if(!ok) bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&d?'  <-- '+d:''}`); };
  EV('try{TOUR.live=false;}catch(e){} try{S.tour={done:true};}catch(e){} render();');
  chk('no zone when not dragging', !D.getElementById('gbZone'));
  // start a drag, bear far from the middle
  EV("GB.drag={}; var d=gbDockPos(); GB.tx=d.x; GB.ty=d.y; gbZoneSync();");
  const z=D.getElementById('gbZone');
  chk('zone appears while dragging', !!z);
  chk('not highlighted when out of zone', z && !z.classList.contains('on'));
  // geometry must match the real test
  const geo=JSON.parse(EV(`(function(){var c=gbCenter();
    var R=Math.min(window.innerWidth||360,window.innerHeight||600)*0.18;
    return JSON.stringify({cx:c.x+57, cy:c.y+97, R:R});})()`));
  const left=parseFloat(z.style.left), top=parseFloat(z.style.top), wd=parseFloat(z.style.width);
  chk('diameter matches the zone radius', Math.abs(wd-geo.R*2)<=1, wd+' vs '+(geo.R*2));
  chk('centred on the same point the test uses',
      Math.abs((left+wd/2)-geo.cx)<=1 && Math.abs((top+wd/2)-geo.cy)<=1);
  // move him in
  EV("var c=gbCenter(); GB.tx=c.x; GB.ty=c.y; gbZoneSync();");
  chk('in-zone lights the target', EV('gbInZone()') && D.getElementById('gbZone').classList.contains('on'));
  // landing either way tears it down
  EV('gbPose();');
  chk('gone after landing in the middle', !D.getElementById('gbZone'));
  EV("GB.drag={}; gbZoneSync();");
  chk('reappears on a new drag', !!D.getElementById('gbZone'));
  EV('gbDock();');
  chk('gone after landing back at the edge', !D.getElementById('gbZone'), 'zone outlived the drag');
  console.log(`  runtime errors: ${EV('(typeof ERR_LOG!=="undefined"?ERR_LOG.length:"n/a")')}`);
  console.log('  problems:', bad);
  process.exit(bad?1:0);
},1500);
