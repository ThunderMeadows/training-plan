// DANGLING REFERENCES (2026-09-03).
//
// Three separate faults in one day were the same shape: something referred to a thing BY NAME and
// nothing ever checked the name still resolved.
//   - the fill picker rejected a candidate only if its NAME was already on the day, so it happily
//     added a second rear-delt movement under a different name (c186)
//   - deadsweep filtered out Bulk's animated host by the id `#gummyHost`, which had been renamed
//     `#gbHost` - the guard was pointing at nothing and had gone quietly inert
//   - `setbtns` checked a hand-written list of settings launchers that had drifted from the real
//     ones, and waved three broken buttons through
// None of these break anything loudly. They all just stop doing their job.
//
// Two families are checkable without opening a single screen, which matters: an earlier version of
// this scan walked every screen it could reach and flagged 47 selectors, 45 of which were fine and
// simply lived on screens the sweep never opened. A check that cries wolf 45 times out of 47 is one
// you learn to ignore - the same rot it exists to catch.
//   1. every movement NAME in every lookup table exists in the library
//   2. every id / class / data-attribute a selector NAMES appears somewhere else in the source
// Comments are stripped before counting, so a comment mentioning a name cannot make it resolve.
const { JSDOM } = require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const src=fs.readFileSync(f,'utf8');
const dom=new JSDOM(src,{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/',
  beforeParse(w){
    w.AudioContext=function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
    w.alert=()=>{};
  }});
const w=dom.window,EV=e=>w.eval(e);
let bad=0; const chk=(l,ok,d)=>{ if(!ok) bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&d?'  <-- '+d:''}`); };

setTimeout(()=>{
  console.log(`\n--- ${L}: nothing refers to something that is not there ---`);
  EV('try{TOUR.live=false;}catch(e){} S.tour={done:true}; storageOK=true; save();');

  // --- 1. movement names in every lookup table ------------------------------
  const lib=new Set(JSON.parse(EV('JSON.stringify(EXLIB.map(function(r){ return r[0]; }))')));
  chk('(fixture) the library loaded and has movements in it', lib.size>100, lib.size+' rows');

  const tables={
    VOL_PICK:  'JSON.stringify([].concat.apply([],Object.keys(VOL_PICK).map(function(k){ return VOL_PICK[k]; })))',
    VOL_OVERRIDE:'JSON.stringify(Object.keys(VOL_OVERRIDE))',
    STIM:      'JSON.stringify(Object.keys(STIM))',
    VOL_SUPPORT:'JSON.stringify(typeof VOL_SUPPORT!=="undefined"? Object.keys(VOL_SUPPORT) : [])',
    EXVID:     'JSON.stringify(typeof EXVID!=="undefined"? Object.keys(EXVID) : [])',
    'plan subs':'JSON.stringify((function(){ var o=[]; (PLAN.days||[]).forEach(function(d){ (d.exercises||[]).forEach(function(x){ (x.subs||[]).forEach(function(s){ o.push(s); }); }); }); return o; })())'
  };
  let dangling=[];
  Object.keys(tables).forEach(t=>{
    const names=JSON.parse(EV(tables[t]));
    names.filter(n=>!lib.has(n)).forEach(n=>dangling.push(t+' -> "'+n+'"'));
  });
  chk('every movement named in a lookup table is in the library',
      dangling.length===0, dangling.join(' | '));

  // --- 2. muscle keys agree across the tables that use them -------------------
  const tgt=new Set(JSON.parse(EV('JSON.stringify(Object.keys(ANA_TGT))')));
  const lbl=new Set(JSON.parse(EV('JSON.stringify(Object.keys(VOL_LABEL))')));
  const used=JSON.parse(EV(`JSON.stringify((function(){ var o=[];
      Object.keys(VOL_OVERRIDE).forEach(function(n){ for(var m in VOL_OVERRIDE[n]) o.push(m); });
      Object.keys(VOL_PICK).forEach(function(m){ o.push(m); });
      return o; })())`));
  const strayMus=[...new Set(used)].filter(m=>!tgt.has(m));
  chk('every muscle a table credits is a muscle with a target', strayMus.length===0, strayMus.join(', '));
  const unlabelled=[...tgt].filter(m=>!lbl.has(m));
  chk('every muscle with a target has a label to show', unlabelled.length===0, unlabelled.join(', '));

  // --- 3. selector names appear somewhere other than the selector -------------
  const code=src
    .replace(/\/\*[\s\S]*?\*\//g,' ')          // block comments
    .replace(/^[ \t]*\/\/.*$/gm,' ');          // whole-line comments
  const sels=new Set();
  [...code.matchAll(/closest\((['"])([^'"]+)\1\)/g)].forEach(m=>sels.add(m[2]));
  [...code.matchAll(/querySelector(?:All)?\((['"])([^'"]+)\1\)/g)].forEach(m=>sels.add(m[2]));
  const tokens=new Set();
  sels.forEach(sel=>sel.split(/[,\s>+~]+/).forEach(part=>{
    if(/^[.#][A-Za-z][-\w]*$/.test(part) || /^\[data-[-\w]+\]$/.test(part)) tokens.add(part);
  }));
  let dead=[];
  tokens.forEach(tok=>{
    const name = tok[0]==='[' ? tok.slice(1,-1) : tok.slice(1);
    const esc = name.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
    const total=(code.match(new RegExp('\\b'+esc+'\\b','g'))||[]).length;
    const inSel=(code.match(new RegExp('(?:closest|querySelector|querySelectorAll)\\(([\'"])[^\'"]*\\b'+esc+'\\b[^\'"]*\\1\\)','g'))||[]).length;
    if(total-inSel<=0) dead.push(tok);
  });
  chk('(fixture) there are selectors to examine', tokens.size>50, tokens.size+' tokens');
  chk('every id, class and data-attribute a selector names exists somewhere in the card',
      dead.length===0,
      dead.join(', ')+' — named by a selector and nowhere else, so the code around it can never run');

  console.log('  problems:', bad); process.exit(bad?1:0);
},1500);
