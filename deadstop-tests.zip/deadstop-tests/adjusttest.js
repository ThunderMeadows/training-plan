// Adjusting a set must never log it, and logging by mistap must be reversible.
const { JSDOM } = require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const dom=new JSDOM(fs.readFileSync(f,'utf8'),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://thundermeadows.github.io/'});
const w=dom.window,D=w.document,EV=e=>w.eval(e);
w.AudioContext=w.AudioContext||function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
const click=el=>el.dispatchEvent(new w.MouseEvent('click',{bubbles:true,cancelable:true,view:w}));
setTimeout(()=>{
  console.log(`\n--- ${L}: adjust a set without logging it ---`);
  EV('try{TOUR.live=false;}catch(e){} try{S.tour={done:true};}catch(e){}');
  for(const fn of ['coachIdle','ONB_ACTIVE','isStartMode']) EV(`if(typeof ${fn}==="function") ${fn}=function(){return false;};`);
  EV('S.maxes={squat:327,bench:225,dead:405,ohp:145,pull:225}; render();');
  const idx=EV(`(function(){var d=dayObj();for(var i=0;i<d.exercises.length;i++){if(d.exercises[i].loadNum!=null) return i;}return -1;})()`);
  if(idx<0){ console.log('  (no numeric exercise)  problems: 0'); process.exit(0); }
  const reset=()=>EV(`(function(){var ex=dayObj().exercises[${idx}],st=exState(${idx},ex);
    st.open=-1; st.sets.forEach(function(s){ s.st='pend'; delete s.w; delete s.t; }); save(); render(); return 1;})()`);
  const st=()=>EV(`(function(){var st=exState(${idx},dayObj().exercises[${idx}]);
    return JSON.stringify({s0:st.sets[0].st, open:st.open});})()`);
  let bad=0;
  reset();
  // 1. the badge exists on the glowing set and opens the editor without logging
  const badge=D.querySelector(`[data-setadj="0"][data-exadj="${idx}"]`);
  console.log('  weight badge on glowing set:', !!badge); if(!badge) bad++;
  if(badge){
    click(badge);
    const a=JSON.parse(st());
    console.log('  after tapping the number   : set0='+a.s0+', editor open on set '+a.open);
    if(a.s0!=='pend'){ console.log('    <-- it LOGGED the set'); bad++; }
    if(a.open!==0){ console.log('    <-- editor did not open'); bad++; }
  }
  // 2. tapping it a second time still does not log
  reset(); const b2=D.querySelector(`[data-setadj="0"][data-exadj="${idx}"]`);
  if(b2){ click(b2); EV('render();');
    const again=D.querySelector(`[data-setadj="0"][data-exadj="${idx}"]`);
    if(again) click(again);
    const c=JSON.parse(st());
    console.log('  tapped the number twice    : set0='+c.s0);
    if(c.s0!=='pend'){ console.log('    <-- logged on the second tap'); bad++; } }
  // 3. tapping the chip logs, and the undo puts it back
  reset();
  const chip=D.querySelector(`.set[data-ex="${idx}"][data-set="0"]`);
  click(chip);
  const logged=JSON.parse(st());
  console.log('  tapping the chip           : set0='+logged.s0, logged.s0==='hit'?'(logged, as intended)':'<-- did not log');
  if(logged.s0!=='hit') bad++;
  const undo=D.querySelector('#toast .toast-undo');
  console.log('  undo offered               :', !!undo); if(!undo) bad++;
  if(undo){
    click(undo);
    const back=JSON.parse(st());
    console.log('  after undo                 : set0='+back.s0, back.s0==='pend'?'(restored)':'<-- NOT restored');
    if(back.s0!=='pend') bad++;
    console.log('  toast dismissed            :', !D.querySelector('#toast .toast-undo'));
  }
  console.log('  problems:', bad);
  process.exit(bad?1:0);
},1500);
