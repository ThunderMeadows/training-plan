// 2026-09-01: the horizontal pull is a main lift and gets assessed like one. It was the alpha
// of every pull day while running on feel, the only main prescribed without a tested max.
const {JSDOM}=require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const d=new JSDOM(fs.readFileSync(f,'utf8'),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/'});
const w=d.window,EV=e=>w.eval(e);
w.AudioContext=function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
let bad=0; const chk=(l,ok,dd)=>{ if(!ok)bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&dd?'  <-- '+dd:''}`); };
setTimeout(()=>{
  console.log(`\n--- ${L}: horizontal pull assessed ---`);
  if(EV('typeof ONB_ORDER')==='undefined'){ console.log('  ok    (no generator on this card - nothing to test)\n  problems: 0'); process.exit(0); }
  chk('row is in the assessed lifts', EV('ONB_ORDER.indexOf("row")>-1'), EV('JSON.stringify(ONB_ORDER)'));
  chk('it has a name and a cue for the ramp', EV('!!(ONB_LIFTS.row&&ONB_LIFTS.row.n&&ONB_LIFTS.row.cue)'), 'missing');
  chk('it has seed multipliers for every experience level', EV('!!(ONB_BWM.row&&ONB_BWM.row.new&&ONB_BWM.row.some&&ONB_BWM.row.vet)'), 'missing');
  chk('seed lands between the press and the squat', EV('ONB_BWM.row.some>ONB_BWM.ohp.some && ONB_BWM.row.some<ONB_BWM.squat.some'), EV('ONB_BWM.row.some'));
  chk('no main lift is left without a tested max', EV('Object.keys(PG_NOMAXMAIN).length')===0, EV('JSON.stringify(PG_NOMAXMAIN)'));
  chk('the raw-start floor covers it', EV('typeof ONB_RAW_MAXES.row==="number"'), 'missing');
  chk('the You screen lists it', EV('MAXINFO.some(function(m){return m.k==="row";})'), 'absent');
  chk('progress counts follow the list, not a hard-coded 4', !/of 4 (done|retested)/.test(fs.readFileSync(f,'utf8')), 'hard-coded count');
  // a generated plan must prescribe it on percentages, like every other main
  EV('var o=ONB(); o.wt=200; o.exp="some"; o.sex="m"; o.goal="build"; o.days=4; o.res={}; o.prefs={}; o.limits=[];');
  const built=EV(`(function(){
    var mx={}; ONB_ORDER.forEach(function(l){ mx[l]=Math.round(200*(ONB_BWM[l].some)); });
    var p=generatePlan({maxes:mx, goal:'build', days:4, limits:[], emphasis:'balanced', weak:'auto', res:{}, prefs:{}});
    var rows=[]; p.days.forEach(function(dd){ dd.exercises.forEach(function(ex){ if(ex.maxKey==='row') rows.push({n:ex.name,pct:!!ex.pct}); }); });
    return JSON.stringify({rows:rows, days:p.days.length});
  })()`);
  const R=JSON.parse(built);
  chk('the plan actually programs a horizontal pull main', R.rows.length>0, 'no row-keyed lift in the plan');
  chk('and prescribes it on percentages', R.rows.length>0 && R.rows.every(r=>r.pct), JSON.stringify(R.rows));
  // untested athletes still get a number rather than a blank
  const fb=EV(`(function(){ var o=ONB(); o.res={}; var m={};
    ONB_ORDER.forEach(function(l){ m[l]=(o.res[l]&&o.res[l].pm)||Math.round(o.wt*({squat:.6,bench:.45,dead:.8,ohp:.3,row:.4})[l]); });
    return JSON.stringify(m); })()`);
  chk('an unassessed row still falls back to a number', typeof JSON.parse(fb).row==='number' && JSON.parse(fb).row>0, fb);
  // --- all five lifts carry their part of the program ---
  chk('every main lift has an expected-strength ratio', EV('Object.keys(PG_RATIO).length')===EV('ONB_ORDER.length'),
      EV('Object.keys(PG_RATIO).join(",")')+' vs '+EV('ONB_ORDER.join(",")'));
  chk('the row is one of them', EV('typeof PG_RATIO.row==="function"'), 'missing');
  // a lagging row must be DETECTED, not just nameable
  const lag=EV(`(function(){ var m={squat:400,bench:300,dead:480,ohp:186,row:150};
    var d=PG_diagnose(m); return JSON.stringify({weak:d.weak, gap:d.gaps.row}); })()`);
  chk('a lagging row is picked as the weak lift', JSON.parse(lag).weak==='row', lag);
  chk('and a healthy row is not', EV(`(function(){ var m={squat:400,bench:300,dead:480,ohp:186,row:225};
    return PG_diagnose(m).weak!=='row'; })()`), 'flagged a proportionate row');
  // a prioritised row must actually get first billing in the built plan
  const pri=EV(`(function(){
    var m={squat:400,bench:300,dead:480,ohp:186,row:150};
    var base=generatePlan({maxes:m, goal:'build', days:4, limits:[], emphasis:'balanced', weak:'none', res:{}, prefs:{}});
    var pr=generatePlan({maxes:m, goal:'build', days:4, limits:[], emphasis:'balanced', weak:'row', res:{}, prefs:{}});
    function setsFor(p){ var n=0; p.days.forEach(function(d){ d.exercises.forEach(function(e){ if(e.maxKey==='row') n+=e.sets; }); }); return n; }
    function titled(p){ return p.days.some(function(d){ return /Row Priority|\u2605/.test(d.title); }) || /Row Priority/.test(p.block||''); }
    return JSON.stringify({base:setsFor(base), pri:setsFor(pr), titled:titled(pr)});
  })()`);
  const P=JSON.parse(pri);
  chk('prioritising the row buys it more work', P.pri>P.base, JSON.stringify(P));
  chk('and the block says so', P.titled, 'priority never named');
  chk('the row is selectable as a priority lift', /\['row','Barbell row'\]/.test(fs.readFileSync(f,'utf8')), 'not offered');
  // the invented ratio must be declared where it is used
  chk('the row ratio is declared as ours in Provenance',
      EV('provenanceHTML()').indexOf('lagging lift is measured against')>=0, 'undeclared');
  console.log('  problems: '+bad); process.exit(bad?1:0);
},1500);
