// Guards the fix that was found by accident: gbApplyFlavour MUST force a style/layout flush
// after writing the filter, or the bear's promoted layer keeps its old paint on iOS.
const { JSDOM } = require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3];
const dom=new JSDOM(fs.readFileSync(f,'utf8'),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://thundermeadows.github.io/'});
const w=dom.window,D=w.document,EV=e=>w.eval(e);
w.AudioContext=w.AudioContext||function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
setTimeout(()=>{
  console.log(`\n--- ${L}: does applying a flavour force a repaint flush? ---`);
  const host=D.getElementById('gbHost');
  let gcs=0, rect=0;
  const realGCS=w.getComputedStyle;
  w.getComputedStyle=function(el){ if(el===host) gcs++; return realGCS.apply(w,arguments); };
  const realRect=host.getBoundingClientRect.bind(host);
  host.getBoundingClientRect=function(){ rect++; return realRect(); };
  EV("S.gbFlav='cherry'; gbApplyFlavour();");
  const a={gcs,rect}; gcs=0; rect=0;
  EV("S.gbFlav='amber'; gbApplyFlavour();");
  const b={gcs,rect};
  console.log(`  applying Cherry: getComputedStyle=${a.gcs}  getBoundingClientRect=${a.rect}`);
  console.log(`  applying Amber : getComputedStyle=${b.gcs}  getBoundingClientRect=${b.rect}`);
  const ok = a.gcs>0 && a.rect>0 && b.gcs>0 && b.rect>0;
  console.log('  flush forced on every apply:', ok ? 'yes' : 'NO - the fix has been removed');
  console.log('  problems:', ok?0:1);
  process.exit(ok?0:1);
},1500);
