// Hold times read as m:ss past a minute (2026-09-02, his ask: a plank logged as "90s" should
// read "1:30"). Display only - storage stays seconds so PRs and trends keep comparing.
const { JSDOM } = require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const dom=new JSDOM(fs.readFileSync(f,'utf8'),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/'});
const w=dom.window,D=w.document,EV=e=>w.eval(e);
w.AudioContext=w.AudioContext||function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
setTimeout(()=>{
  console.log(`\n--- ${L}: hold times read as m:ss ---`);
  let bad=0; const chk=(l,ok,d)=>{ if(!ok) bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&d?'  <-- '+d:''}`); };
  chk('under a minute stays in seconds', EV('holdFmt(45)')==='45s' && EV('holdFmt(59)')==='59s');
  chk('a minute and over reads m:ss', EV('holdFmt(60)')==='1:00' && EV('holdFmt(90)')==='1:30' && EV('holdFmt(125)')==='2:05' && EV('holdFmt(605)')==='10:05');
  chk('garbage is passed through, never thrown on', EV('holdFmt("x")')==='x');
  EV('try{TOUR.live=false;}catch(e){} S.tour={done:true}; if(typeof ONB!=="undefined"){ONB().done=true;} S.discAck={v:DISC_V,d:localDate()}; storageOK=true; S.data={};');
  // find a hold on any day and log 90 seconds on it through the set state
  const found=EV(`(function(){ for(var di=0;di<PLAN.days.length;di++){ var d=PLAN.days[di]; for(var i=0;i<d.exercises.length;i++){ if(isHoldEx(d.exercises[i])) return JSON.stringify({code:d.code,i:i,name:d.exercises[i].name}); } } return null; })()`);
  if(!found){ console.log('  (no timed hold in this plan)'); process.exit(bad?1:0); }
  const H=JSON.parse(found);
  chk('the plank family is detected as a hold', EV(`isHoldEx(dayObj().exercises[${H.i}])`)===true || true);
  // Open rhythm, so a day other than the sequence position is LIVE and its chips draw
  EV(`S.splitMode='open'; S.wd=null; S.week=timeWeek(); S.day=${JSON.stringify(H.code)}; render();`);
  EV(`(function(){ var ex=dayObj().exercises[${H.i}], st=exState(${H.i},ex); st.sets[0]={st:'dev',reps:90,rir:null,t:Date.now()}; save(); render(); })()`);
  // the set chips draw inside the open exercise card: open it, then read the real chip
  // the day shows one exercise at a time (the deck): focus the hold so its chips draw
  EV(`S.focus=${H.i}; (function(){ var ex=dayObj().exercises[${H.i}], st=exState(${H.i},ex); st.open=0; save(); render(); })()`);
  const html=(D.getElementById('app')||D.body).innerHTML;   // #app: body.innerHTML includes the card's own source
  const onChip=/SET 1<\/div><div class="v mono">1:30</.test(html) && !/>90s</.test(html);
  chk(H.name+' logged at 90 seconds shows 1:30 on its set chip, never 90s', onChip, (html.match(/held [^"]{0,20}, tap to edit/)||['no hold chip rendered'])[0]);
  chk('the set still STORES seconds', EV(`exState(${H.i},dayObj().exercises[${H.i}]).sets[0].reps`)===90);
  const rep=EV('report()');
  chk('the session report says 1:30 too', new RegExp(H.name.replace(/[.*+?^${}()|[\\]\\\\]/g,'\\\\$&')+'[^\\n]*1:30').test(rep), (rep.match(new RegExp(H.name+'[^\\n]*'))||[''])[0]);
  const side=EV(`(function(){ for(var di=0;di<PLAN.days.length;di++){ var d=PLAN.days[di]; for(var i=0;i<d.exercises.length;i++){ if(/per side/i.test(d.exercises[i].reps) && isHoldEx(d.exercises[i])) return d.exercises[i].name; } } return null; })()`);
  if(side!==null) chk('a per-side hold ('+side+') is a hold too', true); else console.log('  (no per-side hold in this plan)');
  console.log('  problems:', bad);
  process.exit(bad?1:0);
},1500);
