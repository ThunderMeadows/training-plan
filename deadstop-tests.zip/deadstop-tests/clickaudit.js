// Real bubbling clicks, the way a finger does it. Checks four things per control:
// state changed, highlight followed, sheet survived, and the visible effect actually applied.
const { JSDOM } = require('jsdom'); const fs = require('fs');
const f = process.argv[2], label = process.argv[3] || f;
const dom = new JSDOM(fs.readFileSync(f, 'utf8'),
  { runScripts:'dangerously', pretendToBeVisual:true, url:'https://thundermeadows.github.io/' });
const w = dom.window, D = w.document, EV = e => w.eval(e);
w.AudioContext = w.AudioContext || function(){ return { state:'running', resume(){}, createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}}, createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}}, destination:{}, currentTime:0 }; };
const click = el => el.dispatchEvent(new w.MouseEvent('click',{bubbles:true,cancelable:true,view:w}));

setTimeout(() => {
  const out=[]; const say=s=>out.push(s);
  say(`\n===== ${label} — REAL CLICKS =====`);
  for (const fn of ['coachIdle','ONB_ACTIVE','isStartMode']) EV(`if(typeof ${fn}==="function") ${fn}=function(){return false;};`);
  // Put the card in a real athlete's state. A fresh profile auto-starts the 43-step
  // walkthrough, and tourGuard legitimately swallows every tap outside the coach while it
  // runs - so testing without finishing it reports every control as dead. That is the tour
  // working, not a bug, and it is exactly the trap that makes a harness lie to you.
  EV('try{ TOUR.live=false; }catch(e){} try{ S.tour={done:true}; save(); }catch(e){}');
  const _ch = D.getElementById('coachHost'); if (_ch) _ch.remove();
  EV('render();');
  say(`walkthrough live: ${EV('(typeof TOUR!=="undefined")?TOUR.live:"n/a"')} (dismissed for testing)`);

  // decide by what actually renders, not by whether the sheet machinery exists: the Session
  // Card ships SET_OPEN but keeps the gear disabled and puts settings inline on You/MAX.
  let inSheet = false;
  if (EV('typeof SET_OPEN')!=='undefined') { EV('SET_OPEN=true; settingsSync();');
    inSheet = !!D.querySelector('#setHost .set-sheet') && !!D.querySelector('#setHost [data-thm]'); }
  if (!inSheet) { EV('SET_OPEN=false; try{settingsSync();}catch(e){} S.day="MAX"; render();'); }
  const scope = inSheet ? '#setHost ' : '';
  say(`surface: ${inSheet ? 'gear sheet' : 'inline You/MAX screen'}`);

  const KEY = {'data-thm':'theme','data-lightmode':'lightMode','data-fnt':'font','data-tsz':'tsize','data-uimode':'uiMode',
    'data-radj':'restAdj','data-kaon':'kaOn','data-snd':'snd','data-tone':'tone',
    'data-brth':'breathe','data-jump':'jump','data-gbflav':'gbFlav'};

  let ctlBad=0;
  say('\n control        | state | highlight | sheet | effect');
  say(' ---------------|-------|-----------|-------|-------');
  for (const attr of Object.keys(KEY)) {
    let chips=[...D.querySelectorAll(scope+'['+attr+']')];
    if(!chips.length){ say(` ${attr.padEnd(14)} | not rendered`); continue; }
    // Light needs a theme whose two renditions actually differ before its effect can be seen.
    // Left to the default, the audit had just selected Coach - whose day variant IS the
    // stylesheet, and whose Auto already resolved to day - so a perfectly bound control
    // reported NO CHANGE. This is the "put the card in a real state first" rule, not a
    // softened check: the row still goes red if the handler is unbound, verified that way.
    if (attr==='data-lightmode'){
      EV("S.theme='iron'; S.lightMode='night'; applyTheme();");
      try{ EV('settingsRefresh();'); }catch(e){}
      chips=[...D.querySelectorAll(scope+'['+attr+']')];   // re-read: 'on' just moved
    }
    const target = chips.find(c=>!c.classList.contains('on')) || chips[0];
    const val = target.getAttribute(attr), key = KEY[attr];
    const before = EV(`JSON.stringify(S["${key}"])`);
    const bgBefore = D.documentElement.style.getPropertyValue('--bg');
    const fontBefore = D.body.style.fontFamily;
    const zoomBefore = D.body.style.zoom;
    try { click(target); } catch(e){ say(` ${attr.padEnd(14)} | THREW ${e.message}`); continue; }
    const after = EV(`JSON.stringify(S["${key}"])`);
    const stillOpen = inSheet ? !!D.querySelector('#setHost .set-sheet') : true;
    const now = D.querySelector(scope+'['+attr+'="'+val+'"]');
    const lit = now ? now.classList.contains('on') : null;

    // visible effect, where there is one to check
    let effect='n/a';
    if (attr==='data-thm')   effect = (D.documentElement.style.getPropertyValue('--bg')!==bgBefore) ? 'vars moved' : 'NO CHANGE';
    if (attr==='data-lightmode') effect = (D.documentElement.style.getPropertyValue('--bg')!==bgBefore) ? 'vars moved' : 'NO CHANGE';
    if (attr==='data-fnt')   effect = (D.body.style.fontFamily!==fontBefore) ? 'font moved' : 'NO CHANGE';
    if (attr==='data-tsz')   effect = (D.body.style.zoom!==zoomBefore) ? 'zoom moved' : 'NO CHANGE';
    if (attr==='data-gbflav')effect = EV('(typeof gbFlavour==="function"? gbFlavour().id : "?")')===val ? 'flavour set' : 'NO CHANGE';

    if(before===after || lit!==true || !stillOpen || effect==='NO CHANGE') ctlBad++;
    say(` ${attr.padEnd(14)} | ${before!==after?' ok  ':' DEAD'} | ${lit===true?'   ok    ':lit===null?' missing ':'  STALE  '} | ${stillOpen?' ok  ':'CLOSED'} | ${effect}`);
  }

  // every theme, one after another
  say('\n every theme in turn:');
  const ids = JSON.parse(EV('JSON.stringify(THEMES.map(function(t){return t.id;}))'));
  let themeBad=0;
  for (const id of ids){
    const c=D.querySelector(scope+'[data-thm="'+id+'"]');
    if(!c){ say(`   ${id}: chip missing`); themeBad++; continue; }
    const before=D.documentElement.style.getPropertyValue('--bg');
    click(c);
    const got=EV('S.theme'), bg=D.documentElement.style.getPropertyValue('--bg');
    // a theme with an empty v:{} (Coach) deliberately clears the vars and falls back to the
    // stylesheet defaults, so an empty --bg is the CORRECT result for it, not a failure
    // Ask the CARD which palette is actually rendering, rather than reading the table here.
    // Themes carry a day and a night variant now; Coach's day variant is deliberately empty
    // and falls back to the stylesheet, so an empty --bg is the CORRECT result for that one.
    const wantsVars = EV(`(function(){var t=THEMES.find(function(x){return x.id==='${id}';});return !!(t&&themeVars(t)&&Object.keys(themeVars(t)).length>0);})()`);
    const ok = got===id && (wantsVars ? bg!=='' : bg==='');
    if(!ok) themeBad++;
    say(`   ${id.padEnd(9)} S.theme=${String(got).padEnd(9)} --bg=${(bg||'(defaults)').padEnd(10)} ${ok?'':'  <-- PROBLEM'}`);
  }
  say(` themes with problems: ${themeBad}`);

  if (inSheet){
    say('\n close paths (real clicks):');
    const done=[...D.querySelectorAll('#setHost [data-setclose]')].pop();
    click(done); say(`   Done closes:     ${!D.querySelector('#setHost .set-sheet')}`);
    EV('SET_OPEN=true; settingsSync();');
    const x=D.querySelector('#setHost .set-x'); click(x);
    say(`   X closes:        ${!D.querySelector('#setHost .set-sheet')}`);
    EV('SET_OPEN=true; settingsSync();');
    const wrap=D.querySelector('#setHost .hw-wrap'); click(wrap);
    say(`   backdrop closes: ${!D.querySelector('#setHost .set-sheet')}`);
  }
  say(`\n runtime errors: ${EV('(typeof ERR_LOG!=="undefined"?ERR_LOG.length:"n/a")')}`);
  say(`\n problems: ${ctlBad+themeBad}`);
  console.log(out.join('\n'));
  process.exit((ctlBad+themeBad)?1:0);
}, 1400);
