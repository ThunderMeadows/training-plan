# Credentials and this archive

**This archive must not be published.** It is a test suite, not a deployed asset.

Until 2026-09-10 it contained `access-codes.json`: 253 plaintext access codes including the
admin code, whose fingerprints matched the shipped card exactly. Those were live credentials.
The deploy instructions of the day told the owner to place this archive at the root of a public
repository, in the same commit as the app — which would have published the codes the card keeps
as one-way hashes in its source. Found by an independent review (finding D1).

## Now

- `access-codes.json` is gone from the archive and is in `.gitignore`.
- `fixture-codes.js` generates synthetic codes (`TEST-xxxx-xxxx`), writes their fingerprints
  into `ACCESS_CODES` in the test window, and re-encrypts a synthetic pool under the synthetic
  admin code using the card's own scheme — so the real decryption path and every security
  property built on it are still exercised. An earlier attempt stubbed `poolOpen()` instead;
  that bypassed the lock eight of `accesstest`'s own security checks assert on, and they went
  green against the stub. Encrypt, never stub.
- The synthetic pool matches production's SHAPE (four dated batches, 200 athlete / 50 coach) so
  pool-accounting assertions remain meaningful. No value in it is real.

## If you need to test against production codes

Put the real `access-codes.json` beside this file locally. `loadCodes()` prefers it when
present. Never commit it. For CI, supply it as a secret at run time, not as a repo file.

## If the codes were ever published

Removing the file is not enough — git history keeps it. Treat them as exposed, regenerate,
re-seed the Worker, and rotate the admin code first.
