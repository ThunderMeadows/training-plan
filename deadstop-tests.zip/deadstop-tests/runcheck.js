// Harness for the standalone runner. Stages collisions on purpose instead of waiting for a
// random spawn to land in his lane, advances the loop by hand, and captures the frame - so the
// crash behaviour is observed rather than argued about.
const C=require('canvas'), {JSDOM}=require('jsdom'), fs=require('fs');
const file=process.argv[2]||'bulk-run.html';
const cv=C.createCanvas(390,780), ctx=cv.getContext('2d');
const dom=new JSDOM(fs.readFileSync(file,'utf8'),{runScripts:'dangerously',pretendToBeVisual:true,
  beforeParse(w){
    Object.defineProperty(w,'innerWidth',{value:390,configurable:true});
    Object.defineProperty(w,'innerHeight',{value:780,configurable:true});
    w.HTMLCanvasElement.prototype.getContext=function(){ return ctx; };
    w.Image=C.Image;
  }});
const w=dom.window, EV=e=>w.eval(e);
const errs=[]; w.addEventListener('error',e=>errs.push(e.message));
let bad=0;
const chk=(l,ok,d)=>{ if(!ok) bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&d?'  <-- '+d:''}`); };

setTimeout(()=>{
  console.log('\n--- bulk run: staged collisions ---');
  w.document.getElementById('go').onclick();
  EV('W=390;H=780;DPR=1;');

  // bank some slices first, so the penalty has something to take
  EV('score=8; scoreEl.textContent=8; spd=10; lane=0; tLane=0; py=0; slide=0; hurt=0;');
  const before={score:EV('score'), spd:EV('spd')};

  // stage a low stack dead ahead and walk him into it
  EV('items=[{z:60,lane:0,type:"ob"}];');
  EV('running=true; loop();');
  const after={score:EV('score'), spd:EV('spd'), hurt:EV('hurt'), flash:EV('typeof flash!=="undefined"?flash:-1'), shake:EV('shake')};
  console.log(`  before: ${before.score} slices at speed ${before.spd.toFixed(1)}`);
  console.log(`  after : ${after.score} slices at speed ${after.spd.toFixed(1)}`);
  chk('hitting a stack costs the slices', after.score===0, 'score untouched');
  chk('and breaks his speed', after.spd < before.spd-2, `${before.spd.toFixed(1)} -> ${after.spd.toFixed(1)}`);
  chk('a stumble is registered', after.hurt>0);
  chk('the screen flashes', after.flash>0, 'no visible feedback');
  chk('and shakes', after.shake>0);

  // the same obstacle must not charge him twice
  const s1=EV('hurt');
  EV('loop(); loop(); loop();');
  chk('one obstacle, one stumble', EV('hurt') < s1 && EV('hurt')>0, 'hit repeatedly across frames');

  // a bench must be survivable by sliding, and fatal to the run if not
  EV('score=6; scoreEl.textContent=6; spd=10; hurt=0; slide=40; py=0; lane=0; tLane=0;');
  EV('items=[{z:60,lane:0,type:"bench"}]; loop();');
  chk('sliding under a bench costs nothing', EV('score')===6, 'penalised for doing it right');
  EV('score=6; hurt=0; slide=0; spd=10;');
  EV('items=[{z:60,lane:0,type:"bench"}]; loop();');
  chk('running into one does cost', EV('score')===0);

  // and jumping clears a stack
  EV('score=5; scoreEl.textContent=5; spd=10; hurt=0; slide=0; py=120; vy=2; lane=0; tLane=0;');
  EV('items=[{z:60,lane:0,type:"ob"}]; loop();');
  chk('jumping clears a stack', EV('score')===5, 'punished mid-air');

  // capture what a crash actually looks like
  EV('score=9; scoreEl.textContent=9; spd=11; hurt=0; slide=0; py=0; items=[{z:40,lane:0,type:"ob"},{z:520,lane:1,type:"bench"},{z:820,lane:-1,type:"pz"}]; loop();');
  fs.writeFileSync('/mnt/user-data/outputs/bulk-run-crash.png', cv.toBuffer('image/png'));
  console.log(`  runtime errors: ${errs.length? errs.slice(0,2):'none'}`);
  if(errs.length) bad++;
  console.log('  problems:', bad);
  process.exit(bad?1:0);
},1200);
