// FIELD 2026-09-10, from a coach watching his athlete: "he set his goal for lose fat and the
// reps, sets, and rest was not at all near matching the kind of training that would help
// someone lose weight."
//
// Three defects and one programming call came out of it.
//
// 1. exSets() and exReps() both short-circuit on isStartProgram() - the beginner template's
//    own numbers, deliberately, because a beginner never asked for a goal. exRest() had no
//    such check, so a Start athlete with a goal set got 2x10 with the GOAL's rest attached.
//    Neither beginner programming nor goal programming.
// 2. The Settings goal line promised the goal's scheme to every card, including Start cards
//    that would never run it. The card described a program it was not running.
// 3. Every goal carries a `cardio` line. It had ZERO render sites in the card - dead data
//    since it was written. For "Lose Weight" that line IS the answer.
// 4. His call: cut dropped load to 65-75% and rest to 1:30. Load is what keeps muscle in a
//    deficit, so intensity goes to maintenance and the volume comes down instead.
//
// What this holds: cut is heavier and shorter than it was; it is still distinct from every
// other goal; Start keeps its own rest while still obeying the movement-class caps; and the
// cardio guidance reaches the screen.
const {JSDOM}=require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const raw=fs.readFileSync(f,'utf8');
const AC=function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
let bad=0;
const chk=(l,ok,d)=>{ if(ok!==true)bad++; if(typeof ok==='string'&&ok.slice(0,3)==='ERR') d=ok;
  console.log(`  ${ok===true?'ok  ':'FAIL'}  ${l}${ok!==true&&d?'  <-- '+d:''}`); };

const w=new JSDOM(raw,{runScripts:'dangerously',pretendToBeVisual:true,url:'https://thundermeadows.github.io/',
  beforeParse(win){ win.AudioContext=AC; }}).window;
const E=e=>{ try{ return w.eval(e); }catch(err){ return 'ERR '+err.message; } };
const N=e=>{ const v=E(e); return typeof v==='number'? v : NaN; };

console.log(`\n--- ${L}: the cut goal, and what a goal is allowed to change ---`);

setTimeout(()=>{
  // ---- 4. cut is maintenance intensity on trimmed volume ----
  chk('cut mains are heavy enough to hold muscle (top set >=80%)',
      N('GOALS.cut.pct[4]*100')>=80, 'top set '+N('GOALS.cut.pct[4]*100')+'%');
  chk('cut opens at maintenance, not light (first week >=72%)',
      N('GOALS.cut.pct[0]*100')>=72, 'week 1 '+N('GOALS.cut.pct[0]*100')+'%');
  chk('cut main volume is trimmed, not raised (<=3 sets)',
      N('GOALS.cut.sets')<=3, 'sets '+N('GOALS.cut.sets'));
  chk('cut accessory volume is trimmed too (<=2 sets)',
      N('GOALS.cut.accSets')<=2, 'accSets '+N('GOALS.cut.accSets'));
  chk('cut rest is long enough for the sets to stay honest (>=2:00)',
      E("restSecs(GOALS.cut.restMain)>=120")===true, 'rest '+E('GOALS.cut.restMain'));
  chk('cut is heavier than hypertrophy, since it is protecting muscle not adding it',
      N('GOALS.cut.pct[4]')>N('GOALS.hypertrophy.pct[4]'),
      'cut '+N('GOALS.cut.pct[4]')+' vs hyp '+N('GOALS.hypertrophy.pct[4]'));
  chk('cut still carries less total main volume than hypertrophy',
      N('GOALS.cut.sets')<N('GOALS.hypertrophy.sets'), 'cut '+N('GOALS.cut.sets')+' vs hyp '+N('GOALS.hypertrophy.sets'));

  // every goal must still resolve to its own scheme - goaltest guards the six, this guards
  // that the cut edit did not collapse it onto a neighbour
  chk('the goals still resolve to distinct schemes',
      E(`(function(){var seen={},ids=Object.keys(GOALS).filter(function(k){return !!GOALS[k];});
         for(var i=0;i<ids.length;i++){var g=GOALS[ids[i]];
           var sig=g.sets+'x'+g.reps+'@'+g.pct.join(',')+'/'+g.restMain;
           if(seen[sig]) return false; seen[sig]=1; }
         return true; })()`)===true, 'two goals share a scheme');

  // ---- 3. the cardio guidance reaches a screen ----
  // read the rendered page as TEXT with script source removed - matching against
  // document.body.innerHTML would hit the inline script's own source and pass vacuously
  E("window.__vis=function(){ S.day='MAX'; render(); var b=document.body.cloneNode(true);"
    +" Array.prototype.slice.call(b.querySelectorAll('script')).forEach(function(s){ s.parentNode.removeChild(s); });"
    +" return b.textContent||''; }");
  chk('every goal still carries its cardio line',
      E("Object.keys(GOALS).filter(function(k){return !!GOALS[k];}).every(function(k){return typeof GOALS[k].cardio==='string' && GOALS[k].cardio.length>10;})")===true,
      'a goal lost its cardio line');
  // boot the card into a real athlete's state: past the access gate, past onboarding, past
  // the walkthrough. Without this the MAX screen never renders and every DOM assertion below
  // passes or fails on an empty page - a harness lying to you either way.
  E("for(var i=0,fs=['coachIdle','ONB_ACTIVE','isStartMode'];i<fs.length;i++){ try{ if(typeof window[fs[i]]==='function') window[fs[i]]=function(){return false;}; }catch(e){} }");
  E("try{ TOUR.live=false; }catch(e){} try{ S.tour={done:true}; }catch(e){}");
  E("S.access={role:'coach', until:'2027-12-31'};");
  E("S.profile=S.profile||{}; S.profile.goal='cut'; S.mode=null; save();");
  const html=E('__vis()');
  chk('the cut cardio guidance is actually rendered',
      typeof html==='string' && html.indexOf('deficit does the losing')>=0,
      'cardio line still has no render site');

  // ---- 2. Settings tells a Start athlete the truth ----
  E("S.mode='start';");
  const sh=E('__vis()');
  chk('a Start card is NOT promised the goal scheme it will not run',
      typeof sh==='string' && /mains\s*\d+\u00d7/.test(sh)===false,
      'still promising the goal scheme on Start');
  chk('a Start card is told what it will actually get',
      typeof sh==='string' && sh.indexOf('2 sets of 10')>=0,
      'no plain statement of the Start prescription');

  // ---- 1. Start keeps its own rest, and the class caps still bite ----
  const mainEx={name:'Barbell Row', reps:'10', sets:2, rest:'1:30', maxKey:'row', barbell:true};
  E("S.mode='start'; S.profile.goal='cut';");
  chk('a Start main does not inherit the goal rest',
      E(`exRest(${JSON.stringify(mainEx)})`)!=='2:30',
      'Start main got the cut rest 2:30');
  const plank={name:'Plank', reps:'30s', sets:2, rest:'1:30'};
  const pr=E(`exRest(${JSON.stringify(plank)})`);
  chk('and a Start plank is still capped by its movement class',
      E(`restSecs(exRest(${JSON.stringify(plank)}))<=60`)===true,
      'plank rest '+pr+' - class cap was skipped');
  E("S.mode=null;");
  chk('off Start, a main DOES take the goal rest',
      E(`exRest(${JSON.stringify(mainEx)})`)==='2:30',
      'got '+E(`exRest(${JSON.stringify(mainEx)})`));

  console.log('\nproblems: '+bad);
  process.exit(bad?1:0);
}, 2200);
