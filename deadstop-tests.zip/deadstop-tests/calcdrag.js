// THE CALCULATOR GOES WHERE THE ATHLETE PUTS IT (2026-09-03, his ask).
// Drag the button and it snaps to the nearest screen edge and stays there - across renders,
// reloads and backups. A tap still opens it; a drag never does. The position is an edge and a
// fraction along it, so it survives the viewport changing under it.
const { JSDOM } = require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const dom=new JSDOM(fs.readFileSync(f,'utf8'),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/',
  beforeParse(w){
    w.AudioContext=function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
    w.alert=()=>{};
  }});
const w=dom.window,D=w.document,EV=e=>w.eval(e);
let bad=0; const chk=(l,ok,d)=>{ if(!ok) bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&d?'  <-- '+d:''}`); };
const fab=()=>D.getElementById('calcFab');
const W=()=>w.innerWidth, H=()=>w.innerHeight;
// jsdom has no PointerEvent, so the card falls back to mouse events - the same path phones
// without pointer events take, and the same fallback Bulk's drag uses.
const press=(x,y)=>fab().dispatchEvent(new w.MouseEvent('mousedown',{bubbles:true,clientX:x,clientY:y}));
const moveTo=(x,y)=>fab().dispatchEvent(new w.MouseEvent('mousemove',{bubbles:true,clientX:x,clientY:y}));
const release=(x,y)=>fab().dispatchEvent(new w.MouseEvent('mouseup',{bubbles:true,clientX:x,clientY:y}));
const click=()=>fab().dispatchEvent(new w.MouseEvent('click',{bubbles:true}));
// FIELD 2026-09-04: "magnetically impossible to pull away from the top left corner." The first
// version of this harness dispatched every move ON THE BUTTON and never re-rendered mid-drag, so
// it exercised neither of the two faults that actually broke it: listeners bound to a 46px target
// the finger leaves immediately, and calcPaint() repositioning the button on every render while
// the drag was still live. Moves now go to the DOCUMENT, as a real finger's do once it is off the
// button, and the card re-renders in the middle of the drag the way it constantly does in use.
const moveDoc=(x,y)=>D.dispatchEvent(new w.MouseEvent('mousemove',{bubbles:true,clientX:x,clientY:y}));
const releaseDoc=(x,y)=>D.dispatchEvent(new w.MouseEvent('mouseup',{bubbles:true,clientX:x,clientY:y}));
const drag=(x0,y0,x1,y1)=>{
  press(x0,y0);
  moveDoc((x0+x1)/2,(y0+y1)/2);
  EV('render();');                       // the card redraws constantly; a drag must survive it
  moveDoc(x1,y1);
  releaseDoc(x1,y1);
  click();
};

setTimeout(async()=>{
  console.log(`\n--- ${L}: the calculator button is the athlete's to place ---`);
  EV('try{TOUR.live=false;}catch(e){} S.tour={done:true}; if(typeof ONB!=="undefined"){ONB().done=true;} S.discAck={v:DISC_V,d:localDate()}; storageOK=true; S.calcPos=null; CALC.open=false; save(); S.day=PLAN.days[0].code; render();');

  chk('(fixture) the button is on screen', !!fab(), 'no #calcFab');
  chk('it starts on the right edge, as it always has', fab().dataset.edge==='right' && /58/.test(fab().style.top), fab().dataset.edge+' / '+fab().style.top);

  // --- a tap still opens it --------------------------------------------------
  press(W()-30, H()*0.58); release(W()-30, H()*0.58); click();
  chk('a tap opens the calculator', EV('CALC.open')===true && !!D.getElementById('calcPanel'), 'tap did not open it');
  EV('CALC.open=false; calcPaint();');

  // --- a drag moves it and does NOT open it -----------------------------------
  drag(W()-30, H()*0.58, 20, H()*0.30);
  chk('dragging to the left edge lands it on the left', fab().dataset.edge==='left', 'edge is '+fab().dataset.edge);
  chk('and roughly where it was dropped along that edge', Math.abs(EV('(S.calcPos||{}).at')-0.30)<0.03, 'at='+EV('(S.calcPos||{}).at'));
  chk('a drag is not a tap - the calculator stays closed', EV('CALC.open')===false && !D.getElementById('calcPanel'), 'the drag opened it');
  chk('the panel follows the button to that side', fab().dataset.edge==='left', 'panel anchor not updated');

  // --- every edge, with clamping ---------------------------------------------
  drag(20, H()*0.30, W()/2, 5);
  chk('top edge', fab().dataset.edge==='top', fab().dataset.edge);
  drag(W()/2, 5, W()*0.8, H()-5);
  chk('bottom edge', fab().dataset.edge==='bottom', fab().dataset.edge);
  drag(W()*0.8, H()-5, W()-5, 1);
  chk('a drop in the very corner is clamped so it cannot leave the screen',
      EV('(S.calcPos||{}).at')>=0.06 && EV('(S.calcPos||{}).at')<=0.94, 'at='+EV('(S.calcPos||{}).at'));

  // --- the magnet: a render mid-drag must not pull it home ----------------------
  EV("S.calcPos={edge:'left',at:0.06}; save(); render();");
  press(20, H()*0.06);
  moveDoc(W()*0.5, H()*0.5);
  EV('render();');
  const midX=fab().style.left, midTop=fab().style.top;
  chk('a re-render in the middle of a drag does not yank the button back',
      /px$/.test(midX) && /px$/.test(midTop) && Math.abs(parseFloat(midX)-W()*0.5)<2,
      'mid-drag the button sits at left='+midX+' top='+midTop+' instead of under the finger');
  moveDoc(W()*0.5, H()-6);
  releaseDoc(W()*0.5, H()-6); click();
  chk('and it lands where it was dropped, not back in the corner it started in',
      fab().dataset.edge==='bottom', 'landed on '+fab().dataset.edge);

  // --- it stays put ------------------------------------------------------------
  drag(fab().getBoundingClientRect().x||W()-30, 1, 20, H()*0.7);
  const posBefore=EV('JSON.stringify(S.calcPos)');
  EV("S.day='PLAN'; render(); S.day=PLAN.days[0].code; render();");
  chk('a re-render does not move it', EV('JSON.stringify(S.calcPos)')===posBefore && fab().dataset.edge==='left', 'moved to '+fab().dataset.edge);
  chk('the position is in saved state, so it survives a reload and a backup',
      EV("(function(){ var r=localStorage.getItem('nsc:'+curSKEY()); return r && JSON.stringify(JSON.parse(r).calcPos); })()")===posBefore,
      'not in storage');

  // --- garbage in state is ignored, never thrown -------------------------------
  let died=null;
  ['S.calcPos="nope";','S.calcPos={edge:"diagonal",at:0.5};','S.calcPos={edge:"left",at:"x"};','S.calcPos={edge:"left",at:99};']
    .forEach(js=>{ try{ EV(js+' render();'); if(!fab().dataset.edge) died=js; }catch(e){ died=js+' -> '+(e.message||e); } });
  chk('a mangled position falls back to the default rather than breaking the button', !died, died);
  EV('S.calcPos=null; save();');

  console.log('  problems:', bad); process.exit(bad?1:0);
},1500);
