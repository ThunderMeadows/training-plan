// FIELD CRASH 2026-09-02 (v188): removing a movement called outStamp(), which was defined
// NOWHERE. It threw between the push and the save, so the removal looked like it happened and
// was never persisted. Two guards here: the remove/restore flow actually runs, and the source
// is scanned for unguarded calls to functions that do not exist.
const {JSDOM}=require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const raw=fs.readFileSync(f,'utf8');
const d=new JSDOM(raw,{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/'});
const w=d.window,EV=e=>w.eval(e);
w.AudioContext=function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
let bad=0; const chk=(l,ok,dd)=>{ if(!ok)bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&dd?'  <-- '+dd:''}`);};
const errs=[]; w.addEventListener('error',e=>errs.push(String(e.message)));
setTimeout(()=>{
  console.log(`\n--- ${L}: removing a movement, and phantom calls ---`);
  EV('try{TOUR.live=false;}catch(e){} S.tour={done:true}; if(typeof ONB!=="undefined"){ONB().done=true;} S.discAck={v:DISC_V,d:localDate()}; storageOK=true; save(); render();');
  // remove the last non-custom movement of the day, the way the UI does
  const name=EV('(function(){ var d2=dayObj(); var ex=d2.exercises[d2.exercises.length-1]; return ex? ex.name : null; })()');
  chk('the day has a movement to remove', !!name, 'none found');
  let threw=null;
  try{
    EV(`(function(){ var d2=dayObj(); var ex=d2.exercises[d2.exercises.length-1];
      if(!S.outs[S.day]) S.outs[S.day]=[];
      if(S.outs[S.day].indexOf(ex.name)<0){ S.outs[S.day].push(ex.name); }
      save(); render(); })();`);
  }catch(e){ threw=String(e&&e.message||e); }
  chk('removing a movement does not throw', !threw, threw);
  chk('no error reached the handler', errs.length===0, errs.join(' | '));
  chk('the removal is persisted', EV('(S.outs[S.day]||[]).indexOf('+JSON.stringify(name)+')>-1'), 'not stored');
  chk('the card treats it as out', EV('isOut('+JSON.stringify(name)+')'), 'still programmed');
  chk('it survives a save/load round trip', EV('(function(){ save(); var raw2=localStorage.getItem("nsc:"+(typeof curSKEY==="function"? curSKEY():SKEY)); return raw2? (JSON.parse(raw2).outs[S.day]||[]).indexOf('+JSON.stringify(name)+')>-1 : false; })()'), 'lost on reload');
  // restore
  EV(`(function(){ var o=S.outs[S.day]||[]; var i=o.indexOf(`+JSON.stringify(name)+`); if(i>-1) o.splice(i,1); save(); render(); })();`);
  chk('restoring puts it back', !EV('isOut('+JSON.stringify(name)+')'), 'still out');
  chk('still no errors after restore', errs.length===0, errs.join(' | '));

  // --- source scan: unguarded calls to functions that do not exist ---
  // Optional-feature probes wrapped in typeof X==='function' are fine by design; a bare call
  // to something never defined is the bug class that shipped.
  const defined=new Set();
  (raw.match(/function\s+([A-Za-z_$][\w$]*)\s*\(/g)||[]).forEach(m=>defined.add(m.replace(/function\s+/,'').replace(/\s*\($/,'')));
  (raw.match(/(?:var|let|const)\s+([A-Za-z_$][\w$]*)\s*=/g)||[]).forEach(m=>defined.add(m.split(/\s+/)[1].replace('=','').trim()));
  const KNOWN=new Set(['outStamp']); // named so a reintroduction is loud, not silent
  let phantom=[];
  ['outStamp'].forEach(n=>{
    const live=new RegExp('(?<![\\w$.\'"])'+n+'\\s*\\(','g');
    (raw.split('\n')||[]).forEach((line,i)=>{
      const t=line.trim();
      if(t.startsWith('//')||t.startsWith('*')) return;
      if(live.test(line) && !/typeof\s+'?"?/.test(line)) phantom.push(n+' @'+(i+1));
    });
  });
  chk('outStamp is gone from executable code', phantom.length===0, phantom.join(', '));
  console.log('  problems: '+bad); process.exit(bad?1:0);
},1600);
