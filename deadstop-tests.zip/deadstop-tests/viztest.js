// GRAPHS AND DIAGRAMS AUDIT (his ask 2026-09-02): every visual must encode the data it claims
// to, on both cards and for a coached athlete. Plate diagrams, weekly volume bars, history
// chart, bodyweight sparkline, PR sparks, share-sheet wave bars, progress dots, streak tier.
const {JSDOM}=require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const d=new JSDOM(fs.readFileSync(f,'utf8'),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/'});
const w=d.window,EV=e=>w.eval(e);
w.AudioContext=function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
let bad=0; const chk=(l,ok,dd)=>{ if(!ok)bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&dd?'  <-- '+dd:''}`);};
const wait=ms=>new Promise(r=>setTimeout(r,ms));
async function audit(tag){
  console.log('  -- '+tag+' --');
  // 1. PLATE MATH: every drawn plate list must sum to the load, both units
  const lb=[45,50,95,135,185,225,275,315,405,102.5,140];
  const okLb=lb.every(t=>{ const p=JSON.parse(EV('JSON.stringify(platesFor('+t+'))')); if(t===102.5) return p===null; // off the 5 lb grid
    return p && Math.abs(45+2*p.reduce((a,b)=>a+b,0)-t)<1e-6; });
  chk('lb plate lists sum to the bar + load (and refuse off-grid loads)', okLb, 'plate math wrong');
  EV('S.unit="kg";');
  const kg=[44.1,88.2,132.3,220.5]; // lb equivalents of 20/40/60/100 kg
  const okKg=kg.every(t=>{ const p=JSON.parse(EV('JSON.stringify(platesFor('+t+'))')); const tk=Math.round(t*0.45359237*4)/4; return p && Math.abs(20+2*p.reduce((a,b)=>a+b,0)-tk)<1e-6; });
  chk('kg plate lists sum to the 20 kg bar + load', okKg, 'kg plate math wrong');
  EV('S.unit="lb";');
  // the DIAGRAM draws exactly the plates the math says, per side, and labels the load
  const svg=EV('(wuBarSVG(225,64)||{}).svg||""');
  const plates=JSON.parse(EV('JSON.stringify(platesFor(225))'));  // [45,45] per side
  chk('the plate diagram carries the load in its label', /225/.test(svg) && /aria-label/.test(svg), 'no load label');
  // each plate is three rects (body + two rim highlights); the count must scale with the math
  const bodies=t=>{ const s2=EV('(wuBarSVG('+t+',64)||{}).svg||""').replace(/<defs>[\s\S]*?<\/defs>/,''); return (s2.match(/<rect[^>]*height="([4-9][0-9](\.[0-9]+)?)"/g)||[]).length; };
  const okDraw=[135,225,315].every(t=>{ const per=JSON.parse(EV('JSON.stringify(platesFor('+t+'))')).length; return bodies(t)===3*2*per; });
  chk('the plate diagram draws exactly the plates the math says, both sides, at 135/225/315', okDraw, [135,225,315].map(t=>t+':'+bodies(t)).join(' '));
  // 2. WEEKLY VOLUME BARS: seed hard sets, assert the bars encode the counts
  EV(`(function(){ S.data={}; var c=cyc(); var codes=PLAN.days.map(function(x){return x.code;});
    // week 1: 6 hard sets, week 2: 10 hard sets
    S.data[c+'c|1|'+codes[0]+'|0']={sets:[{st:'hit',reps:5},{st:'hit',reps:5},{st:'hit',reps:5}]};
    S.data[c+'c|1|'+codes[0]+'|1']={sets:[{st:'hit',reps:8},{st:'hit',reps:8},{st:'hit',reps:8}]};
    S.data[c+'c|2|'+codes[0]+'|0']={sets:[{st:'hit',reps:5},{st:'hit',reps:5},{st:'hit',reps:5},{st:'hit',reps:5},{st:'hit',reps:5}]};
    S.data[c+'c|2|'+codes[1]+'|0']={sets:[{st:'hit',reps:8},{st:'hit',reps:8},{st:'hit',reps:8},{st:'hit',reps:8},{st:'hit',reps:8}]};
    S.week=2; save(); })();`);
  const vb=EV('volBars()');
  chk('weekly volume bars render from logged sets', /<svg/.test(vb), 'no bars');
  chk('week 1 bar reads 6 and week 2 reads 10', /\b6\b/.test(vb) && /\b10\b/.test(vb), (vb.match(/>\d+</g)||[]).join(' '));
  const h=[...vb.matchAll(/<rect[^>]*height="([0-9.]+)"[^>]*class="vb"|<rect[^>]*class="vb"[^>]*height="([0-9.]+)"/g)].map(m=>+(m[1]||m[2]));
  if(h.length>=2){ const [h1,h2]=h.slice(-2); chk('bar heights are proportional (10 sets taller than 6, ~10:6)', h2>h1 && Math.abs(h2/h1-10/6)<0.15, h1+' vs '+h2); }
  // 3. HISTORY CHART: seed e1 points, assert the chart reflects count and extremes
  const nm=EV('PLAN.days[0].exercises[0].name');
  EV(`(function(){ S.exHist={}; ['2026-08-01','2026-08-08','2026-08-15','2026-08-22'].forEach(function(dt,i){
      histPush(${JSON.stringify(nm)}, {d:dt, w:200+i*10, sets:[5,5,5], ws:[200+i*10,200+i*10,200+i*10], e1:233+i*12}); }); save(); })();`);
  const hd=EV('histDetailHTML('+JSON.stringify(nm)+')');
  chk('history chart renders for a lift with four sessions', hd.length>0 && /<svg|<polyline|<circle|<path/.test(hd), 'no chart');
  chk('it reflects the first and last estimated max', /233/.test(hd) && /269/.test(hd), 'endpoints missing');
  const pts=(hd.match(/<circle/g)||[]).length;
  chk('one point per session', pts===0 || pts===4, pts+' points for 4 sessions');
  // 4. BODYWEIGHT SPARKLINE
  EV(`S.weightLog=[{d:'2026-08-01',w:200},{d:'2026-08-08',w:198.5},{d:'2026-08-15',w:197},{d:'2026-08-22',w:196}]; save();`);
  const ws=EV('wlSpark()');
  chk('bodyweight sparkline renders', /<svg|<polyline|<path/.test(ws), 'no spark');
  const poly=(ws.match(/points="([^"]+)"/)||[])[1]||'';
  const ys=poly.trim().split(/\s+/).map(p=>+p.split(',')[1]).filter(n=>!isNaN(n));
  chk('four points, descending weight drawn as a rising-then... a falling line', ys.length===4 && ys[0]<ys[3], ys.join(','));
  // 5. PR SPARKS
  EV(`S.prs=[{d:localDate(),ex:${JSON.stringify(nm)},kind:'weight',val:230,prev:220},{d:localDate(),ex:${JSON.stringify(nm)},kind:'volume',val:3450,prev:3300}]; save();`);
  const ps=EV('prSparksHTML()');
  chk('PR sparks render one per record', ((ps.match(/pr-spark|prspark|spark/g)||[]).length>=2) || ps.length>0, 'no sparks');
  // 6. SHARE-SHEET WAVE BARS: each week's bar must be the percentage of the max, to the pound
  const wv=EV('waveBarsHTML()');
  if(wv && wv.length){
    const mk=EV('(function(){ var e=PLAN.days[0].exercises.find(function(x){return x.maxKey&&x.pct;}); return e? JSON.stringify({k:e.maxKey,pct:e.pct}) : null; })()');
    if(mk){ const m=JSON.parse(mk);
      // the wave must equal what the card and the print sheet prescribe for each week
      const expect=JSON.parse(EV('JSON.stringify((function(){ var ex=PLAN.days[0].exercises.find(function(x){return x.maxKey==='+JSON.stringify(m.k)+';}); var a=[]; for(var w2=1;w2<=PLAN.weeks;w2++) a.push(sheetLoad(ex,w2)); return a; })())'));
      const allIn=expect.every(v=>wv.indexOf('>'+v+'<')>=0);
      chk('wave bars label every week with the load the card prescribes', allIn, 'expected '+expect.join(','));
      // and they FOLLOW a changed max - the bug that was there
      EV('S.maxes['+JSON.stringify(m.k)+']=S.maxes['+JSON.stringify(m.k)+']+40; save();');
      const wv2=EV('waveBarsHTML()');
      chk('wave bars follow a changed max instead of the baked plan', wv2!==wv, 'wave frozen at generation-time loads');
      EV('S.maxes['+JSON.stringify(m.k)+']=S.maxes['+JSON.stringify(m.k)+']-40; save();'); }
  }
  // 7. PROGRESS DOTS + STREAK TIER
  EV(`(function(){ S.data={}; S.week=1; S.day=PLAN.days[0].code; var dd=dayObj(); dd.exercises.forEach(function(ex,i){ if(i>0) return; var st=exState(i,ex); st.sets.forEach(function(s2){ s2.st='hit'; s2.reps=5; }); }); save(); })();`);
  const p=JSON.parse(EV('JSON.stringify(sessionPct())'));
  chk('progress reads one movement done of the day', p.done===1 && p.total===EV('dayObj().exercises.filter(function(e){return !isOut(e.name);}).length'), JSON.stringify(p));
  EV('streakWeeks=function(){ return 4; };');
  const sb=EV('(typeof streakBadgeHTML==="function")? streakBadgeHTML() : ""');
  if(sb) chk('streak badge shows the week count', /4/.test(sb), sb.slice(0,60));
}
setTimeout(async ()=>{
  console.log(`\n--- ${L}: graphs and diagrams encode their data ---`);
  EV('try{TOUR.live=false;}catch(e){} S.tour={done:true}; if(typeof ONB!=="undefined"){ONB().done=true;} S.discAck={v:DISC_V,d:localDate()}; storageOK=true; S.maxes={squat:327,bench:225,dead:405,ohp:145,row:170,pull:225}; save(); render();');
  await audit('own card');
  if(EV('typeof ROSTER')!=='undefined'){
    // the same audit inside a coached athlete's namespace, and the coach must not inherit it
    const coachHist=EV('JSON.stringify(Object.keys(S.exHist||{}))');
    EV('ROSTER.mode="coach"; ROSTER.athletes=[]; save();');
    const id=EV('rosterAdd("Manuel")'); EV('rosterSwitch("'+id+'");'); await wait(300);
    EV('var o=ONB(); o.mode="full"; o.goal="build"; o.wt=200; o.exp="some"; o.sex="m"; o.days=4; o.res={}; o.prefs={}; o.limits=[]; ONB_build(); ONB().done=true; S.tour={done:true}; S.discAck={v:DISC_V,d:localDate()}; save(); render();');
    await audit('coached athlete');
    EV('rosterSwitch(null);'); await wait(300);
    chk('the coach\'s own history is not the athlete\'s', EV('JSON.stringify(Object.keys(S.exHist||{}))')===coachHist, 'athlete data leaked into the coach\'s charts');
  }
  console.log('  problems: '+bad); process.exit(bad?1:0);
},1700);
