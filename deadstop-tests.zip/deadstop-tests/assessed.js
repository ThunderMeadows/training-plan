// EVERY MAX THE CARD ASSESSES IS A MAX IT PROGRAMS (2026-09-04).
//
// He asked whether the barbell row shows up in The road ahead. It did not - and the reason was
// bigger than the table. The card assessed FIVE main lifts, held a row max, listed it in MAXINFO
// as driving "Pull days", and `rowmax` asserts "the horizontal pull is assessed and programmed
// like every other main lift"... while the starter block programmed FOUR. Both pull days opened
// with Cable Rows, an accessory carrying no max key and no percentage.
//
// The cost was not cosmetic. A max that never drives a working weight is never tested, so the
// adapt engine has no evidence to move it: it sits wherever setup guessed, forever, while the
// card tells the athlete it is driving their pull days. The road-ahead table was the only place
// the gap was visible.
//
// Generated plans were always right - every split size from 3 to 7 days programs the row. It was
// the hand-written starter block that was short. So this pins the RELATIONSHIP rather than the
// table: anything the card assesses, it programs, in the default block and in every generated one.
const { JSDOM } = require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const dom=new JSDOM(fs.readFileSync(f,'utf8'),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/',
  beforeParse(w){
    w.AudioContext=function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
    w.alert=()=>{};
  }});
const w=dom.window,EV=e=>w.eval(e);
let bad=0; const chk=(l,ok,d)=>{ if(!ok) bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&d?'  <-- '+d:''}`); };

setTimeout(()=>{
  console.log(`\n--- ${L}: what the card assesses, the card programs ---`);
  EV('try{TOUR.live=false;}catch(e){} S.tour={done:true}; if(typeof ONB!=="undefined"){ONB().done=true;} S.discAck={v:DISC_V,d:localDate()}; storageOK=true; S.maxes={squat:327,bench:225,dead:405,ohp:145,row:170,pull:225}; save();');

  // the lifts the card tells the athlete it assesses
  const assessed=JSON.parse(EV('JSON.stringify((MAXINFO||[]).map(function(m){ return m.k; }))'));
  chk('(fixture) the card declares the lifts it assesses', assessed.length>0, 'MAXINFO is empty');
  chk('the row is one of them', assessed.indexOf('row')>-1, 'assessed: '+assessed.join(', '));

  // --- the DEFAULT block -----------------------------------------------------
  const programmed=k=>EV(`(function(){ var out=false; PLAN.days.forEach(function(d){ d.exercises.forEach(function(ex){
      if(ex.maxKey===${JSON.stringify(k)} && ex.pct && ex.pct.length) out=true; }); }); return out; })()`);
  const missing=assessed.filter(k=>!programmed(k));
  chk('every assessed lift is percentage-programmed in the starter block', missing.length===0,
      'assessed but never programmed: '+missing.join(', ')+' - that max is never tested and can never adapt');

  // and it reaches the projection the athlete actually looks at
  // roadAheadRows returns {name, max0, cells} - no key. Reading r.k gave undefined and flagged
  // all five lifts as missing on a card where every one of them was present: a harness fault that
  // would have buried the real finding underneath four false ones. Matched by the exercise NAME
  // the plan uses for each max instead.
  const road=JSON.parse(EV('JSON.stringify(roadAheadRows(8).map(function(r){ return r.name; }))'));
  const nameFor=k=>EV(`(function(){ var n=null; PLAN.days.forEach(function(d){ d.exercises.forEach(function(ex){
      if(ex.maxKey===${JSON.stringify(k)} && ex.pct && !n) n=ex.name; }); }); return n; })()`);
  const offRoad=assessed.filter(k=>{ const n=nameFor(k); return n && road.indexOf(n)<0; });
  chk('and every one of them appears in The road ahead', offRoad.length===0,
      'missing from the projection: '+offRoad.join(', '));

  // --- MAXINFO must not promise what the plan does not do ---------------------
  const rowInfo=JSON.parse(EV('JSON.stringify((MAXINFO||[]).find(function(m){ return m.k==="row"; })||null)'));
  chk('the row is described as driving pull days, and a pull day really opens with it',
      !!rowInfo && EV(`(function(){ var ok=false; PLAN.days.forEach(function(d){
         if(/Pull/i.test(d.title||'') && d.exercises[0] && d.exercises[0].maxKey==='row') ok=true; }); return ok; })()`),
      rowInfo? ('MAXINFO says the row drives "'+rowInfo.lifts+'" but no pull day opens with it') : 'no row entry in MAXINFO');

  // --- EVERY generated split, not just the default ----------------------------
  let thin=[];
  EV(`window.__T=(function(){ for(var k in window){ try{ var v=window[k];
      if(v && typeof v==='object' && v[6] && v[6][0] && v[6][0].mains) return v; }catch(e){} } return null; })()`);
  const sizes=JSON.parse(EV('JSON.stringify(window.__T? Object.keys(window.__T) : [])'));
  chk('(fixture) the generator templates were found', sizes.length>0, 'no template table');
  sizes.forEach(n=>{
    const lifts=JSON.parse(EV(`JSON.stringify((function(){ var o={}; window.__T[${JSON.stringify(n)}].forEach(function(d){
        (d.mains||[]).forEach(function(m){ o[(typeof m==='string')? m : m.l]=1; }); }); return Object.keys(o); })())`));
    assessed.filter(k=>k!=='pull').forEach(k=>{ if(lifts.indexOf(k)<0) thin.push(n+'-day is missing '+k); });
  });
  chk('every generated split programs every assessed lift', thin.length===0, thin.join(' | '));

  // --- the row must be trainable his way without losing the programming --------
  const subs=JSON.parse(EV(`JSON.stringify((function(){ var s=null; PLAN.days.forEach(function(d){ d.exercises.forEach(function(ex){
      if(ex.maxKey==='row' && !s) s=ex.subs||[]; }); }); return s||[]; })())`));
  chk('a machine or cable row is offered as a swap on the programmed row',
      subs.some(x=>/machine row|cable row/i.test(x)),
      'subs are: '+subs.join(', ')+' - the athlete who prefers the machine has no first-class swap');

  console.log('  problems:', bad); process.exit(bad?1:0);
},1500);
