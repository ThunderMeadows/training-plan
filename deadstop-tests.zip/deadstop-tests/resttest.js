// An accidental +30s must be correctable mid-session, and must never cut rest below prescribed.
//
// NOTE: an earlier version of this file reimplemented the clamp in the harness and therefore
// passed even with the fix removed from the card - it was testing itself. It now dispatches
// real clicks at the card's own document handler, so removing the clamp fails this test.
const { JSDOM } = require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const dom=new JSDOM(fs.readFileSync(f,'utf8'),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://thundermeadows.github.io/'});
const w=dom.window,D=w.document,EV=e=>w.eval(e);
w.AudioContext=w.AudioContext||function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};

setTimeout(()=>{
  console.log(`\n--- ${L}: rest extension is reversible ---`);
  // pin a completion for the handler to hang the extension off, then press the real buttons
  // A fresh profile auto-starts the walkthrough, and tourGuard correctly swallows every tap
  // outside the coach while it runs. Testing without finishing it reports the buttons as dead.
  EV('try{ TOUR.live=false; }catch(e){} try{ S.tour={done:true}; }catch(e){}');
  const ch=D.getElementById('coachHost'); if(ch) ch.remove();
  EV('lastCompletion=function(){ return {t:1234}; }; S.restExt=null;');
  const press=n=>{
    const b=D.createElement('button');
    b.setAttribute('data-restext',String(n));
    D.body.appendChild(b);
    b.dispatchEvent(new w.MouseEvent('click',{bubbles:true,cancelable:true,view:w}));
    b.remove();
    return EV('(S.restExt&&S.restExt.add)||0');
  };
  const row=()=>EV('restExtRow({t:1234})');
  let bad=0;
  const check=(label,got,want)=>{ const ok=got===want; if(!ok) bad++;
    console.log(`  ${label.padEnd(34)} ${String(got).padEnd(5)} ${ok?'':'<-- want '+want}`); };

  console.log('  fresh rest shows:', /rest-extrow/.test(row())?'+/- pair':'single +30s button');
  check('accidental bump',            press(30), 30);
  console.log('  row now offers a way back:', /data-restext="-30"/.test(row())?'yes':'NO - one-way');
  if(!/data-restext="-30"/.test(row())) bad++;
  check('take it back',              press(-30), 0);
  console.log('  row back to:', /rest-extrow/.test(row())?'+/- pair':'single +30s button');
  press(30); press(30);
  check('three bumps total',          press(30), 90);
  press(-30); press(-30);
  check('undo all three',            press(-30), 0);
  check('extra undo cannot go below 0', press(-30), 0);
  check('and still cannot',          press(-30), 0);
  console.log('  problems:', bad);
  process.exit(bad?1:0);
},1500);
