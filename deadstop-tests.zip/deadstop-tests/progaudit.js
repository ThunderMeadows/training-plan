// AUDIT 2026-09-06 (v208). A deep pass over the progression engine - every automatic writer to a
// weight. Six real faults came out of it, all reproduced against the live build before they were
// fixed, and every one of them is pinned below. The theme is that the card has FOUR automatic
// writers to a max (layoff, stall, rate, probation) plus auto-calibration and the accessory
// anchor, and the faults all lived where two of them met.
//
//   1. THE DELOAD ATE THE ACCESSORIES. accLoad() scales the whole ladder to the last logged
//      weight, and a deload week was logged like any other session, so it became the anchor the
//      next block was built from. Three blocks of an athlete topping the rep range every set:
//      Romanian Deadlift 260 -> 180 -> 125, Hammer Curls 25 -> 15 -> 10. updateE1RM() already
//      refused to let a deload set a max; the accessory anchor never got the same rule.
//   2. A FAILING TRIAL COULD ADD WEIGHT. pvJudge clamped its step-down to the trial floor
//      unconditionally, so a max sitting BELOW that floor - hand-lowered, or cut by the layoff
//      pass - was raised to it as the penalty for two bad sessions. The athlete-facing line read
//      "the working weight comes back -25 lb".
//   3. adRate MIXED REP TARGETS - the same fault the stall rule was field-caught on the day
//      before, in its sibling. Flat strength on an alternating heavy/volume split read as
//      +1.7 lb a week or -1.7 depending only on where the window ended; on a wide enough gap it
//      added 5 lb to a flat lift every week forever.
//   4. TWO WRITERS, ONE POT OF EVIDENCE. autoCalibrate (every bank) and the rate pass (weekly)
//      both read e1rmH; one bank moved a 300 lb squat to 345.
//   5. THE BIGGEST AUTOMATIC MOVE HAD NO WAY BACK. Calibration wrote to acLog, which nothing
//      undoes, against the c188-c190 promise that any change the card made can be put back.
//   6. THE STRUGGLE FLAG BELONGED TO WHICHEVER MOVEMENT WENT LAST. Two movements sharing a max
//      key on one day: a ground-out main followed by a clean back-off filed the day as clean.
//
// Plus two latent ones: deload=wk[5] hard-coded the sixth rung, and a stored zero or negative
// weight was accepted as a real anchor and prescribed 5 lb labelled "logged".
const {JSDOM}=require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const raw=fs.readFileSync(f,'utf8');
const d=new JSDOM(raw,{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/'});
const w=d.window,EV=e=>w.eval(e);
const safe=(e,fb)=>{ try{ return EV(e); }catch(err){ return (fb===undefined)? ('ERR '+err.message) : fb; } };
w.AudioContext=function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
let bad=0; const chk=(l,ok,dd)=>{ if(!ok)bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&dd?'  <-- '+dd:''}`);};
const errs=[]; w.addEventListener('error',e=>errs.push(String(e.message)));

setTimeout(()=>{
  console.log(`\n--- ${L}: the progression engine, audited ---`);
  EV('try{TOUR.live=false;}catch(e){} S.tour={done:true}; if(typeof ONB!=="undefined"){ONB().done=true;} S.discAck={v:DISC_V,d:localDate()}; storageOK=true; save();');
  const T=EV('shiftDate()');
  const ago=n=>EV(`(function(){var q=new Date('${T}T12:00:00'); q.setDate(q.getDate()-${n}); return q.toISOString().slice(0,10);})()`);

  // ============ 1. a deload week does not re-base the accessories ============
  // The end-to-end version: three blocks, logged through the REAL recordPerf, topping the rep
  // range every session. If the deload week can set the anchor, the trajectory falls.
  const traj=safe(`(function(){
    var p=generatePlan({maxes:{squat:315,bench:225,dead:405,ohp:135,row:185}, goal:'general', days:4});
    S.genPlan=p; PLAN=p; S.maxes={squat:315,bench:225,dead:405,ohp:135,row:185};
    var ex=null;
    p.days.forEach(function(dd){ dd.exercises.forEach(function(e){
      if(!e.maxKey && e.wk && e.wk[0]>=100 && !ex) ex=e; }); });
    if(!ex) return {err:'no loaded accessory in the generated plan'};
    var day={code:'A', exercises:[ex]};
    var realDay=window.dayObj, realEff=(typeof effDay==='function')? effDay:null;
    window.dayObj=function(){ return day; }; if(realEff) window.effDay=function(){ return day; };
    var top=parseInt(String(exReps(ex)).split('-').pop(),10)||10;
    S.lastPerf={}; S.stall={}; S.data={};
    var opens=[], all=[];
    for(var blk=1; blk<=3; blk++){
      for(var wk=1; wk<=PLAN.weeks; wk++){
        S.week=wk;
        var v=accLoad(ex);
        if(wk===1) opens.push(v);
        all.push((wk===PLAN.weeks?'D':'')+v);
        // log it the way the card does: sets answered at that weight, then recordPerf()
        S.when={date:'2026-0'+blk+'-0'+wk};
        S.data[exKey(0)]={sets:[{st:'done',reps:top,rir:2,w:v},{st:'done',reps:top,rir:2,w:v},{st:'done',reps:top,rir:2,w:v}]};
        recordPerf();
      }
    }
    window.dayObj=realDay; if(realEff) window.effDay=realEff;
    return {name:ex.name, opens:opens, all:all.join(' ')};
  })()`, {err:'threw'});
  console.log('    ' + (traj.err? traj.err : traj.name + ': ' + traj.all));
  chk('a deload week never becomes the weight the next block is built from',
      !traj.err && traj.opens[1]>=traj.opens[0] && traj.opens[2]>=traj.opens[1],
      'block openings ran '+JSON.stringify(traj.opens)+' - the accessory ratchets down every deload');

  // and the unit fact underneath it
  const anch=safe(`(function(){
    var ex={name:'Audit Curl', reps:'8-12', sets:3, loadNum:60};
    var day={code:'A', exercises:[ex]};
    var realDay=window.dayObj, realEff=(typeof effDay==='function')? effDay:null;
    window.dayObj=function(){ return day; }; if(realEff) window.effDay=function(){ return day; };
    S.lastPerf={'Audit Curl':{d:'2026-09-01', w:60, r:'12,12,12', rir:2}};
    S.week=PLAN.weeks; S.when={date:'2026-09-08'};
    S.data={}; S.data[exKey(0)]={sets:[{st:'done',reps:12,rir:3,w:35}]};
    recordPerf();
    var afterDeload=(S.lastPerf['Audit Curl']||{}).w;
    S.week=1; S.when={date:'2026-09-15'};
    S.data={}; S.data[exKey(0)]={sets:[{st:'done',reps:12,rir:2,w:65}]};
    recordPerf();
    var afterWork=(S.lastPerf['Audit Curl']||{}).w;
    window.dayObj=realDay; if(realEff) window.effDay=realEff;
    return {dl:afterDeload, wk:afterWork};
  })()`, {});
  chk('a deload session leaves the working anchor alone', anch.dl===60,
      'the anchor moved to the deload weight: '+JSON.stringify(anch));
  chk('a working session still sets the anchor', anch.wk===65,
      'the guard swallowed a real session: '+JSON.stringify(anch));

  // ============ 2. a trial step is always downward ============
  const mat=safe(`(function(){
    var rows=[];
    [[200,200],[195,200],[175,200],[210,200],[200,0]].forEach(function(pair){
      S.maxes={x:pair[0]};
      S.mxProv={x:{tested:220, from:pair[1], floor:pair[1], since:'${ago(20)}', start:210, src:'test'}};
      S.adLog=[]; S.adNew=0;
      S.e1rmH={x:[{d:'${ago(5)}',v:1,r:1,c:0,n:5},{d:'${ago(2)}',v:1,r:1,c:0,n:5}]};
      var acts=pvJudge();
      rows.push({cur:pair[0], floor:pair[1], end:S.maxes.x,
                 up:acts.some(function(a){ return a.to>a.from; }),
                 zero:acts.some(function(a){ return a.kind==='prov' && a.to===a.from; })});
    });
    return rows;
  })()`, []);
  mat.forEach(r=>console.log(`    cur ${r.cur} floor ${r.floor} -> ${r.end}`));
  chk('a failing trial never puts weight ON the bar',
      mat.length===5 && !mat.some(r=>r.up) && !mat.some(r=>r.end>r.cur),
      'a penalty raised the max: '+JSON.stringify(mat));
  chk('a trial that has nowhere left to step files no change at all',
      !mat.some(r=>r.zero), 'a zero-move action was filed: '+JSON.stringify(mat));
  chk('a trial above its floor still steps down',
      mat[3] && mat[3].end<mat[3].cur && mat[3].end>=mat[3].floor,
      'the real step-down regressed: '+JSON.stringify(mat[3]));
  chk('a trial back at its proven floor is closed, not left running',
      safe(`(function(){ S.maxes={x:190}; S.mxProv={x:{tested:220,from:200,floor:200,since:'${ago(20)}',start:210,src:'test'}};
        S.adLog=[]; S.e1rmH={x:[{d:'${ago(5)}',v:1,r:1,c:0,n:5},{d:'${ago(2)}',v:1,r:1,c:0,n:5}]};
        pvJudge(); return !(S.mxProv||{}).x; })()`, false),
      'the lift is still on trial with nothing left to judge');

  // ============ 3. the rate trend compares like with like ============
  const saw=[]; for(let i=8;i>=1;i--) saw.push(`{d:'${ago(i*7)}',v:${i%2? 473:383},r:2,c:1,n:${i%2?5:12}}`);
  EV(`S.maxes={dl:405}; S.mxProv={}; S.adLog=[]; S.acLog=[]; S.adLast=null;
      S.e1rmH={dl:[${saw.join(',')}]}; save();`);
  chk('a heavy day alternating with a volume day is not a trend',
      safe('JSON.stringify(adRateMove("dl"))','')==='null',
      'flat strength earned a rate rise off a mixed-rep sawtooth: '+safe('JSON.stringify(adRateMove("dl"))'));
  // four weekly passes on that same flat history must not ratchet
  EV(`S.maxes={dl:405}; S.adLog=[]; S.readyH=[];`);
  const ratchet=safe(`(function(){ var out=[]; for(var i=0;i<4;i++){ S.adLast=null; adaptRun(); out.push(S.maxes.dl); } return out; })()`,[]);
  chk('four weekly passes on flat strength leave the bar where it was',
      ratchet.length===4 && ratchet.every(v=>v===405),
      'the max climbed on no evidence: 405 -> '+ratchet.join(' -> '));
  // a real, like-for-like climb is still read
  const rise=[]; for(let i=8;i>=1;i--) rise.push(`{d:'${ago(i*7)}',v:${473-i*8},r:2,c:1,n:5}`);
  EV(`S.maxes={dl:405}; S.adLog=[]; S.adLast=null; S.acLog=[]; S.e1rmH={dl:[${rise.join(',')}]}; save();`);
  chk('a genuine climb on one rep target still earns its step',
      /"kind":"rate"/.test(safe('JSON.stringify(adRateMove("dl")?{kind:"rate"}:null)','null')),
      'the fix silenced real progress: '+safe('JSON.stringify(adRateMove("dl"))'));
  EV(`S.e1rmH={dl:[{d:'${ago(21)}',v:400,r:2,c:1},{d:'${ago(14)}',v:420,r:2,c:1},
                  {d:'${ago(7)}',v:440,r:2,c:1},{d:'${ago(1)}',v:460,r:2,c:1}]}; save();`);
  chk('untagged history is not judged - no rep target, no move',
      safe('JSON.stringify(adRateMove("dl"))','')==='null',
      'a rate move was made on points that cannot be bucketed');

  // ============ 4. one automatic writer per lift per week ============
  const two=safe(`(function(){
    S.genPlan=generatePlan({maxes:{squat:300,bench:225,dead:405,ohp:135,row:185}, goal:'general', days:4});
    S.maxes={squat:300,bench:225,dead:405,ohp:135,row:185};
    S.onb={exp:'vet'}; S.mxProv={}; S.adLog=[]; S.acLog=[]; S.readyH=[]; S.adNew=0;
    S.adLast='${ago(9)}';
    S.e1rmH={squat:[{d:'${ago(21)}',v:360,r:1,c:1,n:5},{d:'${ago(14)}',v:370,r:1,c:1,n:5},
                    {d:'${ago(7)}',v:380,r:1,c:1,n:5},{d:'${ago(1)}',v:390,r:1,c:1,n:5}]};
    var start=S.maxes.squat;
    autoCalibrate();
    var mid=S.maxes.squat;
    adaptRun();
    return {start:start, mid:mid, end:S.maxes.squat,
            rate:(S.adLog||[]).some(function(a){ return a.kind==='rate' && a.lift==='squat'; })};
  })()`, {});
  console.log(`    one bank: ${two.start} -> calibration ${two.mid} -> after the weekly pass ${two.end}`);
  chk('the rate pass does not spend evidence calibration already spent',
      two.end===two.mid && !two.rate,
      'both writers moved the same lift on one bank: '+JSON.stringify(two));

  // ============ 5. every change the card makes to a max can be put back ============
  const undo=safe(`(function(){
    var entry=(S.adLog||[]).filter(function(a){ return a.kind==='calib' && a.lift==='squat'; })[0];
    if(!entry) return {found:false};
    var i=(S.adLog||[]).indexOf(entry);
    var before=S.maxes.squat;
    var okFlag=adUndoable(entry);
    adaptUndoOne(i);
    return {found:true, undoable:okFlag, before:before, after:S.maxes.squat, from:entry.from,
            twice:adaptUndoOne(i)};
  })()`, {});
  chk('an auto-calibration is filed as a change the athlete can see',
      undo.found===true, 'calibration still only writes to acLog, which nothing undoes');
  chk('"put back" reverses an auto-calibration exactly',
      undo.found && undo.undoable===true && undo.after===undo.from,
      'undo did not restore the number: '+JSON.stringify(undo));
  chk('a change already put back cannot be put back twice',
      undo.twice===false, 'the entry was undone a second time');

  // ============ 6. struggle belongs to the day, not to whichever movement went last ============
  const tag=safe(`(function(){
    S.week=1; S.e1rmH={}; S.e1rm={}; S.when={date:'2026-09-01'};
    var day={code:'A', exercises:[
      {name:'Bench Press', maxKey:'bench', reps:'5', rir:2, sets:3, loadNum:200, wk:[200,205,210,215,220,150]},
      {name:'Close-Grip Bench', maxKey:'bench', reps:'8', rir:2, sets:3, loadNum:160, wk:[160,165,170,175,180,120]}
    ]};
    var realDay=window.dayObj, realEff=(typeof effDay==='function')? effDay:null;
    window.dayObj=function(){ return day; }; if(realEff) window.effDay=function(){ return day; };
    S.data={};
    S.data[exKey(0)]={sets:[{st:'done',reps:3,rir:0,w:200},{st:'done',reps:3,rir:0,w:200},{st:'done',reps:2,rir:0,w:200}]};
    S.data[exKey(1)]={sets:[{st:'hit',rir:2,w:160},{st:'hit',rir:2,w:160},{st:'hit',rir:2,w:160}]};
    updateE1RM();
    var pt=(S.e1rmH.bench||[])[0];
    window.dayObj=realDay; if(realEff) window.effDay=realEff;
    return pt||{};
  })()`, {});
  chk('a ground-out main lift is still recorded as a struggle when a clean back-off follows it',
      tag.c===0, 'the day filed as clean: '+JSON.stringify(tag));

  // ============ 7 & 8. the two latent ones ============
  chk('the deload rung is the last rung, whatever the ladder length',
      safe(`(function(){
        S.genPlan=generatePlan({maxes:{squat:315,bench:225,dead:405,ohp:135,row:185}, goal:'general', days:4});
        S.maxes={squat:315,bench:225,dead:405,ohp:135,row:185};
        S.genPlan.weeks=4;
        S.genPlan.days.forEach(function(dd){ dd.exercises.forEach(function(e){ if(e.pct) e.pct=e.pct.slice(0,4); }); });
        applyMaxesToPlan();
        var bad=0;
        S.genPlan.days.forEach(function(dd){ dd.exercises.forEach(function(e){
          if(e.maxKey && e.pct && (e.deload==null || !isFinite(e.deload))) bad++; }); });
        return bad===0;
      })()`, false),
      'a shorter block leaves deload undefined, and that is what a deload week falls back to');
  chk('a zero or negative logged weight is not an anchor',
      safe(`(function(){
        var ex={name:'Audit Row', reps:'8-12', sets:3};
        S.lastPerf={'Audit Row':{w:0,r:12,rir:2}};
        var a=accAnchor(ex);
        S.lastPerf={'Audit Row':{w:-40,r:12,rir:2}};
        var b=accAnchor(ex);
        return (!a || a.src!=='logged') && (!b || b.src!=='logged');
      })()`, false),
      'junk was accepted as a logged anchor and scaled the ladder to 5 lb');

  // ============ the standing invariant: nothing here throws ============
  chk('no runtime errors anywhere on the audited paths', errs.length===0, errs.join(' | '));

  console.log(`\nproblems: ${bad}`);
  process.exit(bad? 1:0);
},2600);
