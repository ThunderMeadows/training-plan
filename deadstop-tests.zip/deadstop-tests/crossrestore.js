// A Session Card backup restored into the Training Card (2026-09-03, his own migration).
// Field: it sent him straight to setup with his data hidden behind it, the welcome copy was
// blank (Minimal coaching text hid it), the previous day's deck footer showed under setup, and
// - found by reading, not by him - every banked session was restoring under the prefix this
// card reserves for roster athletes, where the personal drawer filters it out.
const { JSDOM } = require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const dom=new JSDOM(fs.readFileSync(f,'utf8'),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/'});
const w=dom.window,D=w.document,EV=e=>w.eval(e);
w.AudioContext=w.AudioContext||function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
(async()=>{ await new Promise(r=>setTimeout(r,1500));
  console.log(`\n--- ${L}: a Session Card backup restored here ---`);
  let bad=0; const chk=(l,ok,d)=>{ if(!ok) bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&d?'  <-- '+d:''}`); };
  if(EV("typeof ONB==='undefined'")){ console.log('  (no setup on this card - nothing to be sent to)'); process.exit(0); }
  EV('try{TOUR.live=false;}catch(e){} S.tour={done:true}; S.discAck={v:DISC_V,d:localDate()}; storageOK=true; delete S.onb; S.mail=[]; S.mailSent={}; save();');
  // FIRST, on a genuinely new card (no logs, no flag): the setup screen with Minimal coaching
  // text on, and the footer from a previous render sitting underneath it
  EV("S.uiMode='std'; S.day=PLAN.days[0].code; ONB().done=true; render(); ONB().done=false;");
  EV("S.uiMode='min'; render();");
  const cue=D.querySelector('#app .cue'); const marked=D.getElementById('app').hasAttribute('data-onb');
  const rule=EV('(function(){ try{ for(var i=0;i<document.styleSheets.length;i++){ var r=document.styleSheets[i].cssRules; for(var j=0;j<r.length;j++){ if(/ui-min #app\\[data-onb\\] \\.cue/.test(r[j].selectorText||"") && r[j].style.getPropertyValue("display")==="block") return true; } } }catch(e){} return false; })()');
  chk('setup copy is never hidden by Minimal coaching text', D.body.classList.contains('ui-min') && !!cue && marked && rule, 'ui-min '+D.body.classList.contains('ui-min')+' cue '+!!cue+' marked '+marked+' rule '+rule);
  chk('the deck footer does not leak under setup', (D.getElementById('footInner')||{innerHTML:''}).innerHTML.trim()==='', 'footer: '+(D.getElementById('footInner')||{innerHTML:''}).innerHTML.slice(0,50));
  // what a Session Card writes: personal logs under nova-sc-log:<date>-..., rich history, no onb, Minimal coaching text
  const backup={v:1, exported:'2026-09-03', S:{
      maxes:{squat:327,bench:225,dead:405,ohp:145,row:170,pull:225}, uiMode:'min', theme:'iron', week:3,
      exHist:{'Bench Press':[{d:'2026-08-20',w:215,sets:[5,5,5],ws:[215,215,215],e1:250},{d:'2026-08-27',w:220,sets:[5,5,5],ws:[220,220,220],e1:256}],
              'Back Squat':[{d:'2026-08-21',w:275,sets:[5,5,5],ws:[275,275,275],e1:320}]},
      prs:[{d:'2026-08-27',ex:'Bench Press',kind:'weight',val:220,prev:215}],
      calNotes:[{d:'2026-09-10',t:'PT test'}], discAck:{v:1,d:'2026-08-01'}, tour:{done:true}},
    logs:{'nova-sc-log:2026-08-20-A-W1B1':JSON.stringify({date:'2026-08-20',day:'A',week:1,report:'Bench Press 215: 5, 5, 5'}),
          'nova-sc-log:2026-08-27-A-W2B1':JSON.stringify({date:'2026-08-27',day:'A',week:2,report:'Bench Press 220: 5, 5, 5'})}};
  const before=EV('JSON.stringify(S.maxes)');
  let ok=false; try{ await EV('restoreBackup({ text: async function(){ return '+JSON.stringify(JSON.stringify(backup))+'; } })'); ok=true; }catch(e){ console.log('  restore threw', e.message); }
  chk('the restore runs', ok);
  chk('it lands on the card, not on setup', EV('ONB_ACTIVE()')===false && EV('ONB().done')===true, 'setup active: '+EV('ONB_ACTIVE()'));
  chk('maxes came across', EV('S.maxes.bench')===225 && EV('S.maxes.squat')===327);
  chk('history came across', EV('Object.keys(S.exHist||{}).length')===2 && EV("S.exHist['Bench Press'].length")===2);
  chk('records and calendar came across', EV('(S.prs||[]).length')===1 && EV('(S.calNotes||[]).length')===1);
  await EV('refreshLogs()');
  const keys=JSON.parse(EV('JSON.stringify(logKeys||[])'));
  chk('the banked sessions are in the PERSONAL drawer, not the roster namespace', keys.length===2 && keys.every(k=>k.indexOf('tc-log:')===0), keys.join(', ')||'no logs found');
  const box=JSON.parse(EV('JSON.stringify(mailBox())'));
  const letter=box.find(x=>/^restore-/.test(x.id));
  chk('Bulk says what came across, in numbers', !!letter && /2 sessions/.test(letter.txt) && /2 lifts/.test(letter.txt) && /6 maxes/.test(letter.txt), letter? letter.txt.slice(0,90):'no letter');
  chk('and says the old block did not come with it', !!letter && /Session Card backup/.test(letter.txt) && /Assessments/.test(letter.txt));
  chk('the toast carries the same numbers', /2 sessions/.test(EV('S.restoreNote||""')));
  // the card renders his data, with Minimal coaching text on
  EV('render();');
  chk('the training screen renders (no setup, no blank box)', !!D.querySelector('#app .ex, #app .deckrow, #app [data-day]'), 'app: '+D.getElementById('app').innerHTML.slice(0,60));
  // a same-card backup with no data at all still goes to setup (a new athlete restoring an empty file)
  const empty={v:1, S:{maxes:{}, exHist:{}}, logs:{}};
  // the card treats logs in storage as proof of an athlete (correctly), so clear them first
  EV('delete S.onb; (logKeys||[]).slice().forEach(function(k){ try{ stDel(k); }catch(e){} }); logKeys=[];');
  await EV('restoreBackup({ text: async function(){ return '+JSON.stringify(JSON.stringify(empty))+'; } })'); await EV('refreshLogs()');
  chk('an empty backup still leads to setup - data is the proof of an athlete', EV('ONB_ACTIVE()')===true);
  console.log('  problems:', bad); process.exit(bad?1:0);
})();
