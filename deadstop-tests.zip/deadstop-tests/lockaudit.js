// The day-lock guard is an ALLOWLIST: anything not named in it is dead on a banked day. It has
// already killed two whole features (disclaimer gate c144, coaching c152). Inverting it needs a
// structural wrapper around the session region and was judged too risky mid-stabilisation, so
// this audit stands in for it: enumerate every control rendered on a locked day and fail if a
// non-session control would be swallowed.
const {JSDOM}=require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const d=new JSDOM(fs.readFileSync(f,'utf8'),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/'});
const w=d.window,EV=e=>w.eval(e);
w.AudioContext=function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
let bad=0; const chk=(l,ok,dd)=>{ if(!ok)bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&dd?'  <-- '+dd:''}`);};
// controls that SHOULD be blocked on a banked day: they edit the logged session
// Everything that edits the logged session, verified one by one 2026-09-02: set marks, add/
// remove a set, swap, take out, load editor, per-set feel, readiness check-in (part of that
// day's record), the session date/time, and the custom-exercise adder. These SHOULD be dead on
// a banked day. Anything else that is dead is a guard omission - the c144/c152 bug class.
const SESSION_EDIT=/^(data-set|data-addset|data-subset|data-swap|data-out|data-restore|data-edit|data-rir|data-reps|data-load|data-note|data-wu|data-done|data-undo|data-skip|data-wbtn|data-feelbtn|data-rdy)/;
const SESSION_CLASS=['.swapsel','#sdate','#stime','#nowBtn','#cxName','#cxNameTxt','.cardio-row'];
setTimeout(()=>{
  console.log(`\n--- ${L}: what survives a banked day ---`);
  EV('try{TOUR.live=false;}catch(e){} S.tour={done:true}; if(typeof ONB!=="undefined"){ONB().done=true;} S.discAck={v:DISC_V,d:localDate()}; storageOK=true; save();');
  EV('S.locked=S.locked||{}; S.locked[cyc()+"|"+S.week+"|"+S.day]=true; save(); render();');
  chk('the day is locked', EV('dayLocked()')===true, 'not locked');
  // every interactive element currently on screen
  const report=EV(`(function(){
    var out=[], seen={};
    var nodes=document.querySelectorAll('#app [data-set],#app [role="button"],#app button,#app .daybtn,#app .chip,#app .toggle,#app .prof-edit,#app input,#app [onclick]');
    for(var i=0;i<nodes.length;i++){
      var el=nodes[i];
      var attrs=[]; for(var j=0;j<el.attributes.length;j++){ var n=el.attributes[j].name; if(n.indexOf('data-')===0) attrs.push(n); }
      var key=(attrs[0]||el.className||el.tagName);
      if(seen[key]) continue; seen[key]=1;
      var exempt = !!(el.closest('.lockfree')||el.closest('.tabrow')||el.closest('.chiprow')||el.closest('.weekhead')
        ||el.closest('#coachHost')||el.closest('.wn-wrap')||el.closest('.rpt-wrap')||el.closest('.hw-wrap')
        ||el.closest('#gbHost')||el.closest('.footer')||el.closest('.bfx-card')||el.closest('.pr-fx')
        ||el.closest('.hifive-wrap')||el.closest('.avabig-wrap')||el.closest('[data-unlock]'));
      var sessionish = !!(el.closest('.cardio-row')||el.matches('.swapsel')||['sdate','stime','nowBtn','cxName','cxNameTxt'].indexOf(el.id)>-1);
      out.push({key:key, attrs:attrs, exempt:exempt, sessionish:sessionish});
    }
    return JSON.stringify(out);
  })()`);
  const items=JSON.parse(report);
  chk('the locked day renders controls to audit', items.length>0, '0 found');
  const dead=items.filter(it=>!it.exempt && !it.attrs.some(a=>SESSION_EDIT.test(a)) && !it.sessionish);
  chk('no non-session control is swallowed by the guard', dead.length===0,
      dead.map(x=>x.key+'['+x.attrs.join(',')+']').join(' | '));
  console.log('  problems: '+bad); process.exit(bad?1:0);
},1700);
