// NO REDUNDANT FILLS (2026-09-03, field: "Reverse Peck Deck and reverse flys got generated as
// recommendations for the same day's training but they're essentially the same type of exercise
// hitting the same muscles").
//
// A fill exists to cover something the day is MISSING. sessPickExercise walked the day's own
// muscles and added a second movement for whichever was furthest under its weekly target, so a
// day with a rear-delt movement on it got another rear-delt movement - and the second pass added
// the third name off the same list.
//
// The redundancy signature is deliberately narrow: two PURE ISOLATIONS for the same muscle,
// where pure isolation means one muscle at full credit and nothing else meaningful. That catches
// Reverse Pec Deck + Rear Delt Fly and Lateral Raises + Cable Lateral Raise. It does NOT catch
// Bench Press + Incline Press, which share chest at full credit but each carry front delts and
// triceps as well - two chest movements on a push day are programming, not redundancy, and this
// harness must never start failing them.
const { JSDOM } = require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const dom=new JSDOM(fs.readFileSync(f,'utf8'),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/',
  beforeParse(w){
    w.AudioContext=function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
    w.alert=()=>{};
  }});
const w=dom.window,EV=e=>w.eval(e);
let bad=0; const chk=(l,ok,d)=>{ if(!ok) bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&d?'  <-- '+d:''}`); };

setTimeout(async()=>{
  console.log(`\n--- ${L}: a fill covers what the day is missing ---`);
  EV('try{TOUR.live=false;}catch(e){} S.tour={done:true}; if(typeof ONB!=="undefined"){ONB().done=true;} S.discAck={v:DISC_V,d:localDate()}; storageOK=true; S.maxes={squat:327,bench:225,dead:405,ohp:145,row:170,pull:225}; save();');

  // pure isolation: exactly one muscle, at full credit, nothing else worth counting
  EV(`window.__iso=function(n){ var mm=volMuscles(n); if(!mm) return null;
        var full=[], other=0;
        for(var m in mm){ if(mm[m]>=1) full.push(m); else if(mm[m]>=0.4) other++; }
        return (full.length===1 && other===0)? full[0] : null; };`);

  // the fixture has to be able to SEE the bug, or a green here means nothing
  chk('(fixture) the two movements he saw really do read as the same thing',
      EV('__iso("Reverse Pec Deck")')==='rdelt' && EV('__iso("Rear Delt Fly")')==='rdelt',
      'iso says '+EV('__iso("Reverse Pec Deck")')+' / '+EV('__iso("Rear Delt Fly")'));
  chk('(fixture) and two chest presses do NOT - this rule must not touch real programming',
      EV('__iso("Bench Press")')===null || EV('__iso("Incline Barbell Press")')===null,
      'a bench and an incline read as redundant, which would fail honest programming');

  // 1. THE PICKER: whatever it returns must not be a muscle the day already trains directly
  const codes=JSON.parse(EV('JSON.stringify(PLAN.days.map(function(d){return d.code;}))'));
  let clashes=[];
  codes.forEach(c=>{
    const r=EV(`(function(){
      var exs=effectiveExercises(${JSON.stringify(c)});
      var direct={}; exs.forEach(function(ex){ var mm=volMuscles(ex.name); if(mm) for(var m in mm) if(mm[m]>=1) direct[m]=1; });
      var p=sessPickExercise(${JSON.stringify(c)}, exs);
      return JSON.stringify(p? {code:${JSON.stringify(c)}, name:p.name, muscle:p.muscle, clash:!!direct[p.muscle]} : null);
    })()`);
    const o=r&&r!=='null'? JSON.parse(r) : null;
    if(o && o.clash) clashes.push(o.code+': '+o.name+' for '+o.muscle+', already trained directly');
  });
  chk('the fill picker never picks a muscle the day already trains directly',
      clashes.length===0, clashes.join(' | '));

  // 2. TWO PASSES: the real bug needed a second fill to land on the same muscle as the first
  let pairFail=[];
  codes.forEach(c=>{
    const r=EV(`(function(){
      var exs=effectiveExercises(${JSON.stringify(c)}).slice();
      var picks=[];
      for(var n=0;n<2;n++){
        var p=sessPickExercise(${JSON.stringify(c)}, exs); if(!p) break;
        picks.push(p);
        exs.push({name:p.name, sets:3});
      }
      return JSON.stringify(picks);
    })()`);
    const picks=JSON.parse(r);
    if(picks.length===2){
      const a=EV('__iso('+JSON.stringify(picks[0].name)+')'), b=EV('__iso('+JSON.stringify(picks[1].name)+')');
      if(picks[0].muscle===picks[1].muscle || (a && a===b))
        pairFail.push(c+': '+picks[0].name+' + '+picks[1].name+' (both '+(a||picks[0].muscle)+')');
    }
  });
  chk('two fills on one day never land on the same muscle',
      pairFail.length===0, pairFail.join(' | '));

  // 3. THE ADDED FILLS THEMSELVES, after sessFillDay has actually run. Scoped to fills on
  // purpose: the base template pairs Straight Bar Curl with Incline DB Curl, and Hanging Leg
  // Raises with Plank - a stretched-position curl next to a mid-range one, and dynamic flexion
  // next to an anti-extension hold. Those are programming choices with different stimuli behind
  // them, and they are HIS to make. This harness polices what the card adds on its own.
  let dupes=[];
  codes.forEach(c=>{
    EV(`S.day=${JSON.stringify(c)}; try{ sessFillDay(${JSON.stringify(c)}); }catch(e){}`);
    const r=EV(`(function(){
      var fills=(custList(${JSON.stringify(c)})||[]).filter(function(x){ return x.fill; }).map(function(x){ return x.name; });
      var all=effectiveExercises(${JSON.stringify(c)}).map(function(x){ return x.name; });
      return JSON.stringify({fills:fills, all:all});
    })()`);
    const {fills, all}=JSON.parse(r);
    fills.forEach(fn=>{
      const fm=EV('__iso('+JSON.stringify(fn)+')');
      if(!fm) return;
      all.forEach(other=>{
        if(other===fn) return;
        const om=EV('__iso('+JSON.stringify(other)+')');
        if(om && om===fm) dupes.push(c+': fill '+fn+' duplicates '+other+' (both '+fm+')');
      });
    });
  });
  chk('a fill the card adds never duplicates a movement already on the day',
      dupes.length===0, dupes.join(' | '));

  // 4. and the feature still works - fills are not simply switched off
  const stillFills=EV(`(function(){
    var any=false;
    PLAN.days.forEach(function(d){ if(sessPickExercise(d.code, effectiveExercises(d.code))) any=true; });
    return any;
  })()`);
  console.log('  (a fill is still offered somewhere: '+stillFills+')');

  console.log('  problems:', bad); process.exit(bad?1:0);
},1500);
