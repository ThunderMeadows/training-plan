// The session-length target, engine-filled (2026-09-02, his ruling: "take it off - I'll let
// the machine make that decision"). The athlete sets a target in Settings and never touches
// the fill. Order of judgement: +1 set on the lightest accessories (never a main, three max,
// none past four), then a recommended exercise for the day's own muscle furthest under its
// weekly target, then a Zone 2 finisher. A day at target is left alone; logged work is never
// removed; a fill the day no longer needs is taken back only if nothing was logged on it.
const { JSDOM } = require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const dom=new JSDOM(fs.readFileSync(f,'utf8'),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/'});
const w=dom.window,D=w.document,EV=e=>w.eval(e);
w.AudioContext=w.AudioContext||function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
setTimeout(()=>{
  console.log(`\n--- ${L}: session length, engine-filled ---`);
  let bad=0; const chk=(l,ok,d)=>{ if(!ok) bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&d?'  <-- '+d:''}`); };
  EV('try{TOUR.live=false;}catch(e){} S.tour={done:true}; if(typeof ONB!=="undefined"){ONB().done=true;} S.discAck={v:DISC_V,d:localDate()}; storageOK=true; S.data={}; S.customs={}; S.week=1;');
  const code=EV('S.day=PLAN.days[0].code; S.day');
  // ---- off: untouched ----
  EV('S.sessTarget=null; sessFillDay(S.day); render();');
  chk('target off: no plan, no fill', !EV('dayObj().sessPlan') && EV('custList(S.day).filter(function(c){return c.fill;}).length')===0);
  chk('the manual chips are gone', D.querySelectorAll('[data-ssel],[data-sfin]').length===0);
  // ---- 1:30 on a short day ----
  EV('S.sessTarget=90; sessFillDay(S.day); render();');
  const base=EV('sessionMinutes(PLAN.days[0])');
  const sp=JSON.parse(EV('JSON.stringify(dayObj().sessPlan||null)'));
  const fills=JSON.parse(EV('JSON.stringify(custList(S.day).filter(function(c){return c.fill;}))'));
  console.log('  base day ~'+base+' min; sets added:', sp? sp.adds.length : 0, '; exercises added:', fills.map(x=>x.name+' ('+x.why+')').join(', ')||'none', '; finisher:', sp? sp.fin : 0);
  chk('a short day is filled without being asked', !!sp || fills.length>0);
  if(sp){
    chk('never more than three added sets', sp.adds.length<=3);
    const mains=sp.adds.filter(a=>EV(`(function(){ var ex=dayObj().exercises.filter(function(x){return x.name===${JSON.stringify(a.name)};})[0]; return !!(ex&&(ex.maxKey||ex.pct)); })()`));
    chk('no main lift ever grows', mains.length===0, mains.map(a=>a.name).join(','));
    chk('finisher stays 10-30 min (or 0)', sp.fin===0||(sp.fin>=10&&sp.fin<=30), sp.fin);
  }
  if(fills.length){
    chk('an added exercise is a real library movement with a real load', fills.every(x=>EV(`!!libRow(${JSON.stringify(x.name)})`) && (x.load==='BW'||x.load>0)));
    chk('it targets a muscle the day already trains, in the day\'s own family', fills.every(x=>{
      const fam=EV(`sessFamily(${JSON.stringify(code)})`); const grp=EV(`libRow(${JSON.stringify(x.name)})[1]`);
      return (!fam || grp===fam) && !!x.why; }), JSON.stringify(fills.map(x=>[x.name,x.why])));
    chk('never more than two exercises added', fills.length<=2);
    chk('the added exercise is on the day with set state', EV(`dayObj().exercises.some(function(e){ return e.name===${JSON.stringify(fills[0].name)}; })`));
    chk('no duplicate of something already on the day', new Set(EV('JSON.stringify(dayObj().exercises.map(function(e){return e.name;}))')).size>0 && JSON.parse(EV('JSON.stringify(dayObj().exercises.map(function(e){return e.name;}))')).filter(n=>n===fills[0].name).length===1);
  }
  const total=EV('(function(){ var d=dayObj(); return sessSecsExact(d.exercises)+((d.sessPlan&&d.sessPlan.fin)||0)*60; })()');
  chk('lifting + finisher lands within 10 min of 1:30', Math.abs(total-90*60)<=600, Math.round(total/60)+' min');
  chk('the day says what was filled and points at Settings', /Filled to your target/.test(D.body.innerHTML) && /Settings/.test(D.body.innerHTML));
  // ---- idempotent: composing again adds nothing ----
  EV('sessFillDay(S.day); render();');
  chk('composing the same day twice adds nothing', EV('custList(S.day).filter(function(c){return c.fill;}).length')===fills.length);
  // ---- a day over target is never trimmed ----
  EV('S.sessTarget=60; sessFillDay(S.day); render();');
  chk('a day over target keeps every original exercise', EV('dayObj().exercises.length')>=EV('PLAN.days[0].exercises.length'));
  // ---- logged work on a fill survives the target going away ----
  EV('S.sessTarget=90; S.customs={}; S.data={}; sessFillDay(S.day); render();');
  const f2=JSON.parse(EV('JSON.stringify(custList(S.day).filter(function(c){return c.fill;}))'));
  if(f2.length){
    EV(`(function(){ var d=dayObj(); var i=d.exercises.findIndex(function(e){ return e.name===${JSON.stringify(f2[0].name)}; }); var st=exState(i,d.exercises[i]); st.sets[0].st='hit'; st.sets[0].reps=10; save(); })()`);
    EV('S.sessTarget=null; sessFillDay(S.day); render();');
    chk('a fill with a logged set is never taken back', EV(`custList(S.day).some(function(c){ return c.fill && c.name===${JSON.stringify(f2[0].name)}; })`), 'logged work removed');
    EV('S.data={}; sessFillDay(S.day);');
    chk('the same fill with nothing logged is taken back when the target is off', !EV(`custList(S.day).some(function(c){ return c.fill; })`));
  } else console.log('  (this day filled with sets alone - the exercise-retirement checks need a shorter day)');
  // ---- deload: nothing added ----
  EV('S.sessTarget=90; S.customs={}; S.week=PLAN.weeks; sessFillDay(S.day); render();');
  chk('a deload week is never filled', !EV('dayObj().sessPlan') && EV('custList(S.day).filter(function(c){return c.fill;}).length')===0);
  EV('S.week=1; S.customs={};');
  console.log('  problems:', bad);
  process.exit(bad?1:0);
},1500);
