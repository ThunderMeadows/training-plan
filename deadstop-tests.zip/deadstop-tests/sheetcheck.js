// The gear must actually open the sheet, via a real click, and the same controls must not
// also render inline anywhere else - two live copies fight over one piece of state.
const { JSDOM } = require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const dom=new JSDOM(fs.readFileSync(f,'utf8'),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://thundermeadows.github.io/'});
const w=dom.window,D=w.document,EV=e=>w.eval(e);
w.AudioContext=w.AudioContext||function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
const click=el=>el.dispatchEvent(new w.MouseEvent('click',{bubbles:true,cancelable:true,view:w}));
setTimeout(()=>{
  console.log(`\n--- ${L}: the gear opens the settings sheet ---`);
  EV('try{TOUR.live=false;}catch(e){} try{S.tour={done:true};}catch(e){}');
  const ch=D.getElementById('coachHost'); if(ch) ch.remove();
  for(const fn of ['coachIdle','ONB_ACTIVE','isStartMode']) EV(`if(typeof ${fn}==="function") ${fn}=function(){return false;};`);
  EV('render();');
  let bad=0;
  const gear=D.querySelector('[data-setopen]');
  console.log('  gear in header      :', !!gear); if(!gear) bad++;
  if(gear){
    // NB: the gear is bound with addEventListener, not onclick - checking el.onclick reports
    // a false negative on a perfectly wired gear. Dispatch a real click.
    click(gear);
    const open=!!D.querySelector('#setHost .set-sheet');
    console.log('  opens on a real tap :', open); if(!open) bad++;
    console.log('  controls inside     :', D.querySelectorAll('#setHost [data-thm]').length, 'themes,',
                D.querySelectorAll('#setHost [data-gbflav]').length, 'flavours');
    if(D.querySelectorAll('#setHost [data-thm]').length===0) bad++;
  }
  // no duplicate copies of the same controls anywhere outside the sheet, on any screen
  let dupes=0;
  for(const day of JSON.parse(EV('JSON.stringify(PLAN.days.map(function(d){return d.code;}))')).concat(['MAX'])){
    EV(`S.day=${JSON.stringify(day)}; render();`);
    const outside=D.querySelectorAll('[data-thm]').length - D.querySelectorAll('#setHost [data-thm]').length;
    if(outside>0){ console.log(`  DUPLICATE controls rendered on screen ${day}: ${outside}`); dupes+=outside; }
  }
  console.log('  duplicate inline copies:', dupes); if(dupes) bad++;
  console.log('  runtime errors      :', EV('(typeof ERR_LOG!=="undefined"?ERR_LOG.length:"n/a")'));
  console.log('  problems:', bad);
  process.exit(bad?1:0);
},1500);
