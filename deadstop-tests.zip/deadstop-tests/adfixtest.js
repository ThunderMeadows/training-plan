// The repair pass for cuts the OLD stall rule made.
//
// c166 corrected the rule going forward. It did nothing about cuts already sitting in S.maxes,
// and "Put it back" only ever reverses the most recent batch - so a bad cut with any
// adaptation after it was unreachable from the UI. This is the card undoing its own mistake.
//
// The danger in a repair pass is that it is too eager: handing an athlete a bar 8% heavier
// because a script decided a cut looked wrong. So most of these checks are about what it must
// REFUSE to touch - an earned cut, a falling estimate, a max the athlete has since moved, and
// a second run of itself.
const { JSDOM } = require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const dom=new JSDOM(fs.readFileSync(f,'utf8'),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/'});
const w=dom.window,D=w.document,EV=e=>w.eval(e);
w.AudioContext=w.AudioContext||function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};

// One scenario, set up through the card's own state. `hist` is [estimate, cleanFlag] per
// session, oldest first; cleanFlag undefined = a point recorded before c166 carried no flag.
function scenario(o){
  const h=o.hist.map((p,i)=>{
    const pt={d:'2026-08-'+String(10+i).padStart(2,'0'), v:p[0], r:5};
    if(p[1]!==undefined) pt.c=p[1];
    return pt;
  });
  EV(`S.adFixStall=null; S.adFixed=null; S.genPlan=null;
      S.maxes=${JSON.stringify(o.maxes)};
      S.e1rmH={${JSON.stringify(o.lift)}:${JSON.stringify(h)}};
      S.adLog=${JSON.stringify(o.adLog)};`);
  return EV('adRepairStalls()');
}

setTimeout(()=>{
  console.log(`\n--- ${L}: repairing the old stall rule's cuts ---`);
  let bad=0; const chk=(l,ok,d)=>{ if(!ok) bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&d?'  <-- '+d:''}`); };

  const CUT={kind:'stall', lift:'bench', from:250, to:230, d:'2026-08-14',
             why:'three sessions without progress'};

  // ---- his exact case: a rising-percentage block, executed clean, cut anyway ----
  // 70x8 -> 75x6 -> 80x5 estimates the same max every session. That is the block working.
  let n=scenario({lift:'bench', maxes:{bench:230, squat:400}, adLog:[CUT],
                  hist:[[250,1],[250,1],[250,1]]});
  chk('the compliant lifter gets his max back', n===1 && EV('S.maxes.bench')===250,
      'restored to '+EV('S.maxes.bench'));
  chk('the bad entry leaves the adaptation log', EV('(S.adLog||[]).length')===0);
  chk('the athlete is told, in the card, what was put back',
      EV('(S.adFixed||[]).length')===1 && EV('S.adFixed[0].to')===250);
  chk('and no other lift is touched', EV('S.maxes.squat')===400);

  // ---- legacy points carry no flag at all: the c166 "no evidence, no reset" standard ----
  n=scenario({lift:'bench', maxes:{bench:230}, adLog:[CUT], hist:[[250],[250],[250]]});
  chk('an unflagged flat history is repaired too - no evidence, no cut', n===1 && EV('S.maxes.bench')===250);

  // ---- REFUSALS ----
  // an earned cut: two of three sessions struggled. The rule was right; leave it alone.
  n=scenario({lift:'bench', maxes:{bench:230}, adLog:[CUT], hist:[[250,0],[250,0],[250,1]]});
  chk('an earned cut is left standing', n===0 && EV('S.maxes.bench')===230,
      'a genuine stall was reversed - the athlete gets a bar they could not move');
  chk('and no notice is shown for it', !EV('(S.adFixed||[]).length'));

  // a falling estimate is real regression, flags or not. This is the discriminator that works
  // on legacy data: flat is a percentage block, falling is going backwards.
  n=scenario({lift:'bench', maxes:{bench:230}, adLog:[CUT], hist:[[260],[255],[248]]});
  chk('a falling estimate keeps its back-off', n===0 && EV('S.maxes.bench')===230,
      'an athlete who genuinely regressed was handed 8% more bar');

  // the athlete (or a later climb) has moved that max since: their number wins.
  n=scenario({lift:'bench', maxes:{bench:240}, adLog:[CUT], hist:[[250,1],[250,1],[250,1]]});
  chk('a max moved since the cut is never overwritten', n===0 && EV('S.maxes.bench')===240,
      'the repair walked over a number the athlete set');

  // not enough history to judge
  n=scenario({lift:'bench', maxes:{bench:230}, adLog:[CUT], hist:[[250,1],[250,1]]});
  chk('too little history to judge means hands off', n===0 && EV('S.maxes.bench')===230);

  // other adaptation kinds are none of this pass's business
  n=scenario({lift:'bench', maxes:{bench:230}, hist:[[250,1],[250,1],[250,1]],
              adLog:[{kind:'rate', lift:'bench', from:250, to:230, d:'2026-08-14', why:'x'}]});
  chk('a rate change is left alone', n===0 && EV('S.maxes.bench')===230 && EV('(S.adLog||[]).length')===1);

  // ---- it runs once, ever ----
  scenario({lift:'bench', maxes:{bench:230}, adLog:[CUT], hist:[[250,1],[250,1],[250,1]]});
  EV("S.maxes.bench=230; S.adLog=[{kind:'stall',lift:'bench',from:250,to:230,d:'2026-08-14',why:'x'}];");
  const again=EV('adRepairStalls()');
  chk('a second run does nothing - the flag is set, not the outcome', again===0 && EV('S.maxes.bench')===230,
      'it would re-restore every time the card opened');

  // ---- the notice renders, and dismisses ----
  scenario({lift:'bench', maxes:{bench:230}, adLog:[CUT], hist:[[250,1],[250,1],[250,1]]});
  const html=EV('adFixedHTML()');
  chk('the notice names the lift and both numbers',
      /Bench Press/.test(html) && /230/.test(html) && /250/.test(html), html.slice(0,80));
  chk('it explains the card was wrong, not the athlete', /rising-percentage block/.test(html));
  EV('S.adFixed=null;');
  chk('and it disappears once dismissed', EV('adFixedHTML()')==='');

  // ---- the corrected forward rule is still the one in force ----
  EV(`S.adFixStall=1; S.adLog=[]; S.maxes={bench:250};
      S.e1rmH={bench:[{d:'2026-08-10',v:250,r:5,c:1},{d:'2026-08-12',v:250,r:5,c:1},{d:'2026-08-14',v:250,r:5,c:1}]};`);
  chk('a clean flat block still raises no stall going forward', JSON.parse(EV('JSON.stringify(adStalled())')).length===0);
  EV(`S.e1rmH={bench:[{d:'2026-08-10',v:250,r:5,c:0},{d:'2026-08-12',v:250,r:5,c:0},{d:'2026-08-14',v:250,r:5,c:1}]};`);
  chk('and a struggled flat block still does', JSON.parse(EV('JSON.stringify(adStalled())')).length===1);

  console.log('  problems:', bad);
  process.exit(bad?1:0);
},1500);
