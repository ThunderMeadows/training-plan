// The repair pass for cuts the OLD stall rule made.
//
// c166 corrected the rule going forward. It did nothing about cuts already sitting in S.maxes,
// and "Put it back" only ever reverses the most recent batch - so a bad cut with any
// adaptation after it was unreachable from the UI. This is the card undoing its own mistake.
//
// The danger in a repair pass is that it is too eager: handing an athlete a bar 8% heavier
// because a script decided a cut looked wrong. So most of these checks are about what it must
// REFUSE to touch - an earned cut, a falling estimate, a max the athlete has since moved, and
// a second run of itself.
const { JSDOM } = require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const dom=new JSDOM(fs.readFileSync(f,'utf8'),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/'});
const w=dom.window,D=w.document,EV=e=>w.eval(e);
w.AudioContext=w.AudioContext||function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};

// One scenario, set up through the card's own state. `hist` is [estimate, cleanFlag] per
// session, oldest first; cleanFlag undefined = a point recorded before c166 carried no flag.
function scenario(o){
  const h=o.hist.map((p,i)=>{
    const pt={d:'2026-08-'+String(10+i).padStart(2,'0'), v:p[0], r:5};
    if(p[1]!==undefined) pt.c=p[1];
    if(p[2]!==undefined) pt.n=p[2];        // c207: the rep target the point came from
    return pt;
  });
  // mxProv MUST be cleared between scenarios: an earlier unprovable put-back leaves a lift on
  // trial, and without this reset the next scenario inherits it and the check passes or fails
  // for the wrong reason. Fixture leak, caught by the proven-vs-unprovable pair.
  EV(`S.adFixStall=null; S.adFixed=null; S.genPlan=null; S.mxProv=null;
      S.maxes=${JSON.stringify(o.maxes)};
      S.e1rmH={${JSON.stringify(o.lift)}:${JSON.stringify(h)}};
      S.adLog=${JSON.stringify(o.adLog)};`);
  return EV('adRepairStalls()');
}

setTimeout(()=>{
  console.log(`\n--- ${L}: repairing the old stall rule's cuts ---`);
  let bad=0; const chk=(l,ok,d)=>{ if(!ok) bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&d?'  <-- '+d:''}`); };

  const CUT={kind:'stall', lift:'bench', from:250, to:230, d:'2026-08-14',
             why:'three sessions without progress'};

  // ---- his exact case: a rising-percentage block, executed clean, cut anyway ----
  // 70x8 -> 75x6 -> 80x5 estimates the same max every session. That is the block working.
  let n=scenario({lift:'bench', maxes:{bench:230, squat:400}, adLog:[CUT],
                  hist:[[250,1],[250,1],[250,1]]});
  chk('the compliant lifter gets his max back', n===1 && EV('S.maxes.bench')===250,
      'restored to '+EV('S.maxes.bench'));
  chk('the bad entry leaves the adaptation log', EV('(S.adLog||[]).length')===0);
  chk('the athlete is told, in the card, what was put back',
      EV('(S.adFixed||[]).length')===1 && EV('S.adFixed[0].to')===250);
  chk('and no other lift is touched', EV('S.maxes.squat')===400);
  // that first case is UNTAGGED, so it is on trial. A tagged, flat, clean window proves the cut
  // was wrong outright, and the number goes straight back as a standing max.
  n=scenario({lift:'bench', maxes:{bench:230, squat:400}, adLog:[CUT],
              hist:[[250,1,5],[250,1,5],[250,1,5]]});
  chk('a PROVEN put-back is standing, not on trial', n===1 && EV('S.maxes.bench')===250
      && !EV('!!(S.mxProv&&S.mxProv.bench)'), 'a proven restore was put on trial anyway');

  // ---- legacy points carry no flag at all: the c166 "no evidence, no reset" standard ----
  n=scenario({lift:'bench', maxes:{bench:230}, adLog:[CUT], hist:[[250],[250],[250]]});
  chk('an unflagged flat history is repaired too - no evidence, no cut', n===1 && EV('S.maxes.bench')===250);

  // ---- REFUSALS ----
  // an earned cut: two of three sessions struggled. The rule was right; leave it alone.
  n=scenario({lift:'bench', maxes:{bench:230}, adLog:[CUT], hist:[[250,0],[250,0],[250,1]]});
  chk('an earned cut is left standing', n===0 && EV('S.maxes.bench')===230,
      'a genuine stall was reversed - the athlete gets a bar they could not move');
  chk('and no notice is shown for it', !EV('(S.adFixed||[]).length'));

  // REVERSED 2026-09-05 (c207), by a real card. This used to assert that a falling UNTAGGED
  // estimate is real regression and keeps its cut - "flat is a percentage block, falling is
  // going backwards". Jefe's own history is the counterexample that killed it: 181 -> 162 -> 154,
  // untagged, and he was pressing MORE weight for MORE sets the whole time. The fall was an
  // eight-rep day followed by two ten-rep days. On untagged history a fall proves nothing, so it
  // no longer protects a cut. Gate 2 still keeps cuts that struggle actually earned, and if the
  // regression is real the forward rule cuts again within three same-kind sessions.
  n=scenario({lift:'bench', maxes:{bench:230}, adLog:[CUT], hist:[[260],[255],[248]]});
  chk('an untagged fall no longer protects a cut - it may just be the rep scheme changing',
      n===1 && EV('S.maxes.bench')===250, 'kept a cut it cannot justify: bench '+EV('S.maxes.bench'));
  // ...but the restore is not a standing number. Untagged history proves neither the cut nor the
  // put-back, so the max goes back ON TRIAL: if the regression was real, two missed or ground-out
  // sessions step it back down, and never below the number it was cut to.
  chk('and an unprovable put-back comes back ON TRIAL, not as a standing max',
      EV('!!(S.mxProv&&S.mxProv.bench)') && EV('(S.mxProv.bench||{}).src')==='putback',
      'restored outright on evidence that proves nothing');
  chk('with a floor at the number it was cut to - already trained, never below it',
      EV('(S.mxProv.bench||{}).floor')===230, 'floor is '+EV('(S.mxProv.bench||{}).floor'));

  // ...but a fall measured LIKE FOR LIKE is still real evidence, and still keeps the cut.
  n=scenario({lift:'bench', maxes:{bench:230}, adLog:[CUT], hist:[[260,undefined,5],[255,undefined,5],[248,undefined,5]]});
  chk('a fall within ONE rep target does keep its back-off', n===0 && EV('S.maxes.bench')===230,
      'an athlete who genuinely regressed was handed 8% more bar');

  // the athlete (or a later climb) has moved that max since: their number wins.
  n=scenario({lift:'bench', maxes:{bench:240}, adLog:[CUT], hist:[[250,1],[250,1],[250,1]]});
  chk('a max moved since the cut is never overwritten', n===0 && EV('S.maxes.bench')===240,
      'the repair walked over a number the athlete set');

  // not enough history to judge
  n=scenario({lift:'bench', maxes:{bench:230}, adLog:[CUT], hist:[[250,1],[250,1]]});
  chk('too little history to judge means hands off', n===0 && EV('S.maxes.bench')===230);

  // other adaptation kinds are none of this pass's business
  n=scenario({lift:'bench', maxes:{bench:230}, hist:[[250,1],[250,1],[250,1]],
              adLog:[{kind:'rate', lift:'bench', from:250, to:230, d:'2026-08-14', why:'x'}]});
  chk('a rate change is left alone', n===0 && EV('S.maxes.bench')===230 && EV('(S.adLog||[]).length')===1);

  // ---- it runs once, ever ----
  scenario({lift:'bench', maxes:{bench:230}, adLog:[CUT], hist:[[250,1],[250,1],[250,1]]});
  EV("S.maxes.bench=230; S.adLog=[{kind:'stall',lift:'bench',from:250,to:230,d:'2026-08-14',why:'x'}];");
  const again=EV('adRepairStalls()');
  chk('a second run does nothing - the flag is set, not the outcome', again===0 && EV('S.maxes.bench')===230,
      'it would re-restore every time the card opened');

  // ---- the notice renders, and dismisses ----
  scenario({lift:'bench', maxes:{bench:230}, adLog:[CUT], hist:[[250,1],[250,1],[250,1]]});
  const html=EV('adFixedHTML()');
  chk('the notice names the lift and both numbers',
      /Bench Press/.test(html) && /230/.test(html) && /250/.test(html), html.slice(0,80));
  chk('it explains the card was wrong, not the athlete', /rising-percentage block/.test(html));
  EV('S.adFixed=null;');
  chk('and it disappears once dismissed', EV('adFixedHTML()')==='');

  // ---- the corrected forward rule is still the one in force ----
  EV(`S.adFixStall=1; S.adLog=[]; S.maxes={bench:250};
      S.e1rmH={bench:[{d:'2026-08-10',v:250,r:5,c:1,n:5},{d:'2026-08-12',v:250,r:5,c:1,n:5},{d:'2026-08-14',v:250,r:5,c:1,n:5}]};`);
  chk('a clean flat block still raises no stall going forward', JSON.parse(EV('JSON.stringify(adStalled())')).length===0);
  EV(`S.e1rmH={bench:[{d:'2026-08-10',v:250,r:5,c:0,n:5},{d:'2026-08-12',v:250,r:5,c:0,n:5},{d:'2026-08-14',v:250,r:5,c:1,n:5}]};`);
  chk('and a struggled flat block still does', JSON.parse(EV('JSON.stringify(adStalled())')).length===1);

  console.log('  problems:', bad);
  process.exit(bad?1:0);
},1500);
