# Deadstop card tests

Pre-deploy checks for the Session Card and the Training Card. Run them before every
upload. They take about a minute, which is cheaper than a bad deploy on a live card.

## Setup — once

```
cd tests
npm install
```

Needs Node 18 or newer. The only dependency is jsdom.

## Running

```
npm test                                    # auto-discovers index.html one level up
node run.js ../training/index.html          # or name the cards explicitly
node run.js ../training/index.html ../session/index.html
node smoke.js ../training/index.html        # one harness on its own, full output
```

Exit code 0 means everything passed. Non-zero means do not deploy. The runner prints
only the failing detail, so a green run is short.

## What each check guards, and the bug that caused it

Every one of these exists because something shipped broken. The description is the
symptom you would see if the fix were removed.

| Harness | Guards against |
|---|---|
| `smoke` | Any screen failing to render, or a runtime error on any day of the plan. |
| `clickaudit` | A settings control that changes state but does not highlight, closes the sheet, or has no visible effect. Caused by a hand-written attribute list drifting out of step with the markup. |
| `flushtest` | The two "pointless-looking" reads in `gbApplyFlavour` being tidied away. They force a repaint; without them the bear keeps its old colour until the app is relaunched. |
| `interp` | A flavour whose filter has a different function list from the others. CSS only interpolates matching lists, so a mismatched one silently fails to repaint. |
| `spotchange` | A flavour that removes the filter instead of assigning one. |
| `shadowtest` | A tint overwriting the bear's drop shadow — they share the `filter` property and must be composed, never replaced. |
| `persist` | The saved bear colour not being reapplied after storage loads. State is read asynchronously, after the bear is drawn. |
| `anchortest` | A movement with no known ratio being prescribed the floor weight while claiming it was "estimated from your squat". Twelve movements did this; one produced 5 lb against a 327 lb squat, in the field. |
| `resttest` | The rest extension becoming one-way again. An accidental +30s must be reversible, and must never drop below the prescribed rest. |
| `grindtest` | The grind flag being dropped at save, or changing the next prescription in the wrong direction. Walks all eight rir × grind combinations plus the stall escape. |
| `presctest` | The rest-screen weight stepper writing the exercise-level override, which *is* the day's prescription — rewriting what the card asked for, including sets already banked. It must write the set's own performed weight, and that is what anchors the next session. |
| `adjusttest` | The weight badge under a set logging it instead of opening the editor, or a mistapped set having no way back. A pending set's only action used to be "I did this", so returning to adjust it banked it. |
| `goaltest` | A goal offered in setup that has no scheme behind it, schemes that are not actually different, or the plan generator disagreeing with the scheme table about the same goal — it prescribed 5s for strength while the scheme said 3s. |
| `besttest` | "Best logged" ranked by raw weight (which makes a rep block read as regression) or nagging beside the working set. It must rank on estimated max, appear inline only when today is genuinely close, and say nothing during a deload. |
| `prdupe` | The same personal record shown twice. History replaces a same-date entry (`histPush`), but the PR ledger only ever appended — so banking a session, then banking it again after `+ set` or a correction (his exact day), filed every record that still stood a second time, and the banner reads that ledger. A re-bank now replaces today's entries for the lifts it judged, which also retires a record a correction took away. Ledgers written before the fix are tidied once at boot. |
| `prtest` | Personal records reading the exercise-level setting instead of the sets performed. Field-caught: a record showed 70 lb against a prescription of 60. Also guards volume being computed from one weight when the sets were done at several. |
| `holdfmt` | A plank held for 90 seconds reading "90s" where "1:30" is wanted. `holdFmt()` prints m:ss past a minute on the set chip, the rest screen, the print sheet and the session report; storage stays seconds so PRs and trends keep comparing. Any exercise `isHoldEx()` recognises — max holds, "30–45s per side", carries — goes through it. Harness note: the day shows one exercise at a time, so focus the hold (`S.focus`) before reading its chips, and read `#app`, not `body` — `body.innerHTML` includes the card's own source and will match anything. |
| `anchorday` | A session changing under the athlete's feet. He trained bench at 200 under a cut max, the update's repair pass restored the max mid-day, and the header plus every `+ set` re-prescribed at 215 beside five sets done at 200. Once a set of an exercise is logged, that session's prescription is what was lifted — read off the first logged set. An explicit adjustment still wins, an unlogged exercise still follows the live max, and a pre-stamp legacy log falls through. |
| `histtest` | A later change to the exercise weight rewriting what already-logged sets were performed at. Sets carried no weight of their own, so three sets done at 175 reported 165 the moment the bar was dropped for the fourth — and the rewritten number anchored the next session. |
| `restguard` | A single stray tap on the next set logging it mid-rest and throwing the running rest away. Guards both directions: it must ask while the clock is counting down, and must NOT ask once the rest is over. Also checks the prompt stays on screen long enough to read — it ran on the 1.5s default while describing a 5s window, so it flashed and vanished while a second tap would still have worked. |
| `zonetest` | The drawn drop zone drifting from `gbInZone()`. A target that does not match the test it represents is worse than no target. Also guards it never outliving the drag. |
| `recaptest` | The finish prompt losing its share button, describing the plan instead of what was logged, or failing to return after cardio or an extra lift. |
| `manifesttest` | The page not linking its manifest. Chrome will not offer to install an app it has never read a manifest for, and it only reads the one the page points at — the file shipped correct and unreferenced for the card's whole life, so no Android user was ever offered Install. Also checks the icons it names actually exist in the deploy. |
| `a2hstest` | Android users being shown iOS install steps. The Mac+touch heuristic that detects iPadOS also caught Android phones in Desktop-site mode, which send a Macintosh UA — they were told to tap Share in Safari. Walks eight real user agents. |

## Two tiers (2026-09-03)

`npm test` runs the **fast suite** - 70 harnesses, about 3.5 minutes at `-j 4`. `npm run predeploy`
runs **deadsweep** alone, which is minutes on its own; run it before an upload. `npm run all` runs both.
The runner is parallel because 64 harnesses open with a fixed 1.4-1.7s boot wait - roughly 100 seconds
a card of pure waiting. The box has one cpu, so `-j` buys overlapping waits, not throughput, and past
about 6 it stops helping. Serial work totals ~796s; `-j 4` finishes in ~208s.

**A declared harness that is not on disk is a HARD FAILURE, and so is a duplicate declaration.** The old
runner printed `SKIP (missing)` and still ended `ALL CHECKS PASSED` with exit 0. `deadsweep` was declared
in c181 but never committed as a file, so builds shipped green against a suite that was not running it.
The manifest is checked before any card is touched.

`statefuzz` alone takes 120s and is now the parallel floor - nothing finishes faster than it does.

| `deadsweep` | Dead buttons `orphantest` cannot see. That scan is static: a `data-` name in any selector counts as bound, so it misses a wire function that never runs for a screen, a handler that returns early, or a control bound by id. This one is dynamic: every `addEventListener` is recorded at parse time, what looks tappable is learned from the card's own `cursor:pointer` rules, and every screen and overlay is walked. A tappable with no handler on itself or a non-root ancestor is tapped for real, from reset state, and only one that changes nothing in `#app` is called dead. Four harness lessons, each of which let a deliberately unbound button through until fixed: the lock guard on `#app` is not a handler for its children; state must reset before every tap ("Got it, hide this" reads dead once it has been hidden); a leftover toast counts as an effect; and compare `#app`, not `body` — Bulk's idle animation rewrites body markup every tick. |
| `crossrestore` | His own migration: a Session Card backup restored into the Training Card. It sent him to setup with his data hidden behind it (no setup flag in the backup), the welcome copy was blank (Minimal coaching text hid it), the previous day's deck footer showed under setup — and, found by reading rather than in the field, every banked session was restoring under `nova-sc-log:`, the prefix this card reserves for roster athletes, where the personal drawer filters it out. Now: logs remapped to the personal prefix, data counts as proof of an athlete, setup copy is never hidden, the footer clears, and Bulk says in numbers what came across. Fixture lesson: the card treats logs in storage as proof of an athlete, so anything that needs the setup screen has to run before logs exist. |
| `setlaunch` | Settings buttons that look dead because what they open lands UNDER the sheet. The paste-restore box and the copied-text box Backup uses were created at z 40 beneath a sheet at 200, and Assessments started the warm-up retest in the app underneath the sheet. `setbtns` checked a hand-written list and stayed green through all three. This walks the real DOM with real clicks and reads z-order from the stylesheet and inline styles: disclaimer, terms, report, paste-restore, the copied-text box, the phone check, and Assessments closing the sheet. |
| `setbtns` | A panel launched from the settings sheet rendering *behind* it. The problem report shared the sheet's z-index of 200 and rendered later, so you had to close settings to reach the thing settings had just opened. Also checks every chip and data button is actually bound. |
| `selftest` | The phone check writing anywhere near the athlete's state, probing quota by filling storage, or running mid-session. A diagnostic that damages what it inspects is worse than none. |
| `gametest` | The rest-screen game opening on its own, surviving the rest it borrowed, leaving an animation frame running, or altering the session. A game inside a training app is only safe while it stays a guest. |
| `eyetest` | The eye glow drifting off the eyes, sitting above the blink lids, or being added back into the pose dimming rule — which would blank his eyes again while everything else still looked right. |
| `gotest` | A help shortcut pointing at a screen or element that is not there. Caught three on the first run: maxes sit behind the You tab's Edit button, and the body map and volume bars are on Plan, not You. |
| `helptest` | The help card failing to appear beside the posed bear, or outliving the pose and sitting orphaned over the app. |
| `safetytest` | Restore replacing the entire state from a file picker with no confirmation and no way back — while erasing the phone has three layers of protection. Also guards the shape merge (a backup taken before a field existed used to leave that field missing and kill the next tick) and that the rescue snapshot is REACHABLE from settings, not just written. |
| `sheetcheck` | The gear not opening the settings sheet, or the same controls rendering both in the sheet and inline. Two live copies of one control fight over one piece of state. |
| `releasetest` | Athletes never being told what changed. `WHATSNEW` sat unfed from August 22 and its sheet never fired. Now every noticeable build gets an entry with a `bulk:` line and Bulk delivers it as one letter, once ever per release, to returning athletes only — through the send ledger, so clearing the box cannot resend it — and the old sheet must not also pop. Also guards the fallback: an entry with no `bulk` line is still delivered from its title and items. |
| `audit` | The gap between "every unit passes" and "the feature works." Drives real flows in a real athlete state: a c166-era saved card booting into this build (theme migration, repair, rhythm default), every theme in both lights through real taps with the status bar following, an Open athlete jumping, banking through `saveSessionLog`, being closed for the day, repeating the next day, and the banked repeat reading as a document after that. First run found two bugs the suite had waved through: the rhythm answer was written by only one of the three program builders, and a repeat pass stayed live forever. |
| `rhythmtest` | Open mode taking down restrictions that were never about sequence. "Fewer restrictions" is one instruction and four different locks: the sequence lock (which Open lifts), the integrity lock on a banked day, one session per day, and the week boundary. Only the first is Open's business. Also guards the other direction — Guided is what every existing athlete runs, and it must keep its rail — and that the weekday map is built in week order rather than tap order, so his tester's push Mon/Thu, pull Tue/Fri, legs Wed/Sat comes out of a 3-code split without anyone hand-assigning a cell. |
| `adfixtest` | The card keeping a cut it should never have made. c166 fixed the stall rule going forward and left every cut already in `S.maxes` sitting there, reachable only through a "Put it back" button that reverses the most recent batch — so a bad cut with any adaptation after it could not be undone at all. Equally guards the opposite failure, which is the dangerous one: a repair pass that hands an athlete 8% more bar. An earned cut, a falling estimate, a max the athlete has moved since, and a second run of itself must all be refused. |
| `progaudit` | The engine paying an athlete's weight out to the wrong place. Written after the v208 deep audit, which found six live faults where two automatic writers met. The one that mattered most: `accLoad` scales the accessory ladder to the last logged weight and a deload week was logged like any other session, so every deload re-based every accessory and the next block was built from it — Romanian Deadlift 260 → 180 → 125 over three blocks on an athlete topping the rep range every set. Also pinned: a failing tested-max trial clamping *up* to its floor (a penalty that put 25 lb ON the bar, reason line "comes back -25 lb"); `adRate` fitting a trend across mixed rep targets, the same fault the stall rule was field-caught on the day before, which added 5 lb a week to a flat lift forever; auto-calibration and the weekly rate pass both spending one pot of evidence (300 → 345 on a single bank); calibration being the biggest automatic move in the card and the only one with no "put back"; and the day's struggle flag being written by whichever movement sharing a max key went last. Every check in it goes red on v207. |
| `joketest` | Bulk running dry, or telling a joke at the wrong moment. `MAIL_GREET` held four lines picked by date-of-month % 4, so an athlete met the whole of his personality inside a fortnight and then watched it loop in the same order every month. Guards the library (size, no duplicates, phone-length lines, no markup) and the content rules that keep the card friendly and forgiving — nothing about drugs, food restriction, or the athlete's body. Guards the rotation: the day's joke is fixed for that day (reopen the card and a letter read twice must not show two punchlines), 60 days give 60 different jokes, never the same two days running, and repeats do come back eventually because he asked for that. And the part that matters most: a punchline rides only on letters already in a good mood — never on the streak warning, never on the backup warning, checked through the real `mailSweep`. |
| `slotdrift` | One movement's logged sets landing on another movement, or vanishing. Found in his own backup: the "hard sets per week" chart read 123/109/94 while his session reports for those weeks said 120/137/91 — day F of week 2 held 26 logged sets in the report and nothing at all in the card's set state. Set data is keyed by an exercise's POSITION in the day, and the delete-an-added-movement branch computed that position as `planDay().exercises.length + index-in-customs` — the end of the day — while `S.order` had the athlete's dragged movement sitting at position 3 of 9. So it deleted whatever was really in that slot and slid every later movement down one. It also only ever touched `exKey()`, the current week, leaving every logged week behind. This is not a chart bug: `blockSuccess()` reads the same slots to judge whether prescribed reps were hit, and that feeds max progression. Drives the real controls by real taps — add, drag, delete, remove, restore — on a live session, because a previewed day refuses every control and an earlier cut of this file tapped a read-only screen and reported success. |
| `docday` | A build rewriting the athlete's past. His rule, verbatim: "all training in the past does not change due to revisions of the application." c203 inserted Barbell Row at the top of every pull day and every pull session he had already logged re-rendered with it — "Barbell Row 4 sets @155" for a movement he has never performed, wearing the sets he did on Cable Rows, every movement below shifted one down and showing today's weights. A past day was never stored; it was rebuilt on each visit from the live program plus position-keyed set state, and the existing freeze (`S.froze`) only ever froze the athlete's own additions and removals. A session now banks its **shape** — movements in order, as performed, weight used, every set — into its own log, and a finished session renders from that alone. This file banks a real session through `saveSessionLog`, then revises the program every way a build or an athlete can (insert a main lift at the front, move every max 60 lb, reorder, remove, add) and reopens the finished session. It must not move. Also holds the two boundaries: the next live session IS live and DOES see the revised program, and a log from before shapes existed is not reconstructed — it gets a notice and the banked report, never an invented day. |
| `landtest` | The card reopening wherever it was closed. His ask: "Anytime i close out the app it keeps the user on the same page they where on when they closed it. Can you automatically place them on their training day instead?" `syncToNext()` brought a stale day pointer forward on open but was written never to leave a tab, so a card closed on Rate reopened on Rate. `landOnTraining()` now runs ahead of it at boot and on a return from 30+ minutes in the background. Tested by real reboots — a second window over the same storage — and real visibility events: closed on each tab it reopens on the session; closed on a finished session it reopens on the next one; a session in progress is never abandoned, by reboot or by resume, and its focus is not touched; five minutes in another app moves nothing, forty-five does; with the block spent a tab still lands on a training day. |
| `gatetest` | A dead "I understand". Third field report of it — his sister, first open, "frozen, buttons don't work." Two things on the shipped build: `bootDisc()` ran before `load()`, so `S.discAck` was never there to read and the gate stood on **every open, for everyone**, since it shipped; and every accept path depended on a `click` event, which a phone can withhold (a preventDefault-ed touch, a finger that moved, a touch overlapping a scroll of the gate's own box). The acknowledgment is the tap, not the event name. Delivers the tap every way a phone can — click, pointer down/up, touch start/end, and a pointer-down with nothing after it (the watchdog) — and each must close the gate; a finger that travelled is a scroll and must not. Also: Terms still opens from the gate, an accepted gate does not return on the next open, re-reading it from Settings does not rewrite the acknowledgment, and the button is sticky inside the gate's scroll box so it cannot fall below the fold on a short phone. |
| `accesstest` | The access gate. His ask: a code before the app, athlete or coach rights depending on the code, once, good for three months, then renew; everyone already using the card becomes an athlete automatically. The card is one static file, so this is a gate (who gets in, which tools they see, who can be cut off at renewal), not a lock against editing one's own phone. Codes live in the file only as SHA-256 fingerprints; the plain codes sit in `access-codes.json` beside this harness and nowhere in the build. Boots real cards: a new card meets the gate in front of the disclaimer; a wrong code is refused; the athlete code grants 90 days and hides the coach switch; the coach code shows it; a card from before the gate gets athlete rights with no gate and its data untouched; a coach-mode card without coach rights runs solo with its roster kept; expired access meets the gate with every session behind it; Settings can open the gate to renew or upgrade; the hash matches the standard vector. |
| `dosetest` | The engine prescribing more than a session should carry. His rule: six movements is the dose ("what exercise science recommends" — sets per muscle per session and total hard sets per session both land there at 3–4 sets a movement), at most one core/grip movement per day, and it goes last. The starter template shipped four days at eight — the pull days grew from seven to eight on Sept 4 when Barbell Row went in without anything coming out — and day F carried three core movements. Guards the template and every generated plan (every day count × every goal), the classifier, the caution firing at seven not six, an athlete's own additions being counted and warned about but never removed, a core addition landing last and a non-core addition landing ahead of the core, and — the part that could have hurt — the template change migrating every logged set to its own movement by name, with the sets of departed movements parked rather than misfiled. |
| `removedtest` | A removed movement cluttering the session. His rule: "if your removing a prescribed exercise and replacing it... it hides or doesnt show on the days training because it shows as skipped but its distracting and doesnt actually have to be there if the athlete is deciding to change their plan." A removal is a decision, not skipped work, so the movement leaves the day — no SKIPPED pill on the deck, no OUT row in the walk, `focusMax` and the focus walk index against live movements only, and it counts nothing toward the day's load. It is not deleted: it is listed under REMOVED TODAY at the bottom, one tap from returning to its own place (v213's lesson — a removal that cannot be undone is a one-way door). Also holds the boundaries: the report already omitted an untouched removed movement and still does, and a **swap** is not a removal — a substituted movement still shows under its new name. |
| `wholecard` | The floor under everything. "Run an audit and test all features in the card. No stone unturned." Builds itself a card with three weeks of banked training, then walks it: every tab, every day of every week in both views, every overlay, kg mode over all of it, the report on a banked day, the share sheet, the print sheet, the backup payload, the block handoff, thirty days of mail, every view that draws the You/Rate/Plan tabs, the live day's controls by real tap, every calendar cell, the library, the deload week, bodyweight, the kg set buttons — then a fresh card through both gates, a session trained and banked, the pointer advancing, a coach drawer round trip that must leave the coach's own state untouched, the self-test, and the deploy files. Asserts that nothing throws, nothing leaks `undefined`/`NaN`/`null` into text, and nothing contradicts itself. The probe this came from found two hardenings and nothing else. |
| `themetest` | A theme that is unreadable in one of its two lights, an update silently repainting a card an athlete has used for weeks, or Auto guessing. The trap it was written for: `!!(window.matchMedia && ...)` reports *false* when matchMedia is absent, and false reads as "the phone says light" — so every browser too old to answer would have opened a dark card white. No signal must resolve to the theme's own light, not to a guess. Also guards that Auto keeps following a phone that flips mid-session, and never overrides an athlete who pinned Day or Night. |

## Writing a new harness

Copy the shape of an existing one. Four rules, each learned the hard way:

1. **Drive the card's own code.** An early version of `resttest` reimplemented the clamp
   inside the harness and passed with the fix removed from the card. It was testing
   itself. Dispatch real events, or call the card's real functions.

2. **Use real bubbling clicks, not direct handler calls.**
   `el.dispatchEvent(new MouseEvent('click',{bubbles:true}))`. Calling `el.onclick()`
   directly skips propagation and hides a whole class of bug — that is exactly how a
   sheet-closes-on-every-tap bug reached a live build.

3. **Put the card in an athlete's state first.** A fresh profile auto-starts the
   walkthrough, and `tourGuard` correctly swallows every tap outside the coach while it
   runs. Test without finishing the tour and every control reports as dead. Set
   `TOUR.live=false`, `S.tour={done:true}`, and remove `#coachHost`. Also neutralise
   `coachIdle`, `ONB_ACTIVE` and `isStartMode` if you need the main training screen.

4. **Check bindings with a real click, never `el.onclick`.** Some controls are bound with
   `addEventListener` — the gear is one — so `el.onclick` is `null` on a perfectly wired
   element. That reported a working gear as dead during this very port.

5. **Read state through `window.eval`, not `window.S`.** `S` and `BUILD` are declared
   with `let`/`const`, which in a classic script are script-scoped and are *not*
   properties of `window`. `window.S` reads as `undefined` on a perfectly working card.
   This produced a false "the settings are completely dead" report that cost a rewrite.

6. **A prompt asking for a second tap must outlive its own window.** `alertToast` defaults
   to 1.5s, which is right for a notice and wrong for anything you have to read and act on.
   Pass the window as the second argument.

7. **Prove the test can fail.** Break the fix on a scratch copy and confirm the harness
   goes red. A check that cannot fail is decoration. All ten here were verified this way.

## Known-good baseline

Session Card v125 and Training Card c85 pass every check.
