// SEASONAL TONE (2026-09-04, his ask: holiday colour during the month, tone change only, and a
// slot behind the logo on the splash for the art he is drawing).
//
// A holiday is a layer over the athlete's theme, not a replacement for it. This pins: the calendar
// resolves on exactly the right days and nothing else; the layer touches tone only and never the
// go/stop colours; every holiday clears the same contrast floors as every theme in both lights;
// the athlete can switch it off and get their theme back byte-for-byte; and the splash draws the
// art when there is art and is unchanged when there is none.
const { JSDOM } = require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const dom=new JSDOM(fs.readFileSync(f,'utf8'),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/',
  beforeParse(w){
    w.AudioContext=function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
    w.alert=()=>{};
  }});
const w=dom.window,D=w.document,EV=e=>w.eval(e);
let bad=0; const chk=(l,ok,d)=>{ if(!ok) bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&d?'  <-- '+d:''}`); };
// the same maths and the same floors themetest holds the themes to
const hex=c=>{ c=String(c||'').trim().replace('#',''); if(c.length===3) c=c.split('').map(x=>x+x).join(''); return [0,2,4].map(i=>parseInt(c.substr(i,2),16)||0); };
const lum=c=>{ const s=hex(c).map(v=>{ v/=255; return v<=.03928? v/12.92 : Math.pow((v+.055)/1.055,2.4); }); return .2126*s[0]+.7152*s[1]+.0722*s[2]; };
const ratio=(a,b)=>{ const l1=lum(a), l2=lum(b); return (Math.max(l1,l2)+.05)/(Math.min(l1,l2)+.05); };
const FLOOR={'amber-ink/amber':3.0,'amber/panel':3.0,'chalk/panel2':10,'dim/panel2':4.5};

setTimeout(async()=>{
  console.log(`\n--- ${L}: the season is a layer, and it clears the same bar as the themes ---`);
  EV('try{TOUR.live=false;}catch(e){} S.tour={done:true}; if(typeof ONB!=="undefined"){ONB().done=true;} S.discAck={v:DISC_V,d:localDate()}; storageOK=true; S.seasonal=true; save();');
  const has=EV('typeof HOLIDAYS!=="undefined" && typeof holidayFor==="function"');
  chk('the seasonal layer exists', has, 'no HOLIDAYS table / holidayFor on this build');
  if(!has){ console.log('  problems:', bad); process.exit(1); }

  // --- 1. the calendar, day by day at every boundary ----------------------------
  const want={'2026-09-30':null,'2026-10-01':'halloween','2026-10-31':'halloween','2026-11-01':'thanksgiving',
              '2026-11-30':'thanksgiving','2026-12-01':'christmas','2026-12-31':'christmas','2027-01-01':'newyear',
              '2027-01-31':'newyear','2027-02-01':null,'2026-07-04':null,'2026-05-25':null};
  let wrong=[];
  Object.keys(want).forEach(d=>{ const got=EV('(function(){ var h=holidayFor('+JSON.stringify(d)+'); return h? h.id : null; })()'); if(got!==want[d]) wrong.push(d+' -> '+got+' (wanted '+want[d]+')'); });
  chk('every boundary resolves to the right holiday and nothing else', wrong.length===0, wrong.join(' | '));
  chk('only the four he asked for are in the calendar',
      JSON.stringify(EV('JSON.stringify(HOLIDAYS.map(function(h){return h.id;}))'))===JSON.stringify(JSON.stringify(['halloween','thanksgiving','christmas','newyear'])),
      EV('JSON.stringify(HOLIDAYS.map(function(h){return h.id;}))'));

  // --- 2. tone only: the meaning colours are never touched --------------------------
  const touched=JSON.parse(EV('JSON.stringify((function(){ var k={}; HOLIDAYS.forEach(function(h){ ["d","n"].forEach(function(s){ Object.keys(h[s]||{}).forEach(function(v){ k[v]=1; }); }); }); return Object.keys(k); })())'));
  chk('a holiday never overrides the go or stop colours', !touched.includes('--green') && !touched.includes('--red'), 'overrides '+touched.join(', '));
  chk('and never the ground or the ink the card reads in', !touched.includes('--bg') && !touched.includes('--chalk') && !touched.includes('--panel'), 'overrides '+touched.join(', '));

  // --- 3. every holiday over every theme, both lights, clears the floors -----------
  const themes=JSON.parse(EV('JSON.stringify(THEMES)'));
  const hols=JSON.parse(EV('JSON.stringify(HOLIDAYS)'));
  // BASE is the STYLESHEET's :root - what a theme with an empty variant (Coach by day) actually
  // wears. Reading the computed style here returned Iron-night, already applied at boot, and
  // put night ink over the holiday's light day panels: a fixture fault reported as a palette one.
  const KEYS=['--bg','--panel','--panel2','--line','--chalk','--dim','--faint','--amber','--amber-ink','--green','--red'];
  const BASE=JSON.parse(EV(`(function(){ var r=document.documentElement.style, saved={}, out={};
    ${JSON.stringify(KEYS)}.forEach(function(k){ saved[k]=r.getPropertyValue(k); r.removeProperty(k); });
    ${JSON.stringify(KEYS)}.forEach(function(k){ out[k]=getComputedStyle(document.documentElement).getPropertyValue(k).trim(); });
    ${JSON.stringify(KEYS)}.forEach(function(k){ if(saved[k]) r.setProperty(k, saved[k]); });
    return JSON.stringify(out); })()`));
  let low=[];
  themes.forEach(t=>['d','n'].forEach(side=>hols.forEach(h=>{
    const v=Object.assign({},BASE,t[side]||{},h[side]||{});
    Object.keys(FLOOR).forEach(p=>{ const [a,b]=p.split('/'); const r=ratio(v['--'+a],v['--'+b]);
      if(r<FLOOR[p]) low.push(`${t.id} ${side} + ${h.id}: ${p} ${r.toFixed(2)} < ${FLOOR[p]}`); });
  })));
  chk('every holiday over every theme in both lights clears the contrast floors', low.length===0, low.slice(0,4).join(' | '));

  // --- 4. it is a layer: the theme underneath is unchanged, and Off restores it -------
  EV("S.theme='iron'; S.light='night'; S.seasonal=true; save();");
  // pin the clock inside a holiday so the layer is live regardless of when this runs
  EV("window.__realShift=shiftDate; shiftDate=function(){ return '2026-12-15'; };");
  EV('applyTheme();');
  const withLayer=EV("getComputedStyle(document.documentElement).getPropertyValue('--amber').trim()");
  chk('inside a holiday the accent wears the season', EV("document.documentElement.getAttribute('data-holiday')")==='christmas' && withLayer.toLowerCase()===hols.find(h=>h.id==='christmas').n['--amber'].toLowerCase(),
      'data-holiday='+EV("document.documentElement.getAttribute('data-holiday')")+' amber='+withLayer);
  chk('the athlete\'s chosen theme is still the theme', EV('S.theme')==='iron' && EV("themeDef().id")==='iron');
  EV('S.seasonal=false; save(); applyTheme();');
  const off=EV("getComputedStyle(document.documentElement).getPropertyValue('--amber').trim()");
  chk('Off gives the theme back exactly', off.toLowerCase()===themes.find(t=>t.id==='iron').n['--amber'].toLowerCase() && !EV("document.documentElement.hasAttribute('data-holiday')"),
      'amber='+off+' data-holiday='+EV("document.documentElement.getAttribute('data-holiday')"));
  EV('S.seasonal=true; save(); applyTheme();');

  // --- 5. the toggle is on the settings sheet and works by tap ---------------------
  EV("S.day=PLAN.days[0].code; render(); SET_OPEN=true; settingsSync();");
  const offChip=D.querySelector('#setHost [data-seasonal="0"]');
  chk('Seasonal colours is a control in Settings', !!offChip, 'no [data-seasonal] in the sheet');
  if(offChip){ offChip.dispatchEvent(new w.MouseEvent('click',{bubbles:true})); await new Promise(r=>setTimeout(r,30));
    chk('tapping Off turns it off', EV('S.seasonal')===false && !EV("document.documentElement.hasAttribute('data-holiday')"), 'seasonal='+EV('S.seasonal')); }
  EV('SET_OPEN=false; settingsSync(); S.seasonal=true; save(); applyTheme();');

  // --- 6. the splash slot: nothing without art, art when there is art ---------------
  D.querySelectorAll('#bootSplash').forEach(x=>x.remove());
  EV("HOLIDAY_ART.christmas=[]; bootIdent();");
  chk('with no art the splash is unchanged - no empty art layer', !D.querySelector('#bootSplash .bs-art'));
  D.querySelectorAll('#bootSplash').forEach(x=>x.remove());
  EV("HOLIDAY_ART.christmas=[{u:'data:image/gif;base64,R0lGODlhAQABAAAAACw=',x:20,y:30,w:90},{u:'data:image/gif;base64,R0lGODlhAQABAAAAACw=',x:80,y:70,w:120}]; bootIdent();");
  const art=D.querySelectorAll('#bootSplash .bs-art img');
  chk('with art, the splash floats it behind the mark', art.length===2 && !!D.querySelector('#bootSplash .bs-wrap'), art.length+' images');
  chk('the art never takes a tap', !!D.querySelector('#bootSplash .bs-art') && (D.querySelector('#bootSplash .bs-art').getAttribute('aria-hidden')==='true'));
  D.querySelectorAll('#bootSplash').forEach(x=>x.remove());
  EV("HOLIDAY_ART.christmas=[]; shiftDate=window.__realShift;");

  // --- 7. outside every holiday: nothing at all ---------------------------------------
  EV("shiftDate=function(){ return '2026-07-04'; }; applyTheme();");
  chk('outside a holiday there is no layer and no attribute', !EV("document.documentElement.hasAttribute('data-holiday')"));
  D.querySelectorAll('#bootSplash').forEach(x=>x.remove());
  EV("HOLIDAY_ART.halloween=[{u:'data:image/gif;base64,R0lGODlhAQABAAAAACw=',x:50,y:50,w:100}]; bootIdent();");
  chk('and no holiday art shows in July even if art exists', !D.querySelector('#bootSplash .bs-art'));
  EV("HOLIDAY_ART.halloween=[]; shiftDate=window.__realShift; applyTheme();");

  console.log('  problems:', bad); process.exit(bad?1:0);
},1500);
