// NEW STATE, END TO END (2026-09-03 audit of c183-c190).
//
// Today added fields the card never had: S.mxProv (a tested max on trial), S.adLog entries of
// kind prov/provok and an `undone` mark, `stim` on a card-added fill, and a `t:1` flag on e1rmH
// entries. Each was tested where it was built. This is the other question - do they survive
// everything ELSE the card does: every screen drawn with all of them live at once, mangled
// versions of each on boot, and the real backup/restore path. A field that works in its own
// feature and vanishes in a restore is a bug shipped by a green suite.
const { JSDOM } = require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const errs=[];
const dom=new JSDOM(fs.readFileSync(f,'utf8'),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/',
  beforeParse(w){
    w.AudioContext=function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
    w.alert=()=>{}; w.confirm=()=>true;
    w.addEventListener('error',e=>errs.push(String(e.message||e.error||e)));
  }});
const w=dom.window,D=w.document,EV=e=>w.eval(e);
let bad=0; const chk=(l,ok,d)=>{ if(!ok) bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&d?'  <-- '+d:''}`); };

const ALL_NEW = `
  S.maxes={squat:327,bench:225,dead:405,ohp:145,row:170,pull:225};
  S.mxProv={bench:{tested:250,from:225,floor:225,since:'2026-09-01',start:240},
            ohp:{tested:160,from:145,floor:145,since:'2026-09-02',start:150}};
  S.adLog=[
    {kind:'rate',   lift:'squat', from:320, to:327, rate:2.1, d:'2026-08-28', why:'climbing'},
    {kind:'stall',  lift:'dead',  from:420, to:405, d:'2026-08-30', why:'three flat', undone:'2026-08-31'},
    {kind:'layoff', lift:'row',   from:180, to:170, d:'2026-09-01', days:12, why:'12 days away'},
    {kind:'prov',   lift:'bench', from:240, to:235, d:'2026-09-02', why:'not holding'},
    {kind:'provok', lift:'ohp',   from:150, to:150, d:'2026-09-03', why:'held'},
    {kind:'weak',   lift:'dead',  muscle:'hams', sets:4, d:'2026-09-03', why:'hams light'},
    {kind:'deload', d:'2026-09-03', debt:4, why:'debt'},
    {kind:'volume', muscle:'chest', dir:1, from:12, d:'2026-09-03', why:'room'}
  ];
  S.adNew=3; S.adDeloadDue=true;
  S.e1rmH={bench:[{d:'2026-08-30',v:245,r:2,c:1},{d:'2026-09-01',v:250,r:0,c:1,t:1},{d:'2026-09-02',v:240,r:2,c:0}]};
  S.e1rm={bench:{val:250,date:'2026-09-01'}};
  mxTouched={bench:1};
  S.seasonal=false;                       // c195: the seasonal-colour off switch
  S.calcPos={edge:'left',at:0.06};        // c193-c200: a stranded position the card must clear
  (function(){ var c=custList(PLAN.days[0].code); if(c && !c.some(function(x){return x.fill;}))
     c.push({b:cyc(), w:S.week, cid:1, name:'Cross-Body Cable Rear Delt Fly', fill:true, why:'rdelt', stim:'stretched', load:15, sets:3, reps:'12-15', perHand:false}); })();
  save();`;

setTimeout(async()=>{
  console.log(`\n--- ${L}: every field added today survives everything else the card does ---`);
  EV('try{TOUR.live=false;}catch(e){} S.tour={done:true}; if(typeof ONB!=="undefined"){ONB().done=true;} S.discAck={v:DISC_V,d:localDate()}; storageOK=true; save();');
  EV('ERR_LOG.length=0;');

  // --- 1. every screen, with ALL new state live at once ----------------------
  EV(ALL_NEW);
  const codes=JSON.parse(EV('JSON.stringify(PLAN.days.map(function(d){return d.code;}))'));
  const screens=[];
  codes.forEach(c=>screens.push(['day '+c, `S.rptOpen=false; SET_OPEN=false; settingsSync(); S.day='${c}'; render();`]));
  ['MAX','RATE','CAL','PLAN','LIB'].forEach(t=>screens.push(['tab '+t, `S.rptOpen=false; SET_OPEN=false; settingsSync(); S.day='${t}'; render();`]));
  screens.push(['MAX, unlocked', "S.day='MAX'; mxEdit=true; render();"]);
  screens.push(['settings', "S.day=PLAN.days[0].code; render(); SET_OPEN=true; settingsSync();"]);
  screens.push(['report', "SET_OPEN=false; settingsSync(); S.rptOpen=true; S.rptKind='bug'; render();"]);
  screens.push(['print sheet', "S.rptOpen=false; try{ if(typeof sheetHTML==='function') sheetHTML(); }catch(e){ oops('sheetHTML',e); }"]);
  screens.push(['recap text', "try{ if(typeof sessionRecapText==='function') sessionRecapText(); }catch(e){ oops('recap',e); }"]);
  screens.push(['adapt panel', "try{ adaptHTML(); }catch(e){ oops('adaptHTML',e); }"]);
  screens.push(['coverage flags', "Object.keys(ANA_TGT||{}).forEach(function(m){ try{ stimOneSided(m); }catch(e){ oops('stimOneSided',e); } });"]);
  screens.push(['fill picker', "PLAN.days.forEach(function(d){ try{ sessPickExercise(d.code, effectiveExercises(d.code)); }catch(e){ oops('sessPick',e); } });"]);
  screens.push(['probation judge', "try{ pvJudge(); }catch(e){ oops('pvJudge',e); }"]);
  screens.push(['adapt pass', "try{ adaptRun(true); }catch(e){ oops('adaptRun',e); }"]);
  let drawn=0;
  for(const [name,js] of screens){ try{ EV(js); drawn++; }catch(e){ errs.push(name+': '+(e.message||e)); } }
  chk('every screen and every engine pass runs with all new state live at once',
      drawn===screens.length, drawn+'/'+screens.length);
  const logged=JSON.parse(EV('JSON.stringify(ERR_LOG.map(function(e){ return e.where+": "+e.msg; }))'));
  chk('the card recorded no internal errors doing it', logged.length===0, logged.slice(0,4).join(' | '));
  chk('and the window threw nothing', errs.length===0, errs.slice(0,3).join(' | '));

  // --- 2. mangled versions of each new field on boot ------------------------
  const mangles=[
    ['mxProv is a string',    "S.mxProv='garbage';"],
    ['mxProv is null',        "S.mxProv=null;"],
    ['mxProv is an array',    "S.mxProv=[1,2,3];"],
    ['a trial with no floor', "S.mxProv={bench:{tested:250}};"],
    ['a trial with junk',     "S.mxProv={bench:'x', ohp:null, dead:42};"],
    ['adLog is a string',     "S.adLog='nope';"],
    ['adLog entries hollow',  "S.adLog=[null, {}, {kind:'prov'}, {kind:'rate', lift:'bench'}, {kind:'stall', lift:'nothere', from:'a', to:'b'}];"],
    ['undone is a number',    "S.adLog=[{kind:'rate', lift:'bench', from:220, to:225, d:'2026-09-01', why:'x', undone:1}];"],
    ['fill stim is an object',"(function(){ var c=custList(PLAN.days[0].code); c.push({b:cyc(), w:S.week, cid:2, name:'Dead Hang', fill:true, stim:{a:1}, load:'BW', sets:3, reps:'30s'}); })();"],
    ['e1rmH has a t on junk', "S.e1rmH={bench:[{t:1},{d:'2026-09-01',v:'x',c:'y',t:'z'}]};"],
    ['mxTouched is null',     "mxTouched=null;"],
    ['seasonal is a string',  "S.seasonal='yes';"],
    ['calcPos is garbage',    "S.calcPos='corner';"],
  ];
  let survived=0, died=[];
  for(const [name,js] of mangles){
    EV('ERR_LOG.length=0;'); errs.length=0;
    EV(ALL_NEW);
    try{
      EV(js);
      EV("save(); S.day='MAX'; mxEdit=true; render(); S.day='PLAN'; render(); S.day=PLAN.days[0].code; render(); adaptHTML(); pvJudge(); adaptUndo(); Object.keys(ANA_TGT||{}).forEach(function(m){ stimOneSided(m); });");
      const el=JSON.parse(EV('JSON.stringify(ERR_LOG.map(function(e){ return e.where; }))'));
      // oops() catching a mangled field is CORRECT behaviour - it means nothing escaped. Only an
      // uncaught throw counts as a death.
      if(errs.length) died.push(name+' -> '+errs[0]); else survived++;
    }catch(e){ died.push(name+' -> '+(e.message||e)); }
  }
  chk('the card boots, renders and saves against every mangled new field', died.length===0,
      died.slice(0,3).join(' | '));
  console.log('  ('+survived+'/'+mangles.length+' mangled shapes survived; caught-and-logged errors are fine, uncaught ones are not)');
  EV('mxTouched={};');

  // --- 3. the real backup/restore path, with the new fields in it ------------
  EV('ERR_LOG.length=0;'); errs.length=0;
  EV(ALL_NEW);
  const before={
    prov: EV('JSON.stringify(S.mxProv)'),
    undone: EV('JSON.stringify((S.adLog||[]).map(function(a){ return a.kind+":"+(a.undone||""); }))'),
    stim: EV("JSON.stringify((custList(PLAN.days[0].code)||[]).filter(function(x){return x.fill;}).map(function(x){ return x.name+':'+(x.stim||''); }))"),
    tflag: EV('JSON.stringify((S.e1rmH.bench||[]).map(function(x){ return !!x.t; }))')
  };
  const payload=await EV(`(async function(){ var logs={};
    for(const k of logKeys){ try{ logs[k]=await stGet(k); }catch(e){} }
    return JSON.stringify({v:1, exported:localDate(), S:S, logs:logs}); })()`);
  EV('localStorage.clear(); S=mergeIntoShape({}); logKeys=[]; logCache={}; save();');
  chk('(fixture) the new state is really gone before the restore', EV('!S.mxProv || !S.mxProv.bench'), 'still there');
  w.__payload=payload;
  const restored=await EV(`(async function(){
    var file={ text: function(){ return Promise.resolve(window.__payload); } };
    try{ await restoreBackup(file); return 'ok'; } catch(e){ return 'threw: '+(e&&e.message||e); }
  })()`).catch(e=>'threw: '+e);
  chk('the real restore path runs with the new fields present', restored==='ok', restored);
  chk('a tested max on trial survives backup and restore', EV('JSON.stringify(S.mxProv)')===before.prov,
      'before '+before.prov+' after '+EV('JSON.stringify(S.mxProv)'));
  chk('the undone marks on the adapt log survive',
      EV('JSON.stringify((S.adLog||[]).map(function(a){ return a.kind+":"+(a.undone||""); }))')===before.undone,
      'log came back as '+EV('JSON.stringify((S.adLog||[]).map(function(a){ return a.kind; }))'));
  chk('the stimulus note on a card-added fill survives',
      EV("JSON.stringify((custList(PLAN.days[0].code)||[]).filter(function(x){return x.fill;}).map(function(x){ return x.name+':'+(x.stim||''); }))")===before.stim,
      'fills came back as '+EV("JSON.stringify((custList(PLAN.days[0].code)||[]).filter(function(x){return x.fill;}).map(function(x){ return x.name+':'+(x.stim||''); }))"));
  chk('the tested-single flag on history survives',
      EV('JSON.stringify((S.e1rmH.bench||[]).map(function(x){ return !!x.t; }))')===before.tflag,
      'flags came back as '+EV('JSON.stringify((S.e1rmH.bench||[]).map(function(x){ return !!x.t; }))'));
  chk('the seasonal off switch survives', EV('S.seasonal')===false, 'seasonal came back as '+EV('JSON.stringify(S.seasonal)'));
  EV('S.day=PLAN.days[0].code; render(); calcPaint();');
  chk('and a stranded calculator position is cleared on the first paint after restore', !EV('S.calcPos'),
      'calcPos survived restore + paint: '+EV('JSON.stringify(S.calcPos)'));
  chk('and the restore itself logged no internal errors', EV('ERR_LOG.length')===0,
      EV('JSON.stringify(ERR_LOG.map(function(e){ return e.where+": "+e.msg; }))'));

  console.log('  problems:', bad); process.exit(bad?1:0);
},1500);
