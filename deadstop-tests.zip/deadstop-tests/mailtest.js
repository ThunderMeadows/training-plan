// Mail from Bulk (2026-09-01): a mailbox with no mail server. Every message is generated on
// the device from facts the card keeps, deterministic ids stop repeats, and Bulk only writes
// when there is something true to say.
const {JSDOM}=require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const d=new JSDOM(fs.readFileSync(f,'utf8'),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/'});
const w=d.window,EV=e=>w.eval(e);
w.AudioContext=function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
let bad=0; const chk=(l,ok,dd)=>{ if(!ok)bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&dd?'  <-- '+dd:''}`); };
setTimeout(()=>{
  console.log(`\n--- ${L}: mail from Bulk ---`);
  EV('try{TOUR.live=false;}catch(e){} S.tour={done:true}; if(typeof ONB!=="undefined"){ONB().done=true;} render();');
  chk('the build announces itself once', EV('mailBox().filter(function(x){return x.id==="build-"+BUILD;}).length')===1, 'missing or duplicated');
  const n0=EV('mailBox().length');
  EV('mailSweep(); mailSweep();');
  chk('the sweep is idempotent', EV('mailBox().length')===n0, EV('mailBox().length')+' vs '+n0);
  // a seeded countdown three days out earns a milestone letter
  const d3=EV(`(function(){ var d2=new Date(shiftDate()+'T12:00:00'); d2.setDate(d2.getDate()+3);
    return new Date(d2.getTime()-d2.getTimezoneOffset()*60000).toISOString().slice(0,10); })()`);
  EV('calNoteAdd("'+d3+'", {t:"ACFT", k:"test", cd:true}); mailSweep();');
  chk('a countdown milestone writes a letter', EV('mailBox().some(function(x){return x.txt.indexOf("ACFT in 3 days")>=0;})'), 'no milestone letter');
  // streak risk letter, via the guard the card already trusts
  EV('calStreakRisk=function(){ return 4; }; mailSweep();');
  chk('the streak guard writes on the last day', EV('mailBox().some(function(x){return x.txt.indexOf("4-week streak dies tonight")>=0;})'), 'no risk letter');
  // header badge counts unread, opening reads everything
  const un=EV('mailUnread()');
  chk('unread mail exists and the header badges it', un>0 && EV('render(), !!document.querySelector(".mail-badge")'), 'no badge');
  EV('mailShow();');
  chk('the inbox opens with every letter', EV('!!document.getElementById("mailGate")') && (EV('document.getElementById("mailGate").textContent').match(/BULK/g)||[]).length>=un, 'letters missing');
  chk('the empty-server honesty line is present', EV('document.getElementById("mailGate").textContent').indexOf('No server, no tracking')>=0, 'missing');
  chk('opening marks everything read', EV('mailUnread()')===0, EV('mailUnread()'));
  EV('document.getElementById("mailX").click();');
  chk('no badge once read', EV('!document.querySelector(".mail-badge")'), 'badge lingers');
  // clear-read leaves nothing behind
  EV('mailShow(); var c=document.getElementById("mailClear"); if(c) c.click();');
  chk('clear removes read mail', EV('mailBox().length')===0, EV('mailBox().length')+' remain');
  EV('var g=document.getElementById("mailGate"); if(g) g.querySelector("#mailX").click();');
  chk('Bulk never wrote an empty or unknown letter', EV('mailBox().every? mailBox().every(function(x){return x.txt&&x.id;}) : true'), 'malformed mail');
  // --- the five faces (2026-09-01): the mood rides with the message ---
  chk('all five expressions are inlined', EV('Object.keys(MAIL_FACES).length')===5 && EV('Object.keys(MAIL_FACES).every(function(k){return MAIL_FACES[k].indexOf("data:image/webp")===0;})'), EV('Object.keys(MAIL_FACES).join(",")'));
  EV('S.mail=[]; S.mailSent={}; save(); mailSweep(); calStreakRisk=function(){return 2;}; mailSweep();');
  chk('every letter wears a known face', EV('mailBox().every(function(x){return !!MAIL_FACES[x.face];})'), EV('JSON.stringify(mailBox().map(function(x){return x.face;}))'));
  chk('the streak warning wears tough love', EV('mailBox().some(function(x){return x.id.indexOf("risk-")===0 && x.face==="tough";})'), 'wrong face');
  chk('the upgrade letter is playful', EV('mailBox().some(function(x){return x.id.indexOf("build-")===0 && x.face==="playful";})'), 'wrong face');
  EV('mailShow();');
  chk('the inbox renders a face per letter', Number(EV('document.querySelectorAll("#mailGate .mail-face").length'))===Number(EV('mailBox().length')), EV('document.querySelectorAll("#mailGate .mail-face").length')+' faces');
  chk('an old faceless letter falls back to focused', EV('(function(){ var g=document.getElementById("mailGate"); g&&g.remove(); S.mail.push({id:"legacy",d:shiftDate(),txt:"old",read:false}); save(); mailShow(); var im=document.querySelectorAll("#mailGate .mail-face"); var first=im[0]; var ok=first && first.src===MAIL_FACES.focused; var g2=document.getElementById("mailGate"); g2&&g2.remove(); return ok; })()'), 'no fallback');
  // --- Bulk pays attention (field-caught 2026-09-02) ---
  // untrained training day: the greeting invites the work
  EV(`(function(){ S.mail=[]; S.mailSent={};
    var dow=new Date(shiftDate()+'T12:00:00').getDay(); S.trainDays=[dow];
    streakDayset=function(){ return {}; }; save(); mailSweep(); })();`);
  chk('an untrained session day gets the invitation', EV('mailBox().some(function(x){return x.id.indexOf("greet-")===0;})'), 'no greeting');
  chk('and not the done letter', EV('!mailBox().some(function(x){return x.id.indexOf("done-")===0;})'), 'wrong letter');
  // same day, work already banked: Bulk must NOT say the bar missed you
  EV(`(function(){ S.mail=[]; S.mailSent={};
    streakDayset=function(){ var o={}; o[shiftDate()]=true; return o; }; save(); mailSweep(); })();`);
  chk('a trained day gets the done letter instead', EV('mailBox().some(function(x){return x.id.indexOf("done-")===0;})'), 'no done letter');
  chk('and never claims the bar missed you', EV('!mailBox().some(function(x){return /missed you|chalked up|stretched for both/.test(x.txt);})'), 'greeted a man who already trained');
  chk('the done letter is encouraging, not playful nagging', EV('(mailBox().find(function(x){return x.id.indexOf("done-")===0;})||{}).face')==='encouraging', 'wrong face');
  // the weekly books wait for Monday
  EV(`(function(){ S.mail=[]; S.mailSent={};
    var mon=mailMonday(shiftDate());
    streakDayset=function(){ var o={}; o[mailShiftIso(mon,-6)]=true; o[mailShiftIso(mon,-4)]=true; return o; };
    S.prs=[]; save(); })();`);
  const isMon=EV('shiftDate()===mailMonday(shiftDate())');
  EV('mailSweep();');
  chk('the books arrive on Monday and only Monday',
      EV('mailBox().some(function(x){return x.id.indexOf("wk-")===0;})')===isMon,
      isMon? 'Monday: books missing' : 'books landed mid-week');
  // --- Bulk reads the whole card (2026-09-01): urgent letters + the weekly books ---
  EV('S.mail=[]; save();');
  // data at risk: one letter per week while true, never more
  EV('backupDue=function(){ return true; }; delete S.lastBackup; mailSweep(); mailSweep();');
  const bk=EV('mailBox().filter(function(x){return x.id.indexOf("bkp-")===0;})');
  chk('backup risk earns exactly one letter per week', EV('mailBox().filter(function(x){return x.id.indexOf("bkp-")===0;}).length')===1, 'wrong count');
  chk('and it wears tough love', EV('mailBox().find(function(x){return x.id.indexOf("bkp-")===0;}).face')==='tough', 'wrong face');
  // your own sets moved your numbers: told every time, once per event
  EV('S.acLog=[{d:shiftDate(), changed:[{k:"bench",from:210,to:215,n:9}]}]; S.acAck=null; save(); mailSweep(); mailSweep();');
  chk('an auto-adjust writes exactly one letter', EV('mailBox().filter(function(x){return x.id.indexOf("adj-")===0;}).length')===1, 'wrong count');
  chk('with the plain numbers in it', EV('mailBox().some(function(x){return x.id.indexOf("adj-")===0 && /bench.*210.*215/.test(x.txt);})'), 'numbers missing');
  // the weekly books: last week's sessions and records, only when the week held something
  // the books are Monday-only now, so pin the clock to a Monday for this check
  EV(`(function(){ var real=shiftDate(); var mon=mailMonday(real);
    shiftDate=function(){ return mon; }; S.mail=[]; S.mailSent={}; })();`);
  EV(`streakDayset=function(){ var ds={}, mon=mailMonday(shiftDate());
    ds[mailShiftIso(mon,-6)]=true; ds[mailShiftIso(mon,-4)]=true; ds[mailShiftIso(mon,-2)]=true; return ds; };
    S.prs=[{ex:"Bench",kind:"weight",val:225,prev:220,d:mailShiftIso(mailMonday(shiftDate()),-3)}]; save(); mailSweep();`);
  chk('the weekly books are written', EV('mailBox().some(function(x){return x.id.indexOf("wk-")===0 && x.txt.indexOf("3 sessions")>=0 && x.txt.indexOf("1 record")>=0;})'), EV('JSON.stringify((mailBox().find(function(x){return x.id.indexOf("wk-")===0;})||{}).txt)'));
  // an empty week earns silence, not filler
  EV('S.mail=S.mail.filter(function(x){return x.id.indexOf("wk-")!==0;}); streakDayset=function(){return {};}; S.prs=[]; save(); mailSweep();');
  chk('an empty week gets no digest', EV('!mailBox().some(function(x){return x.id.indexOf("wk-")===0;})'), 'filler written');
  // FIELD BUG 2026-09-02: clearing read mail brought every letter straight back, because the
  // dedupe read the mailbox itself. Sent history must outlive the letters.
  EV('S.mail=[]; S.mailSent={}; save(); mailSweep();');
  const afterFirst=EV('mailBox().length');
  chk('a fresh sweep writes letters', afterFirst>0, afterFirst);
  EV('mailBox().forEach(function(x){ x.read=true; }); S.mail=mailBox().filter(function(x){return !x.read;}); save();');
  chk('clear empties the box', EV('mailBox().length')===0, EV('mailBox().length'));
  EV('mailSweep(); mailSweep(); render();');
  chk('cleared mail does NOT come back', EV('mailBox().length')===0, EV('mailBox().length')+' letters resurrected');
  chk('and no badge reappears', EV('mailUnread()')===0, EV('mailUnread()'));
  chk('the ledger remembers what was sent', EV('Object.keys(S.mailSent).length')>=afterFirst, EV('Object.keys(S.mailSent).length'));
  // a genuinely NEW fact still gets through after a clear
  const d7=EV(`(function(){ var d2=new Date(shiftDate()+'T12:00:00'); d2.setDate(d2.getDate()+7);
    return new Date(d2.getTime()-d2.getTimezoneOffset()*60000).toISOString().slice(0,10); })()`);
  EV('calNoteAdd("'+d7+'", {t:"Ruck march", k:"test", cd:true}); mailSweep();');
  chk('new letters still arrive after clearing', EV('mailBox().some(function(x){return x.txt.indexOf("Ruck march")>=0;})'), 'new letter blocked');
  chk('but a letter already sent today stays gone', EV('!mailBox().some(function(x){return x.id.indexOf("build-")===0;})'), 'resent an old letter');
  // the ledger is pruned, not unbounded
  EV('(function(){ S.mailSent={}; for(var i=0;i<450;i++){ S.mailSent["old"+i]=mailShiftIso(shiftDate(),-200); } save(); mailPrune(); })();');
  chk('stale ledger entries are pruned', EV('Object.keys(S.mailSent).length')===0, EV('Object.keys(S.mailSent).length'));
  EV('(function(){ S.mailSent={}; for(var i=0;i<450;i++){ S.mailSent["r"+i]=shiftDate(); } save(); mailPrune(); })();');
  chk('the ledger has a hard ceiling', EV('Object.keys(S.mailSent).length')<=400, EV('Object.keys(S.mailSent).length'));
  EV('S.mail=[]; S.mailSent={}; save(); mailSweep();');
  chk('the inbox states the coverage policy', (EV('mailShow(), document.getElementById("mailGate").textContent')).indexOf('reads the whole card')>=0, 'policy line missing');
  EV('var g=document.getElementById("mailGate"); g&&g.remove();');
  console.log('  problems: '+bad); process.exit(bad?1:0);
},1500);
