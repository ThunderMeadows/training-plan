// FIELD 2026-09-06, the third report of a dead "I understand": his sister, first open, "stuck
// on the opening screen 'before you train'. Is frozen, buttons dont work."
//
// Two things found on the shipped build. First, bootDisc() ran before load(), so S.discAck was
// never there to read and the gate stood on EVERY open for everyone - the earlier "frozen gate
// on a banked day" report was the same thing. Second, every accept path depended on a CLICK
// event, and a phone can withhold one (a handler preventDefault-ed the touch, the finger moved,
// the touch overlapped a scroll of the gate's own box). The acknowledgment is the tap, not the
// event name it arrives under.
//
// So this file delivers the tap every way a phone can: click, pointer down/up, touch start/end,
// and a pointer-down with NOTHING after it - and each must close the gate. It also holds the
// other half: an accepted gate does not return on the next open.
const {JSDOM}=require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const raw=fs.readFileSync(f,'utf8');
const AC=function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
let bad=0; const chk=(l,ok,dd)=>{ if(!ok)bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&dd?'  <-- '+dd:''}`);};
const errs=[];
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
function boot(store){
  const d=new JSDOM(raw,{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/',
    beforeParse(win){ Object.keys(store||{}).forEach(k=>win.localStorage.setItem(k, store[k])); win.AudioContext=AC; }});
  d.window.addEventListener('error',e=>errs.push(String(e.message)));
  return d.window;
}
const EVf=w=>e=>{ try{ return w.eval(e); }catch(err){ return 'ERR '+err.message; } };
const gateUp=E=>E('!!document.getElementById("discGate")');
function fire(w, sel, type, init){
  const el=w.document.querySelector(sel); if(!el) return 'NO '+sel;
  let ev;
  // jsdom has no PointerEvent; a MouseEvent carrying the pointer type name reaches the same listeners
  if(/^pointer/.test(type)) ev=new w.MouseEvent(type, Object.assign({bubbles:true,cancelable:true,clientX:100,clientY:300},init||{}));
  else if(/^touch/.test(type)){ const t={clientX:100,clientY:300,identifier:1,target:el}; ev=new w.Event(type,{bubbles:true,cancelable:true}); ev.touches=type==='touchend'?[]:[t]; ev.changedTouches=[t]; }
  else ev=new w.MouseEvent(type, Object.assign({bubbles:true,cancelable:true,clientX:100,clientY:300},init||{}));
  el.dispatchEvent(ev); return 'ok';
}

setTimeout(async ()=>{
  console.log(`\n--- ${L}: the gate can always be passed, and stays passed ---`);
  // The card fires pointerdown/pointerup/click through jsdom's PointerEvent; a phone that
  // withholds the click is modelled by simply not sending it.

  // ---- 1. a plain click still works (the path everyone else uses) ----------------
  let w=boot({}); await sleep(1600); let E=EVf(w);
  chk('(fixture) a first open shows the gate', gateUp(E), 'no gate on a fresh card');
  fire(w,'#discOk','click'); await sleep(30);
  chk('a click closes it', !gateUp(E) && E('!!(S.discAck && S.discAck.v>=DISC_V)'), 'gate still up after click');

  // ---- 2. a phone that withholds the click: pointer down + up only --------------
  w=boot({}); await sleep(1600); E=EVf(w);
  fire(w,'#discOk','pointerdown'); fire(w,'#discOk','pointerup'); await sleep(30);
  chk('pointer down and up with no click closes it', !gateUp(E), 'gate survived a pointer tap');

  // ---- 3. touch start + end only ---------------------------------------------------
  w=boot({}); await sleep(1600); E=EVf(w);
  fire(w,'#discOk','touchstart'); fire(w,'#discOk','touchend'); await sleep(30);
  chk('touch start and end with no click closes it', !gateUp(E), 'gate survived a touch tap');

  // ---- 4. a finger that went down and nothing else arrived: the watchdog ---------
  w=boot({}); await sleep(1600); E=EVf(w);
  fire(w,'#discOk','pointerdown'); await sleep(700);
  chk('a pointer that went down on the button and was never followed up still counts', !gateUp(E), 'watchdog did not fire');

  // ---- 5. a scroll that started on the button is NOT an acceptance ---------------
  w=boot({}); await sleep(1600); E=EVf(w);
  fire(w,'#discOk','pointerdown',{clientX:100,clientY:300}); await sleep(30);
  fire(w,'#discOk','pointerup',{clientX:100,clientY:420}); await sleep(30);
  chk('a finger that travelled 120px on the button is a scroll, not an acceptance', gateUp(E), 'a scroll accepted the disclaimer');
  await sleep(600);
  chk('and the watchdog still honours the tap once the finger has clearly stopped', !gateUp(E), 'gate stuck after a scroll-then-hold');

  // ---- 6. the Terms link on the gate still opens -----------------------------------
  w=boot({}); await sleep(1600); E=EVf(w);
  fire(w,'#discGate [data-termsshow]','click'); await sleep(30);
  chk('Terms & Privacy opens from the gate', E('!!document.getElementById("termsGate")'), 'terms did not open');
  chk('and the gate is still there behind it', gateUp(E), 'terms tap dismissed the gate');

  // ---- 7. accepted once means accepted --------------------------------------------
  w=boot({}); await sleep(1600); E=EVf(w);
  fire(w,'#discOk','click'); await sleep(60);
  const store={}; for(let i=0;i<w.localStorage.length;i++){ const k=w.localStorage.key(i); store[k]=w.localStorage.getItem(k); }
  const w2=boot(store); await sleep(2400); const E2=EVf(w2);
  chk('the next open does not show the gate again', !gateUp(E2), 'the gate came back for a user who already accepted');
  chk('the card is usable underneath', /Training Card|Setup|DEADSTOP/.test(String(E2('document.getElementById("app").textContent'))), 'nothing rendered');

  // ---- 8. re-reading it from Settings still works, and closing it does not re-acknowledge ----
  E2('bootDisc(true);'); await sleep(30);
  chk('the gate can be re-read on request', gateUp(E2), 'forced gate did not show');
  const before=E2('JSON.stringify(S.discAck)');
  fire(w2,'#discOk','click'); await sleep(30);
  chk('closing the re-read gate leaves the original acknowledgment alone', !gateUp(E2) && E2('JSON.stringify(S.discAck)')===before, 'forced close rewrote the ack');

  // ---- 9. the button cannot fall off the bottom of a short screen ----------------
  chk('the button is pinned inside the gate\u2019s scroll box',
      /#discOk\{[^}]*position:sticky/.test(raw.replace(/\s+/g,'')) , 'button is not sticky');

  chk('no runtime errors across the boots', errs.length===0, errs.slice(0,3).join(' | '));
  console.log(`\nproblems: ${bad}`);
  process.exit(bad? 1:0);
},100);
