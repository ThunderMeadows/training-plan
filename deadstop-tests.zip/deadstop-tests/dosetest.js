// His rule, 2026-09-08: "I think 6 should be the magic number of exercises but i would rather
// go with what exercise science recommends. Also, i dont want more than one core or grip
// focused exercise prescribed per day and it must be the last one prescribed on the list."
//
// Six is the dose (sets-per-muscle-per-session and total hard sets per session both land there
// at 3-4 sets a movement). The starter template shipped four days at EIGHT - the pull days went
// from seven to eight on Sept 4 when Barbell Row was inserted without anything coming out - and
// day F carried three core movements. This file holds: the template and every generated plan
// obey the dose; core/grip is single and last; an athlete's own additions are counted, warned
// about, never removed, and a core addition lands last; and the template change did not detach
// a single logged set from its movement.
const {JSDOM}=require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const raw=fs.readFileSync(f,'utf8');
const AC=function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
let bad=0; const chk=(l,ok,dd)=>{ if(!ok)bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&dd?'  <-- '+dd:''}`);};
const errs=[]; const sleep=ms=>new Promise(r=>setTimeout(r,ms));
function boot(store){ const d=new JSDOM(raw,{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/',beforeParse(w){ Object.keys(store||{}).forEach(k=>w.localStorage.setItem(k,store[k])); w.AudioContext=AC; }}); d.window.addEventListener('error',e=>errs.push(String(e.message))); return d.window; }
const EVf=w=>e=>{ try{ return w.eval(e); }catch(err){ return 'ERR '+err.message; } };

setTimeout(async ()=>{
  console.log(`\n--- ${L}: the dose ---`);
  let w=boot({}); await sleep(2000); let E=EVf(w);
  E('try{TOUR.live=false;}catch(e){} S.tour={done:true}; if(typeof ONB!=="undefined"){ONB().done=true;} S.discAck={v:DISC_V,d:localDate()}; storageOK=true; save();');
  chk('(fixture) the card knows the dose', E('typeof DOSE_MAX==="number" && typeof doseCheck==="function"'), 'no dose rule on this build');

  // ---- 1. the starter template ---------------------------------------------------------
  const tpl=E('JSON.stringify((PLAN_DEFAULT.days||[]).map(function(dd){ var n=dd.exercises.map(function(e){return e.name;}); var c=doseCheck(n); return {code:dd.code, n:n.length, core:c.core, ok:c.ok, last:n[n.length-1], mainsFirst:dd.exercises.every(function(e,i,a){ return !e.maxKey || i===0 || a[i-1].maxKey; })}; }))');
  const T=JSON.parse(tpl==='ERR'?'[]':tpl);
  console.log('    template: '+T.map(x=>x.code+'='+x.n+(x.core?'+core':'')).join('  '));
  chk('every starter day is at or under the dose', T.length===6 && T.every(x=>x.n<=6), tpl);
  chk('no starter day carries more than one core/grip movement', T.every(x=>x.core<=1), tpl);
  chk('and where there is one, it is last', T.every(x=>x.ok), tpl);
  chk('main lifts open every day', T.every(x=>x.mainsFirst), 'an accessory sits ahead of a main lift');

  // ---- 2. every generated plan --------------------------------------------------------
  const gen=E(`JSON.stringify((function(){ var bad=[]; [2,3,4,5,6].forEach(function(n){ ['general','strength','hypertrophy','endurance','power','athletic'].forEach(function(g){
      var p=null; try{ p=generatePlan({maxes:{squat:315,bench:225,dead:405,ohp:135,row:185}, goal:g, days:n}); }catch(e){}
      if(!p) return; p.days.forEach(function(dd){ var c=doseCheck(dd.exercises.map(function(e){return e.name;})); if(!c.ok) bad.push(n+'d/'+g+'/'+dd.code+': '+c.count+' moves, core '+c.core+(c.coreLast?'':' not last')); }); }); }); return bad; })())`);
  chk('every generated plan, every shape and goal, obeys the dose with core last', gen==='[]', gen);

  // ---- 3. the classifier ---------------------------------------------------------------
  chk('core/grip is recognised by its primary muscle', E('isCoreGrip("Plank") && isCoreGrip("Side Plank") && isCoreGrip("Hanging Leg Raises") && !isCoreGrip("Back Squat") && !isCoreGrip("Face Pulls") && !isCoreGrip("Lateral Band Walk") && !isCoreGrip("Romanian Deadlift")'), 'classifier wrong');

  // ---- 4. the caution fires at seven, not six ------------------------------------------
  E('S.day="C"; S.outs={}; S.customs={}; S.order={};');
  chk('six movements is not a caution', E('(function(){ var v=volCaution(); return v===null || v.v.ex<=6; })()'), JSON.stringify(E('volCaution()')));
  E('libAdd("Plank","C");'); await sleep(30);
  chk('a seventh movement is', E('(function(){ var v=volCaution(); return !!v && v.v.ex===7; })()'), JSON.stringify(E('volCaution()')));

  // ---- 5. an athlete's own additions ---------------------------------------------------
  chk('an added core movement lands last', E('(function(){ var n=dayOrderNames("C"); return isCoreGrip(n[n.length-1]) && n.indexOf("Plank")===n.length-1; })()'), E('JSON.stringify(dayOrderNames("C"))'));
  chk('and a second core movement is kept, not removed - it is the athlete\u2019s call', E('dayOrderNames("C").filter(isCoreGrip).length')===2, 'the card removed what the athlete added');
  E('libAdd("Walking Lunges","C");'); await sleep(30);
  chk('a non-core movement added to a day ending in core goes in FRONT of the core', E('(function(){ var n=dayOrderNames("C"); return n.indexOf("Walking Lunges")<n.length-1 && isCoreGrip(n[n.length-1]); })()'), E('JSON.stringify(dayOrderNames("C"))'));

  // ---- 6. the template change did not detach logged sets from their movement ----------
  // A card that trained week 1 on the OLD eight-movement pull day, before this template shipped.
  const oldB=['Barbell Row','Cable Rows','Lat Pulldown','Straight-Arm Pulldown','Straight Bar Curl','Hammer Curls','Incline DB Curl','Face Pulls'];
  const data={}; oldB.forEach((n,i)=>{ data['1c|1|B|'+i]={sets:Array.from({length:i+2},()=>({st:'hit',reps:8,rir:2}))}; });
  const st={discAck:{v:1,d:'2026-09-01'}, tour:{done:true}, data:data, week:1, day:'B'};   // no tplVer, no tplNames: the shipped fallback must be used
  w=boot({ 'nsc:training-card-v1': JSON.stringify(st) }); await sleep(2400); E=EVf(w);
  const found=E(`JSON.stringify((function(){ S.day="B"; S.week=1; var out={}; dayObj().exercises.forEach(function(e,i){ var s=S.data[exKey(i)]; out[e.name]=s? (s.sets||[]).length : 0; }); return out; })())`);
  const F=JSON.parse(found==='ERR'?'{}':found);
  chk('after the template change every surviving movement still holds its own sets',
      F['Barbell Row']===2 && F['Cable Rows']===3 && F['Lat Pulldown']===4 && F['Straight Bar Curl']===6 && F['Hammer Curls']===7 && F['Face Pulls']===9, found);
  chk('the sets of the movements that left the template are parked, not lost or misfiled', E('(function(){ var n=0; Object.keys(S.dpark||{}).forEach(function(k){ if(k.indexOf("1c|1|B")===0) n+=(S.dpark[k].sets||[]).length; }); return n; })()')===5+8, 'parked '+E('JSON.stringify(Object.keys(S.dpark||{}))'));
  chk('and the migration runs once', E('S.tplVer===PLAN_DEFAULT.v && !!S.tplNames'), 'no version stamp');

  chk('no runtime errors', errs.length===0, errs.slice(0,3).join(' | '));
  console.log(`\nproblems: ${bad}`);
  process.exit(bad? 1:0);
},100);
