// Everything the settings sheet LAUNCHES must land above the sheet, or close it first.
// FIELD 2026-09-03: "some buttons in settings don't work, some open behind the settings page".
// Two overlays (paste-restore, the copied-text box Backup uses) were created at z 40 under a
// sheet at 200, and Assessments started the retest in the app underneath the sheet. setbtns
// checked a hand-written list and stayed green through all three. This walks the real DOM.
const { JSDOM } = require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const dom=new JSDOM(fs.readFileSync(f,'utf8'),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/'});
const w=dom.window,D=w.document,EV=e=>w.eval(e);
w.AudioContext=w.AudioContext||function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
w.alert=()=>{}; w.confirm=()=>true;
const cssZ=cls=>parseInt(EV('(function(){ try{ var s=""; for(var i=0;i<document.styleSheets.length;i++){ var r=document.styleSheets[i].cssRules; for(var j=0;j<r.length;j++){ if(r[j].selectorText && r[j].selectorText.split(",").some(function(x){ return x.trim()===".'+cls+'"; }) && r[j].style.getPropertyValue("z-index")) s=r[j].style.getPropertyValue("z-index"); } } return s; }catch(e){ return ""; } })()')||'0',10)||0;
const zOf=el=>{ let z=0,n=el; while(n&&n!==D.body){ const inl=parseInt((n.style&&n.style.zIndex)||'',10); if(!isNaN(inl)) z=Math.max(z,inl); (n.className||'').split(/\s+/).filter(Boolean).forEach(c=>{ z=Math.max(z,cssZ(c)); }); n=n.parentElement; } return z; };
setTimeout(async()=>{
  console.log(`\n--- ${L}: what settings launches lands above the sheet ---`);
  let bad=0; const chk=(l,ok,d)=>{ if(!ok) bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&d?'  <-- '+d:''}`); };
  EV('try{TOUR.live=false;}catch(e){} S.tour={done:true}; if(typeof ONB!=="undefined"){ONB().done=true;} S.discAck={v:DISC_V,d:localDate()}; storageOK=true; S.maxes={squat:327,bench:225,dead:405,ohp:145,row:170,pull:225}; save();');
  EV('var g=document.getElementById("discGate"); if(g) g.remove();');
  const SHEET=cssZ('set-wrap')||cssZ('hw-wrap')||200;
  console.log('  sheet z:', SHEET);
  const open=()=>{ EV('SET_OPEN=true; settingsSync();'); };
  const click=sel=>{ open(); const el=D.querySelector('#setHost '+sel); if(!el) return false; el.dispatchEvent(new w.MouseEvent('click',{bubbles:true})); return true; };
  const sheetOpen=()=>!!D.querySelector('#setHost .set-sheet');
  const newest=()=>[...D.querySelectorAll('body > *')].filter(x=>x.id!=='app' && x.id!=='setHost' && x.id!=='coachHost' && x.innerHTML.trim()).map(x=>({el:x, z:zOf(x)}));
  // disclaimer
  if(click('[data-discshow]')){ const g=D.getElementById('discGate'); chk('Read the disclaimer opens, above the sheet', !!g && zOf(g)>SHEET, g? 'z '+zOf(g):'no gate'); if(g) g.remove(); }
  // terms
  if(click('[data-termsshow]')){ const t=D.querySelector('.terms-wrap'); chk('Terms opens, above the sheet', !!t && zOf(t)>SHEET, t? 'z '+zOf(t):'no terms'); D.querySelectorAll('.terms-wrap').forEach(x=>x.remove()); }
  // assessments (training card only)
  if(D.querySelector('#setHost [data-retest]') || (open(), D.querySelector('#setHost [data-retest]'))){
    click('[data-retest]');
    chk('Assessments closes the sheet and puts the retest on screen', !sheetOpen() && /warm|starting weights|Set 1|calibrat/i.test(D.getElementById('app').innerHTML), sheetOpen()? 'sheet still open - the test is running behind it' : 'retest not on screen');
    EV('try{ var o=ONB(); o.retest=false; o.done=true; o.res=o.resBak||{}; save(); render(); }catch(e){}');
  } else console.log('  (no Assessments button on this card)');
  // report
  // FIELD 2026-09-04: this check passed while every button on the panel was dead. It compared
  // z-index NUMBERS - 240 beats 200 - but the panel renders inside #app and the sheet in its own
  // body-level host, so #app's stacking context caps the panel below the sheet whatever number
  // it carries. A panel that is not a body-level sibling of the sheet can only be reachable if
  // the sheet has actually closed. And the buttons have to be proven live by pressing one.
  if(click('#reportBtn')){
    const r=D.querySelector('.rpt-wrap');
    const reachable = !!r && (!sheetOpen() || (r.parentElement===D.body && zOf(r)>SHEET));
    chk('Report a problem is reachable - the sheet closed, or the panel is a real sibling above it', reachable,
        !r? 'no panel' : (sheetOpen()? 'sheet still open and the panel is inside #app - every button on it is dead' : 'z '+zOf(r)));
    const kindBefore=EV('S.rptKind');
    const chip=[...D.querySelectorAll('[data-rptkind]')].find(c=>c.dataset.rptkind!==kindBefore);
    if(chip){ chip.dispatchEvent(new w.MouseEvent('click',{bubbles:true}));
      chk('and a button on the report panel actually does something when pressed', EV('S.rptKind')===chip.dataset.rptkind, 'kind stayed '+EV('S.rptKind')); }
    // the send buttons he named: every one rendered must be bound, not just drawn
    const unbound=['rptShare','rptMail','rptSms','rptCopy'].filter(id=>{ const el=D.getElementById(id); return el && !el.onclick; });
    chk('every send button under the report is wired', unbound.length===0, 'drawn but dead: '+unbound.join(', '));
    EV('S.rptOpen=false; render();');
  }
  // paste restore
  if(click('#restorePasteBtn')){ const ov=D.getElementById('repOv'); chk('Paste-restore box opens above the sheet', !!ov && zOf(ov)>SHEET, ov? 'z '+zOf(ov):'no box'); if(ov) ov.remove(); }
  // the copied-text box Backup uses
  EV('try{ showOverlay("t","x",true); }catch(e){}'); { const ov=D.getElementById('repOv'); chk('the copied-text box (Backup) sits above the sheet', !!ov && zOf(ov)>SHEET, ov? 'z '+zOf(ov):'no box'); if(ov) ov.remove(); }
  // phone check writes into the sheet
  if(click('#selfTestBtn')){ await new Promise(r=>setTimeout(r,1500)); const out=D.getElementById('selfTestOut'); chk('Phone check reports inside the sheet', !!out && out.textContent.trim().length>20 && sheetOpen(), out? out.textContent.trim().slice(0,40):'no host'); }
  // every fixed overlay that can be created at runtime sits above the sheet or is an error bar
  const low=EV(`(function(){ var src=''; Object.getOwnPropertyNames(window).forEach(function(n){ try{ if(typeof window[n]==='function') src+=String(window[n]); }catch(e){} });
      var out=[]; var re=/position:fixed[^'"]*?z-index:\\s*(\\d+)/g, m; while((m=re.exec(src))) if(+m[1]<${SHEET}) out.push(+m[1]); return out; })()`);
  console.log('  (runtime overlays defined below the sheet, none launched from settings: z '+(low.join(',')||'none')+' - error fallback and the PDF viewer)');
  console.log('  problems:', bad); process.exit(bad?1:0);
},1500);
