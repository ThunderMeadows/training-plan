// Every drawn string is recorded with its measured width; two strings on one baseline must
// not overlap, and the work list must stay above the QR band. This is the collision class
// from the 2026-08-31 field screenshot: stats fused, names into prescriptions, QR over rows.
const {JSDOM}=require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const d=new JSDOM(fs.readFileSync(f,'utf8'),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/'});
const w=d.window,EV=e=>w.eval(e);
w.AudioContext=function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
let bad=0; const chk=(l,ok,dd)=>{ if(!ok)bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&dd?'  <-- '+dd:''}`); };
setTimeout(()=>{
  console.log(`\n--- ${L}: share sheet geometry ---`);
  EV('try{TOUR.live=false;}catch(e){} S.tour={done:true};');
  for(const fn of ['coachIdle','ONB_ACTIVE','isStartMode']) EV(`if(typeof ${fn}==="function") ${fn}=function(){return false;};`);
  EV('S.maxes={squat:327,bench:225,dead:405,ohp:145,pull:225}; render();');
  // seed the field scenario: long names, big volume, cardio, duplicate-movement PRs
  EV(`(function(){
    S.profileName='Manuel Grajeda';
    var dt=(S.when&&S.when.date)||localDate(); // the session's date, not the wall clock - a 2am session belongs to yesterday
    S.prs=[{ex:'Cable Rows',kind:'estimated max',val:224,prev:213,d:dt},
           {ex:'Cable Rows',kind:'volume',val:7680,prev:6720,d:dt},
           {ex:'Straight-Arm Pulldown',kind:'weight',val:70,prev:65,d:dt}];
    S.cardio=S.cardio||{}; S.cardio.tacc=20*60000;
    var d0=dayObj();
    var names=['Lat Pulldown','Cable Rows','Straight-Arm Pulldown','Swiss Bar Curl','Hammer Curls','DB Curl','Face Pulls','Reverse Fly'];
    d0.exercises.forEach(function(ex,i){
      var st=exState(i,ex); st.sub=names[i%names.length];
      st.sets.forEach(function(s){ s.st='hit'; s.w=160; });
    });
    save();
  })();`);
  // record every fillText with its measured width under the live font
  EV(`window.__draws=[];
    (function(){ var gc=HTMLCanvasElement.prototype.getContext;
      HTMLCanvasElement.prototype.getContext=function(){ var ctx=gc.apply(this,arguments);
        if(ctx && ctx.fillText && !ctx.__wrapped){ ctx.__wrapped=1; var ft=ctx.fillText.bind(ctx);
          ctx.fillText=function(t,px,py){ try{ window.__draws.push({t:String(t),x:px,y:py,w:ctx.measureText(String(t)).width,f:ctx.font}); }catch(e){} return ft(t,px,py); };
          window.__probeCanvas=this; }
        return ctx; }; })();`);
  // a shipped card must know its home: baked, https, and directory-shaped
  const canon=EV('typeof CANON_URL==="string" ? CANON_URL : null');
  chk('CANON_URL is baked', !!canon && /^https:\/\//.test(canon) && /\/$/.test(canon), JSON.stringify(canon));
  // the QR must encode the card's canonical home, not wherever it happens to run
  EV('window.CANON_URL_TEST="https://example-canon.test/card/"; cardURL=function(){ return CANON_URL_TEST; };');
  let doneBlob=null, canvasRef=null;
  w.__probeDone=(b,c)=>{ doneBlob=b; canvasRef=c; };
  EV('shareCardPaint(function(b,c){ window.__probeDone(b,c); }, null, null);');
  setTimeout(()=>{
    const draws=JSON.parse(EV('JSON.stringify(window.__draws)'));
    chk('sheet drew text', draws.length>10, draws.length);
    // 1. no horizontal overlap on any shared baseline
    const byY={}; draws.forEach(t=>{ (byY[Math.round(t.y)]=byY[Math.round(t.y)]||[]).push(t); });
    let clash=null;
    Object.values(byY).forEach(row=>{ row.sort((a,b)=>a.x-b.x);
      for(let i=0;i<row.length-1;i++) if(row[i].x+row[i].w>row[i+1].x+1) clash=row[i].t+' \u2192 '+row[i+1].t; });
    chk('no two strings collide on a baseline', !clash, clash);
    // 2. nothing overruns the right margin
    const over=draws.find(t=>t.x+t.w>1080-40);
    chk('nothing overruns the right edge', !over, over&&over.t);
    // 3. the work list stays above the QR band, whatever height the sheet chose
    const CH=Number(EV('window.__probeCanvas ? window.__probeCanvas.height : 0'))||1350;
    const FLOOR=CH-96-150-40;
    const buried=draws.find(t=>/32px/.test(t.f)&&t.y>FLOOR);
    chk('work rows stay above the QR band', !buried, buried&&(buried.t+' at y='+Math.round(buried.y)+' floor='+FLOOR));
    chk('sheet is at least 4:5', CH>=1350, CH);
    // 4. duplicate-movement PRs merged to one line
    const cr=draws.filter(t=>t.t==='Cable Rows');
    chk('same movement appears once in the PR box', cr.filter(t=>t.x===104).length<=1, cr.length+' PR lines');
    chk('merged record line carries both records', !!draws.find(t=>/estimated max 224.*volume 7680|volume 7680.*estimated max 224/.test(t.t)), 'not merged');
    // 4b. the QR caption reflects the canonical home, not the runtime origin
    const canonCap=draws.find(t=>/example-canon\.test/.test(t.t));
    const runtimeCap=draws.find(t=>t.t==='x.io');
    chk('QR labels the canonical home', !!canonCap && !runtimeCap, runtimeCap? 'still labels runtime origin':'canon caption missing');
    // 5. NOTHING hidden - his rule: the information is to share. Every logged movement
    // prints, and the "+N more" cap must never come back.
    const capLine=draws.find(t=>/^\+ \d+ more/.test(t.t));
    chk('no "+N more" cap exists', !capLine, capLine&&capLine.t);
    const logged=Number(EV(`(function(){ var n=0; try{ dayObj().exercises.forEach(function(ex,i){
      var st=S.data[exKey(i)]; if(st && st.sets.some(function(s){return s.st!=='pend';})) n++; }); }catch(e){} return n; })()`));
    const printed=draws.filter(t=>/32px/.test(t.f)&&t.x===72).length;
    chk('every logged movement prints ('+logged+' logged)', logged>0 && printed>=logged, printed+' printed');
    // render the proof
    try{
      const du=canvasRef? canvasRef.toDataURL('image/png') : EV('window.__probeCanvas && window.__probeCanvas.toDataURL("image/png")');
      if(du && du.length>2000){ fs.writeFileSync('/home/claude/build/share-preview-'+L+'.png', Buffer.from(du.split(',')[1],'base64')); console.log('       preview written'); }
    }catch(e){ console.log('       preview skipped: '+e.message); }
    console.log('  problems: '+bad); process.exit(bad?1:0);
  },1200);
},1500);
