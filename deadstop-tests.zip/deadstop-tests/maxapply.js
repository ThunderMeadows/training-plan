// MAX APPLY (2026-09-03, field: "I set max then select apply, it reverts or changes the max I set.")
// The +/- steppers under Programming maxes SAVE ON TAP - there is no apply-my-edit button.
// The amber "Apply" beside them applied the card's SUGGESTED max instead, and suggestMax only
// offers when the suggestion is >= current+5 - so it appeared exactly when the athlete had just
// set a LOWER max on purpose, dressed in the card's primary action colour, labelled as if it
// committed their edit. A wrong max is a wrong weight on the bar, so this one is standing.
//
// It must keep BOTH truths: a hand-set max is never overwritten by a suggestion the athlete did
// not ask for, AND the suggestion still works for an athlete who has not touched that max.
const { JSDOM } = require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const dom=new JSDOM(fs.readFileSync(f,'utf8'),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/',
  beforeParse(w){
    w.AudioContext=function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
    w.alert=()=>{};
  }});
const w=dom.window,D=w.document,EV=e=>w.eval(e);
let bad=0; const chk=(l,ok,d)=>{ if(!ok) bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&d?'  <-- '+d:''}`); };
const tap=el=>el.dispatchEvent(new w.MouseEvent('click',{bubbles:true}));
const applies=k=>[...D.querySelectorAll('[data-mxapply="'+k+'"]')];

setTimeout(async()=>{
  console.log(`\n--- ${L}: a hand-set max is the athlete's, not a suggestion ---`);
  EV('try{TOUR.live=false;}catch(e){} S.tour={done:true}; if(typeof ONB!=="undefined"){ONB().done=true;} S.discAck={v:DISC_V,d:localDate()}; storageOK=true; save();');
  const setup="S.maxes.bench=225; S.e1rm={bench:{val:250,date:localDate()}}; S.day='MAX'; mxEdit=true; if(typeof mxTouched!=='undefined') mxTouched={}; save(); render();";
  EV(setup);

  // 1. The suggestion still works for an athlete who has NOT touched this max.
  const fresh=applies('bench');
  chk('an untouched max is still offered the suggestion from logged sets', fresh.length>0,
      'no suggestion offered at all - the feature is gone, not fixed');

  if(fresh.length){
    // 2. It names the number it will write. "Apply" alone reads as "commit what I set".
    const label=fresh[0].textContent.trim();
    chk('the suggestion button names the weight it will write', /\d/.test(label),
        'label is "'+label+'" and names no number');
    // 3. It does not outrank the athlete's own edit in the card's primary colour.
    const style=(fresh[0].getAttribute('style')||'');
    chk('the suggestion is not dressed as the primary action', !/--amber/.test(style),
        'styled amber: '+style.slice(0,60));
  }

  // 4. The steppers save on tap - the edit is committed with no further action.
  EV(setup);
  const down=()=>[...D.querySelectorAll('[data-mx="bench"]')].find(x=>+x.dataset.d<0);
  for(let i=0;i<4;i++){ const b=down(); if(b) tap(b); }
  const handSet=EV('S.maxes.bench');
  chk('the +/- steppers commit the max on tap', handSet===205, 'stepped 4 x -5 from 225 and got '+handSet);
  // state is namespaced: 'nsc:'+curSKEY(), and a coached athlete lives at curSKEY()+':a:<id>'
  const stored=EV("(function(){ var r=localStorage.getItem('nsc:'+curSKEY()); return r? JSON.parse(r).maxes.bench : null; })()");
  chk('and the committed max is on disk, not just on screen', stored===205,
      'in memory '+handSet+' but storage holds '+stored);

  // 5. THE BUG: after hand-setting, nothing offers to overwrite it.
  const after=applies('bench');
  chk('a max just set by hand is not offered a suggestion over the top of it',
      after.length===0,
      'still offers "'+(after[0]?after[0].textContent.trim():'')+'" which would write '+(after[0]?after[0].dataset.v:'')+' over the athlete\'s '+handSet);

  // 6. And if one is somehow tapped, the max lands on the value shown on the button.
  if(after.length){
    const promised=+after[0].dataset.v;
    tap(after[0]); await new Promise(r=>setTimeout(r,50));
    chk('applying a suggestion writes exactly the weight the button showed', EV('S.maxes.bench')===promised,
        'button said '+promised+', max became '+EV('S.maxes.bench'));
  }

  // 7. Closing and reopening Edit is a fresh session - suggestions are offered again.
  EV(setup);
  for(let i=0;i<4;i++){ const b=down(); if(b) tap(b); }
  EV("mxEdit=false; if(typeof mxTouched!=='undefined') mxTouched={}; render(); mxEdit=true; render();");
  chk('re-opening Edit offers the suggestion again - the athlete can still take it',
      applies('bench').length>0, 'suggestion never comes back once suppressed');

  console.log('  problems:', bad); process.exit(bad?1:0);
},1500);
