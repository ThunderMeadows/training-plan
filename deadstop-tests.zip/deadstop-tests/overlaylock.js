// AN OVERLAY IS NEVER PART OF THE LOCKED DAY (2026-09-04, field: "The mail is locked. I'll open it
// then the close button is dead, so is the clear button on the bottom. Terms & conditions is also
// dead.")
//
// The FOURTH bug in this family. lockGuard kept a hand-written list of things that float over the
// session - it had been extended three times, carried a comment saying "hence one rule, on top",
// and still missed #mailGate, #termsGate and #discGate. So on a logged or previewed day an
// athlete could open mail and then not close it. A list of overlays is always one entry behind
// the next overlay somebody adds; hdrlive proved the same point in c185 and I did not generalise
// it far enough.
//
// The rule now: every overlay the card opens is a BODY child beside #app. The session is #app.
// Anything outside #app is never locked. This harness pins BOTH halves - every overlay stays
// usable in every lock state, AND the session itself stays properly read-only.
const { JSDOM } = require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const dom=new JSDOM(fs.readFileSync(f,'utf8'),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/',
  beforeParse(w){
    w.AudioContext=function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
    w.alert=()=>{}; w.confirm=()=>true;
  }});
const w=dom.window,D=w.document,EV=e=>w.eval(e);
let bad=0; const chk=(l,ok,d)=>{ if(!ok) bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&d?'  <-- '+d:''}`); };

// Did the guard swallow this tap? That is exactly what an athlete experiences as a dead button.
const swallowed=(el)=>{
  const ev=new w.MouseEvent('click',{bubbles:true,cancelable:true});
  let stopped=false; const orig=ev.stopPropagation.bind(ev);
  ev.stopPropagation=function(){ stopped=true; return orig(); };
  el.dispatchEvent(ev);
  return stopped;
};

setTimeout(async()=>{
  console.log(`\n--- ${L}: you can always close what you opened ---`);
  EV('try{TOUR.live=false;}catch(e){} S.tour={done:true}; if(typeof ONB!=="undefined"){ONB().done=true;} S.discAck={v:DISC_V,d:localDate()}; storageOK=true; S.maxes={squat:327,bench:225,dead:405,ohp:145,row:170,pull:225}; save();');

  const live   = "S.splitMode='guided'; S.locked={}; S.data={}; S.week=timeWeek(); S.day=PLAN.days[0].code; SET_OPEN=false; settingsSync(); render();";
  const logged = live + " S.locked=S.locked||{}; S.locked[dayKey()]=true; render();";
  const preview= "S.splitMode='guided'; S.wd=null; S.locked={}; S.data={}; S.week=timeWeek(); S.day=PLAN.days[PLAN.days.length-1].code; SET_OPEN=false; settingsSync(); render();";

  // COUNTER-CHECK FIRST, on a page nothing has touched. It used to run last and reported "no
  // session control found" - because the census above presses every control in settings for real,
  // and some of them change the card out from under it. A counter-check that cannot run is not a
  // counter-check, and a fixture that quietly finds nothing is the same vacuous green I keep
  // catching everywhere else.
  EV(logged); EV('render();');
  D.querySelectorAll('#mailGate,#termsGate,.terms-wrap,#discGate').forEach(x=>x.remove());
  // The session control has to be one the guard is actually meant to stop. The first selector
  // came back empty and reported "no session control found", which is a harness fault dressed as
  // a result - a counter-check that cannot run is not a counter-check.
  const sess=[...D.querySelectorAll('#app .set, #app [data-set], #app .savelog')].find(el=>!el.closest('.footer'));
  chk('a logged session is still read-only - the guard still guards', !!sess && swallowed(sess),
      sess? 'a tap reached the session on a banked day' : 'no session control found to test against');


  const overlays=[
    ['mail from Bulk', "try{ mailShow(); }catch(e){}", '#mailGate'],
    ['terms & privacy', "try{ termsShow(); }catch(e){}", '#termsGate,.terms-wrap'],
    ['the disclaimer',  "try{ bootDisc(true); }catch(e){}", '#discGate'],
    ['settings',        "SET_OPEN=true; settingsSync();", '#setHost'],
  ];

  // A DIFFERENTIAL, not an absolute. Plenty of controls legitimately call stopPropagation on
  // their own - the settings sheet wraps every one of its controls that way so a tap inside does
  // not close the sheet. The first version of this check counted those as swallowed and reported
  // 59 dead controls in settings ON A LIVE DAY, where nothing is locked at all: a false
  // accusation, and the same "measuring a proxy for the thing" mistake that let the report panel
  // ship. What matters is only this: does the LOCK change the answer?
  const census=(setup, open, sel)=>{
    EV(setup); try{ EV(open); }catch(e){}
    const host=D.querySelector(sel); if(!host) return null;
    const out={};
    [...host.querySelectorAll('*')].filter(el=>el.onclick||el.onpointerdown).forEach((el,ix)=>{
      // Key by id where there is one. Keying by id+INDEX meant a control whose position in the
      // overlay differs between states did not line up with itself, and the differential reported
      // it as newly dead. That is how #discOk was accused - a keying artifact, not a card fault.
      out[el.id? ('#'+el.id) : ('ix'+ix)]=swallowed(el);
    });
    D.querySelectorAll('#mailGate,#termsGate,.terms-wrap,#discGate').forEach(x=>x.remove());
    try{ EV('SET_OPEN=false; settingsSync();'); }catch(e){}
    return out;
  };

  for(const [oname, open, sel] of overlays){
    const base=census(live, open, sel);
    chk(`(fixture) ${oname} opens on a live day with controls in it`, base && Object.keys(base).length>0,
        'nothing to compare against');
    if(!base) continue;
    for(const [stateName, setup] of [['a logged session',logged],['a future preview',preview]]){
      const now=census(setup, open, sel);
      if(!now){ chk(`${stateName}: ${oname} still opens`, false, 'did not open'); continue; }
      const newlyDead=Object.keys(now).filter(k=>now[k] && !base[k]);
      chk(`${stateName}: the lock does not kill anything inside ${oname}`, newlyDead.length===0,
          newlyDead.length+' control(s) work on a live day and are swallowed here: '+newlyDead.slice(0,4).join(', '));
    }
  }

  // --- and the rule is the rule, not another list ---------------------------------
  const src=fs.readFileSync(f,'utf8');
  const guard=src.slice(src.indexOf('function lockGuard'), src.indexOf('function lockGuard')+3000);
  chk('the guard exempts overlays by what they ARE, not by a list of names',
      /closest\('body > \*'\)/.test(guard),
      'lockGuard is still naming overlays one by one - the next one added will be locked too');

  console.log('  problems:', bad); process.exit(bad?1:0);
},1500);
