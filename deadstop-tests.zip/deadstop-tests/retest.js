// 2026-09-01: "redo their assessments just like in the beginning without restarting the card."
// Retest reruns the guided calibration alone; plan, logs and history stay untouched, skipped
// lifts keep their standing numbers, and cancel restores everything.
const {JSDOM}=require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const d=new JSDOM(fs.readFileSync(f,'utf8'),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/'});
const w=d.window,EV=e=>w.eval(e);
w.AudioContext=function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
let bad=0; const chk=(l,ok,dd)=>{ if(!ok)bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&dd?'  <-- '+dd:''}`); };
setTimeout(()=>{
  console.log(`\n--- ${L}: assessment retest ---`);
  if(EV('typeof ONB_STEPS_FULL')==='undefined'){ console.log('  ok    (no interactive onboarding on this card - nothing to test)\n  problems: 0'); process.exit(0); }
  EV('try{TOUR.live=false;}catch(e){} S.tour={done:true}; S.maxes={squat:327,bench:225,dead:405,ohp:145,pull:225};');
  EV('var o=ONB(); o.done=true; o.res={squat:{pm:320}}; S.data["seed"]={kept:1}; save(); render();');
  chk('settings offers the retest', EV('render(), document.body.innerHTML.indexOf("Redo the assessment")>=0 || settingsBodyHTML().indexOf("data-retest")>=0'), 'no entry');
  EV('(function(){ var o=ONB(); o.retest=true; o.resBak=Object.assign({},o.res||{}); o.res={}; o.ramp=null; o.done=false; o.step=0; save(); render(); })();');
  chk('retest opens straight into calibration', EV('JSON.stringify(ONB_STEPS_FOR())')==='["calibrate"]', EV('JSON.stringify(ONB_STEPS_FOR())'));
  chk('plan and logs untouched by entering', EV('!!(S.data["seed"]&&S.data["seed"].kept)') && EV('!!PLAN.days'), 'state disturbed');
  // retest one lift, skip the rest, apply
  EV('(function(){ var o=ONB(); o.res={bench:{pm:240}}; ONB_ORDER.forEach(function(l){ if(o.res[l]&&o.res[l].pm) S.maxes[l]=o.res[l].pm; }); o.res=Object.assign({},o.resBak||{},o.res); delete o.resBak; o.retest=false; o.done=true; save(); })();');
  chk('retested lift updates', EV('S.maxes.bench')===240, EV('S.maxes.bench'));
  chk('skipped lifts keep standing numbers', EV('S.maxes.squat')===327, EV('S.maxes.squat'));
  chk('prior calibration results restored for skipped lifts', EV('!!(ONB().res.squat&&ONB().res.squat.pm===320)'), EV('JSON.stringify(ONB().res.squat||null)'));
  chk('card is back to normal, not restarted', EV('ONB().done===true && ONB().retest===false') && EV('!!(S.data["seed"]&&S.data["seed"].kept)'), 'state lost');
  console.log('  problems: '+bad); process.exit(bad?1:0);
},1500);
