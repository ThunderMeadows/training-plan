// Every goal offered must resolve to a real scheme, and the schemes must be genuinely
// different. Onboarding used to offer four of six, so power, hypertrophy and muscular
// endurance existed in full and had no front door.
const { JSDOM } = require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const dom=new JSDOM(fs.readFileSync(f,'utf8'),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/'});
const w=dom.window,D=w.document,EV=e=>w.eval(e);
w.AudioContext=w.AudioContext||function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
setTimeout(()=>{
  console.log(`\n--- ${L}: training goals ---`);
  let bad=0; const chk=(l,ok,d)=>{ if(!ok) bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&d?'  <-- '+d:''}`); };
  const want=['strength','power','hypertrophy','build','cut','endurance'];
  chk('all six schemes exist', want.every(g=>EV(`!!GOALS[${JSON.stringify(g)}]`)),
      want.filter(g=>!EV(`!!GOALS[${JSON.stringify(g)}]`)).join(','));

  // the schemes must actually differ - otherwise the choice is decoration
  const rows=want.map(g=>JSON.parse(EV(`JSON.stringify({s:GOALS[${JSON.stringify(g)}].sets,r:GOALS[${JSON.stringify(g)}].reps,rest:GOALS[${JSON.stringify(g)}].restMain,p:GOALS[${JSON.stringify(g)}].pct[0]})`)));
  rows.forEach((r,i)=>console.log(`         ${want[i].padEnd(12)} ${r.s}x${r.r}  from ${Math.round(r.p*100)}%  rest ${r.rest}`));
  chk('rep schemes are distinct', new Set(rows.map(r=>r.r)).size>=4);
  chk('rest periods are distinct', new Set(rows.map(r=>r.rest)).size>=4);
  // c125 decision: endurance rests aligned toward the source (NSCA: up to 30 sec - the
  // incomplete recovery IS the stimulus). Main lift gets 0:45 so fifteen honest reps stay
  // possible; accessories 0:30. The old 1:00 here was the pre-alignment number.
  chk('endurance is genuinely light and short', rows[5].p<=0.60 && rows[5].rest==='0:45');
  chk('strength is genuinely heavy and long', rows[0].p>=0.78 && rows[0].rest==='4:00');
  chk('power is lighter than strength at the same reps', rows[1].p<rows[0].p && rows[1].r===rows[0].r,
      'power should be speed work, not a second strength block');

  // onboarding, where the card has one
  if(EV('typeof ONB_GOALS')!=='undefined'){
    const ids=JSON.parse(EV('JSON.stringify(ONB_GOALS.map(function(g){return g.id;}))'));
    console.log('         onboarding offers:', ids.join(', '));
    chk('onboarding offers every scheme', want.every(g=>ids.indexOf(g)>-1),
        'missing: '+want.filter(g=>ids.indexOf(g)<0).join(','));
    chk('every offered id resolves', ids.every(i=>EV(`!!GOALS[${JSON.stringify(i)}]`)));
    // the plan generator must know them too, or setup picks a goal the plan ignores
    ids.forEach(i=>{
      const p=JSON.parse(EV(`JSON.stringify(PG_pct(${JSON.stringify(i)},false))`));
      const g=JSON.parse(EV(`JSON.stringify({r:GOALS[${JSON.stringify(i)}].reps})`));
      if(String(p.reps)!==String(g.r)){ console.log(`  FAIL  ${i}: generator says ${p.reps} reps, scheme says ${g.r}`); bad++; }
    });
    chk('generator agrees with every scheme', true);
  } else {
    console.log('         (no onboarding goal step on this card - selector only)');
    chk('the goal selector offers every scheme',
        want.every(g=>fs.readFileSync(f,'utf8').indexOf('option value="'+g+'"')>-1));
  }
  // the athlete has to be able to SEE which kind of training they are doing
  if(EV('typeof goalTag')==='function'){
    const tags=want.map(g=>{ EV(`S.profile=S.profile||{}; S.profile.goal=${JSON.stringify(g)};`); return EV('goalTag()'); });
    console.log('         labels:', tags.join(', '));
    chk('every scheme has a label', tags.every(t=>!!t && t.length>2));
    chk('the labels are distinct', new Set(tags).size===tags.length,
        'two goals reading the same tells the athlete nothing');
    // Block 1 is the DEFAULT profile, so a tag that hides there is invisible to most athletes.
    // With no chosen goal it names what the set is, from the prescribed reps.
    EV('S.profile.goal="block1";');
    const ex0=`dayObj().exercises[0]`;
    chk('a coach-built block still names the training', !!EV(`goalTag(${ex0})`),
        'the default profile would show no label at all');
    chk('and it matches the prescription', (function(){
        const r=EV(`defReps(${ex0})`), t=EV(`goalTag(${ex0})`);
        return (r<=5&&t==='STRENGTH')||(r<=8&&t==='HYPERTROPHY')||(r<=12&&t==='MUSCLE')||(r>12&&t==='ENDURANCE');
      })(), EV(`defReps(${ex0})`)+' reps labelled '+EV(`goalTag(${ex0})`));
  }
  console.log('  problems:', bad);
  process.exit(bad?1:0);
},1500);
