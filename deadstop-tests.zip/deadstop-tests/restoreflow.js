// The highest-stakes untested flow: back up, lose everything, restore. A bug here eats real
// history and stays invisible until the day it matters. Never executed by any test before.
const {JSDOM}=require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const d=new JSDOM(fs.readFileSync(f,'utf8'),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/'});
const w=d.window,EV=e=>w.eval(e);
w.AudioContext=function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
let bad=0; const chk=(l,ok,dd)=>{ if(!ok)bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&dd?'  <-- '+dd:''}`);};
setTimeout(async ()=>{
  console.log(`\n--- ${L}: back up, lose it, restore ---`);
  EV('try{TOUR.live=false;}catch(e){} S.tour={done:true}; if(typeof ONB!=="undefined"){ONB().done=true;} S.discAck={v:DISC_V,d:localDate()}; storageOK=true; save();');
  // build a history worth losing: maxes, a PR, bodyweight, a banked session
  EV(`S.maxes={squat:327,bench:225,dead:405,ohp:145,pull:225};
      // dated BEFORE today: since prdupe, banking re-judges today's records for the lifts it
      // banks, and a synthetic record for a lift those sets never earned is (correctly) retired
      S.prs=[{ex:'Bench Press',kind:'weight',val:235,prev:225,d:'2026-08-20'}];
      S.weightLog=[{d:localDate(),w:198}];
      save();`);
  EV(`(function(){ var dd=dayObj(); dd.exercises.forEach(function(ex,i){ var st=exState(i,ex);
      st.sets.forEach(function(s2){ s2.st='hit'; s2.reps=5; s2.rir=2; }); }); save(); })();`);
  await EV('saveSessionLog(true)');
  const logKeyCount=Number(EV('logKeys.length'));
  chk('a session is banked before backup', logKeyCount>0, logKeyCount);

  EV("S.notes='keep the bar over midfoot'; save();");
  // EXPORT: the exact payload backupAll writes
  const payload=await EV(`(async function(){ var logs={};
    for(const k of logKeys){ try{ logs[k]=await stGet(k); }catch(e){} }
    return JSON.stringify({v:1, exported:localDate(), S:S, logs:logs}); })()`);
  chk('the backup payload is valid JSON', (()=>{try{JSON.parse(payload);return true;}catch(e){return false;}})(), 'unparseable');
  const parsed=JSON.parse(payload);
  chk('it carries the state', !!(parsed.S && parsed.S.maxes && parsed.S.maxes.squat===327), 'state missing');
  chk('it carries the session logs', Object.keys(parsed.logs||{}).length===logKeyCount, Object.keys(parsed.logs||{}).length+' vs '+logKeyCount);
  chk('and the logs are not empty strings', Object.values(parsed.logs).every(v=>v && String(v).length>10), 'hollow logs');

  // LOSE EVERYTHING, the way clearing site data does
  EV('localStorage.clear(); S=mergeIntoShape({}); logKeys=[]; logCache={}; save();');
  chk('history is gone before the restore', EV('!S.maxes || S.maxes.squat!==327'), 'not actually cleared');

  // RESTORE via the real code path (a File the picker would hand it)
  w.__payload=payload;
  const restored=await EV(`(async function(){
    var file={ text: function(){ return Promise.resolve(window.__payload); } };
    try{ await restoreBackup(file); return 'ok'; }
    catch(e){ return 'threw: '+(e&&e.message||e); }
  })()`).catch(e=>'threw: '+e);
  chk('the restore runs without throwing', restored==='ok', restored);
  chk('maxes come back', EV('S.maxes && S.maxes.squat')===327, EV('JSON.stringify(S.maxes||null)'));
  chk('records come back', EV('(S.prs||[]).length')===1 && EV('S.prs[0].val')===235, EV('JSON.stringify(S.prs||[])'));
  chk('bodyweight comes back', EV('(S.weightLog||[]).length')===1 && EV('S.weightLog[0].w')===198, EV('JSON.stringify(S.weightLog||[])'));
  // notes are set AFTER banking on purpose: saveSessionLog stashes the day's notes into the
  // session log and clears the live field, so a note written before banking is correctly gone
  chk('a live note is carried by the backup', EV('S.notes')==='keep the bar over midfoot', EV('JSON.stringify(S.notes)'));
  await EV('refreshLogs()');
  chk('the banked SESSION comes back', Number(EV('logKeys.length'))===logKeyCount, EV('logKeys.length')+' vs '+logKeyCount);
  const rep=await EV(`(async function(){ var k=logKeys[0]; var v=await stGet(k); try{ return (JSON.parse(v).report||'').length; }catch(e){ return 0; } })()`);
  chk('and the restored session still holds its report', Number(rep)>20, rep+' chars');
  chk('it survives a reload (written to storage, not just memory)', EV(`(function(){ var k='nsc:'+(typeof curSKEY==='function'? curSKEY():SKEY); var j=JSON.parse(localStorage.getItem(k)||'{}'); return j.maxes && j.maxes.squat===327; })()`), 'memory only');
  // the undo path must exist and not be destructive
  chk('a rescue snapshot was taken before overwriting', EV(`(function(){ try{ return !!localStorage.getItem('nsc:'+((typeof curSKEY==='function'? curSKEY():SKEY)+'|rescue')); }catch(e){ return false; } })()`), 'no rescue key');
  // a junk file must be refused, not half-applied
  EV('S.maxes={squat:111}; save();');
  w.__bad='{"not":"a backup"}';
  await EV(`(async function(){ var f={ text:function(){ return Promise.resolve(window.__bad); } }; try{ await restoreBackup(f); }catch(e){} })()`);
  chk('a junk file leaves the card untouched', EV('S.maxes.squat')===111, EV('JSON.stringify(S.maxes)'));
  console.log('  problems: '+bad); process.exit(bad?1:0);
},1700);
