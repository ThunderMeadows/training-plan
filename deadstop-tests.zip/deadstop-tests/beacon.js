// THE COUNT STAYS ANONYMOUS, AND STAYS DISCLOSED (2026-09-04).
//
// The card now counts anonymous opens so he can tell whether anyone is using it. That is a
// reasonable thing to want and a dangerous thing to let drift. Two ways it could go wrong, and
// both are pinned here:
//
//   1. THE PAYLOAD GROWS. Today the beacon carries a public site token and nothing else. If a
//      future build ever appends an athlete id, a lift, a weight or a name to it, this fails.
//      The card's whole standing with the people using it rests on training data never leaving
//      the phone.
//   2. THE PROMISE GOES STALE. Terms section 4 used to read "there is no analytics or tracking in
//      this card". Installing the beacon made that sentence false, and it was corrected in the
//      same build. A card that counts opens while telling people it does not is worse than one
//      that does not count at all - so the disclosure is treated as part of the feature, and if
//      the beacon is ever removed the text has to change back.
const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const SRC=fs.readFileSync(f,'utf8');
let bad=0; const chk=(l,ok,d)=>{ if(!ok) bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&d?'  <-- '+d:''}`); };

console.log(`\n--- ${L}: the card counts opens, and says so ---`);

const tag=SRC.match(/<script[^>]*cloudflareinsights[^>]*><\/script>/);
const present=!!tag;
chk('(fixture) the analytics beacon is in the card', present, 'no beacon found - if it was removed on purpose, the Terms text below must change back too');

if(present){
  const t=tag[0];
  // the ONLY thing it may carry is the public site token
  const beacon=t.match(/data-cf-beacon='([^']*)'/);
  chk('the beacon carries a data-cf-beacon payload', !!beacon, t.slice(0,120));
  if(beacon){
    let obj=null; try{ obj=JSON.parse(beacon[1]); }catch(e){}
    chk('and that payload is valid JSON', !!obj, beacon[1].slice(0,80));
    if(obj){
      const keys=Object.keys(obj);
      chk('it carries the site token and nothing else', keys.length===1 && keys[0]==='token',
          'payload keys: '+keys.join(', ')+' - anything beyond the token is data leaving the phone');
      chk('and the token is a plain hex site id, not something derived from the athlete',
          /^[a-f0-9]{16,64}$/i.test(String(obj.token||'')), 'token looks like: '+String(obj.token).slice(0,24));
    }
  }
  // nothing about a person may be interpolated into the tag
  chk('the beacon is a static tag, not built from state at runtime',
      !/\+\s*S\.|\$\{|'\s*\+\s*[A-Za-z_]/.test(t), t.slice(0,160));
  chk('it loads from Cloudflare and nowhere else',
      /src=['"]https:\/\/static\.cloudflareinsights\.com\/beacon\.min\.js['"]/.test(t), t.slice(0,160));

  // and it must be DISCLOSED
  chk('Terms no longer claims the card has no analytics',
      SRC.indexOf('there is no analytics or tracking in this card')<0,
      'section 4 still says there is no analytics, which is now untrue');
  chk('Terms tells the athlete their opens are counted',
      /count how many times it is opened/.test(SRC), 'section 4 does not disclose the count');
  chk('and says the count carries no training data',
      /not a lift, not a weight, not a name/.test(SRC), 'section 4 does not say what the count excludes');
  chk('Cloudflare is listed among the services involved',
      /Cloudflare Web Analytics/.test(SRC.slice(SRC.indexOf('Other services involved'))),
      'section 6 does not name Cloudflare');
  chk('the promise that training data never leaves still stands',
      /no third party ever receives your training data/.test(SRC),
      'the core promise was dropped');
}

console.log('  problems:', bad); process.exit(bad?1:0);
