// DEAD-BUTTON SWEEP (2026-09-03, his ask: "there might be dead buttons all over the app and
// we aren't checking"). orphantest is static - a data-name that appears in any selector counts
// as bound - so it cannot see a wire function that never runs for a screen, an overlay whose
// controls were never wired, or a button bound by id that nothing renders.
// This is dynamic. Every addEventListener is recorded at parse time, so for every element on
// every screen the harness knows exactly what handles a tap: its own onclick, a listener on
// it, or a listener on an ancestor (not document/body/window - those are guards). A tappable
// with none of those is tapped for real, and only one that changes nothing is called dead.
//
// REBUILT 2026-09-03 (c183). The c181 original never existed as a file outside the session
// that wrote it; run.js has been calling a harness that was not in the repo, and the runner
// SKIPPED it silently and still printed ALL CHECKS PASSED. Rebuilt from the recovered source
// and the four lessons below, then broken on purpose before being trusted again.
//
// FOUR THINGS THAT MASKED DEAD BUTTONS IN THE FIRST VERSIONS. Each was found by unbinding a
// button on purpose and watching the sweep stay green. Do not "simplify" any of them away:
//   1. Roots are guards, not handlers. The day-lock tap guard on #app counted as a handler for
//      every child and the whole sweep went vacuous. Delegation from a real container counts;
//      delegation from a root does not.
//   2. State carries between taps. "Got it, hide this" worked on day A and read dead on day C
//      because it was already hidden. Every candidate tap restarts from the screen's setup.
//   3. A leftover toast counts as an effect. Clear it before the tap, not after.
//   4. Compare #app, not body. Bulk's idle animation rewrites body markup every tick, so a
//      dead button borrows his motion and looks alive. In c182 his host is #gbHost - the
//      c181 source said #gummyHost, which does not exist on this build, so this guard was
//      about to go quietly dead. Host ids are verified at boot below.
const { JSDOM } = require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const listeners=new WeakMap();
const dom=new JSDOM(fs.readFileSync(f,'utf8'),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/',
  beforeParse(win){
    const orig=win.EventTarget.prototype.addEventListener;
    win.EventTarget.prototype.addEventListener=function(t,fn,o){ try{ const s=listeners.get(this)||new Set(); s.add(t); listeners.set(this,s); }catch(e){} return orig.call(this,t,fn,o); };
    win.AudioContext=function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
    win.alert=()=>{}; win.confirm=()=>true;
  }});
const w=dom.window,D=w.document,EV=e=>w.eval(e);
const TAP=/\b(click|pointerdown|pointerup|touchstart|touchend|mousedown|mouseup|keydown|change|input)\b/;

// LESSON 1: roots carry guards, not handlers.
const ROOT=/^(app|setHost|coachHost|mailGate|termsGate|discGate|gbHost|gbZone|gbHelp|grunHost|toast|handlers)$/;
function handled(el){
  let n=el;
  while(n && n!==D.body && n!==D.documentElement){
    if(n!==el && ROOT.test(n.id||'')) return false;
    if(n.onclick||n.onpointerdown||n.onpointerup||n.ontouchstart||n.ontouchend||n.onmousedown||n.onchange||n.oninput||n.onkeydown) return true;
    const s=listeners.get(n); if(s && [...s].some(t=>TAP.test(t))) return true;
    if(n.tagName==='A' && n.getAttribute('href')) return true;
    if(n.tagName==='LABEL' && n.htmlFor) return true;
    if(n.tagName==='INPUT'||n.tagName==='TEXTAREA'||n.tagName==='SELECT'||n.tagName==='SUMMARY'||n.tagName==='DETAILS') return true;
    n=n.parentElement;
  }
  return false;
}

// What LOOKS tappable is what the card's own CSS gives a pointer cursor - read the rules, do
// not guess class names (the first cut missed #termsX because it knew no such class).
function pointerSelectors(){
  const out=[];
  try{ for(const sh of D.styleSheets){ let rules=[]; try{ rules=[...sh.cssRules]; }catch(e){}
    for(const r of rules){ if(r.selectorText && r.style && r.style.getPropertyValue('cursor')==='pointer') out.push(r.selectorText); } } }catch(e){}
  return out;
}
const POINTER=pointerSelectors();
const CTRL='[role="button"],button,[tabindex],a[href],.chip,.daybtn,.prof-edit,.savelog,.toggle,.tab,.onb-opt,.onb-day,.rc,.fc,.ana-chip,.rv-btn,.lockbar,.fold-h,.set,.setwadj,.hw-done,.hw-grip,.a2hs-done,.a2hs-later,.rpt-kind,.beta-tag,.cn-btn,.mail-open,.deckrow,.du-btn,.dayutil span[data-du],.prevbar [data-backlive],.rest-btn,.rbtn,.calc-key,.libsearch,.gal-day,.wv';
const DATTR='[data-thm],[data-day],[data-focus],[data-set],[data-addset],[data-subset],[data-howto],[data-gocal],[data-mailopen],[data-foldtog],[data-printwk],[data-sharelink],[data-betatag],[data-setclose],[data-rptclose],[data-rptkind],[data-anaview],[data-anasex],[data-onbnext],[data-onbback],[data-onbskip],[data-mxapply],[data-retest],[data-nextgo],[data-backlive],[data-repass],[data-resave],[data-galopen],[data-cnadd],[data-cndel],[data-tday],[data-icsdl],[data-adaptundo],[data-swap],[data-sub],[data-du]';
function tappables(root){
  const out=[]; const seen=new Set();
  const take=el=>{
    if(seen.has(el)) return; seen.add(el);
    if(el.closest('[hidden]')||el.hidden) return;
    if(el.classList.contains('lk')||el.classList.contains('fin')) return;   // deliberately inert
    out.push(el);
  };
  for(const sel of POINTER){ try{ root.querySelectorAll(sel).forEach(take); }catch(e){} }
  try{ root.querySelectorAll(CTRL+','+DATTR).forEach(take); }catch(e){}
  return out;
}
function key(el){ const d=[...el.attributes].filter(a=>/^data-/.test(a.name)).map(a=>a.name+(a.value&&a.value.length<14?'='+a.value:'')).join(' '); return (el.id?'#'+el.id+' ':'')+(d||('.'+String(el.className).split(/\s+/).filter(Boolean).slice(0,2).join('.')))+' "'+el.textContent.trim().slice(0,22).replace(/\s+/g,' ')+'"'; }

// LESSON 4: compare the APP, not the body.
const scope=()=>(D.getElementById('app')||D.body).innerHTML+'|'+[...D.querySelectorAll('body > *')].filter(x=>!ROOT.test(x.id||'')).map(x=>x.id||x.className).join(',');
// LESSON 3: a leftover toast counts as an effect. Clear before the tap.
const clearToast=()=>{ D.querySelectorAll('.toast.show,#toast.show').forEach(t=>t.classList.remove('show')); };

setTimeout(async()=>{
  console.log(`\n--- ${L}: dead-button sweep, every screen ---`);
  let bad=0; const chk=(l,ok,d)=>{ if(!ok) bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&d?'  <-- '+d:''}`); };
  EV('try{TOUR.live=false;}catch(e){} S.tour={done:true}; if(typeof ONB!=="undefined"){ONB().done=true;} S.discAck={v:DISC_V,d:localDate()}; storageOK=true; S.maxes={squat:327,bench:225,dead:405,ohp:145,row:170,pull:225}; save();');
  EV('var g=document.getElementById("discGate"); if(g) g.remove();');

  // LESSON 4, guard: if Bulk's host is not where this harness thinks it is, the motion filter
  // is dead and a dead button can borrow his animation. Fail loudly rather than sweep blind.
  const hostSeen=[...D.querySelectorAll('body > *')].map(x=>x.id).filter(Boolean);
  chk('the animated hosts this sweep filters out are the ones on the card',
      hostSeen.some(id=>ROOT.test(id)), 'body children are ['+hostSeen.join(', ')+'] and none is a known root');

  const codes=JSON.parse(EV('JSON.stringify(PLAN.days.map(function(d){return d.code;}))'));
  const screens=[];
  codes.forEach(c=>screens.push(['day '+c, `S.splitMode='open'; S.week=timeWeek(); S.rptOpen=false; SET_OPEN=false; settingsSync(); S.day=${JSON.stringify(c)}; render();`, '#app']));
  ['MAX','RATE','CAL','PLAN','LIB'].forEach(t=>screens.push(['tab '+t, `S.rptOpen=false; SET_OPEN=false; settingsSync(); S.day='${t}'; render();`, '#app']));
  screens.push(['day, whole-day view', `S.day=PLAN.days[0].code; S.viewAll=true; render();`, '#app']);
  screens.push(['settings sheet', `S.day=PLAN.days[0].code; S.viewAll=false; render(); SET_OPEN=true; settingsSync();`, '#setHost']);
  screens.push(['report panel', `SET_OPEN=false; settingsSync(); S.rptOpen=true; S.rptKind='bug'; render();`, '.rpt-wrap']);
  screens.push(['mail from Bulk', `S.rptOpen=false; render(); try{ mailShow(); }catch(e){}`, '#mailGate']);
  screens.push(['terms', `try{ termsShow(); }catch(e){}`, '#termsGate']);
  screens.push(['disclaimer', `try{ bootDisc(true); }catch(e){}`, '#discGate']);
  screens.push(['how-to sheet', `S.wnOpen=false; S.day=PLAN.days[0].code; howEx=PLAN.days[0].exercises[0].name; render();`, '.hw-wrap:not(.set-wrap)']);
  screens.push(['calendar tools', `S.day='CAL'; S.fold=S.fold||{}; S.fold.caltools=true; render();`, '#app']);
  screens.push(['plan, folds open', `S.day='PLAN'; foldOpenAll(); render();`, '#app']);

  const dead=[]; let total=0, opened=0;
  let SNAP=null;
  const snap=()=>{ try{ SNAP=EV('JSON.stringify(S)'); }catch(e){ SNAP=null; } };
  const reset=(setup,rootSel)=>{
    // restore state IN PLACE first - re-running setup only re-renders. Without this, a tap
    // that wrote to S stayed written and the next tap of the same handler was a no-op that
    // read as dead ("Run a check now" sets S.adhoc; setting it twice changes nothing).
    if(SNAP){ try{ EV('(function(o){ Object.keys(S).forEach(function(k){ delete S[k]; }); Object.assign(S,o); })('+SNAP+')'); }catch(e){} }
    try{ EV(setup); }catch(e){ return null; }
    return D.querySelector(rootSel);
  };
  const cleanup=()=>{
    try{ EV('S.wnOpen=false; S.rptOpen=false; SET_OPEN=false; settingsSync();'); }catch(e){}
    D.querySelectorAll('.terms-wrap,#termsGate,#discGate,#mailGate,.hw-wrap:not(.set-wrap),#repOv').forEach(x=>{ if(x.closest('#setHost')) return; x.remove(); });
    try{ EV('howEx=null;'); }catch(e){}
  };

  for(const [name,setup,rootSel] of screens){
    const root=reset(setup,rootSel);
    if(!root){ console.log('  (did not open: '+name+')'); cleanup(); continue; }
    opened++;
    snap();
    const els=tappables(root); total+=els.length;

    // Candidates: nothing bound on them or a non-root ancestor. Some are delegated from
    // document (a root, excluded on purpose) - so each candidate gets a REAL tap, and only one
    // that changes nothing (state, #app, an overlay, a fresh toast) is called dead.
    const cands=els.map((el,i)=>[el,i]).filter(([el])=>!handled(el));
    const d=[];
    for(const [el0,idx] of cands){
      if(/data-du=reset|wipe|erase|kill|restore/.test(key(el0))) continue;
      const k=key(el0);
      // LESSON 2: every candidate tap restarts from this screen's setup state.
      const r2=reset(setup,rootSel); if(!r2) continue;
      const el2=tappables(r2)[idx]; if(!el2 || key(el2)!==k) continue;
      clearToast();
      const before=EV('JSON.stringify(S)'), hb=scope(), ov=D.querySelectorAll('body > *').length;
      let threw=null; try{ el2.dispatchEvent(new w.MouseEvent('click',{bubbles:true})); }catch(e){ threw=e.message; }
      await new Promise(r=>setTimeout(r,30));
      const changed=(EV('JSON.stringify(S)')!==before)||(scope()!==hb)||(D.querySelectorAll('body > *').length!==ov)||!!D.querySelector('.toast.show,#toast.show');
      if(threw) d.push(k+' -> THREW '+threw); else if(!changed) d.push(k);
    }
    reset(setup,rootSel);

    // A handler that THROWS on a real tap is a dead button with extra steps. Sampled - the
    // handler map above is exhaustive, this pass is for runtime faults.
    const threwList=[];
    if(!/settings|report|mail|terms|disclaimer|how-to/.test(name)){
      const step=Math.max(1, Math.floor(els.length/10));
      for(let ei=0; ei<els.length; ei+=step){
        const el=els[ei]; if(!el || !handled(el)) continue;
        if(/data-du|data-setclose|data-rptclose|reset|wipe|erase|kill|restore|data-blk|data-onbskip|data-mxapply|data-retest|data-nextgo|data-day|data-focus|data-galopen|data-icsdl|data-sharelink|data-printwk|data-repass|data-resave|data-backlive|data-foldtog|data-addset|data-subset|data-set=|data-ex=|setwadj|data-anaview|data-anasex|libsearch|data-cnadd|data-cndel|data-tday|data-howto|howbtn|data-how\b/.test(key(el))) continue;
        const kk=key(el);
        const r3=reset(setup,rootSel); if(!r3) break;
        const el3=tappables(r3)[ei]; if(!el3) continue;
        try{ el3.dispatchEvent(new w.MouseEvent('click',{bubbles:true})); }catch(e){ threwList.push(kk+' -> '+e.message); }
      }
      reset(setup,rootSel);
    }

    if(d.length) dead.push([name, d]);
    if(threwList.length) dead.push([name+' (threw)', threwList]);
    console.log('  '+name.padEnd(22)+' '+String(els.length).padStart(4)+' tappable, '+(d.length? d.length+' DEAD':'all handled')+(threwList.length? ', '+threwList.length+' THREW':''));
    cleanup();
  }

  console.log('  screens opened:', opened+'/'+screens.length);
  console.log('  total tappables walked:', total);
  dead.forEach(([n,ks])=>{ console.log('  DEAD on '+n+':'); ks.slice(0,12).forEach(k=>console.log('     '+k)); if(ks.length>12) console.log('     ...and '+(ks.length-12)+' more'); });

  // A sweep that opened nothing, or walked nothing, must never read green.
  chk('every screen in the list actually opened', opened===screens.length, opened+' of '+screens.length+' opened');
  chk('the sweep found tappables to walk', total>200, 'only '+total+' walked - the selectors or the fixture are wrong');
  chk('the card styles its controls with a pointer cursor the sweep can learn from', POINTER.length>10, 'only '+POINTER.length+' pointer rules read');
  chk('no tappable element on any screen is without a handler', dead.length===0, dead.map(x=>x[0]+' ('+x[1].length+')').join('; '));
  console.log('  problems:', bad); process.exit(bad?1:0);
},1500);
