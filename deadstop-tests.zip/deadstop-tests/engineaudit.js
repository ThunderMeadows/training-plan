// ENGINE AUDIT 2026-09-10. "Make sure that the calibrations are accurate and functioning as they
// should. And that adaptations and weight increases or decreases are perfectly forming."
//
// Every scenario here drives the card the way a session does: sets go into S.data for the live
// day and the bank runs through saveSessionLog(), which is the one path that calls updateE1RM(),
// recordPerf(), recordHistory() and autoCalibrate(). Nothing pokes e1rmH or acLog directly -
// calibbaked did that, and it left one thing unproven: that logging real sets on the baked
// plan feeds the history at all. This closes that.
//
// Expected numbers are computed by hand beside each check so the harness can be read as an
// argument, not just a verdict.
const {JSDOM}=require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const raw=fs.readFileSync(f,'utf8');
const AC=function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
let bad=0;
const chk=(l,ok,d)=>{ if(ok!==true)bad++; if(typeof ok==='string'&&ok.slice(0,3)==='ERR') d=ok;
  console.log(`  ${ok===true?'ok  ':'FAIL'}  ${l}${ok!==true&&d?'  <-- '+d:''}`); };
const sleep=ms=>new Promise(r=>setTimeout(r,ms));

function boot(){
  const w=new JSDOM(raw,{runScripts:'dangerously',pretendToBeVisual:true,url:'https://thundermeadows.github.io/',
    beforeParse(win){ win.AudioContext=AC; }}).window;
  const E=e=>{ try{ return w.eval(e); }catch(err){ return 'ERR '+err.message; } };
  const A=async e=>{ try{ return await w.eval('(async()=>{'+e+'})()'); }catch(err){ return 'ERR '+err.message; } };
  return {w,E,A};
}
async function ready(c){
  await sleep(1900);
  c.E("for(var i=0,fs=['coachIdle','ONB_ACTIVE','isStartMode'];i<fs.length;i++){ try{ if(typeof window[fs[i]]==='function') window[fs[i]]=function(){return false;}; }catch(e){} }");
  c.E("try{ TOUR.live=false; }catch(e){} try{ S.tour={done:true}; }catch(e){}");
  c.E("S.access={role:'coach', until:'2027-12-31'}; S.genPlan=null; S.mode=null; S.profile=S.profile||{}; S.profile.goal='block1';");
  c.E("S.onb=S.onb||{}; S.onb.exp='some';");   // 0.87 factor - the middle case
  c.E("S.week=1; S.maxes=Object.assign({}, S.maxes||{}, {row:170, bench:210, squat:220, dead:250, ohp:105});");
  c.E("S.e1rmH={}; S.acLog=[]; S.adLog=[]; S.adLast=null; S.data={}; S.ready=null; save();");
}
// train one day: every set hit at weight w, prescribed reps, given rir, dated `date`, then bank
async function train(c, day, date, exIdx, w, rir, setsN, week){
  // Bank the session ON its own day. shiftDate() reads the real clock, so a back-dated key
  // banked "now" reads as a layoff gap the moment it lands (the layoff rule works since v232)
  // and the maxes ease before the thing under test even runs. Pin the clock for this bank.
  c.E(`window.__sd=window.__sd||shiftDate; shiftDate=function(){ return '${date}'; };`);
  c.E(`S.week=${week||1}; S.day='${day}'; S.when=S.when||{}; S.when.date='${date}';`);
  c.E(`(function(){ var d=dayObj(); var ex=d.exercises[${exIdx}]; var n=${setsN}||exSets(ex);
       var k=exKey(${exIdx}); S.data[k]={sets:[]};
       for(var i=0;i<n;i++) S.data[k].sets.push({st:'hit', w:${w}, rir:${rir}});
       save(); })()`);
  const r=await c.A("return await saveSessionLog(true);");
  c.E("shiftDate=window.__sd;");
  return r;
}
const daysAgo=(c,n)=>c.E(`(function(){var t=new Date(shiftDate()+'T12:00:00'); t.setDate(t.getDate()-${n}); return t.toISOString().slice(0,10);})()`);

(async()=>{
  console.log(`\n--- ${L}: engine audit, end to end ---`);

  // =====================================================================================
  // 1. CALIBRATION through the real bank. His case: baked plan, out-lifting the programme.
  // =====================================================================================
  console.log('\n[1] calibration feeds from logged sets on the baked plan');
  let c=boot(); await ready(c);
  chk('fixture: baked plan, no genPlan, Row max 170', c.E("!S.genPlan && S.maxes.row===170"), c.E("S.maxes.row"));
  const rowB=c.E("baseLoad(dayObj.call(null) && (S.day='B', dayObj()).exercises[0])");
  // day B week 1: .78333 x 170 = 133.2 -> plateRound -> 135
  chk('day B prescribes .78333 x 170 -> 135 before any evidence', rowB===135, 'got '+rowB);

  // four volume-day sessions at 155x8, 1 in reserve - well above the 115 the plan asked
  const dates=[14,7,0].map(n=>daysAgo(c,n));
  for(let i=0;i<dates.length;i++){ const r=await train(c,'E',dates[i],0,155,2,3,i+1); if(r!==true){ chk('bank accepted session '+dates[i], r===true, String(r)); } }
  c.E('S.week=1;');
  const hN=c.E("(S.e1rmH.row||[]).length");
  chk('three sessions banked into e1rmH.row through updateE1RM', hN>=3, 'history length '+hN);
  const hv=c.E("(S.e1rmH.row||[]).map(function(x){return Math.round(x.v);}).join(',')");
  // 155 x 8 at RIR 2 -> 208 on the card's chart. Allow the chart's own band.
  chk('each estimate sits where 155x8@2 should (200-215)', c.E("(S.e1rmH.row||[]).every(function(x){return x.v>=200&&x.v<=215;})"), 'values '+hv);
  const mx=c.E("S.maxes.row");
  // 208 x 0.87 = 181 -> 180; delta vs 170 = 5.9%, clears the 4% band, well under the 15% cap.
  // (At RIR 1 the same sets estimate 203 -> 175, only 2.9% up - INSIDE the band, no move. The
  // band is doing its job: one rep of reported effort is not enough evidence to move a max.)
  chk('Row max moved off 170', mx>170, 'still '+mx);
  chk('Row max landed at 0.87 x 208 = 180', mx===180, 'got '+mx);
  chk('and never past the 15% cap (195)', mx<=195, 'got '+mx);
  chk('calibration logged as undoable adLog:calib', c.E("(S.adLog||[]).some(function(a){return a.kind==='calib'&&a.lift==='row';})"), 'no calib entry');
  chk('and stamped in acLog for acMovedRecently()', c.E("acMovedRecently('row')===true"), 'acLog missing');
  const rowB2=c.E("(S.day='B', baseLoad(dayObj().exercises[0]))");
  const exp2=c.E(`plateRound(0.78333*${mx})`);
  chk('day B now prescribes .78333 x new max = '+exp2, rowB2===exp2, 'got '+rowB2);
  chk('so the heavy day moved UP with the evidence', rowB2>rowB, rowB+' -> '+rowB2);

  // =====================================================================================
  // 2. The 15% cap and the noise band, through the same path
  // =====================================================================================
  console.log('\n[2] calibration limits');
  c=boot(); await ready(c);
  // absurd evidence: 225x8@0 -> e1rm ~300+. Cap must hold at 170*1.15=195.5 -> 195.
  for(const [i,n] of [14,7,0].entries()) await train(c,'E',daysAgo(c,n),0,225,0,3,i+1);
  const capd=c.E("S.maxes.row");
  chk('a huge jump is held to the 15% cap (195)', capd===195, 'got '+capd);
  c=boot(); await ready(c);
  // evidence that agrees with 170: 170/0.87=195 e1rm -> 5 reps at RIR 2 ~ 81% -> 158 -> use 160x5@2
  for(const [i,n] of [14,7,0].entries()) await train(c,'B',daysAgo(c,n),0,160,2,4,i+1);
  const same=c.E("S.maxes.row");
  chk('evidence inside the 4% band leaves the max alone', same===170, 'moved to '+same);
  const two=boot(); await ready(two);
  for(const [i,n] of [7,0].entries()) await train(two,'E',daysAgo(two,n),0,155,1,3,i+1);
  chk('two sessions is not enough evidence', two.E("S.maxes.row")===170, 'moved on 2');

  // =====================================================================================
  // 3. ADAPTATION: stall, rate climb, the anti-double-move guard, layoff, deload
  // =====================================================================================
  console.log('\n[3] adaptation');
  // -- rate climb yields to calibration that just moved --
  c=boot(); await ready(c);
  for(const [i,n] of [14,7,0].entries()) await train(c,'E',daysAgo(c,n),0,155,2,3,i+1);
  c.E('S.week=1;');
  const afterCal=c.E("S.maxes.row");
  chk('fixture: calibration actually moved row this week', c.E("acMovedRecently('row')===true") && afterCal>170, 'row '+afterCal);
  const acts=c.E("JSON.stringify(adaptRun(true)||[])");
  const rateOnRow=c.E("(adLog=S.adLog||[]).some(function(a){return a.kind==='rate'&&a.lift==='row';})");
  chk('adaptRun does NOT rate-climb a lift calibration just moved (acMovedRecently)', rateOnRow===false, 'double move: '+acts);
  chk('the max is unchanged by that pass', c.E("S.maxes.row")===afterCal, afterCal+' -> '+c.E("S.maxes.row"));

  // -- stall: three sessions of struggle at the same load drops 8%, unless a weak link is found --
  c=boot(); await ready(c);
  c.E("S.acLog=[];");
  // missed reps at 140 on day B, three times. st:'miss' with reps below target, rir 0.
  for(const [i,n] of [14,7,0].entries()){
    const dd=daysAgo(c,n);
    c.E(`window.__sd=window.__sd||shiftDate; shiftDate=function(){ return '${dd}'; };`);
    c.E(`S.week=${i+1}; S.day='B'; S.when.date='${dd}';`);
    c.E("(function(){ var k=exKey(0); S.data[k]={sets:[]}; for(var i=0;i<4;i++) S.data[k].sets.push({st:'miss', w:140, reps:3, rir:0}); save(); })()");
    await c.A("return await saveSessionLog(true);");
    c.E("shiftDate=window.__sd;");
  }
  // The third bank ran the pass itself. What did one bank do with three bad sessions?
  const kinds=c.E("JSON.stringify((S.adLog||[]).filter(function(a){return a.lift==='row';}).map(function(a){return a.kind;}))");
  chk('three struggling sessions moved the row max', c.E("S.maxes.row")<170, 'still '+c.E("S.maxes.row"));
  chk('calibration cut it on their estimates (152 x .87 -> wants 130, capped at -15% = 145)', c.E("S.maxes.row")===145, 'got '+c.E("S.maxes.row")+' log '+kinds);
  chk('the stall rule did NOT cut it a second time for the same sessions', c.E("!(S.adLog||[]).some(function(a){return a.kind==='stall'&&a.lift==='row';})"), 'double cut: '+kinds);
  chk('one calib entry, undoable', c.E("(function(){var a=(S.adLog||[]).filter(function(x){return x.kind==='calib'&&x.lift==='row';}); return a.length===1 && adUndoable(a[0])===true;})()"), kinds);
  // and a week on, with the calibration window closed, the stall rule may act on fresh struggle
  c.E("S.acLog.forEach(function(e){ e.d='"+daysAgo(c,8)+"'; }); S.adLast='"+daysAgo(c,8)+"'; save();");
  chk('fixture: calibration window closed', c.E("acMovedRecently('row')===false"), 'still recent');
  const before=c.E("S.maxes.row");
  c.E("S.adWeakTried=true;");
  const sacts=c.E("JSON.stringify(adaptRun(true)||[])");
  chk('then the stall rule drops it by AD_STALL_DROP', c.E("S.maxes.row")===c.E(`Math.round(${before}*(1-AD_STALL_DROP)/5)*5`), before+' -> '+c.E("S.maxes.row")+' | '+sacts);
  chk('and that is logged as adLog:stall, undoable', c.E("(function(){var a=(S.adLog||[]).filter(function(x){return x.kind==='stall'&&x.lift==='row';}).pop(); return !!a && adUndoable(a)===true;})()"), sacts);

  // -- layoff: away long enough, every max eases back --
  c=boot(); await ready(c);
  await train(c,'E',daysAgo(c,30),0,155,1,3,1);
  const lay=c.E("JSON.stringify(adLayoff())");
  chk('30 days away is recognised as a layoff', c.E("!!adLayoff()"), lay);
  const b4={row:c.E("S.maxes.row"), bench:c.E("S.maxes.bench")};
  const expRow=c.E("(function(){var l=adLayoff(); return l? Math.round(S.maxes.row*(1-l.cut)/5)*5 : null;})()");
  const lacts=c.E("JSON.stringify(adaptRun(true)||[])");
  chk('layoff eases EVERY max down, not just one', c.E("S.maxes.row")<b4.row && c.E("S.maxes.bench")<b4.bench, JSON.stringify(b4)+' -> row '+c.E("S.maxes.row")+' bench '+c.E("S.maxes.bench")+' | '+lacts);
  chk('layoff cut matches adLayoffCut for those days', expRow===c.E("S.maxes.row"), 'expected '+expRow+' got '+c.E("S.maxes.row"));

  // -- deload week: loads fall to the plan's deload rung and updateE1RM banks nothing --
  c=boot(); await ready(c);
  c.E("S.week=6;");
  chk('week 6 is the deload', c.E("isDeload()===true"), 'isDeload false');
  const dl=c.E("(S.day='B', baseLoad(dayObj().exercises[0]))");
  // day B pct[5]=.45 x 170 = 76.5 -> 75
  chk('deload day B prescribes .45 x 170 -> 75', dl===75, 'got '+dl);
  await train(c,'B',daysAgo(c,1),0,75,2,2,6);
  chk('a deload session banks NO e1rm evidence', c.E("!(S.e1rmH.row&&S.e1rmH.row.length)"), 'banked '+c.E("(S.e1rmH.row||[]).length"));
  chk('and so cannot move the max', c.E("S.maxes.row")===170, 'moved to '+c.E("S.maxes.row"));

  // =====================================================================================
  // 4. READINESS scales every load
  // =====================================================================================
  console.log('\n[4] readiness');
  c=boot(); await ready(c);
  c.E("S.ready={date:shiftDate(), sleep:4, sore:5, stress:5};");   // score 0 -> RED -> 0.85
  const rm=c.E("readyMult()");
  chk('a red check-in gives the 0.85 multiplier', rm===0.85, 'got '+rm);
  const red=c.E("(S.day='B', baseLoad(dayObj().exercises[0]))");
  chk('and day B row is 135 x 0.85 -> plateRound', red===c.E("plateRound(135*0.85)"), 'got '+red);

  // =====================================================================================
  // 5. THE CUT GOAL on a generated plan, as his athlete runs it
  // =====================================================================================
  console.log('\n[5] cut goal, generated plan');
  c=boot(); await ready(c);
  c.E("S.profile.goal='cut';");
  const cutMain=c.E("(S.day='B', dayObj().exercises[0])");
  chk('cut mains: sets from GOALS.cut (3)', c.E("(S.day='B', exSets(dayObj().exercises[0]))")===3, 'got '+c.E("(S.day='B', exSets(dayObj().exercises[0]))"));
  chk('cut mains: reps from GOALS.cut (6)', c.E("(S.day='B', exReps(dayObj().exercises[0]))")==='6', 'got '+c.E("(S.day='B', exReps(dayObj().exercises[0]))"));
  chk('cut mains: rest from GOALS.cut (2:30)', c.E("(S.day='B', exRest(dayObj().exercises[0]))")==='2:30', 'got '+c.E("(S.day='B', exRest(dayObj().exercises[0]))"));
  const cutLoad=c.E("(S.day='B', baseLoad(dayObj().exercises[0]))");
  // week 1 cut pct .75 x 170 = 127.5 -> 125 or 130 by plateRound
  chk('cut week 1 load is .75 x 170 -> plateRound', cutLoad===c.E("plateRound(0.75*170)"), 'got '+cutLoad+' expected '+c.E("plateRound(0.75*170)"));
  c.E("S.profile.goal='hypertrophy';");
  const hypLoad=c.E("(S.day='B', baseLoad(dayObj().exercises[0]))");
  chk('cut is heavier on the bar than hypertrophy at the same max', cutLoad>hypLoad, 'cut '+cutLoad+' vs hyp '+hypLoad);

  console.log('\nproblems: '+bad);
  process.exit(bad?1:0);
})();
