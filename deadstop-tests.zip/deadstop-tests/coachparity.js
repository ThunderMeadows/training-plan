// COACHING PARITY (his ask 2026-09-02): an athlete programmed through the roster must get
// exactly the program they would get onboarding on their own card. Same answers in, same
// plan out - every movement, order, sets, reps, percentage, load, rest, warm-up, max.
const {JSDOM}=require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const d=new JSDOM(fs.readFileSync(f,'utf8'),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/'});
const w=d.window,EV=e=>w.eval(e);
w.AudioContext=function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
let bad=0; const chk=(l,ok,dd)=>{ if(!ok)bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&dd?'  <-- '+dd:''}`);};
const wait=ms=>new Promise(r=>setTimeout(r,ms));
// one athlete's answers - every field the generator reads, including a real calibration result
const ANSWERS=`(function(){ var o=ONB(); o.mode='full'; o.goal='build'; o.wt=185; o.exp='some'; o.sex='m'; o.days=4;
  o.emph='balanced'; o.weak='auto'; o.limits=[]; o.mins=null; o.wd=[1,2,4,5];
  o.prefs={}; o.res={squat:{pm:300}, bench:{pm:205}, dead:{pm:365}, ohp:{pm:125}, row:{pm:155}}; })();`;
// everything an athlete would actually be prescribed, week 1, every day
const FINGERPRINT=`(function(){ var out={maxes:S.maxes, days:[]};
  var keepDay=S.day, keepWeek=S.week; S.week=1;
  PLAN.days.forEach(function(dd){ S.day=dd.code; var d2=dayObj(); var rows=[];
    d2.exercises.forEach(function(ex,i){ if(isOut(ex.name)) return; var st=exState(i,ex);
      rows.push({n:ex.name, sets:st.sets.length, reps:String(exReps(ex)), load:curLoad(ex,st), rest:String(exRest(ex)||''),
        pct:ex.pct? ex.pct.slice():null, mk:ex.maxKey||null, wu:ex.warmup||'', rir:String(ex.rir||'')}); });
    out.days.push({code:dd.code, name:dd.name||dd.title||'', rows:rows}); });
  S.day=keepDay; S.week=keepWeek;
  return JSON.stringify(out); })()`;
setTimeout(async ()=>{
  console.log(`\n--- ${L}: an athlete gets the same program either way ---`);
  if(EV('typeof ROSTER')==='undefined'||EV('typeof ONB_build')==='undefined'){ console.log('  ok    (no coaching/generator on this card)\n  problems: 0'); process.exit(0); }
  EV('try{TOUR.live=false;}catch(e){} S.tour={done:true}; S.discAck={v:DISC_V,d:localDate()}; storageOK=true; save();');
  // A. the athlete on their OWN card (personal mode)
  EV('ROSTER.mode="solo"; ROSTER.active=null; S.onb=null; S.data={};');
  EV(ANSWERS); EV('ONB_build(); ONB().done=true; S.tour={done:true}; save(); render();');
  const A=EV(FINGERPRINT);
  // determinism first: the same answers twice on the same card must match, or nothing below means anything
  EV('S.onb=null; S.data={};'); EV(ANSWERS); EV('ONB_build(); ONB().done=true; save(); render();');
  const A2=EV(FINGERPRINT);
  chk('the generator is deterministic for the same answers', A===A2, 'the plan differs run to run on the SAME card');
  // B. the same athlete through the roster
  EV('ROSTER.mode="coach"; ROSTER.athletes=[]; ROSTER.active=null; save();');
  const id=EV('rosterAdd("Manuel")');
  EV('rosterSwitch("'+id+'");'); await wait(300);
  EV('S.onb=null; S.data={};'); EV(ANSWERS); EV('ONB_build(); ONB().done=true; S.tour={done:true}; save(); render();');
  const B=EV(FINGERPRINT);
  const pa=JSON.parse(A), pb=JSON.parse(B);
  chk('same number of training days', pa.days.length===pb.days.length, pa.days.length+' vs '+pb.days.length);
  chk('same maxes seeded from the calibration', JSON.stringify(pa.maxes)===JSON.stringify(pb.maxes), JSON.stringify(pa.maxes)+' vs '+JSON.stringify(pb.maxes));
  let diffs=[];
  pa.days.forEach((da,i)=>{ const db=pb.days[i]; if(!db){ diffs.push('day '+da.code+' missing'); return; }
    if(da.code!==db.code||da.name!==db.name) diffs.push('day '+i+': '+da.code+'/'+da.name+' vs '+db.code+'/'+db.name);
    if(da.rows.length!==db.rows.length){ diffs.push(da.code+': '+da.rows.length+' vs '+db.rows.length+' movements'); return; }
    da.rows.forEach((ra,j)=>{ const rb=db.rows[j];
      ['n','sets','reps','load','rest','mk','wu','rir'].forEach(k=>{ if(JSON.stringify(ra[k])!==JSON.stringify(rb[k])) diffs.push(da.code+' #'+(j+1)+' '+ra.n+' '+k+': '+JSON.stringify(ra[k])+' vs '+JSON.stringify(rb[k])); });
      if(JSON.stringify(ra.pct)!==JSON.stringify(rb.pct)) diffs.push(da.code+' #'+(j+1)+' '+ra.n+' pct differs'); }); });
  chk('every movement, in order, matches', !diffs.some(x=>/ n: |movements|missing|day \d/.test(x)), diffs.filter(x=>/ n: |movements|missing|day \d/.test(x)).slice(0,3).join(' | '));
  chk('every set count matches', !diffs.some(x=>/ sets: /.test(x)), diffs.filter(x=>/ sets: /.test(x)).slice(0,3).join(' | '));
  chk('every rep scheme matches', !diffs.some(x=>/ reps: /.test(x)), diffs.filter(x=>/ reps: /.test(x)).slice(0,3).join(' | '));
  chk('every load matches to the pound', !diffs.some(x=>/ load: /.test(x)), diffs.filter(x=>/ load: /.test(x)).slice(0,3).join(' | '));
  chk('every rest matches', !diffs.some(x=>/ rest: /.test(x)), diffs.filter(x=>/ rest: /.test(x)).slice(0,3).join(' | '));
  chk('every percentage scheme, max key, warm-up and RIR matches', !diffs.some(x=>/ (mk|wu|rir): |pct differs/.test(x)), diffs.filter(x=>/ (mk|wu|rir): |pct differs/.test(x)).slice(0,3).join(' | '));
  chk('the two programs are byte-identical', A===B, diffs.length+' differences');
  // a second profile, so this is not one lucky set of answers: strength goal, 3 days, female,
  // no calibration (fallback maxes), a movement preference set
  const ANS2=`(function(){ var o=ONB(); o.mode='full'; o.goal='strength'; o.wt=140; o.exp='vet'; o.sex='f'; o.days=3;
    o.emph='balanced'; o.weak='auto'; o.limits=[]; o.mins=60; o.wd=null; o.prefs={}; o.res={}; })();`;
  EV('rosterSwitch(null);'); await wait(300);
  EV('ROSTER.mode="solo"; ROSTER.active=null; S.onb=null; S.data={};'); EV(ANS2); EV('ONB_build(); ONB().done=true; save(); render();');
  const C=EV(FINGERPRINT);
  EV('ROSTER.mode="coach"; save();');
  const id2=EV('rosterAdd("Rosa")'); EV('rosterSwitch("'+id2+'");'); await wait(300);
  EV('S.onb=null; S.data={};'); EV(ANS2); EV('ONB_build(); ONB().done=true; save(); render();');
  const D=EV(FINGERPRINT);
  chk('a second, different profile is also byte-identical both ways', C===D, 'strength/3-day/female profile differs');
  // and the beginner Start path
  const ANS3=`(function(){ var o=ONB(); o.mode='start'; o.place='machines'; o.days=3; o.limits=[]; })();`;
  EV('rosterSwitch(null);'); await wait(300);
  EV('ROSTER.mode="solo"; ROSTER.active=null; S.onb=null; S.data={};'); EV(ANS3); EV('ONB_build(); ONB().done=true; save(); render();');
  const E=EV(FINGERPRINT);
  EV('ROSTER.mode="coach"; save();');
  const id3=EV('rosterAdd("Lee")'); EV('rosterSwitch("'+id3+'");'); await wait(300);
  EV('S.onb=null; S.data={};'); EV(ANS3); EV('ONB_build(); ONB().done=true; save(); render();');
  const F=EV(FINGERPRINT);
  if(E!==F){ const pe=JSON.parse(E), pf=JSON.parse(F);
    console.log('       maxes solo:', JSON.stringify(pe.maxes), ' roster:', JSON.stringify(pf.maxes));
    pe.days.forEach((da,i)=>{ const db=pf.days[i]||{rows:[]};
      da.rows.forEach((ra,j)=>{ const rb=db.rows[j]||{}; ['n','sets','reps','load','rest'].forEach(k=>{ if(JSON.stringify(ra[k])!==JSON.stringify(rb[k])) console.log('       '+da.code+' #'+(j+1)+' '+ra.n+' '+k+':', JSON.stringify(ra[k]), 'vs', JSON.stringify(rb[k])); }); }); }); }
  chk('the beginner Start path is byte-identical both ways', E===F, 'Start-mode plan differs');
  chk('and the three profiles really are different programs', A!==C && C!==E, 'profiles collapsed into one plan');
  // and the coach's own card was not rewritten by any of it
  EV('rosterSwitch(null);'); await wait(300);
  chk('the coach\'s own program is untouched by programming an athlete', EV('!ROSTER.active') && EV(FINGERPRINT)===E, 'coach program changed');
  console.log('  problems: '+bad); process.exit(bad?1:0);
},1700);
