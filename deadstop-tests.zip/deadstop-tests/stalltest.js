// FIELD 2026-09-02: "three sessions without progress" fired on bench and OHP for an athlete
// who was adding weight every week. A rising-percentage block (70x8 -> 75x6 -> 80x5) estimates
// the SAME max every session by design, so the flat-estimate rule read compliance as a stall
// and cut two training maxes 8%. A stall now needs struggle.
const {JSDOM}=require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const d=new JSDOM(fs.readFileSync(f,'utf8'),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/'});
const w=d.window,EV=e=>w.eval(e);
w.AudioContext=function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
let bad=0; const chk=(l,ok,dd)=>{ if(!ok)bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&dd?'  <-- '+dd:''}`);};
// run one session of the bench-keyed main lift with given reps-vs-target and RIR, then bank the estimate
function session(date, repsDelta, rir){
  EV(`(function(){ S.when={date:'${date}',time:'10:00'}; var dd=dayObj();
    dd.exercises.forEach(function(ex,i){ if(ex.maxKey!=='bench') return; var st=exState(i,ex); var tgt=defReps(ex);
      st.sets.forEach(function(s2){ if(${repsDelta}>=0){ s2.st='hit'; s2.reps=null; } else { s2.st='adj'; s2.reps=tgt+(${repsDelta}); } s2.rir=${rir}; }); });
    save(); updateE1RM(); })();`);
}
setTimeout(()=>{
  console.log(`\n--- ${L}: a stall needs struggle ---`);
  EV('try{TOUR.live=false;}catch(e){} S.tour={done:true}; if(typeof ONB!=="undefined"){ONB().done=true;} S.discAck={v:DISC_V,d:localDate()}; storageOK=true; S.maxes={squat:327,bench:225,dead:405,ohp:145,row:170,pull:225}; S.e1rmH={}; S.adLog=[]; S.adLast=null; save();');
  // find a day that carries the bench main, park on it, week 1
  EV(`(function(){ for(var i=0;i<PLAN.days.length;i++){ if(PLAN.days[i].exercises.some(function(e){return e.maxKey==='bench';})){ S.day=PLAN.days[i].code; break; } } S.week=1; save(); render(); })();`);
  chk('the day carries a bench-keyed main', EV('dayObj().exercises.some(function(e){return e.maxKey==="bench";})'), 'no bench main');
  // FOUR CLEAN SESSIONS as prescribed: rising %, target reps hit, RIR 2 - the flat line by design
  ['2026-08-05','2026-08-12','2026-08-19','2026-08-26'].forEach((dt,i)=>{ EV('S.week='+(i+1)+'; S.data={};'); session(dt, 0, 2); });
  const pts=JSON.parse(EV('JSON.stringify((S.e1rmH.bench||[]).map(function(x){return {v:Math.round(x.v),c:x.c};}))'));
  chk('four estimate points were banked', pts.length===4, JSON.stringify(pts));
  chk('every clean session is flagged clean', pts.every(p=>p.c===1), JSON.stringify(pts));
  const before=EV('S.maxes.bench');
  const st=JSON.parse(EV('JSON.stringify(adStalled())'));
  chk('doing the work as written is NOT a stall', !st.some(x=>x.lift==='bench'), JSON.stringify(st));
  EV('S.when={date:shiftDate(),time:"10:00"}; adaptRun(true);');
  chk('and the training max is never CUT (it may climb - that is the moving-lift rule)', EV('S.maxes.bench')>=before, before+' -> '+EV('S.maxes.bench'));
  // NOW real struggle: two of the last three sessions miss reps
  EV('S.e1rmH={}; S.adLog=[]; S.adLast=null; S.maxes.bench=225; save();');
  EV('S.week=1; S.data={};'); session('2026-08-05', 0, 2);
  EV('S.week=2; S.data={};'); session('2026-08-12', -2, 0);
  EV('S.week=3; S.data={};'); session('2026-08-19', 0, 2);
  EV('S.week=4; S.data={};'); session('2026-08-26', -3, 0);
  const pts2=JSON.parse(EV('JSON.stringify((S.e1rmH.bench||[]).map(function(x){return x.c;}))'));
  chk('missed reps and RIR 0 are flagged as struggle', pts2.filter(c=>c===0).length===2, JSON.stringify(pts2));
  // the stall verdict itself is checked on a seeded flat line so it does not depend on the
  // plan's percentages: two of three struggled, estimate not rising -> stall
  EV('S.e1rmH={bench:[{d:"2026-08-05",v:281,c:1,n:5},{d:"2026-08-12",v:275,c:0,n:5},{d:"2026-08-19",v:278,c:1,n:5},{d:"2026-08-26",v:274,c:0,n:5}]}; S.adLog=[];');
  // n:5 - c207 judges only points sharing a rep target, so a hand-built history has to say
  // which kind of session each point came from or the card rightly refuses to judge it at all.
  const st2=JSON.parse(EV('JSON.stringify(adStalled())'));
  chk('two struggling sessions in three IS a stall', st2.some(x=>x.lift==='bench'), JSON.stringify(st2));
  // HIS EXACT SHAPE: clean sessions whose estimate is flat-to-falling (rising %, falling reps,
  // plate rounding) - the old rule cut the max here; the new one must not
  EV('S.e1rmH={bench:[{d:"2026-08-05",v:281,c:1,n:5},{d:"2026-08-12",v:280,c:1,n:5},{d:"2026-08-19",v:280,c:1,n:5},{d:"2026-08-26",v:279,c:1,n:5}]}; S.adLog=[];');
  chk('a flat-to-falling estimate from CLEAN sessions is not a stall (his field case)', !JSON.parse(EV('JSON.stringify(adStalled())')).some(x=>x.lift==='bench'), 'reset a compliant lifter');
  // legacy points with no flag never trigger a reset on their own
  EV('S.e1rmH={bench:[{d:"2026-08-05",v:280},{d:"2026-08-12",v:279},{d:"2026-08-19",v:278}]}; S.adLog=[];');
  chk('history recorded before this rule cannot stall a lift (no evidence, no reset)', !JSON.parse(EV('JSON.stringify(adStalled())')).some(x=>x.lift==='bench'), 'legacy points reset the lift');
  console.log('  problems: '+bad); process.exit(bad?1:0);
},1700);
