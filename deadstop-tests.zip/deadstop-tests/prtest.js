// A record must describe what was LIFTED. Field-caught: a record read 70 lb against a
// prescription of 60 because history logged the exercise setting, not the sets.
const { JSDOM } = require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const dom=new JSDOM(fs.readFileSync(f,'utf8'),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/'});
const w=dom.window,EV=e=>w.eval(e);
w.AudioContext=w.AudioContext||function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
setTimeout(()=>{
  console.log(`\n--- ${L}: personal records ---`);
  let bad=0; const chk=(l,ok,d)=>{ if(!ok) bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&d?'  <-- '+d:''}`); };
  EV('try{TOUR.live=false;}catch(e){} try{S.tour={done:true};}catch(e){}');
  for(const fn of ['coachIdle','ONB_ACTIVE','isStartMode']) EV(`if(typeof ${fn}==="function") ${fn}=function(){return false;};`);
  EV('S.maxes={squat:327,bench:225,dead:405,ohp:145,pull:225}; render();');
  const i=EV(`(function(){var d=dayObj();for(var k=0;k<d.exercises.length;k++){if(d.exercises[k].loadNum!=null) return k;}return -1;})()`);
  const nm=EV(`(function(){var ex=dayObj().exercises[${i}],st=exState(${i},ex); return st.sub||ex.name;})()`);
  const plan=EV(`baseLoad(dayObj().exercises[${i}])`);
  console.log(`  ${nm}: prescribed ${plan}`);

  // a prior session, so today can beat it
  EV(`S.exHist={}; S.prs=[]; histPush(${JSON.stringify(nm)},{d:'2026-08-01',w:${plan},sets:[8,8,8],e1:${plan}});`);

  // today: three sets, the last two done heavier than prescribed via per-set weights
  EV(`(function(){var ex=dayObj().exercises[${i}],st=exState(${i},ex);
      st.sets.forEach(function(s){ s.st='pend'; delete s.w; });
      [0,1,2].forEach(function(j){ if(!st.sets[j]) return;
        st.sets[j].st='hit'; st.sets[j].reps=8;
        st.sets[j].w = (j===0? ${plan} : ${plan}+10); });
      S.when={date:'2026-08-29',time:''}; save(); return 1;})()`);
  const prs=JSON.parse(EV('JSON.stringify(recordHistory())'));
  const wPR=prs.filter(p=>p.kind==='weight')[0];
  console.log('  records found:', prs.map(p=>p.kind+' '+p.val).join(', ')||'none');
  chk('a weight record was found', !!wPR);
  if(wPR) chk('it reports the heaviest set actually done', wPR.val===plan+10,
    `reported ${wPR.val}, sets were ${plan} and ${plan+10}`);

  // volume must use each set's own weight, not one weight for all three
  const rec=JSON.parse(EV(`JSON.stringify(histFor(${JSON.stringify(nm)}).slice(-1)[0])`));
  // a set marked hit takes the exercise's target reps, not whatever the harness wrote
  const tgt=EV(`defReps(dayObj().exercises[${i}])`);
  const want=(plan*tgt)+((plan+10)*tgt)+((plan+10)*tgt);
  chk('volume adds each set at its own weight', EV(`histVolume(${JSON.stringify(rec)})`)===want,
    `got ${EV(`histVolume(${JSON.stringify(rec)})`)}, wanted ${want}`);
  chk('per-set weights are stored', Array.isArray(rec.ws) && rec.ws.length===3, JSON.stringify(rec.ws));

  // and older records with no per-set weights must still work
  chk('old records still compute', EV(`histVolume({sets:[8,8],w:100})`)===1600);
  console.log('  problems:', bad);
  process.exit(bad?1:0);
},1500);
