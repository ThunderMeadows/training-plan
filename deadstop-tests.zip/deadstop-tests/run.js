#!/usr/bin/env node
// Deadstop test suite runner.
//   node run.js <card.html> [<card.html> ...]   fast suite (default)
//   node run.js                                 auto-discovers index.html one level up
//   node run.js --predeploy <card.html>         the slow tier only (deadsweep)
//   node run.js --all <card.html>               fast suite + slow tier
//   node run.js -j 6 <card.html>                override how many harnesses run at once
// Exit code 0 = every check passed. Non-zero = the number of failing checks.
//
// WHY THIS IS PARALLEL (2026-09-03). Every harness is its own node process and 64 of them
// open with a fixed 1.4-1.7s boot wait before touching the card - about 100 seconds a card of
// nothing but waiting. The box has ONE cpu, so this does not buy throughput; it buys
// overlapping those waits. Raising -j much past 6 stops helping and starts costing, because
// from there it is real jsdom parse work competing for the one core.
//
// WHY MISSING IS FATAL (2026-09-03). The old runner did:
//     if (!fs.existsSync(file)) { console.log('SKIP (missing)'); continue; }
// with no counter bump, so a declared harness that was not on disk printed one SKIP line and
// the run still ended "ALL CHECKS PASSED", exit 0. deadsweep was declared in c181 and never
// committed; builds shipped green against a suite that was not running it. A harness this
// file declares and cannot find is now a hard failure, and so is a duplicate declaration.
const { spawn } = require('child_process');
const fs = require('fs'), path = require('path');

// [name, what it proves, slow?] - slow harnesses are the pre-deploy tier, not the fast suite.
const HARNESSES = [
  ['smoke',      'every screen renders, no runtime errors'],
  ['leaktext',   'no screen ever shows the athlete a leaked value - undefined, NaN, null, [object Object] - and setup headings match setup steps'],
  ['clickaudit', 'every settings control: state, highlight, sheet survives, effect applies'],
  ['themetest',  'every theme reads in both lights; Auto follows the phone and never guesses'],
  ['seasontest', 'holiday colour is a tone layer over the theme - right days only, never the go/stop colours, clears every contrast floor, switchable off, and the splash art slot draws only when there is art'],
  ['flushtest',  'applying a flavour forces the repaint flush'],
  ['interp',     'all flavour switches are interpolable'],
  ['spotchange', 'the bear changes on the spot, never a removed filter'],
  ['shadowtest', 'tint and drop shadow coexist'],
  ['persist',    'the saved bear survives a reload'],
  ['anchortest', 'no movement is prescribed a floor weight it calls an estimate'],
  ['resttest',   'an accidental +30s can be taken back, never below prescribed'],
  ['grindtest',  'a grind changes the next prescription as specified'],
  ['sheetcheck', 'the gear opens the sheet; no duplicate inline controls'],
  ['presctest',  "the rest screen adjusts the set performed, never the day's prescription"],
  ['adjusttest', 'the weight badge adjusts without logging; a mistapped log can be undone'],
  ['goaltest',   'all six training goals are offered and resolve to distinct schemes'],
  ['sharetest',  'the share sheet never draws one string over another and the QR buries nothing'],
  ['footglue',   'fixed bottom bars follow the visible viewport, not the layout viewport'],
  ['sesslen',    'the session-length target grows days in the declared order and never trims'],
  ['dupemuscle', 'a fill covers what the day is missing - it never adds a second movement for a muscle already trained'],
  ['stimprofile','the engine knows what KIND of work a movement is - stretched vs mid-range vs shortened, anti-extension vs dynamic flexion - and prefers variety without rewriting the program'],
  ['medneutral', 'the card never asks what hurts and never adapts training to an injury claim'],
  ['bootorder',  'the disclaimer is acknowledged first; install sheet and tour wait, then run'],
  ['terms',      'terms & privacy opens from the gate and settings, reads clean, writes nothing'],
  ['beacon',     'the open-count carries the site token and nothing else - no athlete, no lift - and Terms says plainly that opens are counted'],
  ['retest',     'assessments rerun in place - plan, logs and history stay untouched'],
  ['rowmax',     'the horizontal pull is assessed and programmed like every other main lift'],
  ['assessed',   'every max the card assesses is a max it programs - in the starter block and every generated split - and it reaches The road ahead'],
  ['caltest',    'block calendar, countdowns, ics export and streak guard run off real facts only'],
  ['caldays',    'a real banked log key parses back into a calendar day - every namespace - and the splash keeps the mark alone in its flex row'],
  ['mailtest',   'mail from Bulk: generated from card facts, idempotent, badged, honest about no server'],
  ['joketest',   "Bulk's joke book: big enough to last, fixed for the day, nearly all new across two months, never twice running, and never a punchline on a letter that is bad news"],
  ['releasetest','Bulk announces each release once to returning athletes; new athletes get nothing; the sheet never pops'],
  ['coexist',    'two cards on one origin never read or erase each other; overlays survive the day-lock'],
  ['banktest',   'a session banks end to end: saved, reported, locked, no errors anywhere on the path'],
  ['phantomtest','removing a movement persists, and no phantom function calls remain'],
  ['setflow',    'adding a set actually sticks - through re-render, reload, and the minus button'],
  ['wrapflow',   'a day finishes when the movements you actually train are done, not the ones removed'],
  ['rosterflow', 'coaching works on a banked day: athlete cards open and switch namespaces'],
  ['reachtest',  'nothing lands off-screen on a short viewport or a large system font'],
  ['calcfixed',  'the calculator button is fixed and out of the way - no drag, and nothing listening to the whole screen for a finger'],
  ['lockaudit',  'on a banked day, only session-editing controls are dead - no guard omissions'],
  ['overlaylock','every overlay - mail, terms, the disclaimer, settings - stays usable while the day is locked or previewed, and the session itself stays read-only'],
  ['hdrlive',    'settings, mail and the tour replay stay reachable in every lock state - the way out is never locked'],
  ['restoreflow','back up, lose everything, restore - history actually comes back'],
  ['crossrestore','a Session Card backup restored here lands on the card with its logs, not on setup'],
  ['blockroll',  'rolling into the next block keeps every max sane and resets the clock'],
  ['adundo',     'any change the card made to a max can be put back on its own, not just the most recent pass'],
  ['maxapply',   "a hand-set programming max is the athlete's - no suggestion overwrites it, and the steppers save on tap"],
  ['provmax',    'a tested 1RM is trusted on entry, held steady while it is judged, and walks down to a proven floor if it does not hold'],
  ['orphantest', 'every rendered control has a binding - no dead buttons'],
  ['deadref',    'nothing refers to something that is not there - every movement name, muscle key and selector target still resolves'],
  ['staleflow',  'when another copy saved after this one, both exits work and saves resume'],
  ['statefuzz',  'the card boots, renders and saves against mangled or legacy stored state'],
  ['newstate',   'every state field added in c183-c190 survives every screen, a mangled boot, and the real backup/restore path'],
  ['prflow',     'a record set at banking always earns the prompt, even after an earlier dismiss'],
  ['gallerytest','past wrap-ups reopen and share the right day; the live share is untouched'],
  ['sheettest2', 'the print sheet is the card: same movements, sets, reps, loads, rest, finisher'],
  ['athleteflow','coaching end to end: bank as an athlete, switch, coach intact, remove keeps history'],
  ['coachparity','an athlete programmed through the roster gets the identical program to their own card'],
  ['viztest',    'every graph and diagram encodes its data - plates, volume, history, sparks, waves - own card and coached'],
  ['foldtest',   'secondary sections fold, remember their state, cost nothing closed, never hide a jump target'],
  ['stalltest',  'a stall needs struggle - doing a rising-percentage block as written never resets a max'],
  ['adfixtest',  'cuts the old stall rule made are put back, and earned ones are not'],
  ['stallmix',   'a stall is decline in the SAME kind of session - a heavy day is never measured against a volume day - and the put-back pass is versioned so a better one can still run'],
  ['progaudit',  'every automatic writer to a weight: a deload never re-bases the accessories, a failing trial only ever steps down, a trend compares one rep target, calibration and the rate pass never both spend the same evidence, and anything the card changes can be put back'],
  ['rhythmtest', 'Open lets the athlete pick any session this week; Guided, the week and the locks are untouched'],
  ['audit',      'end to end: legacy state loads, every theme taps, Open jumps/banks/repeats through the real paths, setup carries rhythm'],
  ['besttest',   'best logged informs without provoking; silent in a deload'],
  ['prtest',     'records report the weight actually lifted, per set'],
  ['prdupe',     'a record is filed once per day per lift; re-banking replaces, a correction retires'],
  ['histtest',   'a logged set keeps the weight it was done at, whatever changes after'],
  ['anchorday',  'a session in progress keeps its loads when a max moves mid-day; + set matches the sets done'],
  ['holdfmt',    'hold times read as m:ss past a minute on the chip and in the report; storage stays seconds'],
  ['kgplates',   'every kg weight the athlete is asked to lift is a number a plate makes - no long decimals, on the 2.5 kg grid - and storage stays in pounds underneath'],
  ['restguard',  'a running rest survives a stray tap; no prompt once the rest is over'],
  ['restlast',   'after the last set of an exercise the rest screen is a Done state - no countdown, no beeps, no scolding on the next exercise; a superset partner still gets its rest'],
  ['zonetest',   'the drop zone matches the real release test and never outlives the drag'],
  ['recaptest',  'the finish prompt shares the session and returns after cardio or an extra lift'],
  ['manifesttest','the page links a valid manifest so Android can offer Install'],
  ['buildsync',  "the service worker cache carries this build, so an update actually reaches a phone instead of serving the old copy"],
  ['a2hstest',   'install guidance matches the device - no Safari steps on Android'],
  ['setbtns',    'every settings button works and what it opens lands above the sheet'],
  ['setlaunch',  'every launcher in settings, by real click: lands above the sheet, or closes it first'],
  ['reportsend', 'the report actually leaves the phone from a home-screen app - link handoff not location assignment, clipboard fallback, and every button answers where it can be seen'],
  ['selftest',   'the phone check is read-only, namespaced, and stands down mid-session'],
  ['gametest',   'Bulk Run is summoned only, contained, and dies with the rest'],
  ['eyetest',    "the bear's eyes glow and are not dimmed with his body"],
  ['gotest',     'every help shortcut opens the right screen and lands on a real element'],
  ['helptest',   "Gummy's help card opens when he is posed, and leaves with him"],
  ['safetytest', 'a restore can be undone, leaves a rescue copy, and cannot break the state shape'],
  ['emptybank',  'a day nobody trained cannot be filed - not by the athlete, not by a coach - and deleting a log opens its day back up'],
  ['hostileboot','the card boots on hostile saved state - garbage, wrong types, half-built plans - and a broken plan costs the athlete nothing'],
  // --- pre-deploy tier: minutes, not seconds. Run before an upload, not on every pass. ---
  ['deadsweep',  'every tappable on every screen, by real tap: has a handler, does something, does not throw', true],
  ['inert',      'every BOUND control, pressed for real in a home-screen app: does something observable, or it is a dead button', true],
];

const argv = process.argv.slice(2);
let mode = 'fast', jobs = +(process.env.JOBS || 0) || 4, cards = [];
for (let i = 0; i < argv.length; i++) {
  const a = argv[i];
  if (a === '--predeploy' || a === '--slow') mode = 'slow';
  else if (a === '--all') mode = 'all';
  else if (a === '-j' || a === '--jobs') jobs = +argv[++i] || jobs;
  else if (a.startsWith('-')) { console.error('Unknown option ' + a); process.exit(2); }
  else cards.push(a);
}
if (jobs < 1) jobs = 1;

// ---- manifest integrity, checked before any card work ----------------------
// A suite you cannot trust the shape of is worse than no suite, so these are fatal.
let manifestBad = 0;
const seen = new Set();
for (const [name] of HARNESSES) {
  if (seen.has(name)) { console.error(`MANIFEST  '${name}' is declared more than once`); manifestBad++; }
  seen.add(name);
}
const absent = HARNESSES.filter(([n]) => !fs.existsSync(path.join(__dirname, n + '.js'))).map(([n]) => n);
for (const n of absent) console.error(`MANIFEST  '${n}' is declared here but ${n}.js is not in ${__dirname}`);
manifestBad += absent.length;
if (manifestBad) {
  console.error(`\n${manifestBad} MANIFEST PROBLEM(S) — the suite is not what it says it is. Do not deploy.\n`);
  process.exit(manifestBad);
}

if (!cards.length) {
  const up = path.resolve(__dirname, '..');
  cards = fs.readdirSync(up, { withFileTypes: true })
    .filter(d => d.isDirectory())
    .map(d => path.join(up, d.name, 'index.html'))
    .filter(p => fs.existsSync(p));
  const flat = path.join(up, 'index.html');
  if (fs.existsSync(flat)) cards.push(flat);
}
if (!cards.length) {
  console.error('No cards found. Pass paths: node run.js ../training/index.html');
  process.exit(2);
}

const picked = HARNESSES.filter(([, , slow]) =>
  mode === 'all' ? true : mode === 'slow' ? !!slow : !slow);

function runOne(name, card, build) {
  return new Promise(resolve => {
    const file = path.join(__dirname, name + '.js');
    const started = Date.now();
    const p = spawn('node', [file, card, build]);
    let out = '', killed = false;
    const timer = setTimeout(() => { killed = true; p.kill('SIGKILL'); }, 600000);
    p.stdout.on('data', d => { out += d; });
    p.stderr.on('data', d => { out += d; });
    p.on('error', e => {
      clearTimeout(timer);
      resolve({ name, ok: false, n: 1, out: 'could not start: ' + e.message, secs: 0 });
    });
    p.on('close', status => {
      clearTimeout(timer);
      // Same accounting the serial runner used, so results stay comparable build to build.
      const m = out.match(/problems:\s*(\d+)/);
      const n = m ? +m[1] : (status === 0 ? 0 : 1);
      const ok = !killed && status === 0 && n === 0;
      resolve({
        name, ok, n: ok ? 0 : Math.max(n, 1),
        out: killed ? out + '\n  TIMED OUT after 600s' : out,
        secs: (Date.now() - started) / 1000
      });
    });
  });
}

// Results arrive out of order; they are held and flushed in manifest order so two runs of the
// same build read identically and a diff between builds means something.
async function runCard(card, build, list) {
  const results = new Array(list.length);
  let next = 0, flush = 0, failures = 0;

  const emit = () => {
    while (flush < list.length && results[flush]) {
      const r = results[flush], what = list[flush][1];
      console.log(`  ${r.ok ? 'PASS' : 'FAIL'}  ${r.name.padEnd(12)} ${r.secs.toFixed(0).padStart(3)}s  ${what}`);
      if (!r.ok) {
        const detail = r.out.split('\n').filter(l =>
          /MISMATCH|BAD |LOST|STALE|CLOSED|NO CHANGE|THREW|want |problems:|PROBLEM|NOT LIT|TIMED OUT|Error/.test(l)
        ).map(l => '        ' + l.trim()).join('\n');
        console.log(detail || '        (no detail — run it directly)');
      }
      flush++;
    }
  };

  const worker = async () => {
    while (next < list.length) {
      const i = next++;
      const r = await runOne(list[i][0], card, build);
      results[i] = r;
      if (!r.ok) failures += r.n;
      emit();
    }
  };
  await Promise.all(Array.from({ length: Math.min(jobs, list.length) }, worker));
  emit();
  return failures;
}

(async () => {
  const wall = Date.now();
  let failures = 0;
  const tier = mode === 'slow' ? 'PRE-DEPLOY TIER' : mode === 'all' ? 'FULL SUITE' : 'FAST SUITE';
  console.log(`${tier} — ${picked.length} harnesses, ${jobs} at a time, ${cards.length} card(s)`);
  for (const card of cards) {
    let build = '?';
    try {
      const m = fs.readFileSync(card, 'utf8').match(/const BUILD = '([^']+)'/);
      if (m) build = m[1];
    } catch (e) {}
    console.log(`\n${'='.repeat(64)}\n${card}   BUILD ${build}\n${'='.repeat(64)}`);
    failures += await runCard(card, build, picked);
  }
  const secs = ((Date.now() - wall) / 1000).toFixed(0);
  console.log(`\n${failures ? failures + ' FAILING CHECK(S) — do not deploy' : 'ALL CHECKS PASSED'}   (${secs}s wall)\n`);
  if (mode === 'fast') console.log('Fast suite only. Run `node run.js --predeploy <card>` before an upload.\n');
  process.exit(failures ? 1 : 0);
})();
