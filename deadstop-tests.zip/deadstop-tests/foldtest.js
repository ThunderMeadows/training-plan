// FOLDS (2026-09-02): secondary sections collapse and expand, remember their state, cost
// nothing when closed, survive a banked day, and never hide a help/tour target for good.
const {JSDOM}=require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const d=new JSDOM(fs.readFileSync(f,'utf8'),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/'});
const w=d.window,EV=e=>w.eval(e);
w.AudioContext=function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
let bad=0; const chk=(l,ok,dd)=>{ if(!ok)bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&dd?'  <-- '+dd:''}`);};
setTimeout(()=>{
  console.log(`\n--- ${L}: folds ---`);
  EV('try{TOUR.live=false;}catch(e){} S.tour={done:true}; if(typeof ONB!=="undefined"){ONB().done=true;} S.discAck={v:DISC_V,d:localDate()}; storageOK=true; S.maxes={squat:327,bench:225,dead:405,ohp:145,row:170,pull:225}; delete S.fold; save();');
  // seed enough history that the history and gallery sections exist
  const nm=EV('PLAN.days[0].exercises[0].name');
  EV(`histPush(${JSON.stringify(nm)}, {d:'2026-08-20', w:200, sets:[5,5,5], ws:[200,200,200], e1:233}); save();`);
  EV('S.day="PLAN"; render();');
  const app=()=>EV('document.getElementById("app").innerHTML');
  chk('the PLAN tab renders folds', (app().match(/data-foldtog=/g)||[]).length>=4, (app().match(/data-foldtog=/g)||[]).length+' folds');
  chk('history starts closed and renders NO body', EV('!!document.querySelector("[data-fold=hist]")') && EV('!document.querySelector("[data-fold=hist] .fold-b")'), 'history body rendered while closed');
  chk('weekly work starts open', EV('!!document.querySelector("[data-fold=vol] .fold-b")'), 'closed by default');
  chk('the routine itself is NOT a fold (always visible)', app().indexOf('data-fold="routine"')<0, 'the plan was hidden behind a fold');
  // open history
  EV('document.querySelector("[data-foldtog=hist]").click();');
  chk('tapping opens it', EV('!!document.querySelector("[data-fold=hist] .fold-b")'), 'did not open');
  chk('and the history actually renders inside', EV('document.querySelector("[data-fold=hist] .fold-b").textContent').indexOf(nm)>=0, 'history content missing');
  chk('the state is remembered', EV('S.fold && S.fold.hist===true'), JSON.stringify(EV('S.fold')));
  EV('render();');
  chk('it stays open across a re-render', EV('!!document.querySelector("[data-fold=hist] .fold-b")'), 'reset by render');
  EV('document.querySelector("[data-foldtog=hist]").click();');
  chk('tapping again closes it', EV('!document.querySelector("[data-fold=hist] .fold-b")'), 'did not close');
  // CAL tab: past sessions
  EV('S.day="CAL"; render();');
  chk('past sessions is a closed fold on the calendar', EV('!!document.querySelector("[data-fold=gallery]") && !document.querySelector("[data-fold=gallery] .fold-b")'), 'gallery not folded');
  chk('the calendar grid itself is not folded', EV('!!document.querySelector(".cal-grid, [data-calday]")'), 'grid hidden');
  EV('document.querySelector("[data-foldtog=gallery]").click();');
  chk('past sessions opens with its content', EV('!!document.getElementById("gallery")'), 'gallery missing');
  // a banked day cannot freeze a fold
  chk('folds are lockfree', EV('document.querySelector(".fold").className.indexOf("lockfree")>=0'), 'guard would eat the tap');
  // help/tour targets inside closed folds are still reachable
  EV('S.fold={hist:false,vol:false,road:false,why:false,prov:false,caltools:false,gallery:false}; save(); S.day="PLAN"; render();');
  EV('foldOpenAll(); render();');
  chk('foldOpenAll opens every section for a help jump', EV('["road","vol","hist","why","prov"].every(function(k){ return !!document.querySelector("[data-fold="+k+"] .fold-b"); })'), 'a section stayed closed');
  console.log('  problems: '+bad); process.exit(bad?1:0);
},1700);
