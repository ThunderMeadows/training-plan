// ANDROID AUDIT 2026-09-02, after the "can't press I understand" report. Nothing here needs a
// layout engine: it enforces the CSS contract that makes content reachable on a short viewport
// or at a large system display size, which is where Android differs most from the test iPhone.
const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const raw=fs.readFileSync(f,'utf8');
let bad=0; const chk=(l,ok,d)=>{ if(!ok)bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&d?'  <-- '+d:''}`);};
console.log(`\n--- ${L}: everything stays reachable on a small screen ---`);

// 1. every full-screen overlay must be reachable: it scrolls itself, or its inner sheet caps
//    its height AND scrolls. Centring with align-items/justify-content while overflowing puts
//    content in dead space that CANNOT be scrolled to - the field bug.
const wraps=[...raw.matchAll(/\.([\w-]+)\{position:fixed;inset:0;[^}]*\}/g)];
chk('found the full-screen overlays', wraps.length>=5, wraps.length+' found');
let unreachable=[], centredOverflow=[];
wraps.forEach(m=>{
  // strip CSS comments first: restchip's block contains a note explaining why
  // justify-content:center was REMOVED, and matching that text flagged the fix as the bug
  const name=m[1], css=m[0].replace(/\/\*[\s\S]*?\*\//g,'');
  const scrolls=/overflow-y:\s*auto|overflow:\s*auto/.test(css);
  const innerRe=new RegExp('\\.'+name.replace('-wrap','')+'[\\w-]*\\{[^}]*max-height[^}]*overflow:\\s*auto[^}]*\\}');
  const innerCaps=innerRe.test(raw);
  if(!scrolls && !innerCaps) unreachable.push(name);
  // a ROW flex that scrolls must not centre on the cross axis; column flex centring is
  // horizontal and harmless
  const column=/flex-direction:\s*column/.test(css);
  if(scrolls && !column && /align-items:\s*center/.test(css)) centredOverflow.push(name);
  if(scrolls && column && /justify-content:\s*center/.test(css)) centredOverflow.push(name);
});
chk('every overlay can be scrolled or caps its sheet', unreachable.length===0, unreachable.join(', '));
chk('none centre their overflow into dead space', centredOverflow.length===0, centredOverflow.join(', '));

// 2. the disclaimer gate specifically - the one that shipped broken
const gate=(raw.match(/\.disc-wrap\{[^}]*\}/)||[''])[0];
const inner=(raw.match(/\.disc-inner\{[^}]*\}/)||[''])[0];
chk('the gate scrolls and centres via margin:auto', /overflow-y:\s*auto/.test(gate) && !/align-items:\s*center/.test(gate) && /margin:\s*auto/.test(inner), gate.slice(0,70));

// 3. tap targets on the controls a stuck user needs
chk('the accept button is a real button', /<button type="button" class="daybtn" id="discOk"/.test(raw), 'still a div');
chk('and is at least 44px tall', /#discOk\{[^}]*min-height:\s*(4[4-9]|[5-9]\d)px/.test(raw), 'small tap target');

// 4. Android-divergent APIs must be guarded, never assumed
[['navigator.share','share'],['navigator.wakeLock','wakeLock'],['navigator.vibrate','vibrate']].forEach(([api,label])=>{
  const used=raw.split(api).length-1;
  if(!used) return;
  const guarded=new RegExp('(if\\s*\\(\\s*!?'+api.replace('.','\\.')+'|typeof\\s+'+api.replace('.','\\.')+'|'+api.replace('.','\\.')+'\\s*&&|navigator\\.canShare)').test(raw);
  chk(label+' is feature-detected, not assumed', guarded, 'unguarded '+api);
});

// 5. webkit-prefixed properties that Chrome needs a standard form of
[['mask','mask'],['user-select','user-select']].forEach(([p])=>{
  const wk=(raw.match(new RegExp('-webkit-'+p+':','g'))||[]).length;
  const std=(raw.match(new RegExp('[^-]'+p+':','g'))||[]).length;
  if(wk) chk(p+' has a standard form alongside the prefix', std>0, 'prefix only');
});
console.log('  problems: '+bad); process.exit(bad?1:0);
