// A record shown twice (FIELD 2026-09-02): the PR ledger appended on every banking, so a
// session banked, then banked again after "+ set" or a correction, filed the same record twice
// and the banner read both. Re-banking now replaces today's entries for the lifts it judged.
const { JSDOM } = require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const dom=new JSDOM(fs.readFileSync(f,'utf8'),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/'});
const w=dom.window,D=w.document,EV=e=>w.eval(e);
w.AudioContext=w.AudioContext||function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
(async()=>{ await new Promise(r=>setTimeout(r,1500));
  console.log(`\n--- ${L}: no duplicate personal records ---`);
  let bad=0; const chk=(l,ok,d)=>{ if(!ok) bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&d?'  <-- '+d:''}`); };
  EV('try{TOUR.live=false;}catch(e){} S.tour={done:true}; if(typeof ONB!=="undefined"){ONB().done=true;} S.discAck={v:DISC_V,d:localDate()}; storageOK=true; S.data={}; S.prs=[]; S.exHist={};');
  EV(`S.splitMode='open'; S.week=timeWeek(); S.day=PLAN.days[0].code; S.when={date:String(shiftDate()),time:'10:00'}; render();`);
  // a loaded accessory with prior history at 60, lifted today at 65 on every set
  const i=EV(`(function(){ var d=dayObj(); for(var i=0;i<d.exercises.length;i++){ var ex=d.exercises[i]; if(!ex.maxKey && ex.loadNum!=null && !isOut(ex.name)) return i; } return -1; })()`);
  const nm=EV(`dayObj().exercises[${i}].name`);
  EV(`histPush(${JSON.stringify(nm)}, {d:'2026-08-20', w:60, sets:[10,10,10], ws:[60,60,60], e1:80});`);
  EV(`(function(){ var ex=dayObj().exercises[${i}], st=exState(${i},ex); st.w=65; st.sets.forEach(function(s){ s.st='dev'; s.reps=10; s.w=65; }); save(); })()`);
  let ok1=false; try{ ok1=await EV('saveSessionLog(true)'); }catch(e){ console.log('  bank threw',e.message); }
  chk('first banking earns the weight record once', ok1===true && EV(`todayPRs().filter(function(p){ return p.ex===${JSON.stringify(nm)} && p.kind==='weight'; }).length`)===1);
  const n1=EV('todayPRs().length');
  // the athlete adds a set and banks again - his exact day
  EV(`(function(){ var ex=dayObj().exercises[${i}], st=exState(${i},ex); st.sets.push({st:'dev',added:true,reps:10,rir:null,w:65}); save(); })()`);
  let ok2=false; try{ ok2=await EV('saveSessionLog(true)'); }catch(e){ console.log('  rebank threw',e.message); }
  chk('re-banking after + set does not file the record again', ok2===true && EV(`todayPRs().filter(function(p){ return p.ex===${JSON.stringify(nm)} && p.kind==='weight'; }).length`)===1,
      'weight records for '+nm+': '+EV(`todayPRs().filter(function(p){ return p.ex===${JSON.stringify(nm)} && p.kind==='weight'; }).length`));
  const dup=EV(`(function(){ var seen={}, d=0; todayPRs().forEach(function(p){ var k=p.ex+'|'+p.kind; if(seen[k]) d++; seen[k]=1; }); return d; })()`);
  chk("no (lift, kind) appears twice in today's ledger", dup===0, dup+' duplicates');
  EV("S.day='PLAN'; render(); S.day=PLAN.days[0].code; render();");
  const banner=(D.getElementById('app')||D.body).innerHTML;
  const lines=banner.split(nm+' \u00b7 weight 65').length-1;
  chk('and the banner shows it once', lines<=1, lines+' lines');
  // a correction that takes the record away retires it
  EV(`(function(){ var ex=dayObj().exercises[${i}], st=exState(${i},ex); st.w=55; st.sets.forEach(function(s){ s.w=55; }); save(); })()`);
  let ok3=false; try{ ok3=await EV('saveSessionLog(true)'); }catch(e){}
  chk('correcting the sets down retires the weight record instead of leaving it', ok3===true && EV(`todayPRs().filter(function(p){ return p.ex===${JSON.stringify(nm)} && p.kind==='weight'; }).length`)===0);
  chk('while a record that still stands (volume: four sets beat three) is kept', EV(`todayPRs().filter(function(p){ return p.ex===${JSON.stringify(nm)} && p.kind==='volume'; }).length`)===1);
  // legacy: a ledger that already holds duplicates is tidied at boot
  EV(`S.prs=[{d:'2026-08-30',ex:'X',kind:'weight',val:65,prev:60},{d:'2026-08-30',ex:'X',kind:'weight',val:65,prev:60},{d:'2026-08-30',ex:'X',kind:'volume',val:9,prev:8}];`);
  EV(`(function(){ var seen={}; S.prs=S.prs.slice().reverse().filter(function(p){ if(!p) return false; var k=p.d+'|'+p.ex+'|'+p.kind; if(seen[k]) return false; seen[k]=1; return true; }).reverse(); })()`);
  chk('a ledger written before the fix is tidied to one record per day/lift/kind', EV('S.prs.length')===2);
  console.log('  problems:', bad); process.exit(bad?1:0);
})();
