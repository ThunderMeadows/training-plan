const { JSDOM } = require('jsdom'); const fs=require('fs');
const f=process.argv[2],L=process.argv[3];
const dom=new JSDOM(fs.readFileSync(f,'utf8'),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://thundermeadows.github.io/'});
const w=dom.window,D=w.document,EV=e=>w.eval(e); const errs=[];
w.addEventListener('error',e=>errs.push(e.message));
w.AudioContext=w.AudioContext||function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
setTimeout(()=>{
  console.log(`\n--- ${L} smoke ---`);
  for(const fn of ['coachIdle','ONB_ACTIVE','isStartMode']) EV(`if(typeof ${fn}==="function") ${fn}=function(){return false;};`);
  const days = EV('JSON.stringify(PLAN.days.map(function(d){return d.code;}))');
  let bad=0;
  for(const code of JSON.parse(days).concat(['MAX'])){
    try{ EV(`S.day=${JSON.stringify(code)}; render();`);
      const len=D.getElementById('app').innerHTML.length;
      if(len<500){ console.log(`  ${code}: THIN (${len})`); bad++; }
    }catch(e){ console.log(`  ${code}: THREW ${e.message}`); bad++; }
  }
  console.log(`  screens rendered: ${JSON.parse(days).length+1}, problems: ${bad}`);
  console.log(`  ERR_LOG: ${EV('(typeof ERR_LOG!=="undefined"?ERR_LOG.length:"n/a")')}`);
  console.log(`  window errors: ${errs.length}`);
  if(EV('typeof SET_OPEN')!=='undefined'){
    EV('SET_OPEN=true; settingsSync();');
    console.log(`  sheet opens after full screen sweep: ${!!D.querySelector('#setHost .set-sheet')}`);
    const d=[...D.querySelectorAll('#setHost [data-setclose]')].pop();
    if(d && d.onclick){ d.onclick.call(d,{target:d});
      console.log(`  and closes: ${!D.querySelector('#setHost .set-sheet')}`); }
    else console.log('  (no gear sheet on this card - settings are inline, by design)');
  }
  process.exit(bad?1:0);
},1400);
