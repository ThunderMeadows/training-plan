const {JSDOM}=require('jsdom'); const fs=require('fs');
const raw=fs.readFileSync(process.argv[2],'utf8'); const bk=JSON.parse(fs.readFileSync(process.argv[3],'utf8'));
const d=new JSDOM(raw,{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/',
  beforeParse(win){ win.localStorage.setItem('nsc:training-card-v1', JSON.stringify(bk.S));
    for(const k of Object.keys(bk.logs||{})) win.localStorage.setItem('nsc:'+k, bk.logs[k]);
    win.AudioContext=function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};}});
const w=d.window,EV=e=>{try{return w.eval(e);}catch(x){return 'ERR '+x.message;}};
setTimeout(()=>{ console.log('ohp max      ', EV('S.maxes.ohp'));
  console.log('on trial?    ', EV('JSON.stringify((S.mxProv||{}).ohp)'));
},2400);
