# Deadstop — change record

Every change made to the Session Card and Training Card, newest first, with the reason and the
build it landed in. Kept so the same fixes can be carried to the **Field Card**.

Each entry says what was wrong, not just what changed — the reason is usually the part that
matters when porting, because the same mistake tends to exist in the other card in a different
shape.

---

## v212 / 2026-09-06 — OPENS ON THE TRAINING DAY (his ask: "Anytime i close out the app it keeps the user on the same page they where on when they closed it. Can you automatically place them on their training day instead?")

### Cause
`syncToNext()` has always brought a stale day pointer forward on open, but it was written with
an explicit rule — *"Never hijack a tab (YOU/RATE/CAL/PLAN)"* — so a card closed on Rate reopened
on Rate. His ask overrides that rule for the open itself.

### Fix
**`landOnTraining()`**, run at boot in front of `syncToNext()` and on a return from
`LAND_AWAY_MS` (30 min) or more in the background:
- on a tab → the training day (`nextSession()`; with the block spent, the last training day
  stood on, else the first day of the split), then `syncToNext()` as before
- on a finished session → `syncToNext()` moves to the next one, as it always did
- on a session **in progress** (no log yet) → nothing moves; this is the one rule kept whole
- focus is only reset when the day actually changed
- a resume under 30 minutes moves nothing — a glance at a message between sets is not a new
  visit. `SET_BUSY` is respected on resume.

The tab rule inside `syncToNext()` is unchanged and documented as now being handled upstream.

### Tests
- **NEW `landtest.js`** — real reboots (a second window over the same storage) and real
  visibility events. Closed on each of the five tabs → reopens on the session; closed reviewing
  a finished session → reopens on the next; mid-session reboot and 45-minute absence → same
  day, same focus; 5-minute absence from a tab → stays, 45-minute → lands; block spent → still
  a training day. **7 red on v211**, green on v212.
- `emptybank.js` — fixture repaired. Its day-roll section seeded a card closed on the MAX tab
  with day A's sets still logged, and its final check read the *tab's* nonexistent set data, so
  it passed without ever looking at a training day. v212 lands on day A — a session in progress,
  correctly — and the check saw real sets. The section tests that stale cardio and a stale
  finisher do not make a fresh day claim work; the sets were never its subject and are cleared
  from the seed. Passes on v211 and v212.
- Full suite on v212: **97 fast harnesses green, plus `inert` and `deadsweep`.**

### Build
- BUILD v211 → **v212**; sw CACHE `card-v222-v212`. Session Card untouched.
- `WHATSNEW` `2026.09.06e` with a Bulk letter.
- Still open, unchanged: v212 backfill of shapes for pre-v211 logs from their own reports
  (proposed, his call: "later"); re-keying live set state by exercise identity.

## v211 / 2026-09-06 — A BANKED SESSION IS A DOCUMENT (his rule: "Make sure that all training in the past does not change due to revisions of the application")

### What he saw
c203 made Barbell Row the opener of every pull day. Every pull session he had **already logged**
re-rendered with it. His 20 Aug session, read straight off his backup against its own report:

| Card showed | He actually did |
|---|---|
| Barbell Row — 4 sets @155 | *(never performed)* |
| Cable Rows — 4 sets @180 | Cable Rows @140 — 4 sets |
| Lat Pulldown — 3 sets @150 | Lat Pulldown @140 — 4 sets |
| Hammer Curls — 2 sets | Hammer Curls @30 — 3 sets |
| Face Pulls — 0 sets | Face Pulls @35 — 2 sets |

Every movement shifted one down, wearing the wrong sets and today's weights. A movement he
has never performed was displayed carrying four sets he did on something else.

### Cause
A past day was never stored. It was **rebuilt on every visit** from the live `PLAN` plus set
state keyed by position. So the day on screen was always today's program wearing last month's
data, and any revision to the program — by a build or by the athlete — moved history with it.

The card already had a freeze for this rule (`S.froze`, `frzSnap` / `frzGet`, comment: *"a plan
edit must never rewrite a session you already logged"*). It only ever froze the athlete's own
added movements (by cid) and removals. Base plan, order, loads, set counts, sets as performed:
all live. The row change walked straight through it.

### Fix — complete the freeze rather than duplicate it
- **`sessionShape()`** — the day as performed: movements in order, `sub`, reps and rest as
  prescribed, the weight actually used (`curLoad`), whether it was out, and every set's
  `{st, reps, rir, w, g, t, added}`. Taken at bank and at every correction.
- **`saveSessionLog`** writes `shape` into the log beside `report`. The report is for people;
  the shape is what the card renders the session from, forever.
- **`docRef()`** — when a *finished* session is being visited (`isVisiting()`) and its log has a
  shape, returns it. Memoised per `(day, week, block, log count, rePass, splitMode, date)`;
  re-entrancy guarded, because `isVisiting → nextSession → dayObj → docRef`.
- **`dayObj()`** returns the day built from the shape (`docExercises`, plain objects every
  reader already understands, flagged `doc:true`). **`exKey(i)`** returns `doc|<logkey>|i`, and
  **`docMaterialize`** builds those entries from the shape on first visit — so all 28 direct
  `S.data[exKey(i)]` readers and all 30 `exState` callers see the document without being
  touched. `exSets`/`exState` never pad or trim a `doc` exercise; `isOut` reads the shape.
- **`resaveVisitedLog`** re-takes the shape from the document's entries, so corrections stick.
  A log without a shape stays without one — giving it one now would be built from today's
  plan, which is the exact thing this layer exists to stop.
- **Pre-shape logs** (everything before v211): rendered as before, with a notice — *"Logged
  before this version of the card"* — and the banked report shown beside the day. Nothing is
  reconstructed.

Boundaries held on purpose: the live session, previews, and repeat passes stay on the normal
path and **do** see program revisions. Document keys never match `weekSets`/`cycleSets`
prefixes, `pruneCycles` (`^\d+c\|`), or `remapData` (`split('|')` length < 4), so nothing
counts, prunes, or remaps them.

### Tests
- **NEW `docday.js`** — banks a real session through `saveSessionLog`, then revises the program
  every way a build or an athlete can: inserts a main lift at the top, moves every max 60 lb,
  reorders, removes, adds. Reopens the finished session. Must not move. Also holds the two
  boundaries (the next live session is live and sees the revision; a shape-less log gets the
  notice and the report, not a document). **11 red on v210**, including his exact case
  ("Audit Row, 2 sets @100" for a movement never performed). Green on v211.
- Full suite on v211: **96 fast harnesses green, plus `inert` (674 controls, 14 screens) and
  `deadsweep` (1,200 tappables, 20 screens).**

### Still open
Re-keying live set state by exercise identity instead of position. v210 made every path
maintain positions correctly and v211 makes finished sessions stop depending on positions at
all; the live session still uses them. Its own build, with a migration.

### Build
- BUILD v210 → **v211**; sw CACHE `card-v222-v211`. Session Card untouched.
- `WHATSNEW` `2026.09.06d` with a Bulk letter — every athlete who has ever opened a past day
  has been shown the wrong session, and that needs saying.

## v210 / 2026-09-06 — SETS FOLLOW THEIR EXERCISE (FIELD — "My hard sets per week looks like its declining and i dont know why if the sets have only been getting harder increases")

Diagnosed from his own backup, not a fixture.

### What he saw against what he did
His **Hard sets per week** bars on the Rate tab read **123 / 109 / 94**. Reconstructed from his
own banked session reports for the same three weeks: **120 / 137 / 91** — and week 3 was only
four sessions in of six, so it was never a decline at all. Week 2 was short by **28 real sets**:

- **Day F, 1 Sep** — 26 logged sets in the report (squats, deadlifts, leg curls, calves, lunges,
  hip adduction, hanging leg raises). The card's set state for that session: **empty**.
- **Day C, 28 Aug** — missing exactly **6**: the Hip Adduction and Hip Abduction machines, three
  sets each. The two movements he had added that week.

### Cause
Set state is keyed by an exercise's **position** in the day: `cyc()+'c|'+week+'|'+day+'|'+index`.
Four paths change a day's shape and each maintained those positions differently.

The one that did the damage was deleting an **added** movement:

```js
const base=planDay().exercises.length;
delete S.data[exKey(base+ci)];
for(let j=base+ci+1;j<=base+cs.length;j++){ ...slide down one... }
```

It assumed a custom sits at the end of the day. `S.order` says otherwise — his day F has **Lying
Leg Curl at position 3 of 9**, because he dragged it there. So the delete removed whatever was
really in that slot and slid every movement after it down one. Reproduced on the shipped build:
three movements each inherited their neighbour's logged sets.

`exKey()` is also the **current week only**, so every already-logged week kept the old layout
while the day changed underneath it.

The other two paths — removing a plan movement to `S.outs`, and restoring it — touched set data
not at all. (Note for the port: `S.outs` does **not** shift positions, because an out movement
still renders as SKIPPED and keeps its slot. The first draft of the harness assumed it did and
proved nothing.)

**This is not a chart bug.** `blockSuccess()` reads the same slots to judge whether prescribed
reps were hit, and that feeds max progression. A slot off by one credits one movement's reps to
another lift.

### Fix
- **`dayReshape(code, mutate)`** — reads the day's shape, lets the caller change it, then moves
  the set data of **every week and every block** to match, by name. Every shape change now goes
  through it: the delete-added branch (whose hand arithmetic is gone), the remove-to-`S.outs`
  branch, restore, and `libAdd`.
- **The park.** `remapData` used to write an unmapped position back at its *old* index — where
  another movement had just landed, which is worse than losing it. Sets whose movement has left
  the day are now parked under that movement's **name** (`S.dpark`, bounded at 600). Restore the
  movement and its sets come home. `deleteAdded` parks instead of dropping too: the athlete
  edited a plan, they did not un-train a session.
- **`weekSets()` and `cycleSets()` count parked sets.** "Hard sets per week" is a record of work
  performed; editing today's plan is not a claim about three weeks ago.

### Not done, on purpose
**No repair pass for his week 2.** The banked reports are prose, so rebuilding per-set state
means inferring which slot each set belonged to — trading a visible gap for invented history in
the file the engine trusts. The reports hold the truth and the block ends in three weeks.

**Re-keying set state by exercise identity is still the real fix** and is still open. This build
makes every path maintain positions correctly; it does not remove positions as the key. That
wants its own build and a migration.

### Tests — `slotdrift.js`, and two ways this file lied before it worked
Registered in `run.js`, documented in the README. Red on v209, green on v210.

Two vacuous-pass traps caught while writing it, both the same shape as the `sharetest` fault
found in v208 — a check that passes because its own setup silently failed:

1. It called `dayReshape()` directly. That function does not exist on v209, so the call threw,
   the catch returned a fallback, and every check "passed" on the broken build.
2. Rewritten to drive the real controls by real tap, it then tapped a **previewed** day — which
   renders "Coming up — look, don't touch" and refuses every control. Taps returned fine and
   nothing happened. It now stands on the live session from `nextSession()` and asserts it is
   not a preview.

The headline check is his case exactly: add a movement, drag it mid-day, seed three weeks of
distinct set counts, delete it through the real control, and assert no other movement's counts
moved — plus that the week still counts every set performed.

### Build
- BUILD v209 → **v210**; sw CACHE `card-v222-v210`. Session Card untouched.
- `WHATSNEW` `2026.09.06c` with a Bulk letter, since his chart was visibly wrong and other
  athletes' will have been too.
- Full suite on v210: **95 fast harnesses green, plus `inert` and `deadsweep`.**

## v209 / 2026-09-06 — BULK'S JOKE BOOK ("Can you have Bulk spill out funny jokes in his emails? A large joke library. Gym fitness related? Something new almost everyday. Some repeats occasionally depending on the humor. He gets dry after a few. Also, give him a better personality.")

He was right about dry, and it was measurable. `MAIL_GREET` held **four** lines picked by
`getDate() % 4`. Train four days a week and you met the whole of Bulk's personality inside a
fortnight — then watched it arrive in the same order every month, because date-of-month modulo a
pool walks the pool in sequence. `MAIL_DONE` was the same, also four lines.

### The book
`BULK_JOKES` — **204 jokes**, tagged, 66 of them marked keepers. Tags let the joke suit the day
the card already knows about: `leg`, `pull`, `push`, `core`, `cardio`, `deload`, `pr`, `gym`,
`food`, `bulk` (his own material — a gummy bear who lives in a locker, benches a chalk cube, and
is regularly mistaken for pre-workout), and `general`.

House rules written above the array, because this is the list that will get added to:
- Nothing about being weak, small, fat or slow. The card is friendly and forgiving, and a joke
  that lands on the athlete is not a joke.
- Nothing about skipping meals, cutting weight, or earning food.
- No drugs, no injuries, no bodies.
- Bulk is the butt of most of them, which is the correct place for him.

`joketest` enforces the first three with a pattern list, so a joke added later that breaks them
fails the suite rather than reaching an athlete.

### The rotation
- **Fixed for the day.** `S.jokeToday={d,i}`. Open the card five times and it is one joke, not
  five — otherwise a letter read twice shows two punchlines and Bulk reads as several bears.
- **Nearly all new.** `S.jokeH` is a ring of recent picks; a joke waits `JOKE_WINDOW` (70) days
  for its turn. Measured: **60 consecutive days give 60 different jokes, zero back-to-back.**
- **Some repeats, depending on the humour** — his words. Keepers are the only jokes allowed back
  inside the window, and never inside 24 days. Over 420 days it does repeat, as it must with a
  204-joke book, and the good ones come round more.
- **Day-aware.** `jokeTagToday()` reads the day's own exercise names (and `isDeload()`) and the
  picker prefers that tag while fresh ones remain.

### `jokeSeed()` — a note worth keeping
First cut was `n*31+charCode`, fine for a hash table and useless here: consecutive dates differ
by one character, so the seed differed by one and `seed % POOL` walked the greeting pool in
order — reproducing the exact defect the `% 4` was being replaced for. `joketest` caught it.
Now FNV-1a with a final mix. Measured over 200 consecutive days: **24 of 24 greetings used, 11
in-order steps out of 199** (chance is about 8).

### Who gets a punchline
`mailPush(id, txt, face, joke)` — the 4th argument is passed **explicitly at each call site**,
never attached by rule. A punchline under "your max came down" or "back up or lose everything"
is not a joke, it is a card that does not know what it just said. Jokes ride on the training-day
greeting, the already-trained letter, and the weekly books. The streak warning, the backup
warning, the adapt letters and the release letter carry none, and `joketest` checks that through
the real `mailSweep()` rather than a hand-made call.

### Quiet days
He asked for something new almost every day; his own standing rule is that Bulk never writes
filler and an empty week earns silence. Both hold: the mailbox itself now always carries a
**JOKE OF THE DAY** block, so a rest day has something new in it without a letter, a badge, or a
buzz. Opening the box is the athlete's idea.

### Voice
`MAIL_GREET` 4 → **24**, `MAIL_DONE` 4 → **20**, both picked off the date hash. Running bits kept
consistent so he reads as one character: he lives in the gym, he has no hands and mentions it, he
is four inches tall, he is made of sugar, he keeps the books, and the answer to everything is
pizza.

### Build
- BUILD v208 → **v209**; sw CACHE `card-v222-v209`. Session Card untouched.
- `WHATSNEW` `2026.09.06b` with a Bulk letter. Two release entries now ship together
  (`2026.09.06a` progression fixes, `2026.09.06b` jokes) — `releasetest` confirms a returning
  athlete gets each one, oldest first.
- **NEW `joketest.js`** — 26 checks, registered in `run.js`, documented in the README, 20 red on
  v208.
- Full suite re-run on v209: **94 fast harnesses green, plus `inert` and `deadsweep`.**

## v208 / 2026-09-06 — PROGRESSION AUDIT ("I need a deep audit and tests on the progression engine with no problems.")

The previous audit went at the whole file. This one went at one system: every automatic writer
to a weight. The card has four writers to a max (layoff, stall, rate, probation) plus
auto-calibration, and one more to accessory load (the logged anchor). Every fault below lived
where two of them met, and none was reachable by reading a single function — they were found by
driving the real engine in jsdom over simulated blocks, not by reading it.

Six live faults, plus two latent. All eight are pinned by `progaudit.js`, which returns
**14 red on v207 and 14 green on v208**.

### 1. Every deload week permanently shrank the accessories (severe)
`accLoad()` scales the whole accessory ladder to `accAnchor()`, which is the last logged weight.
A deload week was logged like any other session, so the deload weight became the anchor the next
block was built from — and it happened again every block. Driven through the real `recordPerf()`
over three blocks, with the athlete topping the rep range in every session:

    Romanian Deadlift   220 220 230 240 260 D155 | 155 155 160 165 180 D105 | 105 105 110 115 125 D75
    Hammer Curls         25  25  25  25  25 D15  |  15  15  15  15  15 D10  |  10  10  10  10  10 D5
    Face Pulls           20 ... D10 | 10 ... D10

`updateE1RM()` has refused to let a deload set a max since c204 — *"a deload is not a strength
test"* — and the accessory anchor never got the same rule. Fix: `recordPerf()` returns early on
a deload week (guarded on `PLAN.weeks>1`). The deload is still logged and still displayed; it
just does not become the weight the next block is built from. Same three blocks after the fix:
**220→260, 260→305, 305→365.**

FIELD SHAPE TO WATCH FOR IN THE FIELD CARD: any "last logged" anchor that a deliberately light
week can write to. The Field Card's run paces have the same shape if a recovery run can set them.

### 2. A failing tested-max trial could put weight ON the bar (severe)
`pvJudge()` clamped its step-down to the trial floor unconditionally: `if(to<p.floor) to=p.floor`.
When the current max sat *below* that floor — hand-lowered in Programming maxes, or cut by the
layoff pass, which is the one automatic writer with no `pvOn()` guard — the penalty for two bad
sessions *raised* the max to the floor. Reproduced: 175 → 200 with the athlete-facing line
"the working weight comes back **-25 lb**". At `cur===floor` it filed a 0 lb action, an entry in
the record claiming a change that never happened.

Fix: the floor is a floor, never a target. At or under it, the trial is over — clear `mxProv`,
move nothing, file nothing. A trial above its floor steps down exactly as before.

### 3. `adRate()` compared across rep targets (serious)
The same fault the stall rule was field-caught on the day before, sitting untouched in its
sibling. The trend was least-squares fitted across every point in the 56-day window regardless
of rep target, so a split alternating a heavy day with a volume day feeds it a sawtooth.
Identical, unchanging strength measured as **+1.7 lb/wk or −1.7** depending only on which kind
of day the window ended on. With a wide enough gap between the two kinds (a 5-rep day against a
12-rep day, 473 vs 383) it cleared the 5 lb rounding and the 1.5% cap and added weight forever:

    four weekly passes, strength flat throughout:  405 → 410 → 415 → 420 → 425

Fix: same rule as `adStalled()` — the most recent rep target only, and untagged points are not
judged at all. A genuine like-for-like climb still earns its step (verified).

### 4. Two automatic writers, one pot of evidence (moderate)
`autoCalibrate()` runs on every bank; the rate pass runs weekly. Both read `S.e1rmH`, neither
knew about the other. One bank moved a 300 lb squat to 340 (calibration, at its 15% cap) and
then to 345 (rate) — 45 lb off four logged sets, the second move paid for evidence the first had
already spent. Fix: new `acMovedRecently(k)`; the rate pass yields to a calibration inside 7 days.

### 5. The biggest automatic move to a max had no way back (moderate)
c188–c190 shipped per-item "put back" on the promise that any change the card made to a max can
be undone on its own. `autoCalibrate()` wrote only to `acLog`, which nothing reverses — so the
one writer allowed to move a max 15% at a stroke was the one the athlete could not refuse. It now
files a `calib` entry into `S.adLog` alongside every other change, undoable, and renders in
*What the card changed*. Also: `LN` in that panel had no name for `row`, which has been a
programmed main lift since c203, so a row entry read "row".

### 6. The struggle flag belonged to whichever movement went last (moderate)
`updateE1RM()` **assigned** `c` per set. Two movements sharing a max key on one day — a main
bench and a back-off also keyed `bench` — meant the last one processed wrote the day's flag. A
ground-out main (3s missed at RIR 0) followed by a clean back-off filed `c:1`, and the struggle
vanished from the record that both the stall rule and the trial judge read. Reverse the order and
the same day files `c:0`. Fix: keep the worse — struggle anywhere in the lift's day is struggle.

### 7 & 8. Two latent ones
- `ex.deload=ex.wk[5]` hard-coded the sixth rung. Every generated block is six weeks so it is
  right today, but a restored or hand-edited plan with a shorter ladder wrote `deload=undefined`,
  and that is exactly what a deload week falls back to for its load. Now the last rung.
- `accAnchor()` accepted a stored zero or negative weight as a real anchor, scaling the ladder to
  nothing; the card then prescribed 5 lb and labelled it "logged, high confidence". Now ignored.

### Tests
- **NEW `progaudit.js`** — 14 checks, registered in `run.js` and documented in the README.
  Every one of them goes red on v207. Beyond the eight fixes it holds the two regression
  directions that matter: a real like-for-like climb still earns its rate step, and a trial above
  its floor still steps down.
- `provmax.js` — fixture repaired, not weakened. Its ramp-hold fixture pushed estimate points
  with no `n`, which `adRate` now refuses to judge; without the tag the trend was silent and the
  check would have passed on a card with the hold deleted. Points tagged `n:5`.
- `sharetest.js` — probe hardened. node-canvas rejects a family list carrying a quoted name, and
  the card's own `F(size,weight)` emits `800 32px -apple-system,BlinkMacSystemFont,"Segoe UI",…`,
  so the context silently stayed on its 10px default. Every `measureText` in that file was
  measuring at a tenth of the real width and every geometry check was passing vacuously — five
  work rows drawn, zero found, no collision possible. The probe now records the font the card
  *asked for* and re-sets the same weight and size on a generic family where the size did not
  survive. A canvas build that accepts the card's string is unaffected.

### Build
- BUILD v207 → **v208**; sw CACHE `card-v222-v208`. Session Card untouched, per standing scope.
- `WHATSNEW` entry `2026.09.06a` with a Bulk letter — athletes will feel #1 immediately, and it
  is the kind of change that needs explaining rather than noticing.
- Test environment: jsdom 24 plus canvas 3 (prebuilt; canvas 2 cannot build here — pango and
  jpeg dev headers are absent, and 3 needs `--legacy-peer-deps` against jsdom 24's peer range).
  CI installs `canvas@^2.11.2` from `package.json` and is unaffected.

## 2026-09-06 - AUDIT ("Run an audit on the entire html file. Look for everything and anything. Leave no rock unturned.")

The suite was green, so an audit has to go after what the suite was not written for. The five
field faults of 2026-09-05 came in five shapes - a guard with no test, global state leaking
across days, a one-shot flag, an off-by-one gate, a mixed-population comparison, and a fixture
that defined the bug away - and each shape was searched for on its own. Then the card was booted
on a real athlete's state and on thirty hostile ones.

### Static
- 763 functions, no duplicate definitions (two `near()` are local helpers). No `console.log`,
  `debugger`, `alert(` or TODO anywhere.
- **Nine dead functions**, defined and never called: `PG_structFor`, `anaPaint`, `blockWeek`,
  `calCycle`, `hasClip`, `painAlt`, `planBalance`, `stimSame`, `streakDays`. Left in place - dead
  code is not a fault and removing it is a change with no test - but recorded.
- One-shot flag scan: `adFixStall` was the only migration-style flag and c207 already versioned
  it. `installAck` is a preference, not a migration.
- Day-boundary scan: 75 `shiftDate()` (3am training-day boundary) against 29 `localDate()`
  (wall clock). Five functions use both; all on inspection deliberate (calendar and timestamps
  on the wall clock, session identity on the training day).
- Growth: everything that accumulates is capped - `adLog` 30, `e1rmH` 60/lift, `exHist` 80/
  movement, `prs` 200, `readyH` 90, `rirLog` 12, `adhocLog` 20, mail 30. Uncapped: `weightLog`,
  `bodycomp`, `cycleLog` - one entry per weigh-in / per cycle, tens of bytes each, no concern
  for years.
- Service worker precache list matches the nine deploy files exactly.

### On Jefe's real state (2026-09-05 backup)
82 screen renders - every tab, every week, every day, in lb and again in kg - with zero errors
and zero long decimals on screen in kg. All 15 logs open. Share text, recap, calendar and YOU
build on real data. Roster round trip (coach -> athlete -> coach) returns maxes, logs, trial and
change list byte-identical.

**A real finding in the data, not the code:** his 2026-09-03 and 2026-09-04 logs both carry
`Cardio: 25min treadmill (timed 25:02)` - the identical clock to the second. That is the c206
cardio leak, already in his history: the 4th inherited the 3rd's clock. c206's day-roll clear
stops it going forward; the two logs are his to judge.

Simulated his actual next open on 2026-09-06: stale `tacc` 1502025 clears to 0, the press comes
back to 150 on trial, day D week 3 opens unlocked, the c206 and c207 letters land in the mailbox
(cap 30, oldest two roll off), `ERR_LOG` 0.

### Hostile boot - one white screen found
Thirty saved states the card must survive: not-JSON, null, a number, an array, maxes as a string,
garbage estimate points, garbage change entries, set states wiped, week 99, cardio null, trial
garbage, locked/dbf as arrays, profile null, unknown units and theme, a date of "yesterday", a
200 KB note, dates in 2099 and 1999, mail garbage, onboarding half-finished, roster garbage,
three corrupt log entries.

**Twenty-nine survive. One killed the card at boot.** A generated plan whose day had no
`exercises` array passed the adoption check - which was `days.length` alone - became PLAN, and
the very first `dayObj()` did `p.exercises.concat(...)` on undefined. White screen, no way back
in, on a card holding the athlete's whole history. This is the single failure class the card
cannot recover from inside itself.

`planUsable(p)` now stands at every adoption site (boot, roster switch, `applyMaxesToPlan`): days
present, each with a string code and an `exercises` array of named entries, weeks > 0. A plan
that fails is left untouched in `S.genPlan` - nothing of the athlete's is deleted - it is simply
not driven, the starter block runs, and `oops('planUnusable')` records it.

### New standing test hostileboot.js - 35 checks
Builds a real-shaped baseline (onboarded, one session banked) and boots thirty mutations of it.
Also insists a broken plan is left in place, the starter block runs instead, and the banked
session survives. Against the pre-audit build: **2 FAILING CHECKS**.

### Also
- The comment above `E1_MAXREPS` said the gate keeps volume days out of the estimate. It never
  did, and since c207 it deliberately does not: the comment now says so, and says not to "fix"
  it by lowering the number.
- `audit_jefe.js` and `verify_jefe.js` (both need his backup file) stay out of the committed
  suite.

### Honest limits
jsdom is not an iPhone: rest timers, audio, the haptic, drag on a real touchscreen, the install
prompt and the service worker's actual fetch behaviour were not exercised here. Two "verified"
drag fixes reached the gym broken in the past; this audit does not change that record.

## Convention - 2026-09-06: build prefix c -> v
His call: "Change the c letter to v for version." Applies from this release. c66 through c206
shipped as c; the build staged as c207 ships as **v207** (nothing was ever uploaded under c207),
and every build after it is v. The number is the same sequence - only the letter changed.
Nothing parses the prefix: BUILD is displayed, mailed as `build-v207`, and carried in the
service-worker cache name (`card-v222-v207`, which `buildsync` checks). Release-letter ids stay
date-coded and are unaffected. Earlier headings below keep their c - history is history.

## v207 - 2026-09-05 (FIELD - "My overhead press working weight dropped from 115 to 85 on week 3? That is not right")

### Diagnosed against his real backup, not from the code
He sent the 2026-09-05 export and the card was booted on it in jsdom. `S.maxes.ohp` was 140; the
change list carried `stall ohp 150->140 2026-08-31`. Day D programmes the press at 63.3% of the
max, and 0.63333 x 140 = 88.7, which lands the bar on **85**. His number, explained.

### Nothing had stalled
His estimate history read 181 -> 162 -> 154. Reconstructed from the logs:

    2026-08-19  day A  135 x 8  @RIR2  ->  135 / 0.744 = 181     (heavy - EIGHTS)
    2026-08-26  day D  110 x 10 @RIR2  ->  110 / 0.68  = 162     (volume - TENS)
    2026-08-29  day D  105 x 10 @RIR2  ->  105 / 0.68  = 154     (volume - TENS)

Same strength throughout - he went 105, 110, 105, 115 with full reps and more sets. A ten-rep set
estimates a lower one-rep max than an eight-rep set off the same bar, by arithmetic. So **every
volume day following a heavy day read as decline.**

The file already carried the warning, above `E1_MAXREPS`: *"A 4x10 @68% RIR-2 volume day is NOT a
max test - feeding it in drags the estimate far below true single-rep strength. E1_MAXREPS gates
that out."* The gate is `reps > 10`. His volume day prescribes exactly **10**. One rep too
generous to catch his own program.

### Why narrowing the gate would have been the wrong fix
Dropping E1_MAXREPS to 8 would have hidden this case and left the fault: a five-rep day and an
eight-rep day mix in exactly the same way, and it would throw away real data. The collection was
never the problem. **The comparison was.**

- Every estimate now carries `n`, the rep target of the day it came from.
- `adStalled()` filters to points sharing the newest point's rep target before judging. Fewer
  than three in that bucket means no verdict.
- Untagged points - written before the tag existed - are not judged at all. No evidence, no cut.

### The repair pass could never have reached him
`adRepairStalls()` exists to hand back cuts the old rule made wrongly, and it has a gate: "if the
estimate is genuinely falling, leave it alone." 154 < 181 read as falling, so it protected the
cut. That gate now measures like against like, and when a window cannot be built from one rep
target the fall proves nothing and must not protect anything - gate 2 (struggle) still holds the
line on cuts that were actually earned.

**And it was a one-shot boolean.** `if(S.adFixStall) return 0;  // once per card, ever`. His card
spent that flag on 2026-09-04 under the old judgement. Giving the pass better judgement therefore
reached nobody who had already run it - the exact population that needed it. It is now versioned
(`AD_FIX_VER`), bumped whenever the pass's judgement changes. This is the second fix in this
entry and the one that made the first one matter.

### Verified against his card, before and after
Booting his backup on c206 and on c207:

    c206   maxes.ohp 140   day A W3 -> 95    day D W3 -> 85    day D W4 -> 95
    c207   maxes.ohp 150   day A W3 -> 105   day D W3 -> 95    day D W4 -> 105
           put-back panel: ohp 140 -> 150
           adStalled() against his real history: []  (was cutting)

His bench was cut the same day, 300 -> 275, and is deliberately left alone: it now sits at 305,
above where it was cut from, so gate 1 ("someone moved it since") correctly declines to touch it.
It recovered on its own.

### The safety call: an unprovable put-back comes back ON TRIAL
Reversing the "a falling estimate keeps its cut" gate created a real cost: an athlete who
genuinely regressed, and whose struggle was never flagged, would be handed 8% more bar. Choosing
between that athlete and Jefe's athlete was a false choice - the card already owns the machinery
for a number that is believed but not yet demonstrated.

When the window CAN be built from one rep target, a flat or rising line proves the cut was wrong
and the max goes back as a standing number. When it cannot - untagged history, where neither the
cut nor the restore is provable - the max goes back on **probation** (`mxProv`, `src:'putback'`),
floored at the number it was cut to, which is a load already trained successfully. Two missed or
ground-out sessions and `pvJudge()` steps it back down on the athlete's own evidence; three clean
ones and it graduates. The trial note says where the number came from rather than claiming a test
the athlete never did: "Put back to X after a back-off I could not justify - on trial for now."

His own restore lands this way (`prov:true`), because his history predates the tag.

### And the hint line now states the rule
The line under a locked Save button still read "log a set, cardio or a finisher" - the c206
wording, contradicting the rule he set in the same conversation. It now reads "log a set of
today's session".

### New standing test stallmix.js - 13 checks
His exact history shape, plus: a genuine like-for-like decline with struggle still stalls; clean
flatness still does not; untagged history is not judged; new points carry their rep target; a card
that already ran the old repair is still eligible for the new one; an earned cut is not handed
back. Against c206: **8 FAILING CHECKS**.

A second harness fault, in `adfixtest`: `scenario()` reset `adFixStall`, `adFixed` and `genPlan`
between cases but never `mxProv`, so once one scenario left a lift on trial the next inherited it
and passed or failed for the wrong reason. Caught immediately by the proven-vs-unprovable pair,
which is the argument for adding checks in opposing pairs rather than one at a time.

One harness fault, caught by running it against c206: the first fixture set `c:1` on every point,
and the c179 struggle rule alone refuses that cut - so the headline check passed on the broken
build. His own cut predates the struggle rule, so the honest fixture is the one where struggle IS
recorded and the session kinds are mixed. That is the version that discriminates.

### Build
- BUILD c206->v207 (prefix change, see the convention note above); sw CACHE `card-v222-v207`. Training Card only.
- Release letter: yes.

## c206 - 2026-09-05 (FIELD - "I selected save session log for the empty day and it still saves the day?")

### c205 shipped the guard and the guard did not hold
He uploaded c205, tapped Save session to log on an untrained day, and it saved. The live card was
confirmed at c205 before looking any further - this was not a stale build.

`sessionHasWork()` counted cardio as work by reading `S.cardio.on` and `S.cardio.tacc`. The card
already documents, twelve thousand lines earlier, that **the cardio widget is ONE GLOBAL timer
with one config** - "The live cardio widget is TODAY's tool", the c126-era CARDIO, DAY-TRUE
comment. Nothing ever cleared it at the day roll. So the morning after any session with cardio in
it, `S.cardio.on` was still true, `sessionHasWork()` answered yes, and the empty day banked -
locking it, counting it toward the block, advancing the split. Exactly the bug c205 claimed to
have fixed, reached by a different door.

### The harness had the answer and I wrote the fixture wrong
`emptybank.js` built its "empty day" by zeroing the cardio state:

    EV('S.cardio.on=false; S.cardio.tacc=0; S.cardio.tstart=null; S.fin=null; ...');

That is not what an empty day looks like on a phone. On a phone it looks like yesterday's cardio
still sitting in the widget. **The fixture defined what "empty" meant, and defined the bug out of
existence** - 33 checks, all green, against a card that still had the fault. This is worse than
the vacuous check caught in c205: that one merely failed to discriminate, this one actively
constructed a world where the bug could not appear.

### HIS CORRECTION, and it is the real fix
Told what the guard was doing, he cut straight through it: *"the athlete doesn't need to do
cardio in order to complete and save a log they just need to complete their training day whatever
it consist of."*

That deletes the bug class instead of patching around it. **A session is the training day.** Cardio
and the finisher are things added TO a day, not what makes one - the card programs no cardio-only
session - so neither vouches for a day on its own. The first c206 attempt only made cardio's vote
narrower (stamped with today's date); it was still letting something that is not the training
answer the question. `sessionHasWork()` now asks one thing: has any set of today's day been
answered.

Not `sessionPct().done>0`, which was the first draft and is wrong - that counts finished
EXERCISES. An athlete four sets into the first movement has plainly trained, and it would have
refused their save. It now scans the day's set states for anything no longer `pend`, which is the
same test `recordHistory()` uses to decide a movement happened, so the guard and the history agree
on what "done" means. Set states are stored per day cell (`cyc|week|day`), so nothing here can be
answered by yesterday.

### And cardio still gets its day stamp - for a different reason
Kept, because it fixes a second real fault rather than the save: the widget is one global timer,
so the morning after a session it still read "Done today" with yesterday's minutes in it, and
those minutes rode into today's report. `cardioMark()` stamps the day cardio happened on, and on
a day roll boot clears the live widget. The migration for unstamped state runs BEFORE `S.when` is
rolled forward, on purpose: until that line runs, `S.when.date` still holds the day the card was
last used on, which is precisely the day that cardio was done. Saved logs are untouched - a banked
session keeps the cardio that went into its report.

### The original c206 fix - cardio belongs to the day it was done on
- `cardioMark()` stamps `S.cardio.d` (date) and `S.cardio.dk` (dayKey) wherever cardio actually
  happens: the Done-today toggle, starting the clock, stopping the clock, and logging a finisher.
  `S.fin` carries its own `d` from the moment it is offered.
- `cardioIsToday()` requires BOTH to match - date and day cell. `sessionHasWork()` counts cardio
  and the finisher only through it. Unstamped state does not vouch for today.
- **Boot clears it rather than merely ignoring it.** If the guard silently discounted yesterday's
  cardio while the widget still showed "Done today" switched on, the screen and the button would
  contradict each other and today's report would carry yesterday's minutes. On a day roll the
  live widget resets: `on`, `tstart`, `tacc`, stamps, and a finished `S.fin`.
- The migration for state written before the stamp existed runs **before `S.when` is rolled
  forward**, on purpose: until that line runs, `S.when.date` still holds the session date the
  card was last used on, which is precisely the day the unstamped cardio was done. No guessing.
- Saved logs are untouched. A banked session keeps the cardio that went into its report.

### emptybank.js - now 42 checks
The empty-day fixture is the real one: no sets today, last session's cardio still in the widget.
Added: stale cardio is not work, a stale finisher is not work, unstamped cardio is not assumed to
be today's, and the day roll itself proven through **a real second boot** - a second JSDOM seeded
with yesterday's state in localStorage via `beforeParse`, because a boot migration cannot be
tested any other way.
- Against c205 (the build he was running): **8 FAILING CHECKS**, naming his symptom.
- Against c204: 19.

One harness fault, and it is the same one twice: the new fixture lines called `cardioMark()`,
which does not exist before c206, so the run **crashed** on c205 instead of failing it - the
exact fault fixed in c205's own entry, reintroduced by my own setup code one build later. Every
fixture call to a function newer than the card under test is now guarded with `typeof`.

### Build
- BUILD c205->c206; sw CACHE `card-v222-c206`. Training Card only.
- Release letter: yes - and it says plainly that the last one was wrong.

## c205 - 2026-09-05 (FIELD - "I accidentally selected save session to log and it logged that day that is empty")

### The log entry was the smallest part of it
`saveSessionLog()` had no guard of any kind. One tap on an untrained day wrote the log, and then
everything downstream acted on it, because every one of those things asks `sessionLogged()`,
which only asks whether a log KEY exists:
- the split advanced past the slot - a session nobody did counted as done
- `blockDoneCheck()` would count it toward **Block complete**
- the streak counted it
- the day locked (`S.locked[dk]`) and was marked debriefed (`S.dbf[dk]`)

The engine passes themselves were already safe: `recordHistory()` bails on exercises with no set
states, so no false weight, rep or e1RM entered history. The damage was entirely in the
bookkeeping around the log.

### And the athlete's own remedy made it worse
`deleteLog()` removed the key and never touched `S.locked` or `S.dbf`. So an athlete who did the
sensible thing - delete the phantom log - was left on a **locked, empty day with nothing on
screen to explain it**, and `canRePass()` returned false because there was no longer anything to
repeat. The Unlock bar was still there, so nobody was permanently stuck, but his point stands:
"some people might panic."

### The fix
- **`sessionHasWork()`**, beside `sessionPct()`. Work is a completed set, cardio that actually
  ran (`S.cardio.on || S.cardio.tacc>0` - the same test `cardioDone` already used), or a finisher.
  Notes alone are not training; they stay in `S.notes`, so refusing the save loses nothing.
  It **fails OPEN** on purpose: if the check throws, the save proceeds. Refusing to file real
  work would be a far worse bug than the one being fixed.
- **The guard sits at the top of `saveSessionLog()`**, ahead of every engine pass and the write,
  because the passes read the session and the write locks the day. One guard covers all seven
  callers - button, debrief, finisher, wrap-up, `[data-stsave]`, `[data-debsave]` and Copy report
  - **and the coached roster too**, since a coached athlete's card runs the same function with
  `curLOGP()` switched. There is only one log-write path in the card.
- **The button says so before it is tapped**: `.savelog.nowork` (dashed border, `var(--dim)` -
  NOT dimmed opacity, which would fail the card's own contrast floor) plus a plain line beneath
  it. It stays bound and still answers a tap with a toast, because a bound control that does
  nothing observable is the dead-button fault `inert.js` exists to catch.
- **`deleteLog()` clears `S.locked`, `S.dbf` and a matching `S.debriefDone`** for the day the key
  belongs to, parsed with the card's canonical key regex. Set states are deliberately KEPT: if
  the delete was itself the mistake, the work is still on the card and can be saved again.

### New standing test emptybank.js - 33 checks
Banks nothing and insists nothing happened; banks real work and insists it did; deletes that log
and insists the day comes back. Cardio-only, clock-only and finisher-only days are each checked
as work, because "no completed sets" is not "did nothing" and a guard that blocked a real cardio
session would be worse than the bug. Runs the whole thing again as a coached athlete.
Against c204: **14 FAILING CHECKS**, reporting his symptom exactly.

Two harness faults caught, both by running it against the broken build on purpose:
- It **crashed** on c204 instead of failing - `sessionHasWork()` does not exist there, so the
  ReferenceError killed the run and hid every other finding. A `safe()` wrapper now fails the
  check and names the reason, and the run carries on to prove the rest of the damage. This is
  the fault class the 2026-09-04 audit named: a test that crashes on the broken build has not
  caught the bug, it has hidden it behind a stack trace.
- The screen check read the WHOLE body for "Nothing logged yet" and **c204 passed it** - that
  phrase already exists on the card, in the history panel's empty state. A check the build
  without the feature passes is not a check. Now scoped to the line the button renders, and the
  tap check reads `#toast` after clearing it, so it cannot pass on a stale message.

### One existing harness was wrong, not the card
`audit.js` banked its session by calling `saveSessionLog(true)` on a day with no sets logged - it
was relying on the very thing this build forbids. Its fixture now does the work first. Worth
recording: the guard caught a test that was banking phantom sessions to prove banking worked.

### Build
- BUILD c204->c205; sw CACHE `card-v222-c205`. Training Card only.
- Release letter: yes.

## c204 - 2026-09-05 (FIELD - "When selecting kg, the set button shows a large decimal number")

### Two faults under one report
1. **The per-set weight badge wrote the STORED value.** Storage is always pounds, and in kg mode
   `plateRound` snaps to a real kg grid then converts back, so the stored figure is a float exact
   only in kg: 176.36980974790205 lb is exactly 80.0 kg. Every other weight on the screen passes
   through `WV()` on its way out; this badge - and its aria-label - did not. So the athlete read
   the raw float.
2. **`WV()` rounded kg to the half-kilo.** An accessory stored at 100 lb displayed as 45.5 kg, 45 lb
   as 20.5, 225 as 102 - none of them a load a kg gym can build. His rule: common kg plate numbers,
   not uncommon ones.

### The fix
- The badge and its label go through `WV()` and carry the unit.
- `WV()` lands kg on the plate grid: **2.5 kg from 10 kg upward** (a 1.25 plate a side, the
  smallest pair in nearly every kg gym), half-kilos below that for light dumbbells. 62.5 is a bar
  load; 45.5 is not. lb passes through untouched.
- DISPLAY ONLY. Storage is not touched - switching back to lb shows the original prescription.
- Bodyweight and body-composition keep one decimal via `WV1`, on purpose: 90.7 kg is a body mass,
  not a bar load.

### New standing test kgplates.js - 11 checks
Reads every weight the athlete is asked to LIFT, on every screen, in kg: no long decimals, all on
the plate grid, the spoken label matches with its unit; known conversions land where they should;
lb is untouched; storage is untouched. Against the live c202 build it fails 5 ways, reporting his
badge exactly: `176.36980974790205`.

Two harness faults caught:
- The screen scan flagged "5 ft 9 . 90.7 kg" - bodyweight, one decimal by design. Narrowed to
  loads.
- My own expectation said 135 lb -> 62.5 kg. 135 lb is 61.2 kg, and the nearest 2.5 is 60. The
  card was right and the test was wrong.

### Build
- BUILD c203->c204; sw CACHE `card-v222-c204`. Training Card only.
- Fast suite 89 ALL PASSED (298s). Pre-deploy tier ALL PASSED (316s).
- Release letter: yes.

## audit, 2026-09-04 - c191 through c203, and the environment under it

No card change. BUILD stays c203, cache stays `card-v222-c203`. The only file touched is
newstate.js, extended for the fields added since the last audit and verified standalone.

### 1. Every hunk accounted for
`diff` of the original c182 against c203: 1078 lines, 86 hunks. Every build from c191 to c203 has
a changelog entry, in order, and the two tests-only changes (the CI fix, the earlier audit) are
recorded beside them. The edit master and the deploy build are BYTE-IDENTICAL once the 19 image
slots are stripped.

### 2. New state, end to end
newstate.js now also carries `S.seasonal` (c195) and a stranded `S.calcPos` from the draggable
era (c193-c200). All 22 screens and engine passes with every new field live: no internal errors,
nothing thrown. 13 mangled shapes on boot, all survive. The real backup/restore path brings every
field back - and clears the stranded calculator position on the first paint after restore, which
is the migration c200 promised.

### 3. Environment
node 22.22.2 - jsdom 24.1.3 / ^24.0.0 - canvas 2.11.2 / ^2.11.2 built from source, native render
verified. Workflow YAML parses, 10 steps. Manifest 90 declared / 90 on disk, none missing, none
unregistered, no duplicates. No stray files. All 92 .js parse.
Live repo at audit time: c202 (c203 not yet uploaded, expected).

### 4. The suite discriminates - two baselines
Against the ORIGINAL c182, the build this week started with:
    55 FAILING CHECK(S), exit 1  -  18 harnesses fail, 70 pass
    adundo assessed beacon calcfixed caldays deadref dupemuscle hdrlive leaktext maxapply
    newstate overlaylock provmax reportsend restlast seasontest setlaunch stimprofile
Against c199, the build he was holding mid-session:
    17 FAILING CHECK(S)  -  assessed calcfixed overlaylock newstate (manifesttest is a
    fixture artifact: the pulled file has no manifest.json beside it)
That second list is EXACTLY the set of fixes that landed after c199 - the row (c203), the fixed
calculator (c200), the overlays and the record prompt (c201-c202), and the calcPos migration.
Every harness written this session fails on the build that had the bug. Every harness that should
be indifferent passes on both. The suite got stronger, not just bigger.

### 5. How honest the suite is about itself
27 explicit `(fixture)` checks across 16 harnesses - each one refuses to let a test pass on an
empty screen, an unlocked day, a missing fixture. 16 harness faults were caught and recorded in
the changelog between c191 and c203: vacuous checks, proxies measured instead of the thing, tests
that crashed on the broken build instead of failing, checks that accused working code. Every one
was found before it shipped, by breaking the card on purpose or by the harness contradicting a
direct probe. That count is the most important number in this audit.

### 6. Known limits, stated rather than hidden
- iOS gesture handling cannot be reproduced here. Two "verified" drag fixes reached the gym
  broken. The feature was removed rather than guessed at a third time. jsdom is not an iPhone.
- The record prompt's Share button has no observable effect in jsdom in ANY state, so its
  reachability on a locked day could not be tested behaviourally; the structural half is pinned
  and the gap is recorded in c202.
- The full suite at `-j 6` died twice on this single-core, 4 GB box around harness 50. CI runs
  `-j 6` on a 4-core, 16 GB runner and has passed 17 times. Noted so nobody is surprised.
- Cloudflare counts opens only when online; the number is a floor.

### 7. What this session was
Seven field bugs, every one caught by him with a photo or a sentence, every one structurally
perfect and semantically wrong - the class no structural test sees. Four of them were the SAME
class: a hand-maintained list (overlay exemptions, record-prompt controls, settings launchers,
fill candidates) one entry behind reality. Each fix replaced the list with the rule where a rule
existed. Two harness families now read the screen the way he does (leaktext, inert) instead of
checking structure, and the pre-deploy tier carries the slow one. He asked for screenshot-driven
review; the honest answer given was that it works and should not be the plan, and the plan is
those two families.

## c203 - 2026-09-04 (the barbell row was assessed and never programmed)

### The question that found it
"Does the barbell Rower populate on the road ahead box?" It did not - and the table was honest.
The gap was upstream and much bigger than the table.

The card assessed FIVE main lifts, held a row max, and listed it in `MAXINFO` as driving
"Pull days". The starter block programmed FOUR. Both pull days opened with Cable Rows - an
accessory with no `maxKey` and no `pct`. So:
- the row max drove no working weight anywhere
- nothing ever tested it, so the adapt engine had no evidence and could never move it
- it sat at whatever setup guessed, forever, while the card told the athlete otherwise
- the pull days were the only days in the week with no anchored main lift
`rowmax` passes - it checks the row is ASSESSED, not that it is programmed.

Generated plans were always correct: every split from 3 to 7 days programs all five. It was only
the hand-written starter block that was short.

### His call
"The only reason I didn't add it deliberately before was because I personally prefer the row
machine over standing bb rows, but at a professional level, the bb row is an assessed main lift
and it should be in the engine." So: programmed as the main lift, with his own preference kept
one tap away rather than designed around.

### The fix
Barbell Row inserted as the OPENING exercise on both pull days, mirroring Bench exactly:
- Day B heavy: 4x5, pct [.783 .783 .817 .817 .85 .45], 3:00 rest
- Day E volume: 3x8, pct [.68 .68 .71 .71 .74 .42], 2:00 rest
`maxKey:'row'`, real warmup ramp, deload week, and a starting row max of 170 (80% of the block's
bench, plate-rounded) added to `PLAN.maxes`.
Subs lead with **Machine Row** and **Cable Rows** - the athlete who prefers either takes it in one
tap and keeps the percentage programming underneath.

### New standing test assessed.js - 9 checks
Pins the RELATIONSHIP, not the table: every lift in `MAXINFO` must be percentage-programmed in the
starter block AND in every generated split size, must reach The road ahead, and `MAXINFO`'s claim
that the row drives pull days must be true of an actual pull day. Plus: a machine/cable swap must
be offered on the programmed row, so the fix cannot be "correct" and unusable.
Against the previous build it reports 3 failures including the exact words of the problem:
"assessed but never programmed: row - that max is never tested and can never adapt".

Harness fault caught: the road-ahead check read `r.k` from `roadAheadRows`, which returns
`{name, max0, cells}` and no key - so it flagged ALL FIVE lifts as missing on a card where every
one was present, which would have buried the real finding under four false ones. Matched by
exercise name instead.

### Build
- BUILD c202->c203; sw CACHE `card-v222-c203`. Training Card only.
- Fast suite 88 ALL PASSED (234s). Pre-deploy tier ALL PASSED (291s).
- Release letter: yes.

## c202 - 2026-09-04 (FIELD - "Personal record prompts are also locked... That prompt isn't a threat")

His words: "Especially if that day's training is complete. No athlete should have to unlock the
page to share their progress." Correct on both counts, and the list proved him right twice over.

### What was there
The logged-day branch of lockGuard exempted `[data-prclose]`, `.pr-fx`, `.prdis`,
`.hifive-wrap` and `[data-hifive]` - and did NOT exempt `[data-prshare]`. Dismiss was reachable;
Share, rendered in the row directly above it, was not. Each control had been named one at a time
as somebody noticed it, which is the same rot as the overlay list fixed one build ago.

### The fix
`.prbar` - the container holding the records, the recap line, Share and dismiss - is exempt as a
UNIT. Anything added to the prompt later is covered without anyone remembering. The prompt only
renders BECAUSE the day is finished, so it can never be a risk to the session.

### An honest limit on the test
The structural half is pinned and discriminates: the guard must exempt `.prbar` rather than
naming controls, and that check fails on the previous build and passes on this one. The
BEHAVIOURAL half could not be built. In jsdom the share control produces no observable effect in
either state, on either build - no navigator.share, no clipboard, no link, no DOM change on an
unlocked day - so a differential cannot separate the guard swallowing the tap from the handler's
own `stopPropagation`. Recorded as a known gap rather than papered over with a check that would
pass either way.

Two harness faults caught getting there:
- The first record-prompt check used a raw stopPropagation probe and reported Share as DEAD on the
  FIXED card. The share handler calls stopPropagation itself, locked or not. Measuring a proxy for
  the thing rather than the thing - the fifth time that same mistake bit in one session.
- The check ran after the overlay census, which presses 66 settings controls for real; the prompt
  had been rendered away by then and the fixture reported "no .prbar rendered". Moved to a clean
  page, like the counter-check before it.

### Build
- BUILD c201->c202; sw CACHE `card-v222-c202`. Training Card only.
- Fast suite 87 ALL PASSED (239s). Pre-deploy tier ALL PASSED (281s).
- Release letter: yes.

## c201 - 2026-09-04 (FIELD - "The mail is locked. I'll open it then the close button is dead, so is the clear button. Terms & conditions is also dead")

### The fourth bug in this family
`lockGuard` keeps a list of things that float OVER the session and must never be locked. It had
been extended three times, carried a comment reading "Third bug in this family - hence one rule,
on top", and still named its exemptions BY HAND - nine of them - missing `#mailGate`, `#termsGate`
and `#discGate`. So on a logged session or a previewed day the athlete could open mail and then
not close it. Trapped behind a modal by the guard that exists to protect them.

A hand-maintained list of "overlays" is always one entry behind the next overlay somebody adds.
Same rot as `setbtns`' launcher list and the fill picker's name check.

### The fix: the principle instead of the list
Every overlay the card opens - mail, terms, the disclaimer, settings, the install sheet, the
calculator, Bulk, the error and storage bars, the boot splash - is a BODY child sitting beside
`#app`. The session being locked IS `#app`. So:

    var host=t.closest('body > *');
    if(!host || host.id!=='app') return;

Nine named selectors become one rule, and the next panel anybody builds is right without anyone
remembering. `.footer` still needs naming because it lives INSIDE `#app`.

### A second, subtler bug the new harness found on its own
`!host` - a DETACHED target - must be exempt too. Tapping "I understand" on the disclaimer fires a
capture-phase listener that accepts and REMOVES the gate, so by the time lockGuard runs the target
has no body ancestor and `closest()` returns null. Treating that as session content meant the
guard swallowed the very tap that dismissed the overlay. Only reproducible on a previewed day.

### New standing test overlaylock.js - 15 checks
Mail, terms, the disclaimer and settings, across a live day, a logged session and a future
preview. Written as a DIFFERENTIAL: a control is only reported if it works on a live day and is
swallowed once the lock is on. Plus a counter-check that the session itself stays read-only, and a
check that the guard exempts by what a thing IS rather than by a list of names. Against the build
in his hand it names his complaint exactly: `#mailX` and `#termsX` swallowed.

FOUR HARNESS FAULTS CAUGHT WHILE WRITING IT:
- Absolute instead of differential: reported 59 dead controls in settings ON A LIVE DAY, where
  nothing is locked. The sheet's own wrappers call stopPropagation legitimately. Measuring a proxy
  for the thing again.
- Keyed controls by id AND index, so a control at a different position did not line up with
  itself between states; `#discOk` was accused on that basis before the real bug was found.
- The counter-check ran LAST, after the census had pressed 66 settings controls for real and
  changed the card underneath it - "no session control found", a fixture failing silently. Moved
  to the front, on a clean page.
- The break test used `&& false`, which neutered the condition and made the card look correct.

### gametest.js repaired, not worked around
It asserted the game's exemption by grepping `String(lockGuard)` for the text "grunHost". Removing
the list broke it on a card that works perfectly - a test pinning an implementation detail blocks
the fix that removes the detail. It now dispatches a real tap inside the game on a locked day and
checks the guard does not swallow it, with a fixture check that the day really is locked. The game
turns out to be protected twice over (`#grunHost` also carries `.lockfree`), which is why removing
the new rule does not expose it - noted so nobody reads that check as stronger than it is.

### Build
- BUILD c200->c201; sw CACHE `card-v222-c201`. Training Card only.
- Fast suite 87 ALL PASSED (264s). Pre-deploy tier ALL PASSED (299s).
- Release letter: yes.

## c200 - 2026-09-04 (FIELD - "the calculator is still stuck", and the whole screen was following his finger)

### Two reports, one cause
"Bro the calculator is still stuck" - on c199, which already carried the c198 fix. And: the entire
screen was tracking his finger while he only meant to move the button.

Both come from dragging, and both fixes were mine:
- **c193**: `calcPaint()` repositioned the button on every `render()`, and the card re-renders
  constantly, so it was yanked home mid-drag. The magnet.
- **c198**: I moved the move/up listeners to the DOCUMENT so the drag could follow a finger past a
  46px target. When iOS decides a gesture is a scroll it may never deliver a pointerup - the drag
  stays latched, and from then on every touch anywhere on the screen moves the button. I made that
  trade without thinking about the failure mode.

Both shipped after a full green suite. **jsdom is not an iPhone and no harness here can be one** -
it has no real gesture handling, so a test written against it can only agree with the code. Two
"verified" fixes reached the gym broken for exactly that reason.

### The decision
Asked rather than guessed a third time. His call: "Just keep it locked on the side but somewhere
where it's not in the way." Dragging is REMOVED - not disabled, removed: `calcDragWire`,
`calcSnap`, `calcPlace`, `calcPos`, `CALC_DRAGGING`, the edge attribute and the drag CSS are all
gone. The button is fixed by stylesheet at `right:10px; bottom:calc(96px + safe-area-inset-bottom)`
- low on the right, clear of the bottom bar and the home indicator. `touch-action:none` went with
it; it only ever existed to serve the drag.

Anyone stranded by the old drag has `S.calcPos` deleted on paint, so a button pinned in a corner
puts itself back without the athlete doing anything.

### calcdrag.js retired, calcfixed.js in its place - 14 checks
A test for a feature that no longer exists is worse than none. The replacement pins the ABSENCE:
no drag wiring on the button, none of the machinery left in the source, the position holds across
three re-renders, nothing writes an inline position, it sits on an edge and clears the safe area,
a tap still opens and closes the calculator, and a stored legacy position is cleared rather than
honoured. Against the c199 build in his hand it fails 7 ways and names his complaint in its own
words: `document is listening for: mousemove, touchmove`.

THREE FAULTS CAUGHT IN THE NEW TEST AND IN MY OWN FIX, by the test itself:
- It flagged `document` listening for `pointerup` as a drag leak. That is `audioWake` - passive,
  pre-existing, nothing to do with dragging. A false accusation of working code; narrowed to MOVE
  events, which is what actually made the screen follow a finger.
- `touch-action:none` was still in the CSS after my edit. Removed.
- The `S.calcPos` migration was inside the `if(!fab)` creation branch, so it only ran when the
  button did not yet exist - which is never, on a re-render. Anyone already stranded would have
  stayed stranded. Moved out to run on every paint.

### Build
- BUILD c199->c200; sw CACHE `card-v222-c200`. Training Card only.
- Fast suite 86 ALL PASSED (248s). Pre-deploy tier ALL PASSED (287s).
- Release letter: yes - it says plainly that it was tried twice and shipped broken twice.

## c199 - 2026-09-04 (the card counts opens - and the Terms sentence it would have falsified)

### Why
He is building Deadstop for the public and wants to know whether anyone is using it. GitHub Pages
gives no visitor numbers at all, so the count has to come from the card. Cloudflare Web Analytics:
free, cookieless, no fingerprinting, no cross-site tracking, one script tag, and it works on a
site that is not proxied through Cloudflare - which matters, because the card stays on GitHub
Pages and must not move (a new URL would break every home-screen shortcut already installed).

### What was nearly shipped quietly, and was not
Terms section 4 read, word for word: "We do not transmit them, we cannot see them, and there is no
analytics or tracking in this card." Installing the beacon makes that sentence FALSE. The card's
standing with the people using it rests on that paragraph. So the disclosure is part of the
feature, not a follow-up:
- s4 now states plainly that opens are counted, that the count is anonymous - no cookie, no
  fingerprint, no cross-site tracking, no way to tell one person from another - that it carries
  the page and nothing else ("not a lift, not a weight, not a name"), that it does not work
  offline so it undercounts, and that blocking it changes nothing about the card.
- s6 lists Cloudflare Web Analytics alongside GitHub Pages and YouTube, noting it receives an IP
  to count the visit and, by its own account, does not track individual visitors or use cookies.
- The core promise is untouched and still asserted: no third party ever receives training data.

### The beacon
`<script type='module' src='https://static.cloudflareinsights.com/beacon.min.js'
 data-cf-beacon='{"token": "..."}'>` before `</body>`. The token is a public site id - it sits in
readable HTML by design and grants nothing. Hostname registered as `thundermeadows.github.io`, not
the full URL: his first attempt pasted `https://thundermeadows.github.io/training-plan/` into the
hostname box and got "No active websites found", which reads like a rejection and is really a
malformed hostname.

### New standing test beacon.js - 12 checks
Two failure modes, both pinned:
1. THE PAYLOAD GROWS. The tag may carry the site token and NOTHING else, the token must look like
   a plain hex site id rather than anything derived from a person, and the tag must be static -
   not assembled from state at runtime. Verified failable by adding `uid` and `lift` to the
   payload.
2. THE PROMISE GOES STALE. If the beacon is present, Terms may not claim there is no analytics,
   must disclose the count, must say what the count excludes, and must name Cloudflare in s6.
   Verified failable by restoring the c198 sentence.
The fixture check is deliberately two-way: if the beacon is ever REMOVED, the test says so, so the
Terms text cannot be left describing a count that no longer happens.

### Build
- BUILD c198->c199; sw CACHE `card-v222-c199`. Training Card only.
- Fast suite 86 ALL PASSED (270s). Pre-deploy tier (deadsweep + inert) ALL PASSED (309s).
- Release letter: yes - it tells athletes directly, and says the old sentence was rewritten rather
  than left to rot.

### Still to come
The scheduled Action that reads the count and opens a GitHub Issue each morning. That needs a
Cloudflare API token with Account Analytics read - which IS secret, goes in GitHub repository
secrets, and never near the card. Deliberately left until numbers are visible in his dashboard.

## c198 - 2026-09-04 (FIELD - "I'm trying to move the calculator but it's magnetically impossible to pull away from the corner")

### Both faults are mine, from c193
1. **The magnet.** `calcPaint()` called `calcPlace()` unconditionally, and `calcPaint()` runs on
   every `render()`. The card re-renders constantly - a rest tick, a save, almost any touch - so
   several times a second, MID-DRAG, the button was repositioned to its saved spot. Drag it away,
   it snaps home, over and over.
2. **It stopped following the finger.** `pointermove`/`pointerup` were bound to the BUTTON, which
   is 46px across. The moment the finger left it the events stopped unless pointer capture
   happened to hold. The drag then never completed, nothing was saved, and the next render put it
   back. Together: a button welded to a corner.

### The fix
- `CALC_DRAGGING` flag; `calcPaint()` will not reposition while a drag is live.
- move/up listeners moved to the DOCUMENT, so the drag follows the finger anywhere on screen.
- touch fallback added for browsers without PointerEvent, reading `touches[0]`.
- `preventDefault` only when the event is cancelable, so a passive listener cannot throw.

### Why calcdrag.js passed on a broken build
It dispatched every move ON THE BUTTON - which is exactly what a real finger stops doing after a
few pixels - and it never re-rendered mid-drag. So it exercised neither fault. A harness that
drives the happy path the code was written for proves nothing; it agreed with my code instead of
with the phone, the same failure as the report senders.

Repaired: moves now go to the document, and `render()` is called in the middle of the drag the way
the card constantly does in use. Two new checks: the button must sit under the finger after a
mid-drag re-render, and it must land where it was dropped rather than back where it started.
Against the c197 build he was holding it fails 9 ways, reporting the exact corner -
`left=calc(12px + safe-area-inset-left) top=6%`.

### Build
- BUILD c197->c198; sw CACHE `card-v222-c198`. Training Card only.
- Fast suite (85 harnesses) ALL CHECKS PASSED in 263s.
- Release letter: yes.

## c197 - 2026-09-04 (FIELD, with a photo - "I get to this page and from here I try to click any and all the buttons and none direct me anywhere. Nothing happens.")

### The photo was the whole diagnosis
Panel open on a closed session, "I have a question" SELECTED, "Hi" typed in the box. So taps were
reaching the panel and the kind chips worked. Only the four SEND buttons were dead. That split -
state changes fine, platform calls dead - is what named the cause.

Four separate silent failures behind one symptom:
1. **Email it / Text it**: `location.href = 'mailto:...' / 'sms:...'`. An iOS app opened from the
   home screen runs in standalone display mode, where that assignment is IGNORED. No navigation,
   no exception - so the `catch` never fired and even the copy fallback never ran.
2. **Share**: fell back to `alertToast`, and `.toast` ends its declaration block with
   `z-index:70` while `.rpt-wrap` sits at 240. The confirmation rendered UNDER the sheet he was
   reading.
3. **Copy**: same buried toast, and its last-ditch "here is the text, select it yourself" textarea
   is `z-index:99` - also underneath.
4. **Copy** also skipped `tryCopy()`, the helper that carries the execCommand fallback, and went
   straight from a failed async clipboard to that buried textarea.

### Why c194 did not fix it, and why setlaunch said it was fine
c194 fixed a real bug - the panel opening behind the settings sheet - and `setlaunch` proved the
buttons were BOUND. Bound is not working. A handler that runs, does nothing the athlete can see,
and swallows its own failure is indistinguishable from a dead button. jsdom has no standalone mode
and no share sheet, so every harness agreed with the code instead of with the phone.

### The fix
- All outbound handoffs go through a real `<a>` element click - the one form iOS honours from a
  home-screen app - instead of a location assignment.
- Email and Text ALSO copy the report, so a blocked handoff still leaves something to paste.
- Copy routes through `tryCopy()` and answers either way, including on failure.
- Share falls back to a visible copy when there is no share sheet, and a CANCELLED share still
  leaves the report on the clipboard.
- Every button now reports ON ITSELF - inside the panel, above everything, whatever the stacking.
- `.toast` z-index 70 -> 300 and the fallback textarea 99 -> 300, both above the panel at 240.

### New standing test reportsend.js - 13 checks
Simulates a home-screen app: location assignment is swallowed, anchor clicks are recorded,
clipboard is captured, share is removed and separately made to reject. Asserts each button hands
off by link, copies as a backstop, and changes its own label. Plus: the toast and the fallback box
must out-stack the panel. Against the live c195 build in his hand it fails 8 ways.

THREE HARNESS FAULTS CAUGHT WHILE WRITING IT - the worst run of the week:
- The z-index reader walked cssRules and compared selectorText: it returned null on BOTH builds,
  so all three stacking checks could never fail.
- Rebuilt against the raw stylesheet, it then took the FIRST z-index in a block. CSS takes the
  LAST. It reported 300 for a rule ending in `z-index:70` - it would have blessed the exact bug.
- And that is how it caught MY OWN BAD FIX: I had prepended `z-index:300` to a block that already
  ended with `z-index:70`, so the toast was still buried. The corrected reader failed the build
  and the real fix went in.

### Build
- BUILD c196->c197; sw CACHE `card-v222-c197`. Training Card only.
- Full suite (86 harnesses) ALL CHECKS PASSED in 283s.
- Release letter: yes - it is the button athletes use to report the others.

## c196 - 2026-09-04 (FIELD - three at once: calendar blank, splash broken, report still not working)

He asked "what is happening why all these issues?" - a fair question. Three different answers.

### 1. CALENDAR BLANK - old bug, mine to have found sooner, not caused by this week
`calKeyDate` sliced `LOGP.length` off a log key - 12 characters, for 'nova-sc-log:'. The Training
Card's personal logs have lived under `TLOGP` ('tc-log:', 7 characters) since the two cards were
split apart on the shared origin. Chopping 12 off a 7-character prefix ate five characters of the
DATE, the split produced 4 parts where 5 are required, every key returned null, `calIndex()` came
back `{}` and the month drew empty. Reproduced against c182 as well: it has been broken for every
Training Card athlete since the split, in every build I shipped this week without noticing.
NOTHING WAS LOST - the sessions were always in storage, correctly keyed. Only the calendar's
reader was wrong.

Fixed by cutting at the last colon rather than counting characters: correct for `tc-log:DATE-...`,
for a coached athlete's `nova-sc-log:<id>:DATE-...`, and for whatever the namespace becomes next.
`sessionLogged()` and `cycleHasLogs()` make the same bad slice but survive it by luck - their
regexes are anchored to the end of the key - so they are left alone and pinned by the new test.

Why `caltest` never saw it: it builds fixtures through the card's own writers and asserts the
calendar's PROJECTION. It never asserted that a real banked key parses back out. A test of the
output that never checks the input.

### 2. SPLASH HALF OFF THE EDGE - mine, from c195, yesterday
The seasonal build added `#bootSplash .bs-wrap,.bs-word,.bs-line{position:relative;z-index:1}` to
lift them above the holiday art. But `.bs-word` and `.bs-line` are `position:absolute` BY DESIGN;
forcing them relative dropped them into #bootSplash's flex row beside the mark, so three items
shared one row and the logo was pushed half off the left edge. Only `.bs-wrap` is an in-flow flex
item. Now only `.bs-wrap` gets `position:relative`; the other two get `z-index` and nothing else.

Caused by changing shared layout CSS to solve a stacking problem, and shipped because no harness
read the splash's layout. Now one does.

### 3. REPORT PANEL - NOT REPRODUCED, and said so rather than guessed
Driven on the LIVE c195 file from both launchers (Settings and the day footer): the panel opens,
the sheet closes, all three kind chips are bound and switch `S.rptKind`, and rptShare / rptMail /
rptSms / rptCopy all carry handlers. The c194 fix is present and working in the harness. So
whatever he is hitting is device-side and I do not have it yet. Service worker ruled out: it is
network-first for the page with skipWaiting and an activate that purges old caches, and the live
BUILD/CACHE read c195/c195 - he IS getting the deploys. Asked him for one specific detail rather
than shipping a third speculative fix.

### New standing test caldays.js - 13 checks
Banks a real session through the card's own writer and asserts the key parses back to TODAY, that
calIndex contains it, and that all three log namespaces parse. Pins sessionLogged/cycleHasLogs.
Splash: reads the CASCADE, not getComputedStyle.

TWO HARNESS FAULTS CAUGHT, both of the kind that make a red build look green:
- `JSON.parse(JSON.stringify(undefined))` threw on a BROKEN build, killing the harness before the
  splash checks ran - so the splash half silently "passed" on the very build that was broken.
- The splash check first used `getComputedStyle`, which jsdom resolves without specificity: it
  reported `absolute` on the broken build too, so it could never have failed. It now reads the
  stylesheet rules, which is what a browser acts on.
Verified failable: against live c195 it reports both bugs; against c182 it reports the calendar.

### Build
- BUILD c195->c196; sw CACHE `card-v222-c196`. Training Card only.
- Full suite (85 harnesses) ALL CHECKS PASSED in 289s.
- Release letter: yes - and it says plainly that no training was lost.

## c195 - 2026-09-04 (his ask: seasonal colour, four holidays, tone change only)

### The feature
During October, November, December and January the card wears a little of the season: Halloween,
Thanksgiving, Christmas, New Year. Whole months; the calendar is one table, `HOLIDAYS`, and it
holds only the four he asked for. Off is a chip in Settings under Appearance (`S.seasonal`, on
unless turned off).

### Design
- A TONE LAYER, not a theme. `applyHoliday()` runs at the end of `applyTheme()` and overrides
  three variables only - `--amber` (the accent), `--amber-ink`, and a faint `--panel2` tint - with
  a day and a night value each. The athlete's theme and light stay underneath untouched: Iron in
  December is still Iron.
- **The go and stop colours are never touched.** `--green` and `--red` carry meaning everywhere
  on the card; a holiday must never borrow one. Pinned.
- Every holiday over every theme in both lights is held to the SAME contrast floors `themetest`
  holds the themes to (amber-ink/amber 3.0, amber/panel 3.0, chalk/panel2 10, dim/panel2 4.5).
  Christmas is gold over an evergreen tint rather than red for exactly that reason.
- Splash art slot: `HOLIDAY_ART[id]` is a list of `{u,x,y,w}`; `bootArtHTML()` floats them behind
  the mark and the word with a slow drift, `aria-hidden`, `pointer-events:none`, reduced-motion
  honoured. Empty lists render nothing - the splash is byte-for-byte what it was until his images
  land. Contract for the images: WebP, transparent, 200-400px long side, 3-6 per holiday.

### New standing test seasontest.js - 16 checks
Twelve boundary dates resolve to exactly the right holiday and nothing else; only the four ids;
no override of green/red/bg/chalk/panel; contrast across 5 themes x 2 lights x 4 holidays; the
layer sits over Iron and Off restores Iron's own accent byte-for-byte; the Settings chip works by
tap; the splash draws two images when given two and nothing when given none; July shows no layer
and no art even when art exists.

Fixture fault caught: BASE was read from the computed style, which already wore Iron-night at
boot, so Coach's empty day variant inherited night ink over the holiday's light day panels and
the contrast check reported a palette fault that was a fixture fault. It now reads the
stylesheet's own :root, the way themetest does. Verified failable four ways: repaint the go colour,
an unreadable night accent, an Off switch that does nothing, a window that overruns into November.

### Build
- BUILD c194->c195; sw CACHE `card-v222-c195`. Training Card only.
- Full suite (84 harnesses) ALL CHECKS PASSED in 266s.
- Release letter: yes.

## c194 - 2026-09-04 (FIELD - "The report a problem button works but all the buttons under Send a report do not work. They're dead")

### What was happening
`#reportBtn` lives in Settings. Its handler set `S.rptOpen=true` and rendered - and never closed
the settings sheet. The report panel is rendered INSIDE #app; the settings sheet lives in its own
body-level host at z-index 200. The panel carries z-index 240, but #app's stacking context caps
it below the sheet whatever number it has. So the panel drew, visibly, behind the sheet's
backdrop, and every tap on Share / Email / Text / Copy / the kind chips / Close landed on the
sheet instead. Dead, exactly as reported.

### Why setlaunch passed
`setlaunch` exists for this: "every launcher in settings, by real click, lands above the sheet or
closes it first." Its check for this launcher was `zOf(panel) > SHEET` - it compared z-index
NUMBERS. 240 > 200, green. The check measured the number and not the reality, on the one launcher
where the number lies. The same vacuous-green pattern as the deadsweep body-comparison and the
provmax rounding coincidence: a harness that asserts a proxy for the thing rather than the thing.

### The fix
One line in the handler: `SET_OPEN=false; settingsSync();` before `render()`. The athlete tapped
Report; they are leaving settings. The panel now draws on the day with nothing above it.

A wrong turn on the way, recorded because it explains a line of code: `#reportBtn` was on the
sheet's `SET_SKIP` list and I removed it, assuming the skip was why it went untested. It was not -
the skip is there because the sheet WRAPS every bound control with `SET_BUSY=true` around the
original handler, which suppresses render(), and then calls settingsRefresh(). Wrapped, the report
launcher's render never ran and the panel never drew at all ("no panel" in the harness). It is
back on the list, with a comment saying why, and setlaunch's coverage was never the skip list -
that is the CARD's list, not the harness's.

### setlaunch.js repaired
The report check now asserts reachability: the panel exists AND (the sheet has closed OR the panel
is a body-level sibling of the sheet with a higher z). Then it PRESSES a kind chip and checks
`S.rptKind` changed, and checks every send button rendered (rptShare/rptMail/rptSms/rptCopy) has
a handler bound. Against the original c182:
    FAIL  Report a problem is reachable ...  <-- sheet still open and the panel is inside #app - every button on it is dead

### Build
- BUILD c193->c194; sw CACHE `card-v222-c194`. Training Card only.
- Full suite (83 harnesses) ALL CHECKS PASSED in 264s.
- Release letter: yes - it is the one button that lets athletes report the others.

## c193 - 2026-09-03 (his ask: the calculator button can be dragged to any edge)

### The feature
Press and drag the floating calculator button; on release it snaps to the nearest screen edge -
left, right, top or bottom - at the point along that edge where it was dropped, and stays there.
A tap still opens the calculator; a drag never does. The calculator panel opens on the same side
as the button.

### Design choices
- Position is stored as an EDGE and a FRACTION along it (`S.calcPos={edge,at}`), not a pixel
  pair. It means the same thing on a phone held either way and after the keyboard or the rest
  screen changes the viewport height. Clamped to 6%-94% so a corner drop cannot push it off.
- Lives in S, so it survives render, reload, and backup/restore with no extra plumbing.
- Tap-vs-drag uses the same 8px rule Bulk's drag already uses, and the same pointer/mouse event
  fallback, so jsdom tests and phones exercise one path.
- Follows the finger freely while held (no snapping mid-drag), snaps on release. `touch-action:
  none` on the button so a drag does not scroll the page under it.
- Safe-area inset on whichever edge it lands on. A mangled stored position falls back to the
  default (right, 58%) rather than breaking the button.

### New standing test calcdrag.js - 13 checks
Tap opens; drag to each edge lands on that edge and does not open; the drop point is respected;
corner drops are clamped; a re-render does not move it; the position is in storage; four mangled
positions fall back cleanly. Verified failable three ways: drop the drag-is-not-tap check, drop
the save, drop the clamp. Harness fault caught: a null-position read crashed the save-break run
instead of failing it - guarded.

### Build
- BUILD c192->c193; sw CACHE `card-v222-c193`. Training Card only.
- Full suite (83 harnesses) ALL CHECKS PASSED in 259s.
- Release letter: yes.

## c192 - 2026-09-03 (FIELD, with a photo - "This is the last set done sheet. It's still counting down even if there isn't a set to follow.")

### What he saw
Straight-Arm Pulldown, third and final set logged. The rest screen: a 1:22 countdown under
"REST - 1:30 PRESCRIBED - ISOLATION", then in its own words "last set done. Next exercise when
ready", then a +30s button. Counting down to nothing, and saying so.

First diagnosis was wrong: I read "the timer starts over" as the count-UP after GO and asked him
to confirm. He sent the photo instead. Recorded because the wrong guess cost a round-trip.

### What was actually happening
The rest clock paces the gap between sets OF THE SAME EXERCISE - that is what "prescribed" means.
`lastCompletion()` returns the most recent logged set and its rest target, and nothing asked
whether a set actually followed. So after the LAST set:
- the countdown ran, to a set that did not exist
- `scheduleRestBeeps` booked the ten-second warning and the GO bell for it - 42 oscillators in
  the harness
- the "Still resting - tap again to log set 1 early" guard fired on the FIRST set of the NEXT
  exercise, scolding the athlete for jumping a rest that was never real
The screen had already worked out and printed "last set done"; the clock just did not read it.

### The fix
`restIsLast(b)` - one question, asked in one place: `restNextTarget(b).kind!=='set'`. A superset
partner with a set still pending is NOT last; that hand-off rest is real and unchanged.
When last:
- clock reads Done; caption "<EXERCISE> - ALL SETS LOGGED"; mini chip reads Done
- no beeps booked (and any already booked are stopped), no ten-second glow, no +30s, no breathing
  ring, no "Bulk wants to run" - the rest of the screen is unchanged: the fix-it panel for the set
  just logged, and "Next exercise -> hold" / "Day done" exactly as before
- the still-resting guard treats a last-set rest as not resting
Beginner mode gets the same: "Done - <exercise> done. Move on when you are ready."

### New standing test restlast.js - 15 checks
Both halves pinned. Between sets: countdown, +30s, guard all still present. After the last set:
Done, no clock, no extension, no glow, no oscillators, fix-it panel present, next-exercise control
present, next exercise logs on one tap. Superset partner with work left: still counts down.
Against the original c182 it reports his photo almost verbatim:
    2:55 REST - 3:00 prescribed - main lift - Bench Press - last set done. Next exercise when ready. +30s
plus the two things he could not see: 42 oscillators scheduled, and the next exercise's first tap
swallowed by the rest guard.

Harness fault caught: the first version CRASHED on the original build (ReferenceError on the new
helper) instead of failing. Guarded, same as leaktext this morning; the fixture checks now fail
with a sentence.

### Build
- BUILD c191->c192; sw CACHE `card-v222-c192`. Training Card only.
- Full suite (82 harnesses) ALL CHECKS PASSED in 289s.
- Release letter: yes - credits him for spotting it.

## c191 - 2026-09-03 (FIELD - setup step headed "undefined")

### What he saw
The training-rhythm setup step - "The card runs it / I run it" - headed with the word
"undefined". Photographed off his screen.

### Where it came from
The setup heading was an inline object literal indexed by step name, `{welcome:'...', goal:'...',
...}[st]`. `ONB_STEPS_FULL` gained `rhythm` in c169. The heading map never did. `{...}['rhythm']`
is undefined, and that is what the h1 drew - for every new athlete, on every setup, for 22 builds.
Nothing threw. The DOM was complete. The step worked. Only the words were wrong.

The same map also carried headings for `place`, `days`, `pain` and `limits` - steps that no longer
exist. `pain` is a leftover from before the card stopped asking what hurts (medneutral). Two
tables that must agree, drifting apart in both directions: the deadref class, in a place deadref
was not looking.

### The fix
`ONB_HEAD`, declared immediately beside `ONB_STEPS_FULL` so the two cannot drift unseen, with one
entry per step and nothing else. The rhythm heading is "Who picks your session?", matching the
Settings label for the same choice. The four dead headings are gone.

### New standing test leaktext.js
The class, not the instance: no screen may ever show the athlete a JavaScript value. Every setup
step (walked under BOTH rhythms, since Guided never draws `weekdays`), every main tab, every
overlay, a logged day, the adapt panel with entries, a max on trial - the visible text must never
contain undefined, NaN, null, or [object Object]. Plus the two tables held to each other directly.
Against the original c182 it reports exactly what he photographed:
    [guided] step "rhythm" heading reads "undefined"

TWO HARNESS FAULTS CAUGHT WHILE WRITING IT:
- It indexed `ONB_STEPS_FOR()` - the per-athlete list, which drops `weekdays` under Guided - with
  positions from `ONB_STEPS_FULL`. Index 13 of a 13-step list read an empty heading and reported a
  card fault that did not exist. It now walks the list the card actually uses.
- On the original build it CRASHED (ReferenceError on ONB_HEAD) instead of failing. A harness
  that dies on the bug it exists to catch is the worst kind of red. Guarded; it now fails cleanly.

### Why no earlier harness saw it
Every existing harness checks structure - elements present, handlers bound, state correct. None
read the words. A heading of "undefined" is structurally perfect.

### Build
- BUILD c190->c191; sw CACHE `card-v222-c191`. Training Card only.
- Full suite (81 harnesses) ALL CHECKS PASSED in 287s.
- Release letter: yes - and it says plainly that it was the card's placeholder, not the athlete.

## CI fix, 2026-09-03 - the workflow assumed a folder a phone cannot upload

### What he hit
    Run npm install ... with working directory '.../training-plan/tests'. No such file or directory
He added tests.yml and the run died at Install. `tests/` did not exist in the repo - and could
not, because GitHub's web upload does not take folders from a phone. That is the SAME constraint
that keeps the deploy zip flat, and the workflow ignored it. My miss.

### The fix
The suite now arrives as ONE file, `deadstop-tests.zip`, uploaded at the repo root next to
`index.html`. A new first step, "Locate the suite", unpacks it into `tests/` on the runner. A
`tests/` folder already in the repo wins if it holds a run.js. Neither -> a plain sentence and a
red cross, not a shell error about a missing directory.

Verified against a simulated copy of his repo, running the step verbatim:
    zip at the root                 -> "Unpacked deadstop-tests.zip -> tests/ (82 harness files)",
                                       and run.js with no argument then finds index.html one level up
    no zip, no folder (his case)    -> "::error:: ... Upload deadstop-tests.zip next to index.html", exit 1
    the DEPLOY zip under that name  -> "::error:: does not contain run.js - is it the tests zip, or the deploy zip?", exit 1
    two versions left lying around  -> warning, uses the newest by name, carries on

The zip is now shipped under the stable name `deadstop-tests.zip` so each upload replaces the last.

## audit, 2026-09-03 - every change from c182 to c190, and the environment under it

No card change. BUILD stays c190, cache stays `card-v222-c190`.

### 1. Every hunk accounted for
`diff orig/index.html deploy/index.html`: 609 lines, 42 hunks. Each hunk was mapped to the
changelog entry that introduced it - probation engine, header exemption, per-item undo, ledger,
VOL_PICK, STIM, four library rows, Dead Hang, the data-wkv removal, the MAX-tab controls. Nothing
unexplained, nothing stray.

### 2. Edit master and deploy build are the same code
The lite master was patched in parallel with the deploy build every time today. Stripping the 19
image slots (placeholders in the lite copy, inlined payloads in the deploy) leaves the two files
BYTE-IDENTICAL. Next session's edit master is trustworthy.

### 3. New state, end to end (new standing test newstate.js)
Every field added today - S.mxProv, adLog kinds prov/provok and the `undone` mark, `stim` on a
card-added fill, `t:1` on a history entry - was tested where it was built. This asks whether it
survives everything else:
- all 22 screens and engine passes drawn with every new field live at once: no internal errors,
  nothing thrown
- 11 mangled shapes on boot (mxProv as a string / null / array, hollow adLog entries, `undone` as
  a number, a fill's `stim` as an object, junk history with `t` on it, mxTouched null): all 11
  boot, render and save. Errors the card catches through oops() are correct behaviour; uncaught
  ones would not be, and there were none.
- the REAL backup/restore path (`backupAll` payload -> localStorage.clear -> `restoreBackup`):
  every new field comes back intact. A field that works in its own feature and vanishes in a
  restore is exactly the bug a green suite ships.

### 4. Environment
node 22.22.2 - jsdom 24.1.3 against declared ^24.0.0 - canvas 2.11.2 from source against
declared ^2.11.2, native render verified. Workflow YAML parses: 1 job, 8 steps, 3 triggers.
run.js manifest matches disk exactly (80 declared, 80 present, none unregistered after newstate
was added). No stray temp files in the package. All 82 .js files pass `node --check`.

### 5. Full suite
80 harnesses, ALL CHECKS PASSED in 250s.

### 6. The suite discriminates
The same 80 harnesses run against the ORIGINAL c182 - the build the day started with:
    15 FAILING CHECK(S), exit 1
    fails:  adundo  deadref  dupemuscle  hdrlive  maxapply  newstate  provmax  stimprofile
    passes: smoke  orphantest  lockaudit  crossrestore  restoreflow  safetytest  setlaunch
            releasetest  buildsync
Every harness written today fails on the build that had the bug, and every harness that should
be indifferent to today's changes passes on both. The suite got stronger, not just bigger.

## c190 - 2026-09-03 (per-item adapt undo, and the provenance ledger caught up)

### The problem
Four things now move a max on their own: a layoff cut, a stall reset, the rate mover, and a
probation step. `adaptUndo()` reversed only the batch sharing the most recent DATE, so a change
the athlete disagreed with became unreachable the moment another landed on top - which, with four
writers, happens fast.

Two more faults found in the same panel while fixing it:
- **It only ever drew the newest batch.** `S.adLog` keeps 30 entries; everything older was held
  and never rendered. The athlete could not SEE an older change, let alone undo it.
- **`prov` and `provok` had no row renderer.** They fell through to `return ''`, so every
  probation step shipped in c184 was invisible in the one place that is supposed to say what the
  card did to your numbers. Shipped that way and only caught by reading the render.

### The fix
`adaptUndoOne(i)` reverses a single entry. `adaptUndo()` now walks the newest un-undone batch and
calls it, so the existing button behaves as before.

Out-of-order undo is honest about what it can promise:
- nothing has moved the lift since -> the old number goes back exactly
- something has -> the DIFFERENCE that entry made is removed from wherever the max is now, so the
  later changes survive. Winding the max back to `a.from` would silently discard them.

Entries are MARKED (`a.undone`), not deleted: the record of what the card did is worth keeping, and
a marked entry cannot be undone twice. Without the mark, undoing the same entry repeatedly walks
the max upward without limit - the break test drove a 285 bench to 335.

A volume drift reshapes the program rather than moving a number, so it has no clean inverse. It is
shown with a note pointing at the Plan tab instead of a button that half works.

### Provenance ledger caught up
Five entries added, in the tier each belongs to rather than the tier that flatters it:
- **Sourced** - where a movement's tension peaks (biomechanics, not a study result)
- **Sourced** - training at long muscle lengths (Maeo, Pedrosa; real but young, small samples)
- **Reasoned** - variety of stimulus over repetition of it (our read of length-dependent and
  regional adaptation; nobody has shown it directly - which is why the card prefers and reports
  rather than rewrites)
- **Chosen** - a tested max on trial: 2 bad sessions, 3 clean, 2.5% a step. That a window is
  needed is supported; the numbers are ours. The floor is his own data, not a decision.
- **Chosen** - six sets before a one-sided week is worth mentioning

### New standing test adundo.js - 14 checks
Verified failable three ways: restrict the control to the newest entry, restore `a.from` blindly
instead of applying the difference, and drop the `undone` mark. Each fires its own checks.

One fixture error caught: the first version looked for the undo control on the RATE tab. The adapt
panel is rendered inside the volume screen, which is the PLAN tab, so the check reported a wiring
fault that did not exist.

### Build
- BUILD c189->c190; sw CACHE `card-v222-c190`. Training Card only.
- Full suite (79 harnesses) ALL CHECKS PASSED in 242s.
- Release letter: yes.

## c189 - 2026-09-03 (SWEEP - the bug class behind three of today's faults)

### The class
Three separate faults today were the same shape: something referred to a thing BY NAME, and
nothing ever checked the name still resolved.
  - the fill picker rejected a candidate only if its NAME was already on the day, so it added a
    second rear-delt movement under a different name (c186)
  - deadsweep filtered Bulk's animated host by `#gummyHost`, renamed `#gbHost` at some point - the
    guard pointed at nothing and had gone silently inert (c183)
  - `setbtns` checked a hand-written list of launchers that had drifted from the real ones, and
    passed three broken settings buttons
None of these fail loudly. They stop doing their job and say nothing.

### The scan that did not work, and why it is worth recording
The first version walked every screen it could reach and flagged any selector that never matched.
It reported 47, of which about 45 were fine - they lived on screens the sweep never opened
(coaching, block-end review, PR celebration, the ad-hoc lift flow, the install sheet). A check
that cries wolf 45 times out of 47 teaches you to ignore it, which is the same rot it exists to
catch. Discarded.

The reliable signal is static and needs no screen coverage: does this name appear anywhere in the
source OTHER than the selector that names it? That is exactly what made `#gummyHost` dead.
202 selector tokens examined, one genuinely dangling.

### Found and fixed
1. **`VOL_SUPPORT` credited 'Dead Hang' and 'Bar Hang'** for forearm work. Neither was in `EXLIB`,
   so the credit could never apply to anything. `Dead Hang` is now a real library row - and it is
   the first forearm movement on the card that trains under a stretch rather than mid-range, so it
   closes a profile hole as well. `Bar Hang` was the same movement under a second name; the credit
   was removed rather than given a twin.
2. **`[data-wkv]` week-step handler.** The attribute appeared exactly once in the entire file - in
   the `querySelectorAll` that bound the handler. Nothing ever rendered a control for it. Wiring
   with no markup is the same rot as markup with no wiring, and `orphantest` only looks the other
   way round. Removed.

### New standing test deadref.js
Two families, no screens opened:
  1. every movement name in `VOL_PICK`, `VOL_OVERRIDE`, `STIM`, `VOL_SUPPORT`, `EXVID` and the
     plan's own `subs` lists resolves to `EXLIB`; every muscle key credited has a target; every
     muscle with a target has a label.
  2. every id, class and data-attribute a selector names appears somewhere other than that
     selector. Comments are stripped first, so a comment mentioning a name cannot make it resolve
     - the removal note left behind for `data-wkv` would otherwise have covered for it.
Verified failable both ways: restoring the phantom `Bar Hang` credit, and adding a guard on
`#gummyHost`. Each fires its own check and nothing else.

### Build
- BUILD c188->c189; sw CACHE `card-v222-c189`. Training Card only.
- Full suite (78 harnesses) ALL CHECKS PASSED in 225s.
- Release letter: yes - Dead Hang is a movement they can pick.

## tests-only, 2026-09-03 - the suite runs on his upload, not only when asked

No card change. BUILD stays c188 and the sw cache stays `card-v222-c188` - pushing a new build
number for a workflow file would make every tester re-download an identical app.

### Why
The suite only ran when it was run by hand, in a chat session, against files that had to be
carried in and out. deadsweep proved what that costs: declared in the runner in c181, never
committed, and two builds shipped "ALL CHECKS PASSED" against a suite that was not running it.

He deploys from a phone through GitHub's web upload, and that upload is a commit. So the commit
is the trigger. The result lands as a tick or a cross on the Actions tab, readable on a phone.

### .github/workflows/tests.yml
Runs on push, pull_request and manual dispatch. Node 22, canvas BUILT FROM SOURCE with the same
apt libraries and the same `--nodedir=/usr` the suite was verified against - a silently different
prebuilt canvas is worse than a slower install. `tests/node_modules` cached against the hash of
`tests/package.json`, so the canvas build only repeats when dependencies actually change.

The suite is invoked with NO card path. `run.js` discovers `index.html` one level up, so it works
whether the card sits at the repo root or in a folder beside `tests/`, and exits 2 rather than
passing an empty run if it finds nothing. `-j 6` because runners have several cores, unlike the
single-cpu box the concurrency was tuned on.

A step writes the outcome to `$GITHUB_STEP_SUMMARY` so a pass or the failing lines are readable
without opening a raw log on a phone, and the full log is kept as an artifact for 14 days.

### New standing test buildsync.js
His rule is that every build bumps BUILD and the service worker cache. If BUILD moves and CACHE
does not, the app publishes and no phone ever fetches it - the old copy keeps serving from cache
and the deploy silently does nothing. Invisible from the outside, which is exactly what CI should
catch instead of a person remembering. Reads the `sw.js` beside the card, asserts the cache name
carries the BUILD, and checks the manifest parses and names a start_url and scope. Against a card
with no sw.js beside it (the lite master) it says so and passes rather than failing.

### Verified against a simulated repo
A copy of the deploy folder with `tests/` beside it, running exactly what CI runs:
    clean repo, no card argument          77 harnesses, ALL CHECKS PASSED, exit 0
    BUILD bumped, sw CACHE left behind    buildsync FAILS, exit 1
    a declared harness not on disk        MANIFEST failure before any card work, exit 1
    tests present but no card in the repo "No cards found", exit 2
    lite master, no sw.js beside it       nothing to check, exit 0
The exit codes were measured directly rather than through a pipe - an earlier reading showed 0
for all of them because the shell was reporting `head`, not node. CI believes the exit code and
nothing else, so that distinction was the whole test.

## c188 - 2026-09-03 (LIBRARY - four movements to close the stimulus holes c187 exposed)

### Why
Tagging the library in c187 let the card REPORT that a muscle's whole week sat in one stimulus.
It also proved the card had nothing to offer against some of those reports. An audit of every
movement's primary muscle against its profile found muscles with an entire axis missing:

    rdelt    only shortened (4 movements)   - Face Pulls, Reverse Pec Deck, Rear Delt Fly, Band Pull-Aparts
    fdelt    only mid-range (9 movements)
    glutes   no lengthened option
    traps    only shortened (shrugs)

Rear delts were the one he actually hit: the c186 fill bug put two shortened rear-delt movements
on one day, and the reason nothing better was available is that nothing better EXISTED.

### Added
    ['Cross-Body Cable Rear Delt Fly','pull','cable','bench',0.08,'stack','med']   {rdelt:1}   long
    ['Incline Front Raise','push','dumbbell','ohp',0.05,'perHand','med']           {fdelt:1}   long
    ['Prone Y Raise','pull','dumbbell','bench',0.03,'perHand','med']               {traps:1}   mid
    ['Single-Leg Romanian Deadlift','legs','dumbbell','dead',0.12,'perHand','high'] {glutes:1,hams:0.75} long

Each got a library row, a primary-muscle credit, a stimulus tag, and a place in `VOL_PICK` so the
fill picker can actually reach it. Load estimates resolve sensibly through the existing anchor
maths (15 / 5 / 5 / 30 lb against his numbers). Library 165 -> 169, tagged 167.

### Side effect worth recording
`stimPreferred` was DORMANT in c187 - the fill picker only ever landed on tibialis, which has one
candidate, so there was never a choice to make. Rear delts now offer four candidates across two
profiles, so the preference has something to do for the first time.

### Deliberately left open
    back missing short      lowback missing short    obliques missing long
    calves missing short    adductors missing mid    abductors missing long,mid
    tibialis missing long,mid                        forearm missing long,short
    rdelt missing mid       fdelt missing short      traps missing long
Lower value, and several are arguable rather than real (a "shortened lat" movement is not really
a thing worth adding). Closing a gap with a movement nobody would program is worse than leaving
it open.

### Test
`stimprofile.js` gains two checks pinning the closed gaps: each of the four muscles must keep at
least two distinct profiles among its library-present candidates, and rear delts specifically
must keep something lengthened. Verified failable by pulling Cross-Body Cable Rear Delt Fly back
out of `VOL_PICK` - both fire.

### Build
- BUILD c187->c188; sw CACHE `card-v222-c188`. Training Card only.
- Full suite (76 harnesses) ALL CHECKS PASSED in 220s.
- Release letter: yes - four new movements they can pick themselves.

## c187 - 2026-09-03 (ENGINE - the card knows what KIND of work a movement is)

### His direction
On being told the base template pairs Straight Bar Curl with Incline DB Curl and Hanging Leg
Raises with Plank, and that those were left alone as his programming: "No that's exactly the kind
of programming I need this engine to be able to figure out on its own. Exactly how you described
it, mid-range and dynamic flexion and anti-extension. These are huge examples of scientific
advances I want incorporated in the entire engine." Chose FULL scope: detect, prefer, and flag a
muscle whose whole week sits in one profile.

### What the library knew before
Nothing about this. Each of the 163 rows carried name, group, equipment, an anchor lift for load
estimation, a factor, a load unit and a skill rating. The engine could not tell a preacher curl
from an incline curl except by name.

### The layer
`STIM`, one entry per movement, two axes:
- `pos` - where peak tension sits: `long` / `mid` / `short`.
- `mode` - for the trunk, what is being resisted: `antiext`, `antirot`, `antilat`, `flex`,
  `rot`, `latflex`. Everything else is `dyn`.
163 of 165 tagged.

Readers: `stimOf`, `stimKey`, `stimSame` (true ONLY when both are tagged and identical),
`stimWords`, `stimSeen(muscle)` (every stimulus the week already gives it), `stimPreferred`,
`stimOneSided`.

### Provenance, and this matters for the ledger
- **Sourced (biomechanics, not a study result).** The tagging itself. An incline curl loads the
  elbow flexors at a longer muscle length than a preacher curl because the shoulder is extended.
  A seated leg curl holds the hamstring longer than a lying one. These are mechanical facts.
- **Sourced but young.** That lengthened-biased work grows more muscle - Maeo on seated vs
  standing leg curl and overhead vs pushdown triceps, Pedrosa on lengthened partials. Small
  samples, recent. Good enough to PREFER; not settled enough to enforce.
- **CHOSEN, and it is inference.** That two different-profile movements beat two same-profile
  ones at matched volume. A reasonable read of length-dependent and regional adaptation; nobody
  has demonstrated it directly. So the engine prefers and reports. It never overrules.
- **CHOSEN.** `STIM_MIN_SETS=6` before a one-sided week is worth mentioning.

### The three behaviours
1. **Detect.** `stimSame` distinguishes his pair (both shortened, one stimulus) from the pairs
   left alone in c186 (stretched vs mid-range curl; dynamic flexion vs anti-extension hold).
2. **Prefer.** `stimPreferred(muscle, cands)` picks the candidate whose stimulus the week does
   NOT already have, staple order otherwise. The fill records it and the session note says so:
   "X added (stretched work your week was missing)".
3. **Flag.** A muscle whose whole week sits in one stimulus, with 6+ sets, is labelled on the
   Plan tab volume rows. Reported, never auto-corrected.

An untagged movement makes NO CLAIM in either direction. Partial coverage has to degrade quietly:
a mis-tag would put wrong reasoning straight into programming.

### What it says about his own plan, unprompted
chest all mid-range (14 sets) - front delts all mid-range - side delts all shortened - rear delts
all shortened - obliques all anti-lateral-flexion - quads all mid-range - hamstrings all
stretched - calves all stretched. The rear-delt one is an honest gap in the LIBRARY, not a
programming mistake: every rear-delt option in here (Reverse Pec Deck, Rear Delt Fly, Face Pulls,
Band Pull-Aparts) trains near the shortened end. There is no lengthened rear-delt movement to
offer. Worth adding one before that flag can be acted on.

### The preference is currently DORMANT, and he was told so
With his plan the fill picker only ever lands on tibialis, which has a single candidate, so the
preference has nothing to choose between. It is correct and tested; it is just not reachable
through the normal path today. That is why it was extracted into `stimPreferred` rather than
left inline - see below.

### New standing test stimprofile.js - 15 checks
THREE VACUOUS CHECKS CAUGHT WHILE WRITING IT:
- The evidence-floor check compared `sets < STIM_MIN_SETS` - the very constant under test - so
  setting the constant to 0 made it trivially true and it passed with the floor deleted. Now
  asserted against a literal, plus a check that the constant is still worth having.
- The preference check scanned the real plan for a day where the picker faced a choice of
  profile. There is no such day, so it proved nothing and passed with the preference deleted.
- Replacing it with a source-text check for the word "fresh" was no better: the break leaves the
  word behind. The preference was extracted into `stimPreferred` so the SHIPPED function can be
  called directly with a stubbed `stimSeen`. Better code and an actually failable test.
Verified failable three ways: mis-tag the incline curl, delete the preference, delete the
evidence floor. All three fire; the fixed build is clean.

### Build
- BUILD c186->c187; sw CACHE `card-v222-c187`. Training Card only.
- Full suite (76 harnesses) ALL CHECKS PASSED in 258s.
- Release letter: yes.

## c186 - 2026-09-03 (FIELD - "Reverse Peck Deck and reverse flys got generated for the same day's training but they're essentially the same type of exercise hitting the same muscles")

### What he saw
Two rear-delt movements on one day. He removed one before training.

### Where it came from
`sessPickExercise`, the session-length fill. When a day came in more than 8 minutes short of its
time target, the card added a movement. It chose by walking THE DAY'S OWN MUSCLES and taking
whichever was furthest under its weekly target - then filtered candidates only by `have[name]`,
the exercise NAME already on the day. Rear delts were short, a rear-delt movement was already
there, the name did not match, so it added a second one. And because the loop re-reads the day
and can add twice, the next pass found rear delts STILL short and added the third name off the
same `VOL_PICK` list. Reverse Pec Deck + Rear Delt Fly, exactly what he saw.

Structurally the old picker could ONLY pick a muscle the day already trained - `dayMus` was its
entire candidate set. Every fill it ever added was a second movement for something already
covered. Rear delts were just the most obvious case.

### The fix
A fill has to cover what the day is MISSING. Candidates are now every muscle with a weekly
target, minus any with DIRECT work on the day, minus any already at or over target, filtered to
the day's family (push/pull/legs) so a fill still belongs where it lands.

"Direct" is a primary credit (1 in the muscle map), not any credit. A muscle carried as a
secondary by a compound stays open to a fill - biceps at 0.75 from chin-ups still wants a curl.
With no readable day family, the fill stays with a muscle the day touches indirectly rather than
picking out of the blue.

This does NOT touch what the program prescribes. Two chest movements on a push day are
programming, not redundancy, and the rule only governs what the card adds by itself.

### New standing test dupemuscle.js
Verified failable: with the old picker restored it reports his pair by name -
`B: Reverse Pec Deck + Rear Delt Fly (both rdelt)` - plus four more clashes across the week
(Cable Lateral Raise onto trained side delts, Leg Extension and Leg Press onto trained quads).

The redundancy signature is narrow on purpose: two PURE ISOLATIONS for one muscle, meaning one
muscle at full credit and nothing else above 0.4. It catches rear-delt machine next to rear-delt
fly and two lateral raise variants; it does not catch Bench + Incline, which share chest at full
credit but each carry front delts and triceps. Both halves are pinned as fixture checks so the
harness cannot drift into failing honest programming.

### Scoped deliberately, and one thing left alone
The day-level check covers FILLS ONLY. Running it across whole days flagged three pairs in the
base template - Straight Bar Curl + Incline DB Curl on B and E, Hanging Leg Raises + Plank on F.
A stretched-position curl beside a mid-range one, and dynamic flexion beside an anti-extension
hold, are different stimuli and are HIS programming decisions to make. Raised with him rather
than silently rewritten.

### Build
- BUILD c185->c186; sw CACHE `card-v222-c186`. Training Card only.
- Full suite (75 harnesses) ALL CHECKS PASSED in 266s.
- Release letter: yes - athletes see fewer pointless additions.

## c185 - 2026-09-03 (FIELD - "I went to settings to change it from card picks to I pick and it locks the whole page. I cant access the settings")

### What he saw
Switched the training rhythm to "I do", the weekday pins appeared, and the screen he landed on
was locked - including the settings gear, so he could not get back in to change it back.
Screenshot: day C, "Coming up - unlocks at 3:00 AM", and the lock toast over the readiness block.

### What was actually happening
Not the rhythm switch. He was left on a session that had not come round yet, and a future
session is a PREVIEW - look, do not touch. `lockGuard` has two branches:
  - LOGGED day: exempts `.lockfree`, which the header carries. Header worked.
  - FUTURE PREVIEW: deliberately does NOT exempt `.lockfree`, because the day-agnostic utilities
    it marks (cardio, bodyweight) edit TODAY's data and must stay shut while browsing.
All four header controls - settings, mail, the tour replay, his own photo - are marked
`.lockfree` and went down with cardio and bodyweight. `lockGuard` is bound with `{capture:true}`,
so it called `stopPropagation()` before the gear's own listener ever ran.

The header is not part of any session. And settings is the way OUT of a state the athlete has
just put themselves in, so locking it is a trap rather than a guard - the same family as the
install sheet that was field-caught as an inescapable modal on a gated preview.

### The fix
`.hdr-id` is exempt in the preview branch, by its own selector rather than by `.lockfree`, so it
is true in every lock state and does not re-couple the header to the utilities. One line.
The session itself is untouched: a previewed day still refuses edits, and that is pinned.

### Why the suite missed it
`lockaudit` walks a BANKED day's session controls for guard omissions. It never enters the
preview state and never looks at the header, so the one branch with the bug had no coverage.

### New standing test hdrlive.js
The header, across four states: a live day, a logged session, a future preview in Guided, and a
future preview in Open with weekdays pinned and a session already banked today - his exact route.
Every state carries a fixture check that it IS that state. Verified failable: removing the
exemption fails exactly the four preview checks and leaves the live and logged rows green.

TWO VACUOUS FIXTURES CAUGHT WHILE WRITING IT, both would have shipped a green harness:
- The first preview fixture used Open with pinned weekdays and no logs. In Open EVERY unlogged
  session in the current week is active by design, so `isPreviewing()` was false and the row
  tested an unlocked card. What actually gates Open is `loggedToday()` - one session a night -
  which is why his screenshot said "unlocks at 3:00 AM". The fixture now banks a session today.
- A probe asserting `lockGuard` does not call `stopPropagation()` on a header tap failed in all
  four states including an unlocked live day: the gear's OWN handler calls `stopPropagation()`.
  It was measuring the wrong thing entirely and was removed - "does the gear actually open
  settings" is the check that means something.

### Build
- BUILD c184->c185; sw CACHE `card-v222-c185`. Training Card only.
- Full suite (74 harnesses) ALL CHECKS PASSED in 243s.
- Release letter: yes - he could be stranded, and anyone who hit it should know it was the card.

## c184 - 2026-09-03 (FEATURE - a tested 1RM you can program from, on trial)

### His spec
"Perform a 1RM periodically and if it surpasses the engine's E1RM, replace it in the
programmable maxes and have the engine use that number - until the athlete provides satisfactory
proof he can train using the working weight pulled from it. If he can't, the engine stabilizes
the working weight and lowers the max by increments back to a good baseline."

### What was there before
Nothing entered a measured 1RM. The steppers move a max 5 lb at a time and `suggestMax()` offers
a number derived from `S.e1rm`, but a real tested single had no way in, and any number he set by
hand was still walked around afterwards by `adRateMove` and `autoCalibrate`.

### The signals, and where they come from
Asked for evidence-based choices rather than picked ones. What is actually sourced: missed
prescribed reps is close to definitional (the load is above the intended zone), and RIR
proximity-to-failure is the Helms/Zourdos basis the card's load table already rests on. What is
CHOSEN and should be labelled as such in the provenance ledger: the two-session window (that a
window is needed is sourced, that it is 2 is a choice), the 2.5% step, and the 3-session
graduation. There is no literature that sets those numbers; every system that has them chose
them.

The card already computed the signal. `clean` is worked out per lift per session where e1rmH is
fed - c=0 when a set missed target reps OR was ground at RIR<=0 - and stored as `c` on the
history entry. Probation reads that same field, so it and the stall rule can never disagree
about what happened in a session. No new data plumbing.

### The mechanic
1. **Entry** - `data-tmax` field under Programming maxes (Edit unlocked). `pvStart()` sets the max
   to `tested x 0.95` rounded to the bar, records `{tested, from, floor, since}` in `S.mxProv`,
   and files the tested single in `e1rmH` flagged `t:1` so a maximal attempt is never read as
   programmed work.
2. **The ramp hold** - `adRateMove` and `autoCalibrate` skip a lift on trial. You cannot test a
   number that is still moving. This is his "stabilize the working weight".
3. **The walk-down** - `pvJudge()` runs on EVERY bank, ahead of adaptRun's weekly gate, because a
   max proving too heavy should not sit on the bar for another six days. Two bad sessions steps
   it down 2.5%, re-arms the trial at the new load, and logs a `prov` act.
4. **The floor** - the max it replaced. That is a load already trained at successfully; walking
   below it discards the athlete's own data in favour of a bad fortnight. At the floor the trial
   ends and the normal stall rule takes the lift back (its own 8% drop, 21-day cooldown), so a
   lift is never penalised by both at once.
5. **Graduation** - three clean sessions and `S.mxProv` is cleared; the tested max is standing.
6. **Undo** - `prov` acts join stall/rate/layoff in `adaptUndo()` ("Put it back"), and undoing a
   step re-arms the trial rather than declaring the max proven.
7. **Refused entries** - a tested number that programs to at or under the current max is refused
   with a toast, not applied. Below the current max it is nearly always a typo or the wrong unit,
   and silently cutting every barbell load is the one outcome worth refusing outright.

### Bug caught during the build
`pvJudge()` first returned its actions AND seeded `adaptRun`'s `acts` list, so every trial step
was filed in `S.adLog` twice - "Put it back" would have needed two taps to undo one step. It now
files its own actions and adaptRun does not merge them.

### New standing test provmax.js - 16 checks
Verified failable three ways, and TWO OF THE THREE DID NOT FIRE ON THE FIRST ATTEMPT:
- **floor clamp deleted -> still passed.** From 310 the steps land 300, 295, then 295 x 0.975 =
  287.6 which ROUNDS BACK UP to 290 - it hit the floor by rounding luck, not by the clamp. The
  check now starts at a floor of 305, which a single step overshoots and only the clamp can hold.
- **ramp hold deleted -> still passed.** Vacuous three ways: six clean sessions were fed, which
  graduated the lift before the hold was ever reached; the fed estimates were flat, so
  `adRateMove` returns null even unheld; and the assertion was `>=` where a climb passes. It now
  feeds a real rising trend dated BEFORE probation opened, asserts `===`, and carries a fixture
  check that the trend genuinely would move the max if it were not held.
- one-bad-session window: fired correctly first time.
Both repairs are the same lesson the deadsweep README already carries, in a new place: a green
harness means nothing until the thing it guards has been broken underneath it.

### Build
- BUILD c183->c184; sw CACHE `card-v222-c184`. Training Card only.
- Full suite (73 harnesses) ALL CHECKS PASSED in 264s.
- Release letter: yes - new visible control and a new behaviour on the athlete's own maxes.

## c183 — 2026-09-03 (FIELD — "I set max then select apply, it reverts or changes the max I set")

### What he saw
Set a programming max on the You/MAX tab, tap Apply, and the max is not the one he set.

### What was actually there
There is no apply-my-edit button and there never was. The +/- steppers under Programming maxes
call `save()` on tap - the edit is committed the instant it is made. The amber **Apply** beside
them belongs to `suggestMax()`, which offers a max derived from `S.e1rm` (his logged sets).
Three things made it a trap rather than an offer:
1. `suggestMax` only returns when `sugg >= S.maxes[k]+5`, so the button APPEARS PRECISELY WHEN
   the athlete has just set a LOWER max on purpose - the honest training max under an old
   estimate. The more deliberate the edit, the more insistently the card offered to undo it.
2. It was styled `background:var(--amber);color:var(--amber-ink)` - the card's primary action
   colour - so it visually outranked the edit the athlete had just made.
3. It was labelled "Apply", which next to a value you have just changed reads as "commit this".
Reproduced: bench max 225, e1rm 250, stepped down to 205, tapped Apply, max became 240.

### The fix, all in the MAX tab render and its handlers
1. **A hand-set max is left alone.** New `mxTouched` map; stepping a max marks it, and a marked
   max is not offered a suggestion. Cleared on Edit/Done, so the suggestion is still available
   next time he opens the editor - the feature is scoped, not removed.
2. **The button names its number.** "Apply" -> "Use 240 instead", matching the "Set max 240"
   wording the assessment block already used. A button that states the weight it will write
   cannot be read as a confirmation.
3. **It no longer wears the primary colour**, so it does not outrank the athlete's own edit.
4. **Applying one says what it replaced** - "Max set to 240 lb - was 205. Use - and + to change
   it." Wrong taps are cheap to see and cheap to walk back.

### New standing test maxapply.js - 7 checks
Fails 3 ways on c182. Holds both truths: a hand-set max is never overwritten, AND an untouched
max is still offered the suggestion. Also pins that the steppers commit on tap and reach
storage (state is namespaced at `'nsc:'+curSKEY()`, not `curSKEY()` - the first cut of this
test read the wrong key and reported a persistence bug that did not exist).

### releasetest.js de-pinned
Adding the release letter failed `releasetest` six ways, none of them real: it asserted the
COPY of the 2026.09.02b release - a hardcoded `/^2026\.09\.02/`, the words "Settings" and
"fill", the previous letter's "Light"/"Train this again", and a hardcoded `seenBuild`. Every
release would have broken it, which trains whoever runs the suite to wave through a red
harness - the same drift that let `setbtns` pass three broken settings launchers. It now
asserts the mechanism: entries are newest-first, the letter shares real vocabulary with its own
title and items (verified failable against a boilerplate letter), and the previous entry keeps
a letter of its own.

### Build
- BUILD c182->c183; sw CACHE `card-v222-c183`. Training Card only - Session Card untouched at
  v222 on his instruction.
- Full suite (72 harnesses) ALL CHECKS PASSED in 243s.
- Release letter: yes. Athletes see the button change, and anyone who hit this bug deserves to
  be told it was the card and not them.

## c182 / v222 — 2026-09-03 (FIELD — a Session Card backup restored into the Training Card)

### What he saw
Restore a Session Card backup into the Training Card and the card sent him straight to setup,
with everything he had just restored hidden behind it. The welcome copy was a blank white box.
The previous day's deck footer ("NEXT Overhead Press") sat under the setup screen.

### What he did not see, and would have lost
The Session Card writes its sessions under `nova-sc-log:<date>-...`. In the Training Card that
prefix belongs to ROSTER athletes (`nova-sc-log:<id>:...`), and personal logs live under
`tc-log:`. Every banked session in the backup restored into a namespace the personal drawer
filters out. `S.exHist` came across, so trends and the stall rule kept working; the session
log itself vanished. Found by reading `curLOGP()` on both cards, not in the field.

### The fixes, all in `restoreBackup()` and the setup render
1. **Logs remapped.** A `nova-sc-log:<date>...` key with no athlete id is a Session Card personal
   log and is written under this card's own personal prefix. Roster keys are untouched. The
   prefix is resolved locally (`TLOGP` where it exists, else `LOGP`) — defining `TLOGP` on the
   Session Card as a shortcut broke `coexist`, which tells the two cards apart by exactly that.
2. **Data is the proof of an athlete.** The backup carries no setup flag. If it carries maxes,
   history or sessions, setup is marked done and he lands on his card. Setup stays one tap away
   under Settings → Assessments. An empty backup still leads to setup.
3. **The confirmation he asked for.** The toast says what came across in numbers — "Backup
   restored: 47 sessions, history on 12 lifts, 6 maxes, 9 records ✓" — and Bulk writes the same
   line into the mailbox so it does not vanish in a second, plus one sentence when it was a
   Session Card backup: the old block did not come with it; you are on the standard block until
   you build one.
4. **Setup copy is never hidden by Minimal coaching text.** His Session Card had Minimal on,
   and `body.ui-min .cue{display:none}` hid the instructions too. `#app[data-onb]` exempts
   setup: instructions are not coaching.
5. **The footer clears under setup.** `paintFoot()` paints nothing while setup owns the screen.

### New standing test crossrestore.js — 13 checks
On c181 it fails eight ways, including "no logs found". Two fixture lessons: the card treats
sessions in storage as proof of an athlete and correctly refuses to draw setup once they exist,
so the setup-screen checks run BEFORE the restore; and `coexist` identifies the Training Card
by `typeof TLOGP`, so no alias of that name on the Session Card.

### Build
- BUILD c181→c182, v221→v222; sw CACHE `card-v222-c182`; Session title bumped.
- Full suite (72 checks on the Training Card, 70 on the Session Card, 142 total) ALL CHECKS
  PASSED. `crossrestore` reports nothing to test on the Session Card, which has no setup.
- No release letter: nobody but him is restoring across cards, and the restore now announces
  itself.
- **Do the migration on this build.** On c181 the sessions go into the wrong drawer.

## c181 / v221 — 2026-09-03 (DEAD BUTTONS — his ask: "there might be dead buttons all over the app and we aren't checking")

### The one real fix
The day footer's **"Report a problem"** was not the reporter. It copied a SESSION REPORT to the
clipboard, BANKED THE SESSION as a side effect — locking a day the athlete was mid-way through
— and showed an overlay that sat at z 40. It now opens the same reporter the BETA pill and
Settings open. The session-report copy still exists behind the hidden `#copyBtn` for the error
path that needs it.

### The report panel
Every control bound and working by real tap: the three kind chips, Share (clipboard fallback
where there is no share sheet), Copy, Close; Email and Text hand off to `mailto:` and `sms:`.
Nothing dead there.

### New standing test deadsweep.js
`orphantest` is static — a `data-` name in any selector counts as bound — so it cannot see a
wire function that never runs for a screen, a handler that returns early, or a control bound
by id. `deadsweep` is dynamic: every `addEventListener` recorded at parse time; what looks
tappable learned from the card's own `cursor:pointer` rules; twenty-one screens and overlays
walked; a tappable with no handler on itself or a non-root ancestor is tapped for real from
reset state, and only one that changes nothing in `#app` is called dead. A sampled throw pass
taps handled controls too.
- Result: 1,141 tappables on the Training Card, 1,163 on the Session Card, zero dead, nothing
  throws.
- **Four things masked dead buttons in the first versions, each found by unbinding a button on
  purpose and watching the sweep stay green:** the lock guard on `#app` counted as a handler
  for every child; state carried between taps ("Got it, hide this" read dead once already
  hidden); a leftover toast counted as an effect; and Bulk's idle animation rewrites body
  markup every tick, so a dead button borrowed his motion. The final sweep catches the unbound
  footer link on a broken copy. Written into the README so the next harness does not relearn
  them.

### Build
- BUILD c180→c181, v220→v221; sw CACHE `card-v221-c181`; Session title bumped.
- Full suite (71 checks per card, 142 total) ALL CHECKS PASSED on both cards. The suite is now
  about 25 minutes; `deadsweep` is most of the growth.
- No release letter: the footer link now does what its label always said.

## c180 / v220 — 2026-09-03 (FIELD — "some buttons in settings don't work, some open behind it")

### Three, all real, all the same shape
The settings sheet sits at z 200. Things it launches have to land above it or close it first.
Three did neither, and each looked like a dead button:
1. **Assessments** set the retest and re-rendered the app — under the sheet. The warm-up test
   was running behind the settings page. It now closes the sheet before rendering. The sheet's
   own wrapper suppresses the app rebuild while it is up, which is right for every chip and
   wrong for anything that navigates.
2. **Paste-restore** created its box at z 40. Raised to 420.
3. **Backup**'s copied-text box (`showOverlay`) — same z 40, same fix. Also the error bar
   (`__showErrBar`, z 80 → 430): an error message hidden behind a sheet is the worst place for
   one.
Everything else in the sheet was walked by real click and works: every chip changes state and
lights, disclaimer (410) and terms (411) open above, report (240) opens above, the phone check
writes its result into the sheet.

### Why the suite was green
`setbtns` checked a hand-written list, and none of the three were on it — the same drift that
let `clickaudit` wave through the Light control on 2026-09-02. `setlaunch.js` walks the real
DOM and reads z-order from the stylesheet and inline styles. The list cannot drift because
there is no list.

### New standing test setlaunch.js — 7 checks per card
Verified failable: the z 40 overlays and the open-sheet retest restored on a scratch copy go
red three ways with the field symptoms ("sheet still open - the test is running behind it").

### Build
- BUILD c179→c180, v219→v220; sw CACHE `card-v220-c180`; Session title bumped.
- Full suite (70 checks per card, 140 total) ALL CHECKS PASSED on both cards.

## c179 / v219 — 2026-09-03 (PRINT — his ask: soldiers run the printed plan with no engine)

### The gap
The print sheet already printed a load for every exercise for every week, through the same
`baseLoad()` the card uses. Main lifts ramped (percentages of a max). Accessories did NOT: in
the app they climb from logged sets — fill the rep range, up one step — and paper has no logs,
so a generated plan printed "15 15 15 15 15 10" for a dumbbell press. A soldier following the
sheet was never told to add weight.

### The fix
`planLoadsRow()` now projects the accessory climb FORWARD for future weeks only, in the app's
own step — 5 lb, 2.5 on a live load under 20 (dbRound's rule), the bar's jump on a barbell —
and the template's shape: two weeks, up one, two weeks, up one more. Past and current weeks
still come straight from `baseLoad()`, so a card user's sheet matches their card today
(`sheettest2` parity holds), and the deload week keeps its own number. Holds and bodyweight
work are untouched.
- Seated DB Shoulder Press: 15 · 15 · 17.5 · 17.5 · 20 · 10.
- The step reads off the LIVE number, not the template's nominal — first cut used `ex.loadNum`
  and climbed a 15 lb lateral raise by 5s (+67% by week 5). Caught by the new "small steps,
  not leaps" check before it shipped.
- Footer line for the paper athlete: "Smaller exercises climb in the later weeks; if you did not
  hit every rep last week, stay on last week's number until you do." That is the engine's
  double-progression rule in one sentence.

### Test
`sheettest2` extended: every loaded accessory climbs by week 5; never by more than 1.5× (the
leap guard); the current week still prints exactly what the card prescribes; the climb rule is
on the sheet.

### Build
- BUILD c178→c179, v218→v219; sw CACHE `card-v219-c179`; Session title bumped.
- Full suite (69 checks per card, 138 total) ALL CHECKS PASSED on both cards.
- No release letter: a change to the print sheet only.

## c178 / v218 — 2026-09-02 (FIELD — the same personal record shown twice)

### The bug
"Incline DB Press · weight 65 (was 60)" twice on the records banner. History replaces a
same-date entry (`histPush`), but the PR ledger `S.prs` only ever APPENDED. Bank a session,
then bank it again after "+ set" or a correction — his exact day — and every record that still
stood was filed a second time. The banner reads that ledger, so it showed both.

### The fix
A re-bank now REPLACES today's ledger entries for the lifts it judged, then files the fresh
ones. Two consequences, both right:
- Re-banking after "+ set" leaves one record, not two.
- A correction that takes a record away RETIRES it — before, a stale "weight 65" would have
  stayed on the banner after the sets were corrected down to 55. A record that still stands
  after the correction (volume: four sets at 55 beat three at 60) is kept.
- Ledgers written before the fix are tidied once at boot: same day, same lift, same kind is
  one record; the later entry wins. His banner clears on the next open.

### Test correction, mine
`restoreflow` seeded a synthetic Bench Press record dated TODAY, then banked a session. Under
the new rule banking re-judges today's Bench Press and correctly retires a record those sets
never earned — so the restore had nothing to bring back. The fixture is now dated as history,
which is what a restore should actually restore. Same proof, honest fixture.

### New standing test prdupe.js — 7 checks
First banking files once; re-bank after "+ set" files nothing new; no (lift, kind) twice in
today's ledger; the banner shows one line; a correction retires the weight record and keeps
the volume one; a pre-fix ledger is tidied. Verified failable: the append-only ledger restored
on a scratch copy reproduces his duplicate exactly — "weight records for Incline DB Press: 2".

### Build
- BUILD c177→c178, v217→v218; sw CACHE `card-v218-c178`; Session title bumped.
- Full suite (69 checks per card, 138 total) ALL CHECKS PASSED on both cards.
- No release letter: a duplicate line disappearing needs no announcement.

## c177 / v217 — 2026-09-02 (HOLD TIMES — his ask: "1:30", not "90s")

### The change
A plank held for 90 seconds read "90s" on the set chip, the rest screen, the print sheet and
the session report. `holdFmt()` now prints m:ss once a hold passes a minute (45s, 1:00, 1:30,
2:05); under a minute stays in seconds. Both cards.
- **Display only.** Storage stays seconds. Every log, PR and trend keeps comparing on one number,
  and old logs read the new way without migration.
- "Similar exercises" are covered by construction: anything `isHoldEx()` already recognises —
  "max hold", "30–45s per side", carries — routes through the same formatter. Side Plank,
  Farmer Carry and Plank all print alike.
- The hold editor label now says "hold (seconds)" so it is clear what unit you type.

### Test
`holdfmt.js` — the formatter itself, then the real thing: a hold logged at 90 on a live day,
the exercise focused in the deck, the chip reads 1:30, the stored value is still 90, and the
report says 1:30. Two harness lessons written into the README: the day shows one exercise at a
time so the hold must be focused before its chips exist, and read `#app` rather than `body` —
`body.innerHTML` includes the card's own source and will match anything you look for.

### Build
- BUILD c176→c177, v216→v217; sw CACHE `card-v217-c177`; Session title bumped.
- Full suite (68 checks per card, 136 total) ALL CHECKS PASSED on both cards.
- No release letter: a formatting change on a screen the athlete is already reading.

## c176 / v216 — 2026-09-02 (PLAIN LANGUAGE — his ask: setup has to work for everyone)

### Measured first
Flesch–Kincaid grade on every setup step, then on every athlete-facing explanation across the
card (`cue`, `exnote`, `rules`, banners). Setup was mostly grade 5–8 already; three screens were
the problem. The welcome was 335 words at grade 9.3 and explained the whole testing method —
fives, threes, singles, "an estimate with a range" — before the person had done anything.
Emphasis and Prefs were near grade 10 ("which movement carries the load", "prescribed as sets
and reps rather than a percentage").

### Setup, rewritten
Rules applied: one idea per sentence, sentences under fifteen words, say what happens rather
than how it is computed, no jargon without a plain word beside it. Method explanations moved
off the front door and onto the screen where they apply.
- Welcome: 335 → 119 words, grade 9.3 → 3.0. "Setup takes about two minutes. 1. A few quick
  questions. 2. A short warm-up on four lifts. You will never be asked to lift your max."
- Skip screen: 240 → 60 words. Also removed a STALE promise — "anything sore swaps to
  friendlier movements" and "no injury swaps" were still in the copy from before the
  2026-09-01 medical-neutral reversal. The card had not asked what hurts for a day and the
  skip screen was still advertising that it would.
- Prefs, Emphasis, Priority, Experience, Schedule, Length, Weekdays, Rhythm tightened. The
  Priority heading "Your numbers say something." became "Want to focus on one lift?".
- Whole setup: 1,129 → 739 words. Every step now grade 7 or under; most under 5.
- The assessment screen was left alone — "How many MORE reps could you have done?" and its
  five-word answer scale are already the plainest thing in the card. One sentence shortened.

### The rest of the card — first pass
Scan found 49 explanations; 12 at grade 9+, five at 12+. The single worst line on the whole
card (13.4) was the session-length Settings note written earlier tonight. All twelve rewritten
on both cards, e.g. "Every How opens the same sheet you see inside a session — a filmed clip or
curated video first, a precise search as the fallback" → "Tap How on any exercise to see a
short video of it."

### What was NOT changed
The training screen itself — set chips, rest screen, readiness — is already terse and tested
against specific strings in a dozen harnesses; it was not touched. The coaching-text Full/
Minimal switch and Bulk's voice are his and stayed as they are. No release letter: existing
athletes have finished setup and will not see this.

### Build
- BUILD c175→c176, v215→v216; sw CACHE `card-v216-c176`; Session title bumped.
- Full suite (67 checks per card, 134 total) ALL CHECKS PASSED on both cards.

## c175 / v215 — 2026-09-02 (ENGINE FILL — his ruling: "take it off, I'll let the machine decide")

### What came off
The "tap to choose what fills the time" section on the day — accessory chips and the finisher
stepper — and `S.sessManual` with it. His point was right: the chips were "+ set" with a second
doorknob, and that seam (target-grown sets vs athlete-added sets) is where three of today's
bugs lived. The target itself stays in Settings; that is the one control the athlete keeps.

### What the engine does now, unasked, in this order
1. **+1 set on the day's lightest accessories** — never a main lift, three added sets max, no
   accessory past four. Unchanged rule.
2. **Add a recommended exercise** when sets alone leave the day 8+ minutes short. The pick is
   the day's own muscle furthest under its weekly target (`plannedVolume()` against
   `ANA_TGT`), the recommended movement for it from `VOL_PICK` — the same table the volume
   adaptation reads — filtered to the day's family and to what is not already on the day. Up to
   two. Added through the custom-exercise path (`custList`), so it is a real slot with a real
   anchored load and real set state, tagged `fill:true`.
3. **A Zone 2 finisher**, 10–30 min, for what remains.

Composition runs at boot and when the target changes (`sessFillDay`), never inside render —
a getter that writes state is how the trim bug happened. Composing the same day twice adds
nothing. A day over target is never trimmed. A fill the day no longer needs (target off or
lowered) is taken back ONLY if nothing was logged on it; logged work is never removed.

Observed on his own push day: base 55 min at a 1:30 target → three accessory sets, Cable
Lateral Raise (side delts were the week's shortest) and Machine Chest Press, then a 15-minute
finisher — 91 minutes.

### Bulk letter
Release `2026.09.02b`. Returning athletes one release behind get exactly this one; anyone
further behind gets both in order. `releasetest` updated for two live releases.

### Test
`sesslen.js` rewritten for engine fill — 19 checks: off is untouched and the chips are gone;
a short day fills; the set rules hold; an added exercise is a real library movement with a
load, in the day's family, targeting a muscle the day trains, never a duplicate, capped at two;
lands within 10 min of target; the day names what was filled and points at Settings; idempotent;
over-target never trimmed; a logged fill survives the target going off and an unlogged one is
taken back; deload is never filled.

### Build
- BUILD c174→c175, v214→v215; sw CACHE `card-v215-c175`; Session title bumped.
- Full suite (67 checks per card, 134 total) ALL CHECKS PASSED on both cards.

## c174 / v214 — 2026-09-02 (FIELD — "+ set" showed 215 beside five sets done at 200)

### The bug
He trained bench under the CUT max — 86% of 230 rounds to 200 — then the update's repair pass
restored the max to 250 mid-day. `curLoad()` re-prescribed from the live max, so the header
read 215 and every set added with "+ set" landed at 215 next to five sets stamped at 200.
The sets themselves were right (`stampPerf` has been writing performed weight since histtest);
the header and any set added afterwards were the only readers still going back to the max.

### The rule
Once a set of an exercise is logged, that session's prescription is what was lifted — read off
the FIRST logged set, which is the day's effective prescription (a rest-screen drop on set 3 is
that set's own weight, never the day's; presctest). An explicit adjustment still wins; an
exercise with nothing logged still follows the live max; a pre-stamp legacy log falls through.
Only a max moving mid-session ever makes this differ from `baseLoad()` — repair, a rate move,
an assessment rerun — so nothing changes for anyone in the normal case. Tomorrow gets the new
max; today does not move under the athlete's feet.

### A thing that needs saying
The working copies already contained a partial fix for this — an `isVisiting()`-only branch in
`curLoad`, with a comment quoting his report — timestamped eight minutes after my last edit
and not written by me in this session. It was not in the c173 zips. I cannot account for it.
It was replaced, not extended: it only covered a visited day, and his case was the live one.
Whatever wrote it, the diagnosis in its comment was right and its scope was not.

### The lateral raise — same fault, different trigger
Prescribed 20/hand, trained at 20, then the readiness check-in (Stress 4 in his screenshot)
scored YELLOW: `readyMult` 0.925 → 18.5 → dumbbell-rounded 17.5, on the header and on the
added set. Readiness scales accessories too (deliberately, since the machine-athlete fix), so
a check-in answered after training re-prescribed the whole session. Covered by the same rule —
first logged set anchors the session — and now tested on an accessory under a readiness
change, not just a main lift under a max change. The fixture had to be corrected once: soreness
5 means very sore, not fine, so my "green" day was red and the check was vacuous.

### New standing test anchorday.js — 11 checks
Sets stamped; the header holds after the max moves; "+ set" through the real control matches
the sets done; the explicit override wins; an unlogged exercise follows the live max; a legacy
log falls through; a genuinely green fixture; an accessory holds after a late yellow check-in;
an unlogged accessory still follows readiness. Verified failable: the c166 `curLoad` restored
on a scratch copy fails the header, the added set, and the accessory checks with the exact
field numbers (205 vs 190; 45 vs 50).

### Build
- BUILD c173→c174, v213→v214; sw CACHE `card-v214-c174`; Session title bumped.
- Full suite (67 checks per card, 134 total) ALL CHECKS PASSED on both cards.
- No WHATSNEW entry: a correction to loads the athlete already lifted, not something they
  will see change. If he wants Bulk to mention it, it is one line.

## c173 / v213 — 2026-09-02 (BULK ANNOUNCES RELEASES — his ask)

### The gap
`WHATSNEW` — the card's own release-notes list with a "pending since the build you last saw"
mechanism — had not been fed since 2026-08-22, so its sheet never fired and nobody was told
about anything shipped since. Today alone changed three things athletes will see on open.

### The design: Bulk is the channel
Not a new system. The release list already existed; Bulk's mailbox already existed with an
idempotent send ledger. They are now joined:
- Each `WHATSNEW` entry may carry a `bulk:` line — the letter in his voice. `mailUpdates()`
  sends one letter per pending release (oldest first, so the box reads in order), id keyed on
  the release tag so the ledger makes it once-ever, then marks the release seen.
- `whatsNewBoot()` hands off to Bulk wherever a mailbox exists. The sheet stays in the file as
  a fallback for a card with no mailbox, but it never pops alongside a letter.
- A brand-new athlete gets nothing — there is nothing to catch up on. That rule was already
  in `whatsNewPending()` and is kept.
- An entry with no `bulk` line is still delivered, from its title and items.

### Today's letter
Three things, one screen: the Light switch, Training rhythm with "Train this again", and the
put-back — "if I ever cut a max on you for no progress while you were hitting every rep, that
was me being wrong, and it is back." The rename (Ops, Brass, Night into Coach) is in the entry's
items for the record but not in the letter; it is not something an athlete needs telling.

### Standing rule from here
Every noticeable build — anything athletes will see or feel on open — gets a `WHATSNEW` entry
with a `bulk:` line, written when the build is cut. Internal-only builds (test fixes, parity,
renames of things nobody sees) do not. The entry's `build:` tag is the release identity; BUILD
constants still bump every time regardless.

### New standing test releasetest.js — 13 checks
Today's entry present with a letter; a new athlete gets nothing; a returning athlete gets
exactly one, unread, faced, badged; the sheet does not also pop; once-ever through the ledger,
including after "clear read mail"; an athlete several releases behind gets each one oldest
first; the no-`bulk` fallback delivers. `mailtest` unchanged and green.

### Build
- BUILD c172→c173, v212→v213; sw CACHE `card-v213-c173`; Session title bumped.
- Full suite (66 checks per card, 132 total) ALL CHECKS PASSED on both cards.

## c172 / v212 — 2026-09-02 (AUDIT — his ask: test everything built today, end to end)

### What the audit was
Not the unit suite again. A new harness (`audit.js`, now standing) that drives real flows in a
real athlete state: a c166-era saved card booting into this build; every theme in both lights
through real taps with the status bar following; an Open athlete jumping A→C, banking through
`saveSessionLog`, being closed for the day, repeating the next day; and setup carrying the
rhythm answer onto the built card. Plus cross-card parity of every block written today, and a
sweep for retired theme names left in prose.

### What it found — two real bugs the suite had waved through
1. **The rhythm answer was written by one of three program builders.** `ONB_finish` carried
   `S.splitMode`/`S.wd`; `ONB_build` (the review step) and `ONB_buildRaw` (skip setup) did
   not. An athlete who chose "I run it" and built through either landed on Guided. Now one
   helper, `ONB_applyRhythm()`, called from all three. This is the bug that matters most: his
   tester would have answered the question and got nothing for it.
2. **A repeat pass stayed live forever.** `S.rePass` marked the reopened cell and nothing ever
   cleared it, so a banked repeat read as a live cell the next day instead of a document —
   "a visited day is a document" broken. It now carries the date it was opened on and expires
   with it, and banking the pass closes it explicitly.

### And one wrong sentence
In Open, once today's session was banked, the bar on any other same-week session said "Next
week — your loads change when the week does". Not true; the week was fine. The only thing that
closes a same-week session in Open is having trained today, and the bar now says that.

### Parity and copy
Every block built today — theme table, light resolver, rhythm resolver, `dayActiveNow`,
`isVisiting`, repeat pass, review bar, repair pass, settings — is byte-identical across both
cards. No retired theme name remains in athlete-facing copy; the only "Night" strings left are
the light-mode chip and two code comments explaining the fold-in.

### Limits of what could be verified here
- The roster hand-over (coach defaults an athlete to Guided, can set Open) is structural —
  `S.splitMode` undefined reads as Guided, and it is per-athlete state under the roster's
  namespace — and the roster flows are covered by `athleteflow`/`coachparity`, but the audit's
  own roster probe could not drive the API and says so rather than reporting green.
- Canvas paint (the silhouette) cannot be exercised in jsdom. Assets verified byte-identical;
  the field report was the lite file, which has them stripped by design.
- `WHATSNEW` has had no entry since 2026-08-22 — nothing added today is announced in-card on
  update. His convention since c20, so not changed unilaterally; flagged.

### Build
- BUILD c171→c172, v211→v212; sw CACHE `card-v212-c172`; Session title bumped.
- Full suite (65 checks per card, 130 total) ALL CHECKS PASSED on both cards.

## c171 / v211 — 2026-09-02 (REPEAT PASS — Open had no door once the week was logged)

### The gap
His card showed `Logged B1 W1: A B C D E F` — the whole week done. In Open every one of those
reads as a finished session, nothing is active, and there was nowhere left to go until the
calendar rolled. Guided has this door already: `syncToNext()` quietly reopens the cell when the
rotation comes back round. Open never did.

### The fix, and why it is a button rather than the Guided behaviour
Guided reopens SILENTLY, because in Guided the card is the one choosing. In Open the athlete is
choosing, so the choice gets a button and a sentence: **"Train this again — a fresh card. Your
finished session stays in the log and still counts."**
- The previous log is not touched. It keeps its own date and every set in it still feeds volume
  and history — the same rule the Guided repeat pass has always followed.
- Plain tap, not hold-to-fire. Nothing is destroyed, so a confirmation would be theatre; the
  worst case of a mistap is an empty card next to an intact log.
- `S.rePass` marks the reopened cell so it reads as live rather than as a document, and clears
  the moment it is no longer the cell in view.
- The limits hold: Open only, current week only, and never once something is logged today.

### Also corrected
`isVisiting()` now returns true for any banked session in Open, rather than deferring to the
Guided rotation pointer — in Open there is no "next in sequence" to compare against.

### A test that was lying to itself
The new checks failed three times against correct code. `timeWeek()` is derived from the block
start date and is genuinely unstable in a fresh fixture — it reported week 1, then week 2, from
two calls a line apart — so the harness kept building logs for a week the card was not in. Now
stubbed outright for that block, the way the behind-the-calendar checks already do. Worth
remembering when writing any future harness that touches weeks: pin the clock, do not read it.

### Build
- BUILD c170→c171, v210→v211; sw CACHE `card-v211-c171`; Session title bumped.
- Full suite (64 checks per card, 128 total) ALL CHECKS PASSED on both cards.

## c170 / v210 — 2026-09-02 (FIELD — two of the three reports off c169 were mine)

### "Still getting the lock under I run it" — an athlete BEHIND the calendar was locked out
Open gated on `S.week!==timeWeek()`. The intent was to close the FUTURE, because future weeks
carry different loads. What it actually did was close every week that is not exactly the
current one, which includes being behind — so an athlete who had missed a week found every
session in Open locked, which is the opposite of what Open is for.
- The rule was already written three lines above the code that broke it: "Being behind the
  calendar never gates anything." Now `S.week>timeWeek()`, and only the future is closed.
- `syncToNext()` in Open also brings a stale week pointer up to the calendar on open, so a
  returning athlete does not write logs into a week that is already spent.
- Missed because the test set `S.week` to the current week for every case. It now stubs
  `timeWeek()` and drives behind, current and future separately.

### "What happened to choosing your split?" — a step-index desync in setup
`weekdays` is only asked of Open, so the setup step list is CONDITIONAL. Navigation used
`ONB_STEPS_FOR()` while Back, the skip-to-setup path and the review jump indexed the STATIC
`ONB_STEPS` — so from step 7 onward the two disagreed and every one of those controls landed on
the wrong screen. Choosing your split was never removed; the flow around it was walking sideways.
- All three now read `ONB_STEPS_FOR()`. One source of truth for step order.
- This hazard pre-dated c169: the roster already filtered `level` out of the same list. Adding a
  second conditional step is what made it visible.
- The new check scans every function the card defines. Scoped to `wire()` it found nothing on a
  deliberately broken copy — a check looking in one place is not a check.

### The repair notice was buried in a fold
`adFixedHTML()` — the "the card was wrong, here are your maxes back" notice from c168 — rendered
inside `volumeHTML()`, which lives inside the collapsible "Weekly work" fold. An apology the
athlete has to go looking for is not an apology. It now renders at the top of the Plan tab,
outside every fold.

### The silhouette: not reproduced, and not something these builds touched
Checked rather than guessed. Every one of the 19 inlined images is byte-identical to the c166
upload, `ANA_MASK` is intact, and the Plan tab renders both canvases with the "Weekly work" fold
open by default. The paint cannot be exercised here — jsdom's canvas will not decode the mask —
so this one needs a fact from the field before a fix, not a speculative change. Open question
for him in the reply.

### Build
- BUILD c169→c170, v209→v210; sw CACHE `card-v210-c170`; Session title bumped.
- Full suite (64 checks per card, 128 total) ALL CHECKS PASSED on both cards.
- Both field bugs verified failable: restored on a scratch copy, `rhythmtest` goes red three ways.

## c169 / v209 — 2026-09-02 (RHYTHM — his tester wanted to jump around the split)

### The complaint was never about skipping
Nothing ever stopped the athlete missing a day. What he was objecting to was what a miss COST
him: the split slides. Miss Monday, train Tuesday, and push is Tuesday, pull is Wednesday, legs
has walked into Sunday. For an athlete whose week is already fixed — gym hours, a partner, a
rack free at 0530 — that drift is the whole problem.

Two honest models, and the athlete now says which:
- **Guided** (default, and exactly what the card has always done) — a playlist. The card holds
  the next session, nothing is ever lost, a missed day shifts everything right. Right for the
  athlete who trains when they can, which is most soldiers.
- **Open** — the athlete picks. Any session in the CURRENT week, in any order, so A → C is one
  tap. Optionally anchored to weekdays, and then a missed day stays missed instead of dragging
  the rest of the week along.

### Built as one capability, not two
Free jumping and weekday anchoring are the same thing — "the athlete chooses today's session",
once with a saved map pre-filling the choice. One engine change, one set of tests.

Most of this was a REVIVAL, not new construction. `schedMap()` had been left in as a null
accessor when weekday scheduling was removed, with every downstream fallback deliberately kept
live — the weekday chip badges on the day picker, `schedTodayCode()`, and the proximity-aware
interference warning that fires at one day out and stays quiet at three. All of it woke up the
moment the map became real. The dormant `weekdays` onboarding step and its wiring were still
there too.
- `schedMap()` builds the map rather than storing it: chosen weekdays in WEEK order, the plan's
  own day codes dealt across them in rotation. A 3-code split over six chosen days gives
  A B C A B C — his tester's push Mon/Thu, pull Tue/Fri, legs Wed/Sat — with nobody
  hand-assigning a cell. Week order, not tap order, or picking Saturday first would build a
  different week than picking it last.
- Its own `SPLIT_DOW` rather than the generator's `PG_DOW`: the Session Card has no plan
  generator at all, and a rhythm control only half the cards can render is not a feature.

### What Open deliberately does NOT touch
"Fewer restrictions" is one instruction and four different locks. Only the first is Open's
business, and the test suite exists mostly to hold that line:
1. **The sequence lock** — lifted. This is the one he wanted gone.
2. **The integrity lock on a banked day** — untouched. Different job: it closes finished work
   against a stray thumb, it exists because of real field bugs, and it is what makes the card
   trustworthy. Reopening a logged day is still deliberate.
3. **One session per day** — untouched, both rhythms. Recovery is part of the program.
4. **The week boundary** — untouched. Weeks stay time-paced and no rhythm reaches next week's
   loads. His August ruling stands.

Rhythm is a lens over the same dated logs, so switching costs no history in either direction.

### Volume adaptation: checked, and no change needed
The flagged hazard was Open letting someone run three push days in a week while the volume rule
reads cadence as a signal. Read the code rather than assuming: `adVolumeDrift()` only ever
REPORTS into the adaptation banner — nothing mutates the plan. It is already advisory, and it
measures sets actually performed, which stays true whatever order they happen in. A standing
check now fails if a volume adaptation ever starts applying, because that is the moment the
cadence question has to be answered before Open is safe.

### Two calls he left to me, both reversible
- **One session per day stays the floor** in Open. Recovery, not sequence.
- **A coached athlete defaults to Guided**, and the coach changes it from the athlete's own
  settings — it is per-athlete state, so it namespaces with everything else on the roster. A
  coach's program is a prescription; the athlete can still be given the wheel deliberately.

### New standing test rhythmtest.js — 27 checks
Guided keeps its rail; Open frees every session this week; the three refusals (next week, a
second session in a day, the integrity lock); the map built in week order and identical
whatever order the days are tapped; the map retiring when Guided returns; switching costing no
logs; the settings control binding; and setup asking the question in terms of what a missed day
costs rather than naming a setting. His tester's exact week is proved on a stubbed 3-code plan,
since neither shipped card has a 3-code split and skipping the case the feature exists for is
not a test.
- Verified failable on three broken copies — the week guard removed, the one-a-day guard
  removed, and `splitOpen()` forced true. The third goes red six ways, all of them Guided
  athletes losing the rail they chose.

### Build
- BUILD c168→c169, v208→v209; sw CACHE `card-v209-c169`; Session title bumped.
- Full suite (64 checks per card, 128 total) ALL CHECKS PASSED on both cards.

## c168 / v208 — 2026-09-02 (NAMES + THE CUT ITSELF — his two calls)

### The theme picker no longer argues with the Light control
A theme called **Night** sitting beside a Night button is a UI fighting itself. Fixed by
character, not by adding words:
- **`night` is retired.** Once every theme carries both lights, that theme was Coach's dark
  counterpart and nothing else — a duplicate of Coach in both renditions. It folds in: Coach is
  the stylesheet by day and wears the retired theme's palette VERBATIM by night (`#12151A`,
  accent `#5B8CFF`), so nobody loses a colour. Anyone sitting on it migrates to Coach with the
  nova→iron precedent, and their light is pinned to night AT THE MIGRATION — before the default
  reads Coach's `nat` of 'day' and turns a dark card white. Ten themes now, not eleven.
- **Night Ops → Ops. Daylight → Brass.** Labels only; ids and saved state untouched. Brass
  reads as a material beside Iron, and no longer promises a light the Light control now owns.
- A standing check fails any theme name matching day / night / auto / daylight, so this cannot
  come back by accident.

### The card now undoes its own bad cut, instead of asking the athlete to
c166 corrected the stall rule going forward and left every cut it had already made sitting in
`S.maxes`. The only remedy was the athlete finding "Put it back" — which reverses the most
recent BATCH, so a bad cut with any adaptation after it was unreachable from the UI entirely.
The card made the mistake; the card fixes it. `adRepairStalls()` runs once at boot, before the
first paint, and restores the maxes the old rule should never have touched, with a plain notice
naming both numbers and saying the card was wrong, not the athlete.
- The real danger in a repair pass is over-eagerness — handing a lifter 8% more bar because a
  script decided a cut looked wrong. It is deliberately narrow, and refuses four ways:
  1. **The max moved since.** Athlete's number wins; say nothing.
  2. **The cut was earned** — two of the last three sessions flagged struggle.
  3. **The estimate was FALLING, not flat.** This is the discriminator that works on legacy
     data with no flags at all: flat is a compliant percentage block, falling is real
     regression. An athlete who genuinely went backwards keeps their back-off.
  4. **Too little history to judge.**
- Legacy unflagged points are treated as clean, which is the same "no evidence, no reset"
  standard c166 set for the forward rule — applied backwards.
- Runs once ever (`S.adFixStall`), or it would re-restore on every open.

### New standing test adfixtest.js — 17 checks
His exact shape restored; the log entry cleared; the notice shown, worded and dismissible; and
every one of the four refusals. Verified failable on three broken copies — the falling-estimate
guard removed, the moved-max guard removed, the run-once flag removed — all three go red, and
the two that go red are the two that would put a bar an athlete cannot move on their card.
Also re-asserts the c166 forward rule from the other side: clean flat raises no stall, struggled
flat still does.

### Build
- BUILD c167→c168, v207→v208; sw CACHE `card-v208-c168`; Session title bumped.
- Full suite (63 checks per card, 126 total) ALL CHECKS PASSED on both cards.
- `themetest` updated for the ten-theme set; `adfixtest` registered; README documents both.

## c167 / v207 — 2026-09-02 (LIGHT — his ask: day/night theme variants with a Day/Night/Auto control)

### Every theme is now one identity in two lights
Not a twelfth theme. The eleven themes stay exactly as they are and each gains a second
rendition: same hue family, inverted ground, accent re-weighted so its ink still reads on it.
The theme chip picks the character (Iron, Desert, Forest); a new **Light** row — Day / Night /
Auto — picks which rendition renders. Eleven themes × two lights = 22 palettes.
- Each theme's SHIPPED palette is kept verbatim as its `nat` (native) variant — Coach and
  Daylight are natively day, the other nine natively night. Verified mechanically: ids, names,
  order and every colour byte unchanged. Coach's day variant is still `{}` and still falls back
  to the stylesheet, which is why an empty `--bg` remains the correct result for that one.
- All 22 palettes measured for contrast (chalk/bg, chalk/panel, dim, faint, accent ink, line).
  Floors sit below what his own shipped themes already clear, so the check fails a bad NEW
  palette without ever failing one he has run in a gym. Tightest in the whole set is
  Daylight's own accent ink at 3.06 — a number that already shipped.
- `applyTheme()` now resolves through `themeVars()` and writes `data-light` on the document,
  so anything downstream can read the current light without recomputing the rule.

### Auto follows the phone, and never guesses
Auto reads `prefers-color-scheme`. Where there is no signal it falls back to the theme's own
native light rather than to a default.
- **The trap, caught by the new test before it shipped:** the first cut of the resolver was
  `!!(window.matchMedia && ...)`. With matchMedia absent that short-circuits to FALSE, and
  false means "the phone says light" — so every browser too old to answer would have opened a
  dark card blinding white in a squat rack. A missing feature is not a preference. It now
  returns null for no signal, and also catches the `media: 'not all'` case where matchMedia
  exists but the browser does not understand the query.
- A `change` subscription keeps an Auto card following a phone that flips mid-session, and
  is a no-op on a card whose athlete pinned Day or Night.

### Nobody's card is repainted by this update
`S.lightMode` migrates once at boot: a profile that already exists keeps the light it has been
wearing (its theme's native), and Auto is the default for a NEW profile only. An athlete who
opens the card tomorrow sees exactly what they saw yesterday until they choose otherwise.

### New standing test themetest.js — 22 checks, both cards
Both variants complete and legible; native palettes unmoved; all 22 apply without throwing;
Auto with no matchMedia keeps a dark theme dark and a light theme light; Auto on a real dark
phone and a real light phone; live repaint on a system flip; no override of a pinned card; the
migration both ways; and the control itself rendering, binding, repainting and lighting up.
- Verified failable on five broken scratch copies: the short-circuit trap restored, the flip
  listener removed, an unreadable day palette, a drifted native palette, and the Light control
  unbound. All five go red.
- **One test correction, mine:** `clickaudit` reported the Light control as NO CHANGE on a
  working card. The audit had just selected Coach, whose day variant IS the stylesheet and
  whose Auto already resolved to day — so day-pinned and day-under-auto were identical and no
  effect was visible. It now pins Iron/Night before testing that row. Still goes red on an
  unbound control (verified). `clickaudit` also had to stop reading `t.v` and ask the card
  through `themeVars()` which palette is actually up; `setbtns` picked up the new selector.

### Open for him
The chip row now has themes named **Night**, **Night Ops** and **Daylight** sitting beside a
Day/Night/Auto control, and "Daylight" in its night rendition is a confusing label. His names,
left alone. A label-only rename (Night → Steel, say) would not touch ids or saved state.
Auto follows the system setting; clock-based off the existing 3 AM roll is a small swap if he
prefers it.

### Build
- BUILD c166→c167, v206→v207; sw CACHE `card-v207-c167`; Session title bumped.
- Full suite (62 checks per card, 124 total) ALL CHECKS PASSED on both cards.
- Test environment rebuilt from source: jsdom 24.1.3, canvas 2.11.2 compiled against local
  node headers (`--nodedir=/usr`) because the normal header fetch is blocked in this sandbox.

## c166 / v206 — 2026-09-02 (FIELD — "three sessions without progress" on lifts that were progressing)

### His report: bench and OHP flagged as stalled while he added weight every week
He was right; the rule was wrong. The stall detector compares the ESTIMATED 1RM
across the last three sessions and fires if it has not risen. A rising-percentage
block (70x8 -> 75x6 -> 80x5) estimates the SAME max every session BY DESIGN -
that is what a percentage block is - so an athlete doing exactly what the card
prescribes produces a flat line, and the rule read compliance as a stall and cut
two training maxes 8%. Bench and OHP are the lifts he hits cleanly at target
reps; that is why those two.
- Fix: a stall needs STRUGGLE. Each e1RM history point now records whether that
  session was executed clean (every set hit at target with a rep in reserve).
  The stall rule requires a flat-or-falling estimate AND at least two of the
  last three sessions marked as struggle - a missed rep, an adjusted set, or a
  grind to RIR 0. Points recorded before this build carry no flag and are
  treated as clean: no evidence, no reset.
- The existing "Put it back" undo on the adaptation banner reverses the cut
  that already happened. TELL HIM: open the adaptation banner and put both
  lifts back; the corrected rule will not re-cut them.

### New standing test stalltest.js
Four clean sessions through the real banking path -> flagged clean, no stall,
the max is never cut (it may climb - the moving-lift rule). Missed reps and
RIR 0 -> flagged struggle. Two struggled of three on a flat line -> stall.
His exact shape (clean sessions, flat-to-falling estimate) -> no stall. Legacy
unflagged points -> no stall. Verified against the OLD rule in a scratch copy:
it cuts the compliant lifter, exactly as the field did.
- Two test corrections, both plan-dependence in my checks (the Training Card's
  percentages made clean estimates climb; the card correctly RAISED the max).

### Build
- BUILD c165→c166, v205→v206; sw CACHE card-v206-c166; Session title bumped.
  Full suite (52 tests) ALL CHECKS PASSED on both cards.

## c165 / v205 — 2026-09-02 (FOLDS — his ask: collapse anything that distracts)

### Collapsible sections, remembered
- foldHTML(id, title, body, defaultOpen): a header row with a chevron that
  opens and closes the section. State persists per fold in S.fold. A closed
  fold does not render its body at all - Exercise history and Past sessions are
  the heaviest sections on the card and now cost nothing until opened. Every
  fold is lockfree so a banked day cannot freeze it. 44px tap target.
- PLAN tab folds: The road ahead (open), Weekly work (open), Exercise history
  (closed), Why these numbers (closed), Where these numbers come from (closed).
  The routine itself is deliberately NOT folded - the plan is the point.
- CAL tab folds: Training days & calendar export (closed), Past sessions
  (closed). The calendar grid itself stays visible.
- Help jumps and tour steps land on things that may live inside a closed fold:
  both now open every fold first, then find their target. Anyone who asked to
  be shown something wants to see it.

### Suite
- New foldtest.js (14 checks): folds render, history closed by default with NO
  body, weekly work open, the routine never folded, tap opens/closes, state
  remembered across re-render, gallery folded on CAL with the grid visible,
  lockfree, foldOpenAll opens every section.
- gallerytest updated to open the fold first, as a user would.
- orphantest correctly flagged the new data-fold container marker; taught that
  the control is data-foldtog. The scan is doing its job.
  Full suite (51 tests) ALL CHECKS PASSED on both cards.

### Build
- BUILD c164→c165, v204→v205; sw CACHE card-v205-c165; Session title bumped.

## c164 / v204 — 2026-09-02 (VISUALS AUDIT — his ask, all cards, coached athletes included)

### Audited, both cards, own card AND inside a coached athlete's namespace
Plate diagrams, weekly muscle-volume bars, the exercise history chart, the
bodyweight sparkline, PR sparks, the share sheet's "shape of a block" wave bars,
progress dots, the streak badge — and that the coach's own charts never inherit
an athlete's data. New standing test viztest.js, 31 checks per card.

### Found and fixed: the wave bars were frozen at generation time
The share sheet's per-lift wave read ex.wk, an array baked when the plan was
generated. The live load recomputes from CURRENT maxes every session. So after
an auto-adjust or a retest moved a max, the graphic an athlete SHARED showed
loads they no longer lifted. Now each week reads through sheetLoad — the same
path the card and the print sheet use — with the baked array as fallback only.
The test proves the wave equals the prescribed load for every week and that it
follows a changed max.

### Verified accurate (no change needed)
- Plate math: lb lists sum to bar + load on the 5 lb grid and refuse off-grid
  loads; kg lists sum to the 20 kg bar. The plate DIAGRAM draws exactly the
  plates the math says on both sides (three rects per plate; 6/12/18 for
  135/225/315).
- Weekly volume bars read 6 and 10 for 6 and 10 logged hard sets, heights
  proportional (~10:6).
- History chart: one point per session, first and last estimated max present.
- Bodyweight sparkline: four points, direction correct.
- PR sparks: one per record.
- Progress dots: done/total exact.
- Coached athlete: identical results inside the athlete's namespace; the
  coach's own history untouched afterward.

### Test bugs found while writing it (card was right each time)
kg units flag is S.unit not S.units; wuBarSVG returns {svg} not a string; plate
colour counts hit gradient DEFINITIONS not plates; a volume-bar seed bled into
the progress check. All corrected in the test.

### Build
- BUILD c163→c164, v203→v204; sw CACHE card-v204-c164; Session title bumped.
  Full suite (50 tests) ALL CHECKS PASSED on both cards.

## c163 / v203 — 2026-09-02 (COACHING PARITY — his ask, and it found one)

### "Verify that programming athletes through coaching programs them spot on like the original card"
New coachparity.js: the same answers given two ways - on the athlete's own card,
and through the roster - must produce a byte-identical program. Fingerprint =
every day, every movement in order, sets, reps, percentage scheme, max key,
load to the pound, rest, warm-up, RIR, plus the seeded maxes. Three profiles:
build/4-day/male with a full calibration; strength/3-day/female with fallback
maxes and a session length; and the beginner Start path. Also checks the
generator is deterministic at all, that the three profiles are genuinely
different programs, and that programming an athlete never rewrites the coach's
own program.

### Result: two of three identical; the beginner Start path was NOT
A coached beginner was handed **4 x 10-15** where their own card gives the
beginner floor of **2 x 10**.
- Cause: isStartMode() deliberately returns false for a coached athlete so the
  coach is not trapped in the Start SHELL (no "back to roster" there - a real,
  earlier field fix). But exSets/exReps keyed the PRESCRIPTION off the same
  guard. The function's own comment claimed "the athlete still gets a
  beginner-appropriate program" - it did not.
- Fix: two concerns, two functions. isStartProgram() (S.mode==='start', true for
  the athlete no matter who is looking) now drives set count, rep scheme, the
  load-selection cue, the target label, and hiding RIR for beginners.
  isStartMode() keeps driving only the shell: tab strip, rest copy, graduation
  banner, body class.
- After the fix: all three profiles byte-identical both ways.

### Build
- BUILD c162→c163, v202→v203; sw CACHE card-v203-c163; Session title bumped
  (no Session Card code change). Full suite (49 tests) ALL CHECKS PASSED on both.

### Note
This is the first parity bug of the whole run and it was invisible to every
earlier coaching test because they all used FULL-mode athletes. Rosa and Lee
earn their place in the test for exactly that reason.

## c162 / v202 — 2026-09-02 ("so the coaching side is 100%?" — no; now the core is)

No card code changed this build. It closes the coaching flow's coverage gap.

### athleteflow.js — coaching end to end, 17 checks, all passing first run
Two athletes on the roster. Manuel: plan built, review started, a full session
banked AS him — the log key carries his id, is stored in his drawer, and he sees
exactly his one session. Rosa: partial work, no bank, sees no sessions. Switch
back to Manuel: his banked day is still his and still locked, Rosa's note did not
follow. Switch back to the coach: the coach's own notes, maxes and log come back
intact, and the coach never sees an athlete's session. Remove Manuel: off the
roster, his history SURVIVES removal (wipe is a separate, explicit act — the code
says so and the test now holds it to that), the coach's card untouched.

### What is verified on the coaching side now
Add, switch in/out, status readout (incl. built-but-not-started), coaching on a
banked day, banking as an athlete, multi-athlete isolation, coach state restore,
removal preserving history, and the two-card namespace separation.

### What is still NOT verified (honest list)
- The athlete's onboarding driven through the UI screens tap by tap (the test
  drives ONB_build programmatically).
- Retest for an athlete.
- A coach printing an athlete's sheet.
- Anything on a real device.

### Build
- BUILD c161→c162, v201→v202; sw CACHE card-v202-c162; Session title bumped.
  Full suite (48 tests) ALL CHECKS PASSED on both cards.

## c161 / v201 — 2026-09-02 (FIELD — roster said "needs the assessment" after a built plan)

### His report: added an athlete, ran the questionnaire, built the profile — roster still said needs assessment
Reproduced exactly. ONB_build writes the plan and moves the athlete to the review
screen; onb.done flips ONLY when the final "start" button on that review is
tapped. A coach who builds the plan and returns to the roster leaves done=false
with a complete plan stored — and rosterProgress read done alone.
- Fixed: a built plan (genPlan with days) counts as assessed. "Started" is
  tracked separately, so the row now reads one of: "needs the assessment",
  "plan built · open their card to start", "assessed · not started", or
  "N sessions logged". Nothing about the athlete's flow changed — they still see
  the review and tap start when they open their card.
- rosterflow extended: builds the plan without tapping start, asserts the roster
  reads assessed:true, started:false, and the label says "plan built"; then
  taps start and asserts started:true.

### Build
- BUILD c160→c161, v200→v201; sw CACHE card-v201-c161; Session title bumped
  (no Session Card code change this build). Full suite ALL CHECKS PASSED on both.

## c160 / v200 — 2026-09-02

### The print sheet is the card (his rule: "must be identical")
A row-by-row comparison of the printed week against the live day found three
gaps. Names, order, reps and loads already matched; these did not:
- **Set counts.** The sheet printed base plan sets; the card runs the
  session-length additions on top (default ON for the Session Card) plus any set
  the athlete added. Now the sheet runs sessApply exactly as the day does, and
  for the week on screen reads set counts, swaps and loads from the same state
  the card renders from - liveByName, keyed by the planned movement.
- **Rest.** Not printed at all. New Rest column, from exRest (goal + adjustment).
- **Finisher.** The Zone 2 finisher the session-length target prescribes now
  prints under the day it belongs to.
- Swapped movements print under their swapped name with the swapped load.
- New standing test sheettest2.js: builds a day with a swap, a removal, an
  added set and the target on, then asserts every printed row equals the live
  row - movement, order, sets, reps, load, rest - and that the finisher prints.
  The older sheetcheck (geometry/layout) still passes.

### "I understand" dead on the Training Card (his second gate report)
Not reproducible from code: a fresh Training Card in jsdom accepts cleanly, the
gate is lockfree, nothing sits above it, and the boot tour waits for it. So the
accept path is now UNSWALLOWABLE rather than merely correct: one idempotent
discAccept() reachable from the button, the keyboard, and a WINDOW-level capture
listener registered at load, which runs before any document-level guard the card
owns can eat the tap. bootorder proves it against a hostile document guard that
swallows every click, and proves a double-tap cannot double-fire the queue.
Hygiene: the post-onboarding tour start also waits for the disclaimer now.
- STILL NEEDED FROM HIM: the build number on the Training Card's BETA pill when
  it happens. If it is older than c153 the cause is a stale installed copy, not
  code - and c160 makes it moot either way.

### Build
- BUILD c159→c160, v199→v200; sw CACHE card-v200-c160; Session title bumped.
  Full suite (46 tests) ALL CHECKS PASSED on both cards.

## c159 / v199 — 2026-09-02 (HIS RULING: the engine counts sessions, not days)

### "Block 1 ends in 12 days" — it doesn't, and the card had no way to know
He is entering week 3 of 6. The countdown said 12 days. The engine's week is
PLAN.days.length BANKED SESSIONS, however many calendar days they take; rest
days stretch it and the card cannot know by how much. A calendar end date was
me inventing knowledge the engine does not have. Standing principle, his words:
"the engine shouldn't know the precise day, only how many sessions have been
completed that make up a week — just how the engine actually runs."

### Retired, every surface
- calEndIso / calDaysLeft / calWeekOf — all pure projections from PLAN.start.
  Kept as _RETIRED functions so the retirement is visible in code; the live
  names are null-returning stubs so nothing can throw.
- Countdown strip: "N sessions left in the block" (new sessLeft(): whole weeks
  remaining × days per week, plus this week's unbanked days). Never days.
- Calendar export: the remaining SESSIONS placed on the athlete's chosen
  training days, no date bound — the honest version of "send the rest of the
  block to my calendar".
- Bulk's landmarks: "one week of sessions left" fires at sessLeft()===days per
  week; "block complete" fires on blockEndDue() — engine facts only.
- Grid: the ★ block-end projection removed; scheduled marks bounded only by the
  athlete's training days; the dashed DELOAD mark is now a FACT — a banked
  session whose key says W6 — never where the calendar thinks week 6 falls.
  (calWeekOf pre-dated the calendar work; it was a projection too and went with
  the rest.)
- Day detail label: block/week read from the banked session's own key.
- Both legends corrected.

### Suite
- caltest rewritten around sessions: no projection exists, sessLeft arithmetic
  incl. banking today, strip wording, export count === sessLeft(), every export
  event on a chosen training day, no star. mailtest passes unchanged.
- One trap during the change: the retired function was still DECLARED below the
  new stub and won the hoisting race, so the stub was inert. Renamed on both
  cards; test caught it.
  Full suite (45 tests) ALL CHECKS PASSED on both cards.

### Build
- BUILD c158→c159, v198→v199; sw CACHE card-v199-c159; Session title bumped.

## c158 / v198 — 2026-09-02 (THE GALLERY — his call, "low risk, go ahead")

### Past sessions, kept and shareable
- **Past sessions** section at the bottom of the CAL tab: the last 12 banked
  days, each with date, day title, sets, tonnage moved, record count, and two
  buttons - Wrap-up and Share. The day screen's calendar strip also carries a
  "Last session's wrap-up" link whenever a prior banked day exists, so the
  wrap-up stays one tap away until the next session replaces it.
- **Wrap-up** reopens a full-screen sheet for that day: tonnage, sets, movement
  count, every record with its previous best, every movement with sets × reps
  @ top load, and a Share button. Lockfree, so a banked day cannot swallow it.
- **Share** paints THAT day through the existing share pipeline - same sheet,
  same QR, same fallback chain - so a session can be posted from the couch
  instead of composed in a gym.

### Built only from what was already stored
sessionSnapshot(iso) reads exHist (sets and weights by date), prs (records by
date), and the log key (day code → title). Nothing new is written; the gallery
is a read-only view. hit/adjusted per set is not stored per date, so the past-day
sheet shows sets logged rather than "sets as prescribed" - honest to the data.

### The live share path is untouched (his explicit ask: "make sure nothing got affected")
The painter takes a snapshot only through SHARE_SNAP, null by default. Every
existing caller leaves it null, so the gym-day share is byte-for-byte what it was.
gallerytest proves both: a past-day share carries that day's date, movements and
record; with no snapshot, the share is today's and SHARE_SNAP is null afterward.

### Suite
- New gallerytest.js (20 checks): empty history shows nothing; snapshot set
  count, tonnage, record and rows are exact; gallery listed on CAL; strip link
  present; wrap-up reopens with record and movements; lockfree; past-day share
  paints the right day; live share unchanged.
  Full suite (45 tests) ALL CHECKS PASSED on both cards.

### Build
- BUILD c157→c158, v197→v198; sw CACHE card-v198-c158; Session title bumped.

## c157 / v197 — 2026-09-02 (FIELD — the records prompt that never came)

### His report: banked at the gym, no personal-records prompt
Dismissing any prompt sets prHide=today. Cardio and extra lifts cleared it
("new work earns the screen again"); **new records set at banking did not.**
So dismiss the cardio recap after the Zone 2 finisher, bank, set records — the
records were written to the ledger and never shown. Same session that hit the
c151 wrap-up bug (plank taken out): two missing prompts, two separate causes.
- Fixed: recordHistory clears prHide whenever it writes a record. A record
  always earns the screen. Dismissing that prompt still works.
- New standing test prflow.js drives the real order: dismiss earlier, train
  heavier than history, bank, assert the prompt shows, assert dismiss still hides.

### Build
- BUILD c156→c157, v196→v197; sw CACHE card-v197-c157; Session title bumped.
  Full suite (44 tests) ALL CHECKS PASSED on both cards.

### His feature ask, recorded for his decision (NOT built — he is in verification)
A gallery of past session wrap-ups: reopen any banked day's high-five sheet with
its numbers and records, and share it later from home rather than at the gym.
The DATA already exists — every banked log holds its report, S.prs holds every
record with its date, and the share sheet already renders from a day. It would
be a read-only view over stored data plus a share button: low-risk, but it is a
feature, and he said no more features until the card has been fielded. His call.

## c156 / v196 — 2026-09-02 (DEEP DIAGNOSTICS — no new features)

Two diagnostics the suite never had, both run for the first time, both found
real bugs. Nothing added to the cards except fixes.

### Orphan-control scan (orphantest.js) — found a dead pair that mattered
Every data-* attribute the card RENDERS is checked for something that BINDS it.
- **stalekeep / staleuse were rendered and bound nowhere.** When another copy of
  the card saves after this one (Safari tab + home-screen app at once — how
  everyone installs), save() silently returned without writing ON EVERY CALL
  until reload, and the banner's only two exits did nothing. Every set logged
  after the warning was quietly discarded.
- Fixed: "Keep this one" adopts the other copy's stamp as seen and writes this
  copy over it; "Load the other copy" reloads into the stored state (this copy's
  unsaved work is the cost, exactly as the banner says). Banner is lockfree.
  hardReload() added as the one seam so reload exits can be verified.
- staleflow.js drives it: trips the warning, proves saves drop, takes each exit,
  proves saves resume and the banner clears.
- 10 other candidates triaged: 6 bind through the rest overlay's hit('data-…')
  dispatcher, 3 are markers not controls (rstop, streak, wl). Scan taught both.

### Stored-state fuzzer (statefuzz.js) — found two permanent bricks
Boots the card against mangled stored state: every top-level key missing, nulls
on every indexed key, legacy keys from removed features (painLog, limits, onb
with limits), raw garbage in the slot, malformed set lists. 115 cases (Session),
110 (Training).
- **Two crashes**: a set list that is not an array, and a null entry inside one.
  Either threw on EVERY render — the day screen would never draw again.
  Cause: weekSets/cycleSets walk every stored exercise state directly, so
  exState's own healing never reaches a day not on screen.
- Fixed at boot: one pass over all of S.data puts every entry in shape (non-array
  sets → [], non-object entries dropped, non-object states dropped). exState
  also heals defensively.
- Result after fix: 115/115 and 110/110 survive boot, render, save, report,
  settings, provenance and the calendar tab.
- Suite mode runs a 41-case representative sample to fit the runner; the full
  sweep is the documented two-chunk manual run.

### Diagnostic lesson, recorded
The chunked fuzzer accumulated results across runs; two "still failing" reports
after fixes were STALE entries from the pre-fix run. The second fix was right
first time — the instrument was lying. Results file now cleared on start=0 and
before every manual sweep.

### Build
- BUILD c155→c156, v195→v196; sw CACHE card-v196-c156; Session title bumped.
  Full suite (43 tests) ALL CHECKS PASSED on both cards. DEPLOY BOTH — the
  stale-copy fix protects logged sets on every device that has the card open in
  two places.

## c155 / v195 — 2026-09-02 (STABILISATION — no new features)

He has stopped adding features and moved to verification. This build adds no
capability: it closes the flow-coverage gaps that produced seven field bugs.

### Judgment call: the day-lock guard was NOT inverted
Inverting it needs a structural wrapper around the session region, and .ex is
shared between exercise cards and settings blocks. That is exactly the refactor
that produces bug #8 in a codebase entering stabilisation. Reversed my own
earlier recommendation and did the safe equivalent instead.
- **lockaudit.js**: renders a BANKED day, enumerates every interactive control on
  screen, and fails if any non-session control would be swallowed by the guard.
  Same protection as inverting it, no restructuring.
- Result: **no remaining omissions.** Seven controls flagged and all seven
  verified as legitimate session editors - set marks, add/remove set, swap, load
  editor, per-set feel, readiness, session date/time, custom-exercise adder.
  That verified list is now encoded in the test.

### restoreflow.js — the highest-stakes untested flow, now covered
Banks a session, exports the real backupAll payload, CLEARS storage the way
clearing site data does, restores through restoreBackup(), and verifies maxes,
records, bodyweight, notes and the banked session WITH its report all return and
are written to storage rather than memory. Also: a rescue snapshot is taken
before overwriting, and a junk file leaves the card untouched.
**Result: restore works on both cards.** No bug found - which is the answer that
matters, because it was the one flow that could lose months of history.

### blockroll.js — the rollover arriving on its own schedule (he is in week 5 of 6)
Puts the card on the final week, checks the max review (every suggestion carries
its reasoning, none silently below current), rolls the block, and verifies: block
number advances, clock resets to week 1 day one, the finished block is archived
with its maxes, every lift still has a sane number, nothing silently dropped, the
review does not re-offer itself, the new block prescribes real loads, and the day
is unlocked. **Result: rollover works on both cards.**

### Two test bugs found and fixed, both mine, card correct both times
- restoreflow wrote a note BEFORE banking; saveSessionLog deliberately stashes
  the day's notes into the session log and clears the live field. Test resequenced.
- blockroll seeded the Session Card's lift set onto the Training Card, which
  assesses the row - the missing max dropped the key from JSON. It now seeds from
  each card's own MAXINFO. The card had handled the missing max gracefully.

### Build
- BUILD c154→c155, v194→v195; sw CACHE card-v195-c155; Session title bumped.
  Full suite ALL CHECKS PASSED on both cards.

### Coverage now, honestly
Flows executed end to end by the suite: banking, add/remove a set, remove a
movement, finish a day with a removal, coaching on a banked day, restore, block
rollover, mail, calendar, terms, boot order.
STILL NOT COVERED, needs a human: an athlete's assessment driven end to end
(add -> assess -> generated plan -> first banked session), the .ics download in
an installed PWA, and anything layout-dependent on a real Android device.

## c154 / v194 — 2026-09-02 (ANDROID AUDIT)

### What the audit found and fixed
After the "can't press I understand" report, every full-screen overlay in both
cards was checked for the same reachability class.
- SAFE already: hw-wrap, rpt-wrap, wn-wrap are bottom sheets whose INNER panel
  caps at 88-92vh and scrolls. restchip was fixed once before (its comment still
  records "that was the cut-off clock") with the same flex-start + margin:auto
  pattern.
- FIXED: **blockfx** — the block-end celebration centred its card with no scroll
  path and no inner height cap. It carries block stats, so at a large Android
  display size its buttons could sit in clipped, unreachable space. Now
  flex-start + margin:auto + overflow-y:auto.
- FIXED: **avabig-wrap** — the enlarged photo caps the image at 64vh but the
  caption and controls beneath it were uncapped. Given the same scroll path.

### Checked and clean
- navigator.share / wakeLock / vibrate: all feature-detected, never assumed.
- -webkit- prefixes: every one either paired with the standard property or an
  accepted Chrome alias. -webkit-mask is paired with mask.
- 100vh: one use (t, .st-wrap min-height) - harmless in an installed PWA, which
  has no URL bar.
- Input types date/time/number render natively on both platforms.

### New standing test reachtest.js
Enforces the contract that made this bug possible, so a new overlay cannot ship
with it: every full-screen overlay must scroll itself or cap and scroll its inner
sheet; no ROW flex may centre while overflowing (dead space that cannot be
scrolled to); the gate specifically must use margin:auto; the accept control must
be a real button of at least 44px; Android-divergent APIs must be guarded;
prefixed properties need a standard form.
- Three test bugs fixed while writing it, all mine: heredoc double-escaping
  broke two regexes, and the third matched CSS text inside a COMMENT - flagging
  restchip's own fix note as the bug it describes.

### Honest limit — worth stating plainly
The suite runs in jsdom, which has NO layout engine. It could not have caught the
Android bug and cannot prove any layout works. reachtest enforces the CSS rules
that prevent the known failure; it does not render a pixel. Real Android coverage
means a real Android device, ideally at a large display-size setting - which is
what his second tester provides and what no test here replaces.

### Build
- BUILD c153→c154, v193→v194; sw CACHE card-v194-c154; Session title bumped.
  Full suite ALL CHECKS PASSED on both cards.

## c153 / v193 — 2026-09-02 (FIELD HOTFIX 7 — Android)

### His report: an Android user, installed fine, stuck on "I understand" — can't press it
Not the tap guard this time. The gate was a ROW flex with align-items:center AND
overflow-y:auto. When content is taller than the viewport, a centred flex item
overflows in BOTH directions and the overflow cannot be scrolled to — so on
shorter viewports, and at the larger system display sizes Android users commonly
set, the button sat in genuinely unreachable dead space below the fold. It read
as "the button doesn't work" because nothing was wrong with the button.
- Fixed the standard way: align-items:flex-start on the wrapper, margin:auto on
  the child. Centres when there is room, scrolls when there is not.
- Hardened while in there: the control is a real <button> (was a div), 48px
  minimum tap target, touch-action:manipulation, a tap highlight, Enter/Space
  support, and a delegated listener on the gate as a backup path.

### The class, audited
Scanned every position:fixed;inset:0 overlay in both cards for the same trap.
The gate was the only one. restchip flagged as a false positive — it is a COLUMN
flex, so its align-items:center is horizontal, and its own comment records this
exact bug class biting once before ("that was the cut-off clock") and being fixed
with the same flex-start + margin:auto pattern.

### Suite
- bootorder +7: the gate scrolls, does NOT centre with align-items, centres via
  margin:auto on the child, the control is a real button with a >=40px target,
  pressing it acknowledges, and the keyboard path works.
  Full suite ALL CHECKS PASSED on both cards.

### Build
- BUILD c152→c153, v192→v193; sw CACHE card-v193-c153; Session title bumped.

### Tell the Android user
He must reload to get the fix — an installed PWA serves the CACHED build. Open
it, pull to refresh or close and reopen twice; the service worker picks up the
new CACHE name (card-v193-c153) and swaps on the next launch. If he is still
stuck, Chrome menu > his profile > site settings > clear storage for the domain
and reinstall.

## c152 / v192 — 2026-09-02 (FIELD HOTFIX 6)

### His report: tapping an athlete card in coaching does nothing
The day-lock tap guard again — same class as the frozen disclaimer gate in c144.
The guard swallows every tap on a banked day unless the target is on its
allowlist, and NOTHING roster-related was: not the athlete rows, not the add
field, not the remove ×, not the switch banner. He had just banked day F, so the
entire coaching screen was dead. It would have worked fine on an untrained day,
which is exactly why it looked intermittent rather than broken.
- The roster block and the coaching banner are .lockfree now. Coaching is
  day-agnostic: switching athletes never edits the logged session. One class on
  each container covers every control inside it.
- Note for future screens: the allowlist mentions #coachHost, but that is the
  guided-TOUR host, not the roster. The name is misleading and cost time here.

### New standing test rosterflow.js
Adds an athlete, LOCKS the day exactly as banking does, renders the roster,
clicks the athlete card, and asserts the athlete opens, the card switches into
that athlete's log namespace, closing returns to the coach's own namespace, and
the tap guard exempts the row.
- Verified against the old markup: 4 checks fail with active=null — his exact
  symptom, nothing happens.

### Build
- BUILD c151→c152, v191→v192; sw CACHE card-v192-c152; Session title bumped.
  Full suite ALL CHECKS PASSED on both cards.

### Sixth field bug in six builds — and the SECOND from this one guard
The day-lock guard has now killed two whole features (disclaimer gate c144,
coaching c152). Every screen that renders while a day is banked needs .lockfree
or it is dead on arrival. Worth an audit of every remaining overlay and tab
against a locked day - the guard is an allowlist, so anything new is broken by
default until someone remembers it.

## c151 / v191 — 2026-09-02 (FIELD HOTFIX 5)

### His report: finished #7 of 8 on day F, no wrap-up — #8 had been taken out
His diagnosis was right. sessionPct counted EVERY exercise in the day, including
movements taken out of the session. An out movement can never be "done", so the
day sat permanently one short (7 of 8), the wrap-up gate (done<total) never
opened, and the high-five bar was never offered.
- firstOpenFocus had skipped out movements all along; the progress arithmetic
  never learned the same rule. New exCounts(i) gate: a movement that is not in
  today's session is out of the count at BOTH ends, done and total.
- Applies to the progress dots and the deck header too, which read the same
  numbers — they were showing 7/8 for a finished session.

### New standing test wrapflow.js
Takes the day's last movement out, logs every remaining one, and asserts: the
total drops by one, every trained movement counts, the session reads COMPLETE,
the wrap-up is offered, it is the high-five bar, and an unfinished day still
withholds it.
- Verified against the old code: reproduces his exact symptom — {done:4,total:5},
  wrap-up withheld.

### Build
- BUILD c150→c151, v190→v191; sw CACHE card-v191-c151; Session title bumped.
  Full suite ALL CHECKS PASSED on both cards.

### Fifth field bug in five builds, same class every time
Screens tested, flows not. banking (c145), remove-a-movement (c149), add-a-set
(c150), finish-a-day-with-a-removal (c151). Four of the five were regressions
from features added in this same session's run of builds.
STANDING RECOMMENDATION, repeated: stop adding features. Write the remaining
flow tests — restore-from-backup, block rollover, roster switching — then field
the card for two weeks before touching it again.

## c150 / v190 — 2026-09-02 (FIELD HOTFIX 4)

### His report: "unable to add a set to any exercise"
My own regression from c130. The session-length target grows a day by adding
sets, so exState gained a trim that pops untouched trailing sets when the target
is turned off. That trim could not tell a TARGET-grown set from one the ATHLETE
added: "+ set" pushed a set, the very next render popped it straight back off.
Every exercise, both cards, since c130 — eight builds.
- Sets the athlete adds already carried added:true. The trim now stops at any set
  that is logged OR flagged added; only target-grown, untouched sets are eligible.
  The minus button still removes added sets, which is the only thing that should.

### Same gap class, fourth time: screens tested, flows not
The suite knew the add-set button EXISTED (helptest points at it) and had never
PRESSED it. c145 banking, c149 remove-a-movement, now this.
- New standing test setflow.js: click the real control, assert the set is added,
  survives one re-render, survives repeated renders, survives a save/load round
  trip, carries the athlete flag, a second add also holds, the minus button still
  removes it, and logged sets are never trimmed.
- Verified by restoring the old trim in a scratch copy: 8 of 9 checks fail,
  exactly matching his report. The test earns its place.

### Build
- BUILD c149→c150, v189→v190; sw CACHE card-v190-c150; Session title bumped.
  Full suite ALL CHECKS PASSED on both cards.

### Standing recommendation, now urgent
Four field bugs in four builds, every one in a flow the suite never executed.
Before ANY new feature: write the flow tests for restore-from-backup, block
rollover, and roster switching. A restore bug eats real history and stays
invisible until the day it matters.

## c149 / v189 — 2026-09-02 (FIELD HOTFIX 3)

### His report: ReferenceError: Can't find variable: outStamp
Removing a movement called outStamp(S.day, ex.name) — a function defined NOWHERE
in either card, left over from an abandoned "when was this benched" idea. It threw
between the push and the save, so the movement looked removed on screen and was
never persisted: gone until the next render, back afterwards.
- Removed from both cards. Nothing anywhere reads a stamp; S.outs is the whole
  feature and it works. No replacement invented.

### The class, swept
Static scan of both cards for calls to functions that are never defined, with
comments and CSS functions filtered out. Result: **outStamp was the only real
phantom.** Everything else that looked like one is deliberate and safe —
effDay (16 calls), curSKEY, activeAthlete, coachIdle, logLabel and generatePlan
are all optional-feature probes wrapped in typeof X==='function', and getPixel
is a parameter of the function it appears in. Recorded so this scan does not get
re-run from scratch next time.

### New standing test phantomtest.js
The suite had never removed a movement — same gap class as the c145 banking
crash (screens tested, flows not). It now removes the day's last movement the
way the UI does and asserts: no throw, no error to the handler, the removal is
PERSISTED, the card treats it as out, it survives a save/load round trip,
restore puts it back, and outStamp appears in no executable line.

### Build
- BUILD c148→c149, v188→v189; sw CACHE card-v189-c149; Session title bumped.
  Full suite ALL CHECKS PASSED on both cards.

### Flow-coverage gaps still unwritten (recommended before more features)
restore-from-backup, block rollover, roster athlete switching. A restore bug
would eat real history and stay invisible until the day it mattered.

## c148 / v188 — 2026-09-02

### Shared links now arrive looking like something
A shared card rendered as a bare URL — no title, no image, no description. The
card has a share sheet and a QR; the link is the product's first impression.
- Added per card: meta description, author, application-name, rel=canonical,
  full Open Graph set (type, site_name, title, description, url, image 512 with
  dimensions) and Twitter summary card. Both point at that card's CANON_URL, so
  the c129 rule still holds: card moves, everything moves with it.
- Manifests enriched: description, lang, dir, categories, id.

### The home-screen icon was an SVG data URI
The head linked apple-touch-icon to an inline SVG, which OVERRODE the real
apple-touch-icon.png already shipping in the deploy folder. iOS support for SVG
there is unreliable — a blank or generic home-screen icon is the usual symptom.
Now points at the PNG (180 and 192). The favicon keeps its inline SVG (works
everywhere, costs no request) and gains a PNG fallback.

### Suite
- manifesttest +8: description present, og:title/og:image present, og:url AND
  rel=canonical both equal CANON_URL, apple-touch-icon is a PNG with no SVG data
  URI overriding it, manifest has a description, lang and categories.
  Full suite ALL CHECKS PASSED on both cards.

### Build
- BUILD c147→c148, v187→v188; sw CACHE card-v188-c148; Session title bumped.

### Still gating "official" (not code — recorded so it is not forgotten)
1. Terms: 8 [BRACKETED] sections + the CONTACT blank. This is the real gate for
   anyone outside his own circle using the card.
2. Domain: thundermeadows.github.io is the biggest perception tell. He owns
   deadstopgear.com — a subdomain pointed at the same Pages site is free.
   If the domain changes, CANON_URL, og:url and rel=canonical move the SAME build.
3. The BETA pill should stay until 1 is done.

## c147 / v187 — 2026-09-02

### Bulk pays attention (both caught by his question "does everything he says make sense?")

**1. The greeting didn't know you had already trained.**
It fired on any known training day, so training in the morning and opening the
card that evening got "Training day. The bar missed you." — a bear not paying
attention. The greeting now checks whether today's session is banked and splits:
- not yet trained → the invitation (PLAYFUL), as before
- already banked → MAIL_DONE, four new lines (ENCOURAGING), e.g. "Session banked.
  That is the whole job. Go eat something with protein in it." and "Already
  trained today. I have nothing to nag you about, which is unsettling for me."

**2. The weekly books landed on the wrong day.**
The condition read `if(today!==mon || true)` — scaffolding left armed, always
true — so the digest arrived whenever the card was first opened that week rather
than Monday. Content was always correct (it covers the previous week); only the
timing was arbitrary. Now Monday only.

### Suite
- mailtest +6: an untrained session day gets the invitation and NOT the done
  letter; a trained day gets the done letter, never claims the bar missed you,
  and wears ENCOURAGING; the books arrive on Monday and only Monday (the check
  adapts to whichever weekday the suite runs on, and the later books check pins
  the clock to a Monday). Full suite ALL CHECKS PASSED on both cards.

### Build
- BUILD c146→c147, v186→v187; sw CACHE card-v187-c147; Session title bumped.

### Note on what "reminders" means in this card (asked, worth recording)
- Bulk's mail is NOT a push notification. It is written on open and waits in the
  envelope; the phone never buzzes for it. No web push on iOS was ever promised.
- The ONLY reminder that reaches the athlete with the card closed is the .ics
  export's VALARM (-PT60M), fired by their own calendar app. STILL UNTESTED in
  the installed PWA — open field item since c138.
- The rest timer only runs inside a live session.

## c146 / v186 — 2026-09-02

### "Clear read mail" brought everything back (field-caught)
mailPush decided "already sent?" by scanning the MAILBOX. Clearing the mailbox
therefore erased the only record that a letter had ever been sent, and the next
render — the sweep runs on every one — re-sent the lot. Clear became Refresh.

- Sent history now outlives the letters: S.mailSent is an id→date ledger, written
  on every push and read by the dedupe. The mailbox is only what is currently on
  screen; the ledger is what Bulk remembers writing.
- First run after this build adopts the ids already in the box, so nothing
  resends once on upgrade.
- The ledger is bounded: entries older than 120 days are pruned, plus a hard
  ceiling of 400 ids (oldest dropped first), swept once per mailSweep.

### Suite
- mailtest +7: a fresh sweep writes letters, clearing empties the box, repeated
  sweeps do NOT resurrect them, no badge returns, the ledger records what was
  sent, a genuinely new fact still gets through after a clear, a letter already
  sent today stays gone, stale entries prune, and the ceiling holds.
- Two test bugs fixed in the writing, both of which the FIX correctly caused:
  the face section needed to clear the ledger to get a fresh box, and the
  "new letter after clearing" check was re-using the same id — which the ledger
  is supposed to block. The card was right both times.
  Full suite ALL CHECKS PASSED on both cards.

### Build
- BUILD c145→c146, v185→v186; sw CACHE card-v186-c146; Session title bumped.

## c145 / v185 — 2026-09-02 (FIELD HOTFIX 2 — the banking crash)

### His report, verbatim: "undefined is not an object (evaluating 'S.painLog.filter')"
report@:16105 <- saveSessionLog@:13012. Root cause found and fixed. My quota
theory from c144 was WRONG — this was a fourth pain remnant, and c131 armed it.

- report() still built a PAIN FLAGS line from S.painLog. Before c131 that key was
  always an array, so the leftover read was silent. c131 removed the feature and
  added a boot cleanup that DELETES the key — which turned a dormant leftover
  into a crash on the exact line that runs when a session is banked. The feature
  removal did not cause the bug; the cleanup that followed it exposed one.
- Second dead reader removed with it: calIndex still fed pain levels into the
  calendar index (guarded with ||[], so silent, but describing a feature that
  does not exist).
- Both cards, both sites. S.painLog is now mentioned in exactly one place: the
  boot cleanup that deletes it.

### Why three sweeps missed it (the real lesson)
c131 removed the feature, c139 found two stale legends, c140 found a third in the
detail panel — all by READING SURFACES. Nothing ever ran the code path that
crashed, because **no test had ever banked a session.** The suite tested every
screen around banking and never banking itself.
- NEW banktest.js: marks every set hit, calls saveSessionLog(), and asserts it
  returns true, throws nothing, writes a real log key, locks the day, stores a
  real report, and leaves the card rendering. Verified by REINTRODUCING the bug
  in a scratch copy: the test fails exactly as his phone did, on four checks.
- medneutral.js hardened source-wide: strip the boot-cleanup lines and NO mention
  of S.painLog or st.pain may remain anywhere in either card. Surface reading is
  not a sweep; a removed feature needs a source-wide grep, permanently enforced.

### Build
- BUILD c144→c145, v184→v185; sw CACHE card-v185-c145; Session title bumped.
  Full suite ALL CHECKS PASSED on both cards. DEPLOY BOTH.

### Still open from c144
- Whether any PERSONAL Training-Card sessions were banked pre-c144 under the
  shared prefix (roster athletes unaffected). His call; suspicion is none.
- .ics download test inside the installed PWA.

## c144 / v184 — 2026-09-02 (FIELD HOTFIX — deploy both cards together)

### His report: Session Card frozen on the disclaimer; error banking on the Training Card

### Fix 1 — the day-lock tap guard was eating the disclaimer (certain, reproduced)
The card swallows taps on a banked day unless the target carries .lockfree. The
disclaimer gate, Terms, and the mailbox had no such class — on a banked day the
"I understand" tap died silently, and the "session is logged" toast rendered
UNDERNEATH the gate, so it looked completely frozen. All three overlays and the
day-screen calendar strip are lockfree now. The suite missed it because no test
had ever engaged the lock; coexist.js now acknowledges the gate THROUGH one.

### Fix 2 — two cards, one origin: shared storage namespace (root cause class)
Both cards live on thundermeadows.github.io and the Training Card's PERSONAL log
namespace was byte-identical to the Session Card's (LOGP with no athlete id).
Consequences found and fixed:
- Each card counted the other's banked sessions as its own (streaks, calendar,
  weekly books, recaps all cross-contaminated).
- The Session Card's plain prefix scan ALSO counted Training-Card ROSTER
  athletes' sessions (LOGP+id: starts with LOGP) — Manuel's sessions were in the
  owner's log. Found by the new test, not by the field.
- **"Start over" on the Training Card would have ERASED the Session Card's entire
  history** — the wipe listed the shared prefix wholesale. Loaded gun, defused.
Fixes: Training-Card personal logs now write under their own TLOGP ('tc-log:');
its refreshLogs reads both prefixes through the exact-namespace filter; the
Session Card applies the same colon filter; the wipe erases ONLY keys the card
can prove it owns (TLOGP, or LOGP with an id segment).

### Banking error — likely but unconfirmed
saveSessionLog names every failure. Leading suspect given the shared origin:
the 5MB localStorage quota now carries TWO full card states (one holding a photo
avatar) plus all logs — the "out of space" path fires an honest toast on a
failed write. NEED FROM HIM: the exact error text, to confirm or redirect.

### Open item — historical key ambiguity (his decision)
Any PERSONAL sessions banked on the Training Card BEFORE this build sit under
the shared prefix, indistinguishable from Session-Card sessions. After this
build the Training Card no longer sees them. If he banked real personal history
there (roster athletes are unaffected), it needs a manual claim — his call on
whether any exists worth moving.

### Build
- BUILD c143→c144, v183→v184; sw CACHE card-v184-c144. New standing test
  coexist.js (ownership both directions, wipe scope, overlays through the lock).
  Full suite ALL CHECKS PASSED on both cards. DEPLOY BOTH TOGETHER.

## c143 / v183 — 2026-09-01

### Bulk reads the whole card (his ask: "make sure he knows and lets the athlete know")
His question was whether Bulk knows everything; the answer is that Bulk always
SAW everything (same storage) but only spoke about seven things. The design that
expands his voice without turning him into noise — his own "every time? or most
time" hesitation was the right instinct:
**urgent facts get a letter the moment they are true; ambient facts land in one
weekly digest.** The inbox states this policy in its header line.

Three new letter kinds (ten total):
- **8 Data at risk** (TOUGH LOVE): fires while backupDue() is true — never backed
  up, or the last backup is stale — with the iOS storage-eviction warning and the
  one-tap fix. Capped at ONE letter per week while it stays true; recurring risk,
  recurring letter, never a daily nag.
- **9 Your own sets moved your numbers** (ENCOURAGING): mirrors every unacked
  auto-adjust with the plain numbers ("bench 210→215"). Every time, once per
  event — a card that changes the athlete's loads owes them a sentence about it.
- **10 The weekly books** (REFLECTIVE): Monday letter covering the week that
  ended — sessions, records, bodyweight movement where two logs exist. Written
  only when the week actually held something: an empty week earns silence, not
  filler. This is the "most time" answer — proof he was watching everything,
  one letter's worth of attention.

What Bulk still deliberately does NOT do: daily guilt about a missed session.
Misses show on the calendar and in the weekly count; a bear in your pocket
scolding you every morning is how the envelope stops getting opened.

### Suite
- mailtest +7: backup letter exactly once per week, tough-faced; adjust letter
  once per event with the numbers verbatim; the weekly books written from seeded
  history and SILENT for an empty week; coverage policy present in the inbox.
  Full suite ALL CHECKS PASSED on both cards.

### Build
- BUILD c142→c143, v182→v183; sw CACHE card-v183-c143; Session title bumped.

### Field Card port note
- Port wholesale. The weekly books letter is the leader-facing gem there — a
  soldier's week summarized in one honest line.

## c142 / v182 — 2026-09-01

### Bulk's letters wear his face (his expression sheet)
- Five expressions cropped from his uploaded sheet, 144px WebP data URIs, ~32KB
  total per card: FOCUSED, ENCOURAGING, TOUGH LOVE, PLAYFUL, REFLECTIVE.
- The mood rides with the message, fixed per kind: greeting and the upgrade
  letter are PLAYFUL; the streak warning is TOUGH LOVE; countdown milestones are
  FOCUSED until the day itself, which is ENCOURAGING; one-week-left is FOCUSED;
  block-end and deload are REFLECTIVE; yesterday's records are ENCOURAGING.
- Letters render with a 42px circular avatar beside the BULK line. Letters
  written before this build (no face stored) fall back to FOCUSED.
- The lite-master image stripper catches the new WebPs automatically (same
  data-URI pattern as the anatomy maps and sprites).

### Suite
- mailtest +7: five faces inlined as WebP, every letter wears a known face,
  streak=TOUGH, upgrade=PLAYFUL, one avatar per rendered letter, legacy
  letters fall back. Two test bugs fixed in the writing (newest-first ordering
  assumption; a // comment injected into a one-line eval). Full suite ALL
  CHECKS PASSED on both cards.

### Build
- BUILD c141→c142, v181→v182; sw CACHE card-v182-c142; Session title bumped.

### Field Card port note
- Port faces with the mailbox; if Bulk's voice gets a uniform review for the
  soldier-facing card, the TOUGH LOVE face likely carries more of the load.

## c141 / v181 — 2026-09-01

### Mail from Bulk (his ask): a mailbox with no mail server
- Envelope icon in the header beside the settings gear, with an unread badge.
  Opens Bulk's inbox: letters listed newest first, read on open, "Clear read
  mail" available, and an honesty line at the top — no server, no tracking; if
  Bulk knows it, it is because the athlete logged it.
- Every letter is GENERATED on the device from facts the card keeps, in Bulk's
  voice (athlete, coach, friend, pizza). Deterministic ids make the sweep
  idempotent — it runs on every render and never repeats itself. Seven kinds:
  1. Session-day greeting (only on a known training day; four rotating lines)
  2. Streak guard — the six-days-quiet last-chance day
  3. Countdown milestones for the athlete's own entries at 7/3/1/0 days
     ("ACFT in 3 days. Nothing new between now and then — sharpen what you have.")
  4. Block landmarks — one week left, and block-end day
  5. Deload week opening ("Rest is training. Pizza is rest.")
  6. Yesterday's records ("I told everyone at the gym. I am everyone at the gym.")
  7. The build announcing itself — "I got an upgrade, this is c141" — which
     doubles as the honest fix for stale installed copies going unnoticed.
- Bulk never writes without something true to say, and never invents: every kind
  keys off a real stored fact. Mail capped at 30; oldest READ letters yield first.

### Suite
- New mailtest.js: build letter exactly once, sweep idempotent under repetition,
  countdown milestone and streak letters fire from seeded facts, badge counts
  unread, opening reads all, clear leaves nothing, no malformed letters.
  Full suite ALL CHECKS PASSED on both cards.

### Build
- BUILD c140→c141, v180→v181; sw CACHE card-v181-c141; Session title bumped.
- Patch note: the two cards' headers diverge structurally; the Session patch did
  not land on the Training Card until re-anchored. Both verified by the same test.

### Field Card port note
- Port wholesale. Bulk's voice may need a uniform review for the soldier-facing
  card — his ruling; the machinery ports unchanged either way.

## c140 / v180 — 2026-09-01

### Calendar entries: notes, appointments, fitness tests — with countdowns (his ask)
- Tap any day on the CAL tab to add an entry: a name (80 chars), a type (Note /
  Appointment / Fitness test), an optional time, and a "count down to it" toggle.
  Entries are the athlete's own — typed in, listed back, deletable with one tap;
  the card never creates one on its own.
- Days wear typed dots on the grid: grey notes, amber appointments, red fitness
  tests (legend updated). The day's detail panel lists its entries with type,
  time, a COUNTDOWN badge where set, and per-entry delete.
- Countdown entries join the countdown strip — CAL tab and the day-screen slim
  strip both — soonest first, two shown: "ACFT in 12 days", "tomorrow", "today".
  Non-countdown notes stay off the strip.
- Storage: S.calNotes {iso: [{t,k,tm,cd}]}; an emptied day removes its key —
  no residue.
- One more pain remnant found and removed: calDetailHTML still rendered "Pain
  flagged this day" (third find after c139's two — the c131 sweep is now
  believed complete; every calendar surface has been read end to end).

### Suite
- caltest +12: blank entries refused, add/list/delete round-trip, countdown
  math and strip wording, non-countdown entries excluded, typed dots render,
  COUNTDOWN badge, emptied-day cleanup, pain remnant gone from the detail panel.
  Full suite ALL CHECKS PASSED on both cards.

### Build
- BUILD c139→c140, v179→v180; sw CACHE card-v180-c140; Session title bumped.

### Field Card port note
- Port wholesale — the fitness-test type IS the ACFT countdown use case; a
  leader pinning the record test date is likely its first real use.

## c139 / v179 — 2026-09-01

### One calendar: the c138 duplicate merged into the real CAL tab (his catch)
c138 built a month grid on the day screen without checking the card — the CAL tab
with calHTML() has existed all along, richer than the duplicate (day letters,
logged bodyweight, tap-to-open, tour stops). His question "we already had a
calendar tab, why not use it?" was the review that caught it.

- The duplicate grid renderer (calGridHTML) and its nav are REMOVED, CSS included.
- The CAL tab now carries everything: the real grid gains scheduled-day amber
  outlines, red numbers for scheduled days that went untrained, and the ★ block-
  end marker; beneath it sit the countdown strip, the training-day chips, the
  session-time picker, and the .ics export. Marks only exist where training days
  are actually known — nothing invented, unchanged from c138.
- The day screen keeps a slim strip only: countdown + streak guard (which must be
  seen daily to do its job) + "Open the calendar" linking to the tab.

### Stale pain remnants found during the merge (missed by c131)
- calHTML still drew a red outline for pain>=4 entries — dead since c131 deletes
  pain data on boot, now removed.
- BOTH calendar legends still described it: the .rules text under the grid AND
  the in-grid swatch row ("pain flagged"). Both rewritten to describe the marks
  that exist. The adaptation-engine comment naming pain flags as an input is
  also corrected.
- Lesson recorded: c131 removed the feature but not every description of it.
  caltest now asserts the rendered CAL tab never mentions the pain flag.

### Test lessons (two false-positives fixed IN THE TEST, card was right)
- calHTML reads its own calIndex, not streakDayset — the test now seeds the index
  the renderer actually reads.
- The legend check scanned document.body.innerHTML, which includes the card's own
  SOURCE (single-file app) — a code comment about the removed feature tripped it.
  Scoped to #app.textContent: scan the UI, not the engine.

### Build
- BUILD c138→c139, v178→v179; sw CACHE card-v179-c139; Session title bumped.
  Full suite ALL CHECKS PASSED on both cards.

### Field Card port note
- Port c138+c139 together as one unit — the calendar features land directly in
  that card's CAL tab, never as a second surface.

## c138 / v178 — 2026-09-01

### Block calendar, countdowns, calendar export, streak guard (his ask: "all of it")
All four run off facts the card already keeps — PLAN.start/weeks, the banked
dayset, the session-length estimate. No network, no permission, no invented data.

- **Block calendar** on the day screen: month grid with prev/next, trained days
  filled, scheduled days outlined, missed days struck (only when training days
  are known), final week shaded, block end starred, today outlined.
- **Training days** come from the athlete's setting first, else are READ from the
  log (any weekday trained twice or more); tap the weekday chips to set them.
  With neither, schedule-dependent features stand down rather than guess —
  the export refuses with "Pick your training days first".
- **Countdowns**: Week X of Y · block ends in N days · next session in N days
  (the last only when training days are known).
- **Streak guard**: fires ONLY when the last session is exactly six days back —
  the one day the information is useful — "Train today or the N-week streak ends
  tonight." Quiet otherwise; quiet always when there is no streak.
- **Calendar export**: one .ics for the remaining block. Its own "Deadstop"
  calendar (X-WR-CALNAME) — colour is per CALENDAR in every major client, so the
  athlete colours it once there; per-event colour is a promise the format cannot
  keep, so it is not made. Events run as long as the session actually costs
  (session-length target respected), floating local times, and a one-hour VALARM
  the PHONE fires — the reliable reminder path, unlike web push on iOS. Day
  titles project the current rotation forward from today's pointer.

### New standing test
caltest.js: block-end arithmetic, countdown strip, trained/today/nav marks,
streak guard fires at exactly six days and stays quiet at three, ics has calname
+ per-event alarms + real durations + floating times + nothing past block end,
no schedule is ever invented, and the day screen carries the block.
- One flake caught while writing it: seeded trained days straddled the Sep 1
  month boundary while the grid opened on September. Test navigates to the
  seeded month now — same family as the c130 midnight flake, fixed in the test.

### Build
- BUILD c137→c138, v177→v178; sw CACHE card-v178-c138; Session title bumped.
  Full suite ALL CHECKS PASSED on both cards.

### Field test note
- The .ics download path (blob + a[download]) needs a real-device check in the
  INSTALLED card on iOS — standalone-mode downloads have quirks Safari does not.
  If it misbehaves there, the fallback is routing the file through the share
  sheet like the recap image.

### Field Card port note
- Port wholesale; a unit calendar is arguably MORE useful there (PT schedule is
  externally fixed, so the weekday chips would be set once by the leader).

## c137 / v177 — 2026-09-01

### All five main lifts now carry the diagnosis (his call)
The priority-lift diagnosis weighed four lifts while the program programmed five.
A lagging row could never win first billing, so the horizontal pull was assessed
and programmed but exempt from the one mechanism that fixes a weak pattern.

- PG_diagnose now reads from a new PG_RATIO table instead of a hard-coded four.
  Every assessed lift has an expected-strength ratio; the loop iterates the table,
  so adding a sixth main lift later means adding one ratio, not editing a list.
- **The row's ratio is OURS: 0.75 of bench.** The other four are the conventional
  strength-standard relationships. Row-to-bench moves a long way with row style,
  so ours is pinned to the strict row the card actually cues — hinged, flat back,
  no heaving. Declared as a Chosen row in Provenance in the same build, per the
  standing rule that invented numbers get declared where they are used.
- The row is now offered on the manual priority screen, named in the auto-detect
  copy, in the block title ("Row Priority"), in the day-title star, and in the
  auto-adjust log's lift names — five places that each hard-coded the same four.
- Priority itself needed no change: extra-set logic keys off diag.weak generically,
  so a prioritised row gets more work through the existing path.

### Suite gap found and closed
No committed test asserted the provenance tiers — the 5/2/8 counts I have been
citing came from an ad-hoc probe in c126 that was never committed. rowmax.js now
asserts the row ratio is declared in Provenance on the card that uses it, so an
invented number cannot ship undeclared. (A fuller provenance-tier test is still
worth writing.)
- rowmax also now proves: every main lift has a ratio, a lagging row IS detected
  as weak, a proportionate row is NOT, prioritising the row buys it more sets than
  a balanced block, the block names the priority, and the row is selectable.

### Build
- BUILD c136→c137, v176→v177; sw CACHE card-v177-c137; Session title bumped.
  Full suite ALL CHECKS PASSED on both cards.

### Still open (unchanged from c136)
- The Session Card runs his fixed Block 1, whose pull days lead with Cable Rows
  and contain no Barbell Row. Making the row the horizontal primary THERE means
  editing his personal training block — still not done unasked.

### Field Card port note
- Port PG_RATIO wholesale. If the Field Card's row ratio should differ (rucking
  and casualty drag load the horizontal pull harder), that is a separate decision
  and needs its own declaration.

## c136 / v176 — 2026-09-01

### The horizontal pull is assessed like every other main lift (his call)
The barbell row was already the alpha of every pull day — it led the session and
was paid like a main (main sets, main rest) — but it was the ONLY main prescribed
on feel while squat/bench/dead/OHP ran on percentages of a tested max. That
inconsistency is gone.

- ONB_ORDER is now five lifts; the row gets a ramp screen with its own cue
  ("no heaving — a row you swing is not a row you tested"), seed multipliers per
  experience level (.40/.70/1.00 of bodyweight, landing between the press and the
  squat), a raw-start floor for the no-questions path, an untested fallback
  multiplier, and a MAXINFO entry on the You screen.
- PG_NOMAXMAIN is now empty — the row was its only entry. Kept as the mechanism,
  commented: a future pattern whose alpha cannot be safely tested drops in there
  and is prescribed on sets and reps instead.
- Setup and retest counts follow ONB_ORDER.length instead of a hard-coded 4.

### Latent bug this exposed
generatePlan normalised maxes from a hard-coded ['squat','bench','dead','ohp'],
so the row's max was DISCARDED before PG_ex saw it and the lift silently fell
back to straight sets — the change looked applied and did nothing. Now normalises
from PG_MAINNAME, so any main lift added to that table carries its max through.
Caught by the new test asserting percentages, not just presence.

### New standing test
rowmax.js: row is assessed, has name/cue/seeds, seed sits between press and squat,
NO main lift is left without a tested max, You screen lists it, counts are not
hard-coded, a generated plan actually programs a row-keyed main AND prescribes it
on percentages, and an unassessed row still falls back to a number.

### Open questions for him (deliberately NOT decided)
1. PG_diagnose still weighs only the four barbell lifts when picking the block's
   priority lift. Adding the row needs an expected-ratio to bench, and row-to-bench
   ratios vary too much by row style (strict vs Pendlay vs body english) to invent
   one. Should a lagging row be able to win priority, and on what ratio?
2. The Session Card runs his fixed Block 1, whose pull days lead with Cable Rows —
   there is no Barbell Row in it. Making the row the horizontal primary THERE means
   editing his personal training block, so it was not done unasked.

### Build
- BUILD c135→c136, v175→v176; sw CACHE card-v176-c136; Session title bumped.
  Full suite ALL CHECKS PASSED on both cards.

### Field Card port note
- Port wholesale, including the PG_MAINNAME normalisation fix. A soldier-facing
  card leans on horizontal pulling even harder (ruck, carry, casualty drag).

## c135 / v175 — 2026-09-01

### Terms & Privacy extended — 6 sections to 13, benchmarked against comparable apps
Compared against eight fitness-app policies (Fitbit, Anytime Fitness, YouFit,
Refactor Fitness, TLE Fit, Fit-X, Daily Workout Apps, Carrie Fitness) and added
only what actually applies to a free, no-account, local-only card.

Added:
- **5 Consumer health data** — the live issue for fitness apps (Washington's My
  Health My Data Act and similar). Those laws turn on COLLECTION; this card
  collects none, so the section states that plainly and says how to delete.
- **6 Other services involved** — GitHub Pages sees an IP serving the page;
  YouTube sees one on how-to playback. Moved the YouTube caveat out of §4 here.
- **7 The card itself** — [IP / LICENSE GRANT], flagged as a deliberate choice:
  the card is readable HTML on a public host and can be copied.
- **10 The card may change or stop** — free personal project, no availability
  promise; plus how terms changes are announced (DISC_V re-shows the gate).
- **11 If there is a dispute** — [GOVERNING LAW AND VENUE] (Arizona expected),
  [INDEMNIFICATION], and [DISPUTE RESOLUTION] written as a QUESTION for counsel:
  whether to include arbitration + class waiver at all. Most commercial apps do,
  but they carry revenue this card does not, mass-arbitration fees can exceed the
  exposure avoided, and enforceability turns on presentation. Deliberately NOT
  defaulted in.
- **12 If part of this does not hold** — the savings clause present in nearly
  every policy read, plus [SEVERABILITY / ENTIRE AGREEMENT / WAIVER].
- **13 Reaching us** — [CONTACT], flagged: a policy nobody can answer is a
  policy nobody can rely on. Must be filled before release.

Deliberately NOT copied from the comparables (they do not apply): accounts and
credentials, subscriptions/auto-renewal/refunds, user-generated content rules,
data sharing and selling disclosures, wearable integrations.

- 8 [BRACKETED — counsel to supply] markers now. Header notes that bracketed
  sections are where a lawyer's language replaces ours before wide release.
- Still no Army/DoD/H2F reference anywhere — his standing ruling.
- terms.js extended: all 13 sections render, headings run 1..13 with NO GAPS
  (caught a live numbering gap this build — the tail rewrite consumed old §5, so
  numbering jumped 4→6), no raw \\u escapes leak into copy, arbitration is
  flagged as a decision rather than silently added or dropped, contact
  placeholder present, health-data stance stated.

### Build
- BUILD c134→c135, v174→v175; sw CACHE card-v175-c135; Session title bumped.
  Full suite ALL CHECKS PASSED on both cards.

### Field Card port note
- Port sections 1-8 and 10-13 as-is; §9 (shop) drops, and its §5 stance still
  holds since the Field Card is equally local-only. Add the "independent, not an
  official Army product" line there per the c134 note.

## c134 / v174 — 2026-09-01

### Terms & Privacy — the depth layer under the gate
- New full-screen read-only view (termsHTML/termsShow, z-index 411). Two entry
  points: a "Terms & Privacy" link on the disclaimer gate (below "I understand",
  does not block or grant acknowledgment) and a permanent Settings entry beside
  "Read the training disclaimer". Opened from the gate it sits ABOVE it and
  closes back to it, gate still waiting.
- Six sections: (1) training risk + [LIMITATION OF LIABILITY] and [NO WARRANTY /
  AS IS]; (2) not medical advice, stop-and-Swap, the card does not assess
  injuries; (3) the numbers are estimates — a formula on a self-report, corrected
  from logged sets, judgement stays the athlete's; (4) data stays on the phone —
  no account, no analytics, nothing transmitted, with two honest caveats
  (YouTube nocookie embeds see an IP on playback; clearing site data deletes the
  history — export first); (5) age, 13 floor + [MINORS LANGUAGE]; (6) the shop is
  separate, own terms/privacy/returns, no training data ever sent to it.
- [BRACKETED ... counsel to supply.] markers mark exactly where a lawyer's
  language replaces the plain-English draft. The gate copy stays four lines on
  purpose: short text gets read, and an unread wall is weaker evidence of assent.
- NO Army/DoD/H2F/doctrine reference anywhere in it — his ruling: the civilian
  cards derive from civilian sources, so there is no connection to disclaim, and
  denying one nobody suggested only plants the idea. The Field Card is where a
  "not an official Army product" line belongs, since a soldier handed an app by
  their H2F integrator can reasonably assume it is official.
- New standing test terms.js: all six sections render, counsel markers survive,
  both caveats disclosed, no military reference, opens from gate and settings,
  closes back correctly, writes nothing to S, and reading is NOT acknowledgment.

### Build
- BUILD c133→c134, v173→v174; sw CACHE card-v174-c134; Session title bumped.
  Full suite ALL CHECKS PASSED on both cards.

### Field Card port note
- Port the view and both entry points. Its section 6 differs (no shop), and it
  SHOULD carry the "independent, not an official Army product" line the civilian
  cards deliberately omit — different context, different inference to correct.

## c133 / v173 — 2026-09-01

### Boot order: the disclaimer comes first, the install sheet waits its turn
- Regression I introduced in c132: the gate shipped at z-index 215 while the
  install sheet renders at 400, so on a fresh phone "Add to home screen" covered
  the disclaimer entirely — the athlete met the install prompt first and
  acknowledged nothing. Wrong order legally and practically.
- Fix: gate raised to 410 (splash bumped 220→420 so it still covers the gate and
  the fade still reveals it). Boot-time prompts now queue behind the gate via
  DISC_QUEUE and fire on acknowledgment — nothing is skipped, only deferred: the
  install sheet still shows, and the tour still follows it. Settings re-read
  (force mode) never fires queued prompts and never rewrites the ack.
- Add-to-home-screen instructions were never removed; a2hsDue() correctly
  suppresses them when the card is already installed (opened from the home
  screen shortcut), when dismissed as done, on desktop, or inside a 3-day snooze.
- New standing test: bootorder.js (gate outranks install, splash still covers
  gate, install deferred not lost, fires on ack, settings re-read inert).

### Build
- BUILD c132→c133, v172→v173; sw CACHE card-v173-c133; Session title bumped.
  Full suite ALL CHECKS PASSED on both cards.

### Field Card port note
- Port the z-index ordering and DISC_QUEUE deferral with the gate; any card that
  shows an install prompt has this same collision.

## c132 / v172 — 2026-09-01

### Disclaimer gate after the splash
- Full-screen acknowledgment at z-index 215 — UNDER the 220 splash, so it is
  literally what the fade reveals; it also stands alone when reduced-motion
  skips the splash. Copy in the card's voice: training tool not medical advice,
  check with a professional before starting, stop and Swap on pain, train at
  your own risk.
- Acknowledged once per DISC_V (stored S.discAck {v, date}); bump DISC_V when
  the copy changes and every athlete sees it again. Re-readable anytime from
  Settings ("Read the training disclaimer") without disturbing the ack.
- RELEASE NOTE (also in a code comment): this exact copy is what a lawyer
  should bless before wide distribution.
- medneutral extended: gate shows on fresh boot, ack stores and closes,
  acknowledged gate stays gone on reboot, settings re-open is read-only.

### Build
- BUILD c131→c132, v171→v172; sw CACHE card-v172-c132; Session title bumped.
  Full suite ALL CHECKS PASSED on both cards.

### Field Card port note
- Port the gate wholesale; the Field Card's copy should additionally point
  soldiers to their provider/PT per H2F channels, and DISC_V starts at 1 there
  with its own copy version history.

## c131 / v171 — 2026-09-01

### Injury intake removed — the card never asks what hurts (his call, "legal glance")
- Removed the ask-then-adapt pattern everywhere: the onboarding 'limits' question
  (full flow) and 'pain' question (start flow), the per-set None/Ache/Pain row,
  the painAlt "stop and do this instead" prescriptions, the ache technique
  coaching, the pain log, the adaptation-engine pain signal, the weekly-review
  pain count, the report PAIN FLAGS line, the tour stop, and the help jump.
- Stored pain data leaves with the feature: boot deletes S.painLog and sweeps
  st.pain from exercise state. Data the card no longer uses is data it should
  no longer hold.
- What carries the job now, neutrally: Swap (trade any movement, no reason
  asked) and the 'prefs' onboarding step. Help copy rewritten: "Stop the
  movement and use Swap… Nothing in this card is medical advice: for pain or
  injury, see a qualified professional." Same line in Settings → Assessments.
- PG_HOSTILE/limits plumbing remains in the generator but is inert (limits is
  always []) — left for the manual-swap menus, commented.
- NOTE: he intends an actual legal review of the disclaimer copy; this build is
  the engineering posture, not legal advice.

### Assessments rerun in place — no card restart
- Settings → Assessments → "Redo the assessment" reruns the same guided
  calibration from setup (climbing sets per lift, stop when hard). Plan, logs
  and history stay untouched; lifts you skip keep their standing numbers;
  "Keep my old numbers" cancels and restores everything. Apply writes only the
  retested maxes.

### Session-length fill is now the athlete's choice
- Every eligible accessory renders as a tappable chip (auto-picks pre-selected);
  the Zone 2 finisher is a −5/+5 stepper (0–30 min). Whatever the athlete sets
  is exactly what the day runs — auto-fill only decides when they haven't.
  Choices persist per day in S.sessManual.

### Suite
- sesslen extended (manual selection honored, finisher clamps, chips render);
  new medneutral.js (no pain question, no injury step, no adaptation signal,
  neutral help copy, boot cleanup) and retest.js (in-place rerun, skipped lifts
  keep numbers, cancel restores). Both test fixes this cycle were test bugs
  (day screen not rendered; malformed check), not card bugs.
  Full suite ALL CHECKS PASSED on both cards.

### Build
- BUILD c130→c131, v170→v171; sw CACHE card-v171-c131; Session title bumped.

### Field Card port notes
- Port the injury-intake removal WHOLESALE and early — a soldier-facing card
  collecting injury claims and adapting training is the same exposure, sharper.
  Profile/medical readiness stays the unit's lane (MEDPROS, profiles), not the
  card's: the Field Card should point soldiers to their provider/PT per H2F
  channels rather than collect anything.
- Port retest and manual session-fill as-is.

## c130 / v170 — 2026-09-01 (small hours)

### Deck bar floating mid-page — glued to the visible viewport
- Field bug: the next-exercise bar drifted to mid-screen while scrolling. iOS pins
  position:fixed to the LAYOUT viewport; the keyboard (weight editor, notes) or
  zoom shrinks and pans the VISUAL one, so "bottom" became mid-screen. New shim
  listens to visualViewport resize/scroll and translates .footer and .stbar to
  hug the bottom the athlete can see, releasing when the viewports agree.
  New standing test: footglue.js (fakes visualViewport, asserts glue + release).

### Session-length target — "an hour and 30 minutes worth of training"
- His directive for the Session Card. New setting (Settings → Session length:
  Off / 1:00 / 1:15 / 1:30 / 1:45). Session Card DEFAULTS to 1:30 per his ask;
  Training Card ships with it Off.
- Declared fill order, honoring the cut and the 10–20 set landmark: (1) +1 set
  to the day's lightest accessories — never a main lift, three added sets max,
  no accessory past 4 sets — then (2) a Zone 2 finisher for the remaining gap,
  clamped 10–30 min. Days within ~4 min of target are left alone; days OVER
  target are NEVER trimmed. The day header declares every addition in plain
  text ("For the session-length target: +1 set … · Zone 2 finisher — N min").
- His current block runs ≈55–72 min/day; at 1:30 expect ~2–3 added accessory
  sets and a 10–30 min finisher depending on the day.
- exState grows for added sets and now trims UNTOUCHED trailing sets when the
  target turns off — logged sets never leave.
- New standing test: sesslen.js (off = untouched; ≤3 adds; mains never grow;
  accessory cap 4; finisher 10–30; total within 10 min of target; over-target
  days never trimmed; additions declared in the header).

### Suite repair
- sharetest was seeding PRs with the wall date; run it after midnight during a
  late session and todayPRs (which filters by the session's pinned date) came
  up empty. Seeds S.when.date now. Time-of-day flake, not a card bug.

### Build
- BUILD c129→c130, v169→v170; sw CACHE card-v170-c130; Session Card title
  bumped. Full suite ALL CHECKS PASSED on both cards.

### Field Card port notes
- Port the visualViewport glue verbatim (same fixed bars, same iOS).
- Port the session-length machinery with defaults OFF; whether a soldier-facing
  default belongs there is a doctrine/session-design call for the Field Card
  (H2F sessions have their own structure) — flag for his ruling, don't assume.

## c129 / v169 — 2026-08-31 (night, third cut)

### Share QR sent scanners to the wrong card — canonical home baked in
- Field bug: the Training Card's share-sheet QR opened the Session Card. Root
  cause: every share surface encoded location.origin+location.pathname — wherever
  the card happened to be RUNNING when the sheet was generated — and the sheet
  was generated with the card answering at the root, which serves the Session
  Card. The same trap fires for a card opened from a download, a preview URL, or
  the hub.
- Fix: each card now carries a build-time CANON_URL beside BUILD — the card's
  TRUE home — and all four share surfaces (share-sheet QR, PLAN-tab QR, "Send
  the link instead", the social share payload URL) go through cardURL(), which
  returns CANON_URL and falls back to runtime location only if the constant is
  empty. Baked: Training Card = https://thundermeadows.github.io/training-plan/,
  Session Card = https://thundermeadows.github.io/
- sharetest now asserts CANON_URL is baked (https, directory-shaped) and that
  the QR caption reflects the canonical home, never the runtime origin.
- DEPLOY RULE: if a card ever moves, CANON_URL moves with it in the same build.

### Build
- BUILD c128→c129, v168→v169; sw CACHE card-v169-c129; Session Card title
  bumped. Full suite ALL CHECKS PASSED on both cards.

### Field Card port note
- Port cardURL()/CANON_URL wholesale and bake the Field Card's own address when
  it deploys; its share surfaces inherit the same runtime-location trap.

## c128 / v168 — 2026-08-31 (night, second cut)

### His ruling: the sheet hides nothing — the information is to share
- The c127 "+N more — in the card" cap is REMOVED. The sheet now runs a measuring
  pass first (PRs merged, rows counted, header lines known), sizes the canvas
  from the content, then draws: every logged movement prints, the list ends above
  the QR band by construction, and 1080×1350 (4:5) stays the minimum — a big day
  simply makes a taller image. The height formula mirrors the draw flow; a comment
  marks that changing one means changing both.
- Note for testers: very long sessions produce tall images; some social previews
  crop tall images to 4:5 in-feed but the full sheet opens on tap. Nothing is lost.
- sharetest updated to enforce the ruling: the "+N more" line is now a FAILURE,
  every logged movement must print, and the QR-band check follows the dynamic
  height. All c127 collision checks retained.

### Build
- BUILD c127→c128, v167→v168; sw CACHE card-v168-c128; Session Card title bumped.
  Full suite ALL CHECKS PASSED on both cards.

### Field Card port note
- Port the measure-first shareCardPaint wholesale (supersedes the c127 version);
  the nothing-hidden rule is his standing ruling for every card's share sheet.

## c127 / v167 — 2026-08-31 (night)

### Share sheet: six collisions fixed (field screenshot, Manuel Grajeda's card)
- **Stats fused ("23,85020")** — big numbers were a fixed 88px in equal columns with
  no measurement; each stat now shrinks to fit its column.
- **Names into prescriptions ("Straight-Arm Pulldown2×12")** — the name now gets
  whatever width the prescription leaves and yields with an ellipsis.
- **QR buried three movements** — rows only dodged the bear, never the QR band.
  The list now stops above the band; overflow ends with "+N more — in the card"
  instead of hiding work (design decision: declared overflow over burial).
- **Wordmark over ATHLETE** — the drawn logo is 131px tall; the cursor advanced 68.
  Now 112 when the image mark is present.
- **Same movement listed twice in the PR box** — records for one movement merge
  onto one line (design decision), freeing rows for other movements; the merged
  line shrinks to fit rather than overlap.
- All six fixes in shareCardPaint/shareRecapImage, both cards.

### Share to social: blank composer fixed
- Root cause: navigator.share sent FILES ONLY. Targets that accept only text or a
  link (most social composers) received nothing and opened blank. The share now
  sends the image + a text line + the card's URL, falling back by dropping pieces
  since platforms disagree on accepted combinations.

### New standing test
- tests/sharetest.js: records every fillText with its measured width; asserts no
  two strings collide on a baseline, nothing overruns the right edge, work rows
  stay above the QR band, and duplicate-movement PRs merge. Registered in run.js.
  Renders a PNG preview of the sheet as a side effect (jsdom + canvas package).

### Build
- BUILD c126→c127, v166→v167; sw CACHE card-v167-c127; Session Card title bumped.
  Full suite ALL CHECKS PASSED on both cards, sharetest included.

### Field Card port note
- Port all of shareCardPaint's fixes and the share payload change verbatim; the
  Field Card shares the same renderer and will have the same collisions.

## c126 / v166 — 2026-08-31 (late)

### Both open verification items closed
- **NSCA table — VERIFIED cell by cell** against an NSCA-permission reprint of the
  Essentials table plus CSCS Ch.17 materials: strength ≥85%/≤6 reps/2–5 min;
  power single 80–90% (1–2), multiple 75–85% (3–5), 2–5 min; hypertrophy
  67–85%/6–12/30–90 s; endurance ≤67%/12+/≤30 s. Every c125 provenance claim
  held. Provenance row updated: pending caveat removed.
- **Helms/Zourdos RIR table — verified at structure, anchor, and step size** from
  open primary sources: RPE10=0RIR shift-by-one construction (Zourdos 2016);
  published anchor 8 reps @ 70% = RPE 7 vs our cell 71.0 (within 1 pt); the
  group's 2%-per-half-RPE rule implies ~4%/RIR vs our 3.3–4.5% steps. Residual
  stated in the code ledger: the full printed decimal grid is paywalled; any
  plausible cell disagreement is inside the estimator's own ±5% band. Ledger
  comment added above RIR_PCT with date and scope.
- Verification surfaced one undeclared number: **strength opens at 80% against
  the source's ≥85 floor** (weeks 1–2 on-ramp). Now declared as a Chosen row.
  Provenance is 15 rows: 5 Sourced / 2 Reasoned / 8 Chosen.

### Build
- BUILD c125→c126, v165→v166; sw CACHE card-v166-c126; Session Card title
  bumped. Full suite ALL CHECKS PASSED on both cards; probe extended to assert
  the new row and the removed caveat.

### Field Card port note
- Port the strength-ramp declaration and the verification ledger comment. The
  Field Card's Doctrine tier cites FM 7-22 Table 6-4 (verified from the course
  copy on Drive on 2026-08-31); note the FM's power rows diverge from its NSCA
  source (flat 90%/80%, single/repeat apparently swapped) — cite accordingly.

## c125 / v165 — 2026-08-31 (evening)

### Provenance realignment — cite the science, not the citation of the science
Decision: instead of adding a "Doctrine" tier referencing FM 7-22 on the civilian
cards, cite the sources the Army itself drew Table 6-4 from. The civilian wall
stays intact — the cards say "NSCA," never "Army."

Re-scored the four Table 6-4 gaps against the primary sources:
- **Power 70–80%** — vs NSCA repeat-effort power 75–85% (the FM's flat 90% appears
  to have swapped its source's single/repeat rows). Kept 5 points lighter,
  deliberately, for bar speed. Declared as Chosen.
- **Hypertrophy rest 2:00/1:30** — Schoenfeld 2016 rest-interval RCT: longer rest
  beats 1:00 for growth at matched volume. Not a deviation; now declared Sourced.
- **Endurance rest** — the one alignment. NSCA and FM agree: incomplete recovery IS
  the stimulus. `GOALS.endurance` restMain 1:00 → **0:45**, restAcc 1:00 → **0:30**.
  Onboarding copy updated ("one-minute rests" → "short 30–45 second rests").
  The 15 extra seconds on the main lift is ours, declared as Chosen.
- **Endurance load 50→60% ramp** — inside NSCA's ≤67% ceiling; ramp kept, declared.

### Provenance section rewritten (both cards, identical)
14 rows: 5 Sourced / 2 Reasoned / 7 Chosen. New Sourced rows: training loads by
goal (NSCA Essentials), two-minute compound rests (Schoenfeld 2016). New Chosen
rows declare everything added Aug 31 that was previously silent: the power curve,
the set-label thresholds (≤5/≤8/≤12/13+), the plan padding (rear delts→8,
calves→10, Side Plank, Lateral Band Walk — merged into the per-muscle-targets
row), the anatomy bands and the best-within-6% trigger, and the endurance rests.

### Verification status (honesty ledger)
- FM 7-22 Table 6-4 values verified today against the course copy in Drive.
- The NSCA table values cited are the widely reproduced ones — cell-by-cell
  verification against the book itself is now PENDING, alongside the outstanding
  Helms 2016 RIR/RPE check. Neither is closed.
- Both cards probed in jsdom: rest values live through exRest() with class caps
  intact, provenance renders 5/2/7, civilian wall holds (no Army/FM/doctrine
  strings in the rendered block), goal picker shows rest 0:45.
- Full tests/ suite run on BOTH cards after upload — ALL CHECKS PASSED.
  goaltest updated: its endurance assertion encoded the old 1:00 rest; now 0:45
  with the c125 decision documented in a comment. Environment note: gametest
  needs the `canvas` npm package (jsdom has no 2D context) — on this box that
  meant apt cairo/pango dev libs plus `npm install canvas --build-from-source
  --nodedir=/usr` because nodejs.org is unreachable for headers.

### Field Card port notes
- Port the endurance rest change (0:45/0:30) — it feeds the AFT push-up-failure
  retune, where the endurance scheme is exactly what a failing soldier gets.
  Doctrine strictly says up to 30 sec; on the Field Card consider 0:30 flat.
- The Field Card's provenance section SHOULD carry the Doctrine tier
  (Sourced / Doctrine / Chosen) citing FM 7-22 Table 6-4 — there doctrine is the
  point, not a wall violation.
- FM's flat 60% endurance load only binds the Field Card; decide whether its
  on-ramp starts at 60% or declares the ramp as a deviation.
- Power slot unaffected: the Field Card's doctrine power slot (jumps/MB throws,
  RPE 10) never consumed the barbell power scheme.

### Build
- BUILD c124→c125, v164→v165; sw CACHE card-v164-c124 → card-v165-c125; Session
  Card title bumped. Standing rule followed.

## c123 / v163 — The training goal is named on the exercise

Beside the role label: **MAIN LIFT · HYPERTROPHY**. The scheme was always there in the numbers —
5×3 at 85% *is* strength work — but you had to already know that to read it. Naming it means an
athlete learns what they are doing while they do it, instead of just following reps.

- STRENGTH · POWER · HYPERTROPHY · MUSCLE · FAT LOSS · ENDURANCE
- drawn dashed and in chalk rather than amber: the role says what the movement is, the goal says
  what the session is for, and the two should not compete
- **c124 correction:** returning no tag for a coach-built block made the label invisible for the
  DEFAULT profile, which is the plan most athletes are on. With no chosen goal it now names what
  the set is, from the prescribed reps: ≤5 STRENGTH, ≤8 HYPERTROPHY, ≤12 MUSCLE, 13+ ENDURANCE.
  More honest on a mixed day anyway — a 5-rep main lift is strength work even inside a
  hypertrophy block, and 12-rep accessories are not

**Port note:** derive it from `goalDef()`, never store it per exercise. A goal copied onto each
movement goes stale the moment the athlete changes it.

---

## c122 / v162 — All six training goals exposed

Setup offered four goals; six schemes existed. Power, Hypertrophy and Muscular Endurance were
fully built, correct, and had no front door — an athlete could only reach them by changing the
goal on the You screen afterwards, which most never would.

- onboarding now offers all six, with ids matching the `GOALS` keys so nothing is translated
- **the plan generator carried its own copy of the schemes and they had drifted** — it prescribed
  5s for strength while the scheme said 3s, so a generated plan and the live prescription
  disagreed about the same goal. The generator now reads `GOALS` directly
- old ids (`muscle`, `lean`, `general`) kept as aliases so saved profiles still resolve

The six, verified distinct: strength 5×3 from 80% / 4:00 · power 5×3 from 70% / 3:00 ·
hypertrophy 4×8 from 68% / 2:00 · build 4×10 from 65% / 2:00 · cut 4×8 from 65% / 1:30 ·
endurance 3×15 from 50% / 1:00.

**Port note:** one table per concept. Two places describing the same scheme will drift, and the
drift is silent because each is correct on its own.

---

## c121 / v161 — Movement role labels

Each exercise now carries a small label saying what it is: **MAIN LIFT**, **ACCESSORY**,
**ISOLATION**, **CORE / CARRY**, or **HEAVY SET** for a hard low-rep bodyweight set.

The card already knew this — the same classification sets the rest caps — but only the rest
screen ever said it out loud. Surfacing it tells the athlete where a movement sits in the
session's priority before they decide how much they have left to give it.

- amber for main lifts, quiet grey for everything else: priority should be visible at a glance
  without turning the screen into a colour chart
- on the exercise itself, and on the day list where the session is scanned
- derived from `isMain()` and `exRestClass()` — no new classification to drift out of step

**Port note:** reuse the existing rest classification rather than adding a second one. Two
sources for "what kind of movement is this" will disagree eventually.

---

## c120 / v160 — Best logged

Added for reference, deliberately not beside the working weight.

- history ranks **best by estimated max**, not raw weight — 185×5 and 175×8 are not comparable as
  numbers, and ranking by weight makes a hypertrophy block read as regression every week
- heaviest single is still shown in the detail view for anyone who wants it
- inline on the working set **only when today is within 6% of the best**, and never during a
  deload. A standing "best" beside the working weight invites chasing it every session, which is
  worse programming than the junk volume the anatomy colours used to provoke

**Port note:** the rule is that a number shown next to the work must explain the work, not
compete with it. Same lesson as the anatomy colours.

---

## c119 / v159 — Records read the exercise setting, not the sets

**Field-caught: a record showed 70 lb against a prescription of 60.**

`recordHistory()` read `curLoad()` — the exercise-level weight — and ignored the per-set
weights written by the rest-screen stepper and the weight badge. It also disagreed with
`recordPerf()`, which since c81 carries the last completed set's own weight into the next
session's anchor. Two functions, same sets, different numbers.

- weight record is now the **heaviest set actually completed**, using each set's own weight
- e1RM estimate uses **that set's own reps**, instead of pairing the heaviest weight with the
  best rep count from a different set, which inflated it
- volume adds **each set at its own weight**; a session done at three loads was multiplied by one
- old records without per-set weights still compute — fallback preserved

**Port note:** any card that lets a weight be adjusted per set must record per set. Check both
the record path and the anchor path; they are separate functions and drifted apart here.

---

## c118 / v158 — Android home-screen icon

Reported: the wrong icon appeared on an Android home screen.

- **maskable icons were floating** — art spanned 58% × 27% of the tile with a rounded background
  baked in, so Android masked a box inside a circle. Rebuilt full-bleed, mark filling the safe zone
- **SVG entry removed from the manifest** — Chrome's support is inconsistent, and a failed pick
  falls back to a generated letter tile, which is the reported symptom
- verified all five icon sources carry the same mark

**Port note:** maskable icons must be full bleed. Never bake a rounded tile into one.

---

## c117 / v157 — Problem report opened behind settings

The report shared the settings sheet's `z-index:200` and rendered later, so equal stacking put
it underneath. You had to close settings to reach what settings had just opened.

- report lifted to 240
- audited every full-screen overlay; everything else launched from the sheet already sat above it
- new check: every settings control is bound, and anything launched from the sheet lands above it

**Port note:** the rule is "a panel launched from an overlay must outrank it," not "fix the report."

---

## c116 / v156 — Self-test ("Check this phone")

Six checks for the things that have actually broken and are invisible from anywhere but the
device: storage, manifest linked, service worker in control, sprite decode, filters actually
applying, audio state. Results attach to the problem report automatically.

Safety constraints, all enforced and tested:
- read-only apart from one write to its own namespaced key, deleted immediately
- never probes quota by writing until failure — on a full phone that *is* the failure
- stands down during a rest or a part-logged session
- every check individually wrapped

**Port note:** the storage probe must never touch the state key. That is the one line that could
destroy an athlete's history.

---

## c115 / v155 — Game exit button

- moved from bottom-centre to top-left: the bottom is where a downward swipe to slide ends, so
  presses were being read as gameplay
- removed `left:50% + translateX(-50%)` — position depended on a transform, so it shifted when
  pressed ("scooted right")
- claims the gesture on `pointerdown`, because the canvas listens across the whole screen and was
  consuming taps that started on the button

---

## c113–c114 / v153–v154 — Bulk Run tuning

- **difficulty ramp was flat.** Over a full rest, speed ended at 6.4 against a base of 6.2: pace
  only rose with slices and any crash reset it. Added a floor that climbs with time survived
- **obstacle spacing was unfair at pace.** Measured in distance, it shrank in time — at the cap two
  obstacles arrived 458 ms apart, less than a reaction plus a swipe. Gap now scales with speed
- backdrop gradients cached instead of rebuilt 60×/sec; particle pool capped
- intensity raised: ceiling 12 → 15, two-abreast patterns with one lane open

**Measured:** sharp player went from 4 crashes / 7 slices to 0 crashes / 82 slices at top speed.
Skill now separates; before, every skill level performed identically.

---

## c109–c112 / v149–v152 — Bulk Run in the card

Rest-screen mini-game, summoned only. Contract enforced by test: never self-opens, dies with the
rest it borrowed, saves nothing, does not touch the timer or beeps, session byte-identical after.

- **crash reset the whole items array from inside the loop iterating it** → uncaught error on
  every collision. Now raises a flag; the sweep happens after the loop
- crash penalty made visible: score lost, hard slowdown, flash, `-7` readout. Previously it reset
  a score that was often already zero, so it looked like nothing happened
- no red on impact — red spatter on a gummy bear reads as blood

---

## c102–c108 / v142–v148 — Share card and install

- **c108: the page never linked its manifest.** Chrome cannot install an app it has never read a
  manifest for. This shipped missing for the card's entire life; no Android user was ever offered
  Install. One line
- **c107: Android users were shown iOS install steps.** The Mac+touch heuristic that detects
  iPadOS also caught Android phones in desktop-site mode, which send a Macintosh UA. Added a
  `Chrome/` token discriminator (no iOS browser has one) and an "unknown mobile" sheet covering
  both platforms
- share card: athlete name and tenure, QR to the web app, Bulk in the athlete's chosen flavour
  (tinted **in pixels**, because `ctx.filter` can report as supported and do nothing to `drawImage`)
- **QR was labelled with the gear store** while encoding the web app — the label lied

---

## c96–c101 / v136–v141 — Bulk's identity, prompts

- mascot renamed Gummy → **Bulk**; internal `gb*` names kept so saved flavours aren't orphaned
- eyes glow, and are excluded from the pose dimming that darkens his body
- finish prompt: shares a designed image, returns after cardio or an extra lift, always shows the
  day's records
- **dismiss needed its own memory** once the prompt read the day's ledger, or it became permanent

---

## c86–c95 / v126–v135 — Anatomy map and help

- **indirect work could never show green.** Glutes read "needs work" at 10.25 sets against a target
  of 10; traps and forearms read short while *above* target. The athlete's response was to add
  exercises to chase green — the map was provoking junk volume. Now volume decides the band and
  directness decides only the shade
- six-state scale: grey / orange / yellow / three greens. Zero work stays **grey**, never red — an
  absence is not a failure
- plan gaps closed: rear delts 4 → 8 sets, calves 8 → 10, obliques and abductors given direct work
- help card on the posed bear: 52 questions, 10 sections, 26 with working deep-link shortcuts

---

## c76–c85 / v116–v125 — Forgiveness sweep

The design goal: **mistakes should be cheap to correct.** Undo over confirmation prompts, and
prompt only when the action contradicts what the card already knows.

- **prescription is immutable.** The rest-screen stepper wrote the exercise-level override, which
  *is* the day's prescription — it rewrote what the card asked for, including banked sets. It now
  writes the set's own performed weight, and that is what anchors next session
- **logged sets are history.** Sets carried no weight of their own, so three sets at 175 reported
  165 the moment the bar was dropped for a fourth. Weight is stamped at log time
- **weight badge** under the glowing set: adjust without logging. Previously a pending set's only
  action was "I did this," so returning to adjust it banked it
- **undo on a mistapped set**, five seconds
- **mid-rest guard**: tapping the next set while the clock runs asks once. You cannot have finished
  a set you are still resting for. No prompt once the rest is over
- **+30s rest is reversible**, clamped at zero
- **restore is recoverable** — snapshot before overwriting, 15s undo, and a rescue copy reachable
  from settings for a month. Restoring also merges through the expected shape; a backup from
  before a field existed used to leave it missing and kill the next tick
- **prompts outlive their windows.** `alertToast` had one fixed 1.5s life; prompts asking for a
  second tap vanished while still live

---

## c66–c75 / v106–v115 — Settings, Bulk, accessories

- settings sheet: flicker (whole sheet rebuilt per tap, replaying its entry animation), dead
  controls (hand-written attribute list had drifted), and close-on-every-tap (the tapped chip was
  detached mid-dispatch, so an ancestry test read it as outside the sheet)
- Bulk's colour: applied but not repainted (`will-change` layer needed a forced flush); all
  flavours normalised to an identical filter function list so every switch is interpolable
- **accessory estimates: a ratio of 0 meant "unknown" and was multiplied out.** Twelve movements
  were prescribed the floor weight while claiming "estimated from your squat." Field-caught at
  5 lb against a 327 lb squat. Now the card asks instead of inventing
- **grind flag reached the next session** — it was collected on every set and discarded at save

---

## Standing rules

- every build bumps `sw.js` CACHE **and** both BUILD constants, without being asked
- a fix is not done until a harness exists that fails without it
- verify visual work in a standalone with a real harness, then port to the cards
- the two cards diverge silently; parity checks belong in the suite
