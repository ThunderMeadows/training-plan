// FIELD 2026-09-05: "I accidentally selected save session to log and it logged that day that is
// empty. There should be a way to protect the athlete from doing this."
//
// The log entry was the smallest part of it. Everything downstream keys off sessionLogged(),
// which only asks whether a log KEY exists - so an empty save advanced the split past the slot,
// counted toward blockDoneCheck(), fed the streak, and locked the day. And deleteLog() never
// cleared S.locked / S.dbf, so the athlete's own remedy - delete the bad log - left them on a
// locked, empty day with nothing on screen to explain it.
//
// This harness banks nothing and insists nothing happens; then banks real work and insists it
// does; then deletes that log and insists the day comes back. Cardio-only and finisher-only days
// are checked too, because "no completed sets" is NOT the same as "did nothing" and a guard that
// blocked a real cardio session would be a worse bug than the one it fixed.
const {JSDOM}=require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const raw=fs.readFileSync(f,'utf8');
const d=new JSDOM(raw,{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/'});
const w=d.window,EV=e=>w.eval(e);
w.AudioContext=function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
let bad=0; const chk=(l,ok,dd)=>{ if(!ok)bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&dd?'  <-- '+dd:''}`);};
const wait=ms=>new Promise(r=>setTimeout(r,ms));
// A harness that CRASHES on the broken build has not caught the bug - it has hidden it behind a
// stack trace. sessionHasWork() does not exist before c205, so every call to it goes through
// here: on an old build the check FAILS and names the reason, and the run carries on to prove
// the rest of the damage.
const safe=(expr,fallback)=>{ try{ return EV(expr); }catch(e){ return fallback; } };
const errs=[]; w.addEventListener('error',e=>errs.push(String(e.message)));
w.addEventListener('unhandledrejection',e=>errs.push(String(e.reason&&e.reason.message||e.reason)));

const KEY='curLOGP()+S.when.date+"-"+S.day+"-W"+S.week+"B"+cyc()';
const DK='cyc()+"|"+S.week+"|"+S.day';
const logAllSets=`(function(){ var dd=dayObj(); dd.exercises.forEach(function(ex,i){ var st=exState(i,ex);
    st.sets.forEach(function(s2){ s2.st='hit'; s2.reps=5; s2.rir=2; }); }); save(); })();`;
const clearSets=`(function(){ var dd=dayObj(); dd.exercises.forEach(function(ex,i){ var st=exState(i,ex);
    st.sets.forEach(function(s2){ s2.st='pend'; s2.reps=null; s2.rir=null; }); }); save(); })();`;

setTimeout(async ()=>{
  console.log(`\n--- ${L}: an empty day cannot be filed ---`);
  EV('try{TOUR.live=false;}catch(e){} S.tour={done:true}; if(typeof ONB!=="undefined"){ONB().done=true;} S.discAck={v:DISC_V,d:localDate()}; storageOK=true; save(); render();');

  // ---- fixture: the day really is empty ------------------------------------
  EV(clearSets);
  EV('S.cardio.on=false; S.cardio.tacc=0; S.cardio.tstart=null; S.fin=null; save(); render();');
  chk('(fixture) the day starts with nothing done', EV('sessionPct().done')===0 && EV('sessionPct().total')>0,
      'done='+EV('sessionPct().done')+' total='+EV('sessionPct().total'));
  chk('(fixture) and the day is not already locked', EV('dayLocked()')===false, 'locked before we began');

  chk('the card knows the session is empty', safe('sessionHasWork()','missing')===false,
      safe('sessionHasWork()','missing')==='missing'? 'this build has no sessionHasWork() - nothing guards the save' : 'sessionHasWork() said true');

  // ---- the guard -----------------------------------------------------------
  let banked=null, threw=null;
  try{ banked=await EV('saveSessionLog(false)'); }catch(e){ threw=String(e&&e.message||e); }
  chk('banking an empty day is refused', banked===false && !threw, threw||('returned '+banked));
  chk('and nothing was written to storage', EV('localStorage.getItem("nsc:"+('+KEY+'))')===null, 'a log key exists');
  chk('the day is NOT locked by the refused save', EV('dayLocked()')===false, 'locked anyway');
  chk('the day is NOT marked debriefed', EV('!(S.dbf && S.dbf['+DK+'])'), 'debrief flag set');
  chk('the split still counts the session as untrained', EV('!sessionLogged(S.week,S.day)'), 'sessionLogged() says done');
  chk('the refusal threw nothing at the athlete', errs.length===0, errs.join(' | '));

  // ---- and it says so before it is tapped ----------------------------------
  EV('S.day=PLAN.days[0].code; S.view="day"; save(); render();');
  const btn=w.document.getElementById('saveLog');
  chk('the save button is still rendered', !!btn, 'no #saveLog on the page');
  chk('it is marked as not-ready, not silently normal', !!btn && /nowork/.test(btn.className), btn?btn.className:'-');
  // HARNESS FAULT, caught by running this against c204: the first version of this check read
  // the WHOLE body for /Nothing logged yet/, and c204 passed it. That phrase already exists on
  // the card - the empty state of the history panel says "Nothing logged yet. Finish a session
  // and every exercise you did will show up here". A check that a build without the feature
  // passes is not a check. Scoped to the line the button actually renders.
  const hint=btn && btn.nextElementSibling;
  chk('and the line under the button says why', !!hint && /log a set, cardio or a finisher/i.test(hint.textContent||''),
      hint? ('sibling reads: '+(hint.textContent||'').slice(0,60)) : 'no line under the button');

  // a REAL tap must still do something observable - a bound control that does nothing is a
  // dead button, which is the fault inert.js exists to catch
  const before=EV('logKeys.length');
  // clear the toast first: the refused save above already wrote one, and a check that reads a
  // stale message proves nothing about this tap.
  EV('try{ var _t=document.getElementById("toast"); if(_t){ _t.textContent=""; } }catch(e){}');
  btn && btn.dispatchEvent(new w.MouseEvent('click',{bubbles:true}));
  await wait(150);
  const toast=EV('(function(){ var t=document.getElementById("toast"); return t? (t.textContent||"") : ""; })()');
  chk('tapping it answers instead of doing nothing', /Nothing logged yet/i.test(toast), 'toast read: "'+toast+'"');
  chk('and it still files nothing', Number(EV('logKeys.length'))===Number(before), 'a log appeared');

  // ---- cardio alone IS work ------------------------------------------------
  EV('S.cardio.on=true; save();');
  chk('a cardio-only day counts as work', safe('sessionHasWork()',true)===true, 'cardio session would be refused');
  EV('S.cardio.on=false; S.cardio.tacc=600000; save();');
  chk('so does time actually run on the clock', safe('sessionHasWork()',true)===true, 'ran the clock, still refused');
  EV('S.cardio.tacc=0; S.fin={min:10,zone:"z2",done:true}; save();');
  chk('and a finisher on its own', safe('sessionHasWork()',true)===true, 'finisher would be refused');
  EV('S.fin=null; save();');

  // ---- real work banks exactly as before -----------------------------------
  EV(logAllSets);
  chk('a trained day is work', safe('sessionHasWork()',true)===true, 'real sets read as empty');
  let ok2=null; try{ ok2=await EV('saveSessionLog(true)'); }catch(e){ ok2=String(e); }
  chk('and it banks', ok2===true, 'bank returned '+ok2);
  const key=EV(KEY);
  chk('the log is written', EV('localStorage.getItem("nsc:'+key+'")!==null'), 'nothing at '+key);
  chk('and the day locks, the way a finished day should', EV('dayLocked()')===true, 'not locked');

  // ---- deleting the log undoes what the log did ----------------------------
  await EV('deleteLog("'+key+'")'); await wait(150);
  chk('deleting the log removes it', EV('localStorage.getItem("nsc:'+key+'")')===null, 'still stored');
  chk('and the day is open again', EV('dayLocked()')===false, 'day left LOCKED after the log was deleted');
  chk('the debrief flag went with it', EV('!(S.dbf && S.dbf['+DK+'])'), 'debrief flag survived the delete');
  chk('the sets that were done are still on the card', EV('sessionPct().done')>0, 'the delete wiped the work too');
  chk('nothing threw across the whole path', errs.length===0, errs.join(' | '));

  // ---- the same rule on a coached athlete's card ---------------------------
  if(EV('typeof ROSTER')==='undefined'){
    console.log('  ok    (no roster on this card)');
  } else {
    EV('ROSTER.mode="coach"; ROSTER.athletes=[]; ROSTER.active=null; save();');
    const a=EV('rosterAdd("Manuel")');
    EV('rosterSwitch("'+a+'");'); await wait(320);
    EV('var o=ONB(); o.goal="build"; o.wt=200; o.exp="some"; o.sex="m"; o.days=4; o.res={}; o.prefs={}; o.limits=[]; ONB_build(); ONB().done=true; S.tour={done:true}; S.discAck={v:DISC_V,d:localDate()}; save(); render();');
    EV(clearSets);
    EV('S.cardio.on=false; S.cardio.tacc=0; S.cardio.tstart=null; S.fin=null; save(); render();');
    chk('(fixture) the athlete\'s day is empty too', EV('sessionPct().done')===0, 'athlete day not empty');
    chk('a coach cannot bank an empty day for an athlete', (await EV('saveSessionLog(false)'))===false, 'it banked');
    chk('nothing landed in the athlete\'s drawer', EV('localStorage.getItem("nsc:"+('+KEY+'))')===null, 'log written');
    chk('and the athlete\'s day is not locked', EV('dayLocked()')===false, 'athlete locked out');
    EV(logAllSets);
    chk('real work still banks for the athlete', (await EV('saveSessionLog(true)'))===true, 'refused real work');
    EV('rosterSwitch(null);'); await wait(320);
  }

  chk('no error surfaced anywhere in this harness', errs.length===0, errs.join(' | '));
  console.log('  problems: '+bad); process.exit(bad?1:0);
},1700);
