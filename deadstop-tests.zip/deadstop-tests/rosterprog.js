// FOUND BY SECOND REVIEW 2026-09-10 (finding D). The coach's roster showed every athlete at
// "0 sessions" no matter how much they had trained.
//
// rosterProgress() built its session prefix from curLOGP()+a.id+':'. It runs on the OWNER's
// roster screen, where ROSTER.active is null, so curLOGP() returns TLOGP ('tc-log:') - while
// athlete sessions live under LOGP+id+':' ('nova-sc-log:<id>:'). The prefix matched nothing.
// The athlete's id is the namespace, not the caller's.
//
// Second defect in the same function: both reads went at window.localStorage directly with a
// hard-coded 'nsc:' prefix, which is only how ST_MODE==='local' stores things. Under the
// storage bridge the roster read nothing at all for anybody.
//
// What this holds: a coach sees the real session count for each athlete, from the owner's
// screen and after visiting a drawer; counts are per-athlete and never bleed across; the
// owner's own sessions are not counted as any athlete's; assessed/started still read right;
// and it works whether storage is local or bridged.
const {JSDOM}=require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const raw=fs.readFileSync(f,'utf8');
const AC=function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
let bad=0; const chk=(l,ok,d)=>{ if(ok!==true)bad++; if(typeof ok==='string'&&ok.slice(0,3)==='ERR') d=ok; console.log(`  ${ok===true?'ok  ':'FAIL'}  ${l}${ok!==true&&d?'  <-- '+d:''}`); };

// bridged storage: an in-memory window.storage, so ST_MODE resolves to 'bridge' and nothing
// the card reads can come from localStorage. This is the configuration the old code was blind in.
function bridgeStore(){
  const m=new Map();
  return {
    get:async k=>m.has(k)?{key:k,value:m.get(k)}:null,
    set:async(k,v)=>{ m.set(k,v); return {key:k,value:v}; },
    delete:async k=>({key:k,deleted:m.delete(k)}),
    list:async p=>({keys:[...m.keys()].filter(k=>!p||k.indexOf(p)===0)})
  };
}
function boot(bridged){
  const w=new JSDOM(raw,{runScripts:'dangerously',pretendToBeVisual:true,url:'https://thundermeadows.github.io/',
    beforeParse(win){ win.AudioContext=AC; if(bridged) win.storage=bridgeStore(); }}).window;
  return {w, E:e=>{try{return w.eval(e);}catch(err){return 'ERR '+err.message;}}, A:async e=>{try{return await w.eval('(async()=>{'+e+'})()');}catch(err){return 'ERR '+err.message;}}};
}
const neutral=c=>{ c.E("for(var i=0,fs=['coachIdle','ONB_ACTIVE','isStartMode'];i<fs.length;i++){ try{ if(typeof window[fs[i]]==='function') window[fs[i]]=function(){return false;}; }catch(e){} }"); c.E("try{TOUR.live=false;}catch(e){} S.tour={done:true}; S.access={role:'coach',until:'2027-12-31'};"); };

async function seed(c){
  c.E("ROSTER.mode='coach'; ROSTER.athletes=[{id:'a1',name:'Bucky'},{id:'a2',name:'Sis'}]; ROSTER.active=null; rosterSave();");
  // Bucky: setup done, three sessions. Sis: a built plan but never started, one session.
  await c.A("await stSet(SKEY+':a:a1', JSON.stringify({onb:{done:true}, maxes:{squat:300}}));");
  await c.A("await stSet(SKEY+':a:a2', JSON.stringify({onb:{done:false}, genPlan:{days:[{code:'A',exercises:[]}]}}));");
  await c.A("await stSet(LOGP+'a1:2026-09-01-A-W1B0', '{\"date\":\"2026-09-01\"}');");
  await c.A("await stSet(LOGP+'a1:2026-09-03-B-W1B0', '{\"date\":\"2026-09-03\"}');");
  await c.A("await stSet(LOGP+'a1:2026-09-05-C-W1B0', '{\"date\":\"2026-09-05\"}');");
  await c.A("await stSet(LOGP+'a2:2026-09-02-A-W1B0', '{\"date\":\"2026-09-02\"}');");
  // the OWNER's own sessions, which belong to nobody on the roster
  await c.A("await stSet(TLOGP+'2026-09-04-B-W1B0', '{\"date\":\"2026-09-04\"}');");
  await c.A("await rosterProgressLoad();");
}
const P=(c,id)=>c.E(`JSON.stringify(rosterProgress({id:'${id}'}))`);

(async()=>{
  console.log(`\n--- ${L}: the coach's roster counts real sessions ---`);

  for(const mode of ['local','bridge']){
    console.log(`\n[${mode} storage]`);
    const c=boot(mode==='bridge'); await sleep(1900); neutral(c);
    chk('fixture: ST_MODE is '+mode, c.E('ST_MODE')===mode, 'got '+c.E('ST_MODE'));
    await seed(c);
    let p1={}, p2={};
    try{ p1=JSON.parse(P(c,'a1')); }catch(e){}
    try{ p2=JSON.parse(P(c,'a2')); }catch(e){}
    chk('Bucky shows his 3 sessions', p1.sessions===3, JSON.stringify(p1));
    chk('Sis shows her 1 session', p2.sessions===1, JSON.stringify(p2));
    chk("the owner's own session is counted for neither", p1.sessions===3 && p2.sessions===1, 'a1='+p1.sessions+' a2='+p2.sessions);
    chk('Bucky reads assessed and started', p1.assessed===true && p1.started===true, JSON.stringify(p1));
    chk('Sis reads assessed (plan built) but not started', p2.assessed===true && p2.started===false, JSON.stringify(p2));
    chk('an athlete with no drawer reads zero, not a crash', P(c,'ghost')==='{"assessed":false,"started":false,"sessions":0}', P(c,'ghost'));

    // the count must survive a visit to a drawer and back, and pick up a new session
    await c.A("await rosterSwitch('a1');");
    await c.A("await stSet(LOGP+'a1:2026-09-07-A-W1B0', '{\"date\":\"2026-09-07\"}');");
    await c.A("await rosterSwitch(null);"); await sleep(200);
    let p3={}; try{ p3=JSON.parse(P(c,'a1')); }catch(e){}
    chk('after visiting the drawer and returning, the new session shows (4)', p3.sessions===4, JSON.stringify(p3));
    chk('and the coach is back on their own card', c.E("!ROSTER.active"), 'active='+c.E('ROSTER.active'));
  }

  console.log('\nproblems: '+bad); process.exit(bad?1:0);
})();
