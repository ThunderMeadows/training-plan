// Reproduces the field report: squat e1RM 327, hip abduction/adduction machine.
// Asserts no movement is ever prescribed a floor weight while claiming it was
// "estimated from your <main lift>".
const { JSDOM } = require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3];
const dom=new JSDOM(fs.readFileSync(f,'utf8'),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://thundermeadows.github.io/'});
const w=dom.window,EV=e=>w.eval(e);
w.AudioContext=w.AudioContext||function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
setTimeout(()=>{
  console.log(`\n--- ${L}: accessory anchors against a 327 lb squat ---`);
  EV("S.maxes={squat:327,bench:225,dead:405,ohp:145,pull:225}; S.lastPerf={};");
  const rows=JSON.parse(EV('JSON.stringify(EXLIB.map(function(r){return {n:r[0],base:r[3],ratio:r[4],unit:r[5]};}))'));
  let bad=0, silent=0, est=0;
  for(const r of rows){
    if(r.unit==='bw') continue;
    const a=EV(`(function(){var e=estAccessory(${JSON.stringify(r.n)}); return e? e.val : null;})()`);
    const note=EV(`(function(){try{return accNote({name:${JSON.stringify(r.n)}})||'';}catch(e){return 'THREW '+e.message;}})()`);
    const claims=/estimated from your/.test(note);
    if(r.ratio===0){
      if(a!==null){ console.log(`  BAD  ${r.n}: ratio 0 still produced ${a} lb`); bad++; }
      else if(claims){ console.log(`  BAD  ${r.n}: no anchor but still claims an estimate`); bad++; }
      else silent++;
    } else if(a!==null){
      est++;
      // sanity: a real ratio should not land on the bare floor against a 327 squat
      if(r.base==='squat' && a<=5){ console.log(`  SUSPECT ${r.n}: ${a} lb off a 327 squat`); bad++; }
    }
  }
  console.log(`  movements with a real ratio, estimated: ${est}`);
  console.log(`  movements with no ratio, now ask instead: ${silent}`);
  console.log(`  problems: ${bad}`);
  // the two he hit, spelled out
  for(const n of ['Hip Abduction Machine','Hip Adduction Machine']){
    console.log(`  ${n}: est=${EV(`(function(){var e=estAccessory(${JSON.stringify(n)});return e?e.val:'(none - card asks)';})()`)}`);
    console.log(`     note: ${EV(`accNote({name:${JSON.stringify(n)}})`).replace(/<[^>]*>/g,'').trim().slice(0,90)}`);
  }
  process.exit(bad?1:0);
},1500);
