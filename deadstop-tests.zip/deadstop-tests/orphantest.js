// ORPHAN-CONTROL SCAN (2026-09-02). Every data-* attribute the card RENDERS as a control must
// have something that BINDS it. A rendered control with no binding is a dead button - the
// "tap it and nothing happens" class - and this finds it statically, in seconds, both cards.
const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const raw=fs.readFileSync(f,'utf8');
let bad=0; const chk=(l,ok,d)=>{ if(!ok)bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&d?'  <-- '+d:''}`);};
console.log(`\n--- ${L}: every rendered control has a binding ---`);

// attributes RENDERED into markup: data-xxx="..." or data-xxx=\"...\" inside strings
const rendered=new Set();
for(const m of raw.matchAll(/data-([a-z][a-z0-9]*)=\\?["']/g)) rendered.add(m[1]);
// attributes BOUND: querySelector('[data-xxx]'), closest('[data-xxx]'), getAttribute('data-xxx'),
// dataset.xxx, matches('[data-xxx]'), or a delegated `t.getAttribute&&t.getAttribute('data-xxx')`
const bound=new Set();
for(const m of raw.matchAll(/\[data-([a-z][a-z0-9]*)[\]=]/g)) bound.add(m[1]);
for(const m of raw.matchAll(/getAttribute\(\s*['"]data-([a-z][a-z0-9]*)['"]/g)) bound.add(m[1]);
for(const m of raw.matchAll(/dataset\.([a-zA-Z][a-zA-Z0-9]*)/g)) bound.add(m[1].toLowerCase());
for(const m of raw.matchAll(/hasAttribute\(\s*['"]data-([a-z][a-z0-9]*)['"]/g)) bound.add(m[1]);
// the rest overlay dispatches its own taps through hit('data-xxx')
for(const m of raw.matchAll(/\bhit\(\s*['"]data-([a-z][a-z0-9]*)['"]/g)) bound.add(m[1]);

// attributes that are DATA, not controls: they carry a value for a sibling handler to read
const VALUE_ONLY=new Set(['d','lv','fv','i','k','n','v','id','key','idx','iso','code','day','ex','w','r','sfin','ssel','cncd','cntype','cnadd','cndel','tday','slen','radj','fmt','face','win','loop',
  // verified markers, not controls (2026-09-02): rstop wraps the rest-weight stepper whose
  // buttons are data-rwe; streak carries a count for CSS; wl is a dedupe tag in the share sheet
  'rstop','streak','wl',
  // c165: data-fold marks the fold container; the control is data-foldtog, which is bound
  'fold']);
// first real find of this scan: data-stalekeep / data-staleuse were rendered and bound
// nowhere - the two exits from a banner that also silently disabled saving. Fixed c156.

chk('the card renders controls to scan', rendered.size>20, rendered.size+' attributes');
const orphans=[...rendered].filter(a=>!bound.has(a) && !VALUE_ONLY.has(a)).sort();
chk('no rendered control is missing its binding', orphans.length===0, orphans.join(', '));
console.log('  scanned '+rendered.size+' rendered data-attributes against '+bound.size+' bindings');
console.log('  problems: '+bad); process.exit(bad?1:0);
