// FIELD 2026-09-10. "Im ahead but i need the engine to keep up."
//
// He ran the baked starter block and rowed 155x8 for weeks against a plan asking 115-125. His
// Row max never moved off the 170 it was built with, so every prescription stayed wrong and the
// heavy day and the light day drifted toward the same number.
//
// Cause: autoCalibrate() opened with `if(!S.genPlan || !S.genPlan.days) return null;`. The
// starter block is baked into the file and has no S.genPlan, so calibration never ran for it.
// updateE1RM() banks evidence on every save regardless, so the history was there the whole time
// and nothing read it. Every starter-block athlete had a training max frozen for life.
//
// What this holds: a card on the baked plan, fed sets well above its programmed load, raises its
// max; the raise obeys the same evidence gate, noise band and 15% cap as a generated plan; the
// prescription that comes out afterwards actually moves; and a plan that is NOT driven by
// S.maxes is still left alone.
const {JSDOM}=require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const raw=fs.readFileSync(f,'utf8');
const AC=function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
let bad=0;
const chk=(l,ok,d)=>{ if(ok!==true)bad++; if(typeof ok==='string'&&ok.slice(0,3)==='ERR') d=ok; console.log(`  ${ok===true?'ok  ':'FAIL'}  ${l}${!ok&&d?'  <-- '+d:''}`); };

function boot(){
  const d=new JSDOM(raw,{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/',
    beforeParse(win){ win.AudioContext=AC; }});
  return d.window;
}
const EVf=w=>e=>{ try{ return w.eval(e); }catch(err){ return 'ERR '+err.message; } };

// n sessions of evidence at a given e1rm, dated backwards from today inside the 28-day window
const feed=(E,key,val,n)=>E(`(function(){
  S.e1rmH=S.e1rmH||{}; S.e1rmH['${key}']=[];
  for(var i=0;i<${n};i++){
    var dt=new Date(new Date(shiftDate()+'T12:00:00').getTime()-i*3*86400000);
    var ds=dt.toISOString().slice(0,10);
    S.e1rmH['${key}'].push({d:ds, v:${val}, r:1});
  }
  return S.e1rmH['${key}'].length;
})()`);

console.log(`\n--- ${L}: calibration on a baked plan ---`);

setTimeout(()=>{
  const w=boot(); const E=EVf(w);
  setTimeout(()=>{
    // --- the card as he actually runs it: baked PLAN, no generated plan ---
    chk('fixture: running the baked starter block, no genPlan', E('!S.genPlan && !!PLAN && !!PLAN.days'), 'fixture wrong');
    chk('fixture: the baked plan IS driven by S.maxes', E('planMaxDriven()===true'), 'planMaxDriven false on baked plan');

    E("S.maxes=Object.assign({}, S.maxes||{}, {row:170})");
    const before=E('S.maxes.row');
    chk('fixture: Row max starts at 170', before===170, 'got '+before);

    // evidence clearly above the programmed max: a ~230 e1rm wants a 195 training max
    feed(E,'row',230,4);
    const out=E('autoCalibrate()');
    const after=E('S.maxes.row');

    chk('the max moves off 170 on a baked plan', after>before, 'still '+after+' - calibration did not run');
    chk('it respects the 15% cap', after<=Math.round(170*1.15/5)*5, 'jumped to '+after);
    chk('it lands on a sensible training max', after>=180 && after<=200, 'got '+after);
    chk('the change is recorded as undoable', E("(S.adLog||[]).some(function(x){return x.kind==='calib'&&x.lift==='row';})"), 'no adLog entry');

    // --- the gates still hold ---
    const w2=boot(); const E2=EVf(w2);
    setTimeout(()=>{
      E2("S.maxes=Object.assign({}, S.maxes||{}, {row:170})");
      feed(E2,'row',230,2);                       // below AC_MIN_SETS
      E2('autoCalibrate()');
      chk('thin evidence is still refused', E2('S.maxes.row')===170, 'moved on 2 sessions');

      E2("S.e1rmH={}"); feed(E2,'row',196,4);      // 196*.87=170.5 -> inside the 4% noise band
      E2('autoCalibrate()');
      chk('a max already about right is left alone', E2('S.maxes.row')===170, 'moved to '+E2('S.maxes.row'));

      // --- a plan with nothing max-driven is not touched ---
      const w3=boot(); const E3=EVf(w3);
      setTimeout(()=>{
        E3("PLAN={days:[{code:'A',title:'t',exercises:[{name:'Walk', maxKey:null, pct:null}]}], weeks:6}; S.genPlan=null;");
        chk('a plan with no max-driven work reports false', E3('planMaxDriven()===false'), 'reported true');
        E3("S.maxes=Object.assign({}, S.maxes||{}, {row:170})");
        E3("S.e1rmH={}");
        feed(E3,'row',230,4);
        E3('autoCalibrate()');
        chk('and its maxes are left alone', E3('S.maxes.row')===170, 'moved to '+E3('S.maxes.row'));

        console.log('\nproblems: '+bad);
        process.exit(bad?1:0);
      }, 1800);
    }, 1800);
  }, 1800);
}, 50);
