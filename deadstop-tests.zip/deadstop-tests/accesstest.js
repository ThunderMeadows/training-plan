// His ask, 2026-09-07: a gate before the app. A code grants athlete or coach rights, once,
// for 90 days; then renew. Everyone already using the card becomes an athlete automatically.
// He switches himself to coach through Settings.
//
// What this file holds: a new card meets the gate and cannot get past it without a code; a
// wrong code is refused; the athlete code grants athlete rights and no coach switch; the coach
// code grants coach rights and the switch; a card from before the gate gets athlete rights on
// its first open with no gate; a coach-mode card without coach rights runs solo with its roster
// kept; expired access meets the gate with every session still there; a code entered from
// Settings renews or upgrades; and the codes themselves are not in the file.
const {JSDOM}=require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const raw=fs.readFileSync(f,'utf8');
const CODES=(function(){ try{ return JSON.parse(fs.readFileSync(require('path').join(__dirname,'access-codes.json'),'utf8')); }catch(e){ return null; } })();
const AC=function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
let bad=0; const chk=(l,ok,dd)=>{ if(!ok)bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&dd?'  <-- '+dd:''}`);};
const errs=[]; const sleep=ms=>new Promise(r=>setTimeout(r,ms));
function boot(store){
  const d=new JSDOM(raw,{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/',
    beforeParse(win){ Object.keys(store||{}).forEach(k=>win.localStorage.setItem(k, store[k])); win.AudioContext=AC; }});
  d.window.addEventListener('error',e=>errs.push(String(e.message)));
  return d.window;
}
const EVf=w=>e=>{ try{ return w.eval(e); }catch(err){ return 'ERR '+err.message; } };
const dump=w=>{ const o={}; for(let i=0;i<w.localStorage.length;i++){ const k=w.localStorage.key(i); o[k]=w.localStorage.getItem(k); } return o; };
const gate=E=>E('!!document.getElementById("accessGate")');
// v215: a right code turns the gate into a confirmation with a Done button; enter() presses it
function enter(w, code){ const E=EVf(w); E(`(function(){ var i=document.getElementById('accessIn'); if(!i) return 'no input'; i.value=${JSON.stringify(code)};
  document.getElementById('accessOk').dispatchEvent(new window.MouseEvent('click',{bubbles:true}));
  var d=document.getElementById('accessDone'); if(d) d.dispatchEvent(new window.MouseEvent('click',{bubbles:true})); return 'ok'; })()`); }

setTimeout(async ()=>{
  console.log(`\n--- ${L}: the access gate ---`);
  chk('(fixture) the test has the codes beside it', !!(CODES && CODES.athlete && CODES.coach), 'access-codes.json missing - the harness cannot enter a code');
  if(!CODES){ console.log('\nproblems: '+(bad)); process.exit(1); }

  // ---- 1. a new card ----------------------------------------------------------------
  let w=boot({}); await sleep(2400); let E=EVf(w);
  chk('a new card meets the gate', gate(E), 'no gate on a fresh card');
  chk('the gate stands in front of the disclaimer', E('(function(){ var a=document.getElementById("accessGate"), d=document.getElementById("discGate"); return !!a && (!d || (+getComputedStyle(a).zIndex||+a.style.zIndex) > (+getComputedStyle(d).zIndex||410)); })()'), 'disclaimer is above the access gate');
  enter(w, 'NOPE-NOPE-NOPE'); await sleep(30);
  chk('a wrong code is refused and says so', gate(E) && /not recognised/i.test(E('document.getElementById("accessMsg").textContent')), 'wrong code got in, or no message');
  chk('and nothing was granted', E('!S.access'), JSON.stringify(E('S.access')));
  enter(w, CODES.athlete.code.toLowerCase()); await sleep(60);
  chk('the athlete code opens the gate, in any case', !gate(E) && E('accessRole()')==='athlete', 'role '+E('accessRole()'));
  chk('access runs 90 days from today', E('(function(){ var a=S.access; var d=(new Date(a.until+"T12:00:00")-new Date(a.since+"T12:00:00"))/86400000; return Math.round(d)===90; })()'), JSON.stringify(E('S.access')));
  // a fresh card is still on Setup; finish it so the You tab renders
  E('try{TOUR.live=false;}catch(e){} S.tour={done:true}; if(typeof ONB!=="undefined"){ONB().done=true;} S.discAck={v:DISC_V,d:localDate()}; save(); S.day="MAX"; render();');
  chk('an athlete card does not offer the coach switch', E('!document.getElementById("coachToggle")') && /coach code/i.test(E('document.getElementById("app").textContent')), 'coach switch visible to an athlete');
  chk('Settings shows the access with its expiry', /Athlete/.test(E('accessHTML()')) && /until/.test(E('accessHTML()')), E('accessHTML()').slice(0,120));

  // ---- 2. the coach code --------------------------------------------------------------
  w=boot({}); await sleep(2400); E=EVf(w);
  enter(w, CODES.coach.code); await sleep(60);
  chk('the coach code grants coach rights', !gate(E) && E('accessRole()')==='coach', 'role '+E('accessRole()'));
  E('try{TOUR.live=false;}catch(e){} S.tour={done:true}; if(typeof ONB!=="undefined"){ONB().done=true;} S.discAck={v:DISC_V,d:localDate()}; save(); S.day="MAX"; render();');
  chk('and the coach switch is offered', E('!!document.getElementById("coachToggle")'), 'no coach switch for a coach');

  // ---- 3. a card from before the gate -----------------------------------------------
  const legacy={ 'nsc:training-card-v1': JSON.stringify({discAck:{v:1,d:'2026-09-01'}, tour:{done:true}, maxes:{squat:315}}) };
  w=boot(legacy); await sleep(2400); E=EVf(w);
  chk('a card already in use gets athlete rights with no gate', !gate(E) && E('accessRole()')==='athlete' && E('S.access.via')==='legacy', 'role '+E('accessRole()')+' gate '+gate(E));
  chk('its data is untouched', E('S.maxes.squat')===315, 'maxes changed');

  // ---- 4. a coach-mode card whose holder has no coach rights -----------------------------
  const coachy={ 'nsc:training-card-v1': JSON.stringify({discAck:{v:1,d:'2026-09-01'}, tour:{done:true}}),
                 'nsc:training-card-roster-v1': JSON.stringify({mode:'coach', athletes:[{id:'a1',name:'Sam'}], active:null}) };
  w=boot(coachy); await sleep(2400); E=EVf(w);
  chk('a coach-mode card without coach rights runs as a solo card', E('ROSTER.mode')==='solo', 'mode '+E('ROSTER.mode'));
  chk('but the roster is kept, not deleted', E('(ROSTER.athletes||[]).length')===1, 'athletes '+E('JSON.stringify(ROSTER.athletes)'));
  // and the holder enters the coach code from Settings
  E('bootAccess(true);'); await sleep(30);
  chk('Settings can open the gate to enter a code', gate(E), 'no gate on request');
  // v215: his own report - "I entered the coach code, selected enter, and nothing happened."
  // The code was accepted; the roster stayed solo and the sheet behind looked unchanged.
  E(`(function(){ var i=document.getElementById('accessIn'); i.value=${JSON.stringify(CODES.coach.code)};
      document.getElementById('accessOk').dispatchEvent(new window.MouseEvent('pointerup',{bubbles:true})); })()`);   // no click at all
  await sleep(60);
  chk('a coach code entered there upgrades the card - even when the phone withholds the click', E('accessRole()')==='coach', 'role '+E('accessRole()'));
  chk('the gate says in its own words what it just did', gate(E) && /Coach access is on/.test(E('document.getElementById("accessGate").textContent')), 'no visible confirmation');
  chk('and the roster comes straight back', E('ROSTER.mode')==='coach' && E('(ROSTER.athletes||[]).length')===1, 'mode '+E('ROSTER.mode'));
  E('document.getElementById("accessDone").dispatchEvent(new window.MouseEvent("click",{bubbles:true}));'); await sleep(30);
  chk('Done closes it', !gate(E), 'gate still up after Done');

  // ---- 5. expiry --------------------------------------------------------------------
  const st=JSON.parse(dump(w)['nsc:training-card-v1']); st.access.until='2026-01-01'; st.maxes={bench:225};
  w=boot({ 'nsc:training-card-v1': JSON.stringify(st) }); await sleep(2400); E=EVf(w);
  chk('expired access meets the gate again', gate(E) && /expired/i.test(E('document.getElementById("accessGate").textContent')), 'no gate, or not the expired wording');
  chk('with every piece of data still there behind it', E('S.maxes.bench')===225, 'data lost on expiry');
  enter(w, CODES.athlete.code); await sleep(60);
  chk('a current code renews for another 90 days', !gate(E) && E('S.access.until')>'2026-09-07', JSON.stringify(E('S.access')));

  // ---- 5b. v216: the run-out date is visible, and the way to renew is one tap -------------
  // "Add the expiration date to the calendar and have a 'good till' in the header somewhere.
  // Or renew? Then a link that sends the user to send me a direct email or message with an auto
  // message asking for a renewal."
  w=boot({ 'nsc:training-card-v1': JSON.stringify({discAck:{v:1,d:'2026-09-01'}, tour:{done:true}, profileName:'Sam'}) }); await sleep(2400); E=EVf(w);
  E('if(typeof ONB!=="undefined"){ONB().done=true;} save(); render();');
  chk('the header says how long access is good for', /Good till/.test(E('(document.querySelector("[data-accesshdr]")||{}).textContent||""')), E('(document.querySelector("[data-accesshdr]")||{}).textContent'));
  E('S.access.until=(function(){ var q=new Date(shiftDate()+"T12:00:00"); q.setDate(q.getDate()+5); return q.toISOString().slice(0,10); })(); save(); render();');
  chk('with two weeks or less left it says Renew and counts the days', /RENEW.*5 days/.test(E('(document.querySelector("[data-accesshdr]")||{}).textContent||""')), E('(document.querySelector("[data-accesshdr]")||{}).textContent'));
  E('document.querySelector("[data-accesshdr]").dispatchEvent(new window.MouseEvent("click",{bubbles:true}));'); await sleep(30);
  chk('tapping it opens the code screen', gate(E), 'header chip did nothing');
  E('document.getElementById("accessCancel").dispatchEvent(new window.MouseEvent("click",{bubbles:true}));');
  E('S.day="CAL"; S.calSel=null; render();');
  chk('the calendar marks the day access runs out', E('!!Array.from(document.querySelectorAll("[data-calday]")).find(function(el){ return el.getAttribute("data-calday")===S.access.until && /ACCESS/.test(el.textContent); })'), 'no mark on the run-out day');
  chk('and says the date in words with the days left', /runs out on .*5 days from today/.test(E('(document.getElementById("calAccess")||{}).textContent||""')), E('(document.getElementById("calAccess")||{}).textContent'));
  const rt=E('renewText()');
  chk('the renewal request is written for the athlete and signed with their name', /runs out on/.test(rt) && /renewal code/.test(rt) && /Sam$/.test(rt), rt);
  chk('with no address configured there is a copy button, not a dead link', E('!!document.querySelector("[data-renewcopy]")') && E('renewHref("mail")')==='', 'no copy button, or a link to nowhere');
  E('RENEW_EMAIL="coach@example.com"; RENEW_SMS="+15555550100"; render();');
  chk('with an address configured the buttons open a prefilled email and text',
      /^mailto:coach@example\.com\?subject=.*&body=Hi/.test(E('renewHref("mail")')) && /^sms:\+15555550100\?&body=Hi/.test(E('renewHref("sms")')) && E('document.querySelectorAll("#calAccess a[href^=mailto], #calAccess a[href^=sms]").length')===2,
      E('renewHref("mail")').slice(0,60)+' | '+E('renewHref("sms")').slice(0,40));
  // and on an expired gate, the way out is right there
  E('S.access.until="2026-01-01"; save(); bootAccess();'); await sleep(30);
  chk('an expired gate carries the renewal request', gate(E) && E('!!document.querySelector("#accessGate a[href^=mailto]")'), 'expired gate has no way to ask for renewal');

  // ---- 6. the codes are not in the file ---------------------------------------------------
  chk('neither code appears anywhere in the source', raw.indexOf(CODES.athlete.code)<0 && raw.indexOf(CODES.athlete.code.replace(/-/g,''))<0 && raw.indexOf(CODES.coach.code)<0 && raw.indexOf(CODES.coach.code.replace(/-/g,''))<0, 'a code is in the file in plain text');
  chk('the hash is the real thing', E('sha256hex("abc")')==='ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad', E('sha256hex("abc")'));

  chk('no runtime errors across the boots', errs.length===0, errs.slice(0,3).join(' | '));
  console.log(`\nproblems: ${bad}`);
  process.exit(bad? 1:0);
},100);
