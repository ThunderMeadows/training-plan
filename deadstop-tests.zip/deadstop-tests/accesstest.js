// His ask, 2026-09-07: a gate before the app. A code grants athlete or coach rights, once,
// for 90 days; then renew. Everyone already using the card becomes an athlete automatically.
// He switches himself to coach through Settings.
//
// What this file holds: a new card meets the gate and cannot get past it without a code; a
// wrong code is refused; the athlete code grants athlete rights and no coach switch; the coach
// code grants coach rights and the switch; a card from before the gate gets athlete rights on
// its first open with no gate; a coach-mode card without coach rights runs solo with its roster
// kept; expired access meets the gate with every session still there; a code entered from
// Settings renews or upgrades; and the codes themselves are not in the file.
const {JSDOM}=require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const raw=fs.readFileSync(f,'utf8');
// SECURITY 2026-09-10: real codes no longer ship in this archive (see fixture-codes.js).
// Synthetic codes are installed into the card under test, so the same code path is exercised.
const FX=require('./fixture-codes');
const CODES=FX.loadCodes();
const AC=function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
let bad=0; const chk=(l,ok,dd)=>{ if(!ok)bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&dd?'  <-- '+dd:''}`);};
const errs=[]; const sleep=ms=>new Promise(r=>setTimeout(r,ms));
function boot(store){
  const d=new JSDOM(raw,{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/',
    beforeParse(win){ Object.keys(store||{}).forEach(k=>win.localStorage.setItem(k, store[k])); win.AudioContext=AC; }});
  d.window.addEventListener('error',e=>errs.push(String(e.message)));
  // teach this window the fixture codes (no-op when real codes are present locally)
  try{ FX.installCodes(e=>{ try{ return d.window.eval(e); }catch(err){ return 'ERR '+err.message; } }, CODES); }catch(e){}
  return d.window;
}
const EVf=w=>e=>{ try{ return w.eval(e); }catch(err){ return 'ERR '+err.message; } };
const dump=w=>{ const o={}; for(let i=0;i<w.localStorage.length;i++){ const k=w.localStorage.key(i); o[k]=w.localStorage.getItem(k); } return o; };
const gate=E=>E('!!document.getElementById("accessGate")');
// v215: a right code turns the gate into a confirmation with a Done button; enter() presses it.
// v225: and the gate now awaits the server first, so the Done button does not exist until that
// round trip finishes - press, wait, then press Done.
async function enter(w, code){ const E=EVf(w);
  E(`(function(){ var i=document.getElementById('accessIn'); if(!i) return 'no input'; i.value=${JSON.stringify(code)};
    document.getElementById('accessOk').dispatchEvent(new window.MouseEvent('click',{bubbles:true})); return 'ok'; })()`);
  await sleep(120);
  E(`(function(){ var d=document.getElementById('accessDone'); if(d) d.dispatchEvent(new window.MouseEvent('click',{bubbles:true})); })()`);
}

setTimeout(async ()=>{
  console.log(`\n--- ${L}: the access gate ---`);
  chk('(fixture) the harness has codes to enter', !!(CODES && CODES.athlete && CODES.coach), 'fixture-codes.js produced nothing');
  if(!CODES){ console.log('\nproblems: '+(bad)); process.exit(1); }

  // ---- 1. a new card ----------------------------------------------------------------
  let w=boot({}); await sleep(2400); let E=EVf(w);
  chk('a new card meets the gate', gate(E), 'no gate on a fresh card');
  chk('the gate stands in front of the disclaimer', E('(function(){ var a=document.getElementById("accessGate"), d=document.getElementById("discGate"); return !!a && (!d || (+getComputedStyle(a).zIndex||+a.style.zIndex) > (+getComputedStyle(d).zIndex||410)); })()'), 'disclaimer is above the access gate');
  await enter(w, 'NOPE-NOPE-NOPE'); await sleep(30);
  chk('a wrong code is refused and says so', gate(E) && /not recognised/i.test(E('document.getElementById("accessMsg").textContent')), 'wrong code got in, or no message');
  chk('and nothing was granted', E('!S.access'), JSON.stringify(E('S.access')));
  await enter(w, CODES.athlete.code.toLowerCase()); await sleep(60);
  chk('the athlete code opens the gate, in any case', !gate(E) && E('accessRole()')==='athlete', 'role '+E('accessRole()'));
  chk('access runs 90 days from today', E('(function(){ var a=S.access; var d=(new Date(a.until+"T12:00:00")-new Date(a.since+"T12:00:00"))/86400000; return Math.round(d)===90; })()'), JSON.stringify(E('S.access')));
  // a fresh card is still on Setup; finish it so the You tab renders
  E('try{TOUR.live=false;}catch(e){} S.tour={done:true}; if(typeof ONB!=="undefined"){ONB().done=true;} S.discAck={v:DISC_V,d:localDate()}; save(); S.day="MAX"; render();');
  chk('an athlete card does not offer the coach switch', E('!document.getElementById("coachToggle")') && /coach code/i.test(E('document.getElementById("app").textContent')), 'coach switch visible to an athlete');
  chk('Settings shows the access with its expiry', /Athlete/.test(E('accessHTML()')) && /until/.test(E('accessHTML()')), E('accessHTML()').slice(0,120));

  // ---- 2. the coach code --------------------------------------------------------------
  w=boot({}); await sleep(2400); E=EVf(w);
  await enter(w, CODES.coach.code); await sleep(60);
  chk('the coach code grants coach rights', !gate(E) && E('accessRole()')==='coach', 'role '+E('accessRole()'));
  E('try{TOUR.live=false;}catch(e){} S.tour={done:true}; if(typeof ONB!=="undefined"){ONB().done=true;} S.discAck={v:DISC_V,d:localDate()}; save(); S.day="MAX"; render();');
  chk('and the coach switch is offered', E('!!document.getElementById("coachToggle")'), 'no coach switch for a coach');

  // ---- 3. a card from before the gate -----------------------------------------------
  const legacy={ 'nsc:training-card-v1': JSON.stringify({discAck:{v:1,d:'2026-09-01'}, tour:{done:true}, maxes:{squat:315}}) };
  w=boot(legacy); await sleep(2400); E=EVf(w);
  chk('a card already in use gets athlete rights with no gate', !gate(E) && E('accessRole()')==='athlete' && E('S.access.via')==='legacy', 'role '+E('accessRole()')+' gate '+gate(E));
  chk('its data is untouched', E('S.maxes.squat')===315, 'maxes changed');

  // ---- 4. a coach-mode card whose holder has no coach rights -----------------------------
  const coachy={ 'nsc:training-card-v1': JSON.stringify({discAck:{v:1,d:'2026-09-01'}, tour:{done:true}}),
                 'nsc:training-card-roster-v1': JSON.stringify({mode:'coach', athletes:[{id:'a1',name:'Sam'}], active:null}) };
  w=boot(coachy); await sleep(2400); E=EVf(w);
  chk('a coach-mode card without coach rights runs as a solo card', E('ROSTER.mode')==='solo', 'mode '+E('ROSTER.mode'));
  chk('but the roster is kept, not deleted', E('(ROSTER.athletes||[]).length')===1, 'athletes '+E('JSON.stringify(ROSTER.athletes)'));
  // and the holder enters the coach code from Settings
  E('bootAccess(true);'); await sleep(30);
  chk('Settings can open the gate to enter a code', gate(E), 'no gate on request');
  // v215: his own report - "I entered the coach code, selected enter, and nothing happened."
  // The code was accepted; the roster stayed solo and the sheet behind looked unchanged.
  E(`(function(){ var i=document.getElementById('accessIn'); i.value=${JSON.stringify(CODES.coach.code)};
      document.getElementById('accessOk').dispatchEvent(new window.MouseEvent('pointerup',{bubbles:true})); })()`);   // no click at all
  await sleep(60);
  chk('a coach code entered there upgrades the card - even when the phone withholds the click', E('accessRole()')==='coach', 'role '+E('accessRole()'));
  chk('the gate says in its own words what it just did', gate(E) && /Coach access is on/.test(E('document.getElementById("accessGate").textContent')), 'no visible confirmation');
  chk('and the roster comes straight back', E('ROSTER.mode')==='coach' && E('(ROSTER.athletes||[]).length')===1, 'mode '+E('ROSTER.mode'));
  E('document.getElementById("accessDone").dispatchEvent(new window.MouseEvent("click",{bubbles:true}));'); await sleep(30);
  chk('Done closes it', !gate(E), 'gate still up after Done');

  // ---- 5. expiry --------------------------------------------------------------------
  const st=JSON.parse(dump(w)['nsc:training-card-v1']); st.access.until='2026-01-01'; st.maxes={bench:225};
  w=boot({ 'nsc:training-card-v1': JSON.stringify(st) }); await sleep(2400); E=EVf(w);
  chk('expired access meets the gate again', gate(E) && /expired/i.test(E('document.getElementById("accessGate").textContent')), 'no gate, or not the expired wording');
  chk('with every piece of data still there behind it', E('S.maxes.bench')===225, 'data lost on expiry');
  await enter(w, CODES.athlete.code); await sleep(60);
  chk('a current code renews for another 90 days', !gate(E) && E('S.access.until')>'2026-09-07', JSON.stringify(E('S.access')));

  // ---- 5b. v216: the run-out date is visible, and the way to renew is one tap -------------
  // "Add the expiration date to the calendar and have a 'good till' in the header somewhere.
  // Or renew? Then a link that sends the user to send me a direct email or message with an auto
  // message asking for a renewal."
  w=boot({ 'nsc:training-card-v1': JSON.stringify({discAck:{v:1,d:'2026-09-01'}, tour:{done:true}, profileName:'Sam'}) }); await sleep(2400); E=EVf(w);
  E('if(typeof ONB!=="undefined"){ONB().done=true;} save(); render();');
  chk('the header says how long access is good for', /Good till/.test(E('(document.querySelector("[data-accesshdr]")||{}).textContent||""')), E('(document.querySelector("[data-accesshdr]")||{}).textContent'));
  E('S.access.until=(function(){ var q=new Date(shiftDate()+"T12:00:00"); q.setDate(q.getDate()+5); return q.toISOString().slice(0,10); })(); save(); render();');
  chk('with two weeks or less left it says Renew and counts the days', /RENEW.*5 days/.test(E('(document.querySelector("[data-accesshdr]")||{}).textContent||""')), E('(document.querySelector("[data-accesshdr]")||{}).textContent'));
  E('document.querySelector("[data-accesshdr]").dispatchEvent(new window.MouseEvent("click",{bubbles:true}));'); await sleep(30);
  chk('tapping it opens the code screen', gate(E), 'header chip did nothing');
  E('document.getElementById("accessCancel").dispatchEvent(new window.MouseEvent("click",{bubbles:true}));');
  E('S.day="CAL"; S.calSel=null; render();');
  chk('the calendar marks the day access runs out', E('!!Array.from(document.querySelectorAll("[data-calday]")).find(function(el){ return el.getAttribute("data-calday")===S.access.until && /ACCESS/.test(el.textContent); })'), 'no mark on the run-out day');
  chk('and says the date in words with the days left', /runs out on .*5 days from today/.test(E('(document.getElementById("calAccess")||{}).textContent||""')), E('(document.getElementById("calAccess")||{}).textContent'));
  const rt=E('renewText()');
  chk('the renewal request is written for the athlete and signed with their name', /runs out on/.test(rt) && /renewal code/.test(rt) && /Sam$/.test(rt), rt);
  // v218 ships his address, so blank the constants to prove the no-address path still holds
  E('RENEW_EMAIL=""; RENEW_SMS=""; render();');
  chk('with no address configured there is a copy button, not a dead link', E('!!document.querySelector("[data-renewcopy]")') && E('renewHref("mail")')==='', 'no copy button, or a link to nowhere');
  E('RENEW_EMAIL="coach@example.com"; RENEW_SMS="+15555550100"; render();');
  chk('with an address configured the buttons open a prefilled email and text',
      /^mailto:coach@example\.com\?subject=.*&body=Hi/.test(E('renewHref("mail")')) && /^sms:\+15555550100\?&body=Hi/.test(E('renewHref("sms")')) && E('document.querySelectorAll("#calAccess a[href^=mailto], #calAccess a[href^=sms]").length')===2,
      E('renewHref("mail")').slice(0,60)+' | '+E('renewHref("sms")').slice(0,40));
  // and on an expired gate, the way out is right there
  E('S.access.until="2026-01-01"; save(); bootAccess();'); await sleep(30);
  chk('an expired gate carries the renewal request', gate(E) && E('!!document.querySelector("#accessGate a[href^=mailto]")'), 'expired gate has no way to ask for renewal');

  // ---- 5c. v218: administrators and the encrypted pool -----------------------------------
  // His ask: an admin-only tab where an administrator generates athlete and coach keys.
  // Design: a pool baked at build time, encrypted under the admin code; fingerprints verify.
  w=boot({}); await sleep(2400); E=EVf(w);
  await enter(w, CODES.admin.code); await sleep(60);
  chk('the admin code grants admin access for a year, never past the key\u2019s own date', E('accessRole()')==='admin' && E('(function(){ var a=S.access; var d=Math.round((new Date(a.until+"T12:00:00")-new Date(a.since+"T12:00:00"))/86400000); return d===365 || a.until===ACCESS_CODES.filter(function(x){return x.role==="admin";})[0].exp; })()'), JSON.stringify(E('S.access')));
  E('try{TOUR.live=false;}catch(e){} S.tour={done:true}; if(typeof ONB!=="undefined"){ONB().done=true;} S.discAck={v:DISC_V,d:localDate()}; save(); render();');
  chk('an administrator sees the Admin tab', E('!!document.querySelector("[data-day=ADMIN]")'), 'no Admin tab');
  chk('and has coach tools as well', E('coachAllowed()')===true, 'admin without coach tools');
  E('S.day="ADMIN"; render();');
  chk('the pool opens for the admin - 200 athlete, 50 coach across four dated batches', E('(function(){ var p=adminPool(); if(!p||!p.batches||p.batches.length!==4) return false; var a=0,c=0; p.batches.forEach(function(b){ a+=b.athlete.length; c+=b.coach.length; }); return a===200 && c===50 && p.batches.every(function(b){ return /^\\d{4}-\\d{2}-\\d{2}$/.test(b.exp); }); })()'), E('JSON.stringify(adminPool()&&adminPool().batches.map(function(b){return b.id;}))'));
  E('document.getElementById("adminTo").value="Sam"; document.querySelector("[data-adminissue=athlete]").dispatchEvent(new window.MouseEvent("click",{bubbles:true}));'); await sleep(40);
  const issued=E('(S.adminIssued||[])[0]||null');
  chk('issuing an athlete key records who it went to and when', !!issued && issued.role==='athlete' && issued.to==='Sam' && /^[A-Z2-9]{4}-[A-Z2-9]{4}-[A-Z2-9]{4}$/.test(issued.code), JSON.stringify(issued));
  chk('the issued key is shown on the tab with copy, text and email', new RegExp(issued.code).test(E('document.getElementById("app").textContent')) && E('!!document.querySelector("#adminIssue a[href^=sms]") && !!document.querySelector("#adminIssue a[href^=mailto]")'), 'key not shown or no share buttons');
  chk('the pool count goes down by one', /49 athlete/.test(E('document.getElementById("app").textContent')), 'count unchanged');
  chk('the issued key records its batch and its own life', !!issued.b && /^\d{4}-\d{2}-\d{2}$/.test(issued.exp||''), JSON.stringify(issued));
  // a brand-new card accepts the issued key
  const w9=boot({}); await sleep(2400); const E9=EVf(w9);
  await enter(w9, issued.code); await sleep(60);
  chk('a brand-new card accepts a key the admin issued', E9('accessRole()')==='athlete', 'role '+E9('accessRole()'));
  chk('but a new card does not get the Admin tab or the pool', E9('!adminAllowed() && adminPool()===null'), 'a non-admin can see the pool');
  // unissue returns it to the pool - v228: only once the tab has read from the server that
  // nobody has entered it. Model a connected tab whose server says the key is unused.
  E('S.adminTok="t"; S.adminLive=S.adminLive||{}; S.adminLive[accessFp(S.adminIssued[0].code)]={devs:0,rev:false,exp:"2027-03-31",at:shiftDate()}; S.adminStats={at:shiftDate(), s:{totals:{},devices:{},keys:{}}}; render();');
  E('document.querySelector("[data-adminforget]").dispatchEvent(new window.MouseEvent("click",{bubbles:true}));'); await sleep(40);
  chk('unissuing returns the key to the pool', E('(S.adminIssued||[]).length')===0 && /50 athlete/.test(E('document.getElementById("app").textContent')), 'still issued');
  // the pool is locked to anyone without the admin code
  chk('a wrong key opens nothing from the pool', E('poolOpen(poolKeyFor("NOPE-NOPE-NOPE"))===null'), 'garbage decrypted to something');
  chk('a non-admin who forges the role still has a locked pool', E('(function(){ S.access.role="admin"; delete S.poolKey; var p=adminPool(); S.access.role="athlete"; return p===null; })()'), 'the tab is not the only lock');
  chk('the admin code and every pool code are absent from the source in plain text',
      raw.indexOf(CODES.admin.code)<0 && CODES.batches.every(b=>b.athlete.concat(b.coach).every(c=>raw.indexOf(c)<0)), 'a code is in the file');
  chk('the renewal request now opens a real email and text', /^mailto:manuel\.g\.grajeda@outlook\.com/.test(E('renewHref("mail")')) && /^sms:\+15202346160/.test(E('renewHref("sms")')), E('renewHref("mail")').slice(0,50));
  // an ordinary card still never sees the Admin tab
  chk('an athlete card has no Admin tab', E9('!document.querySelector("[data-day=ADMIN]")'), 'Admin tab leaked');

  // ---- 5d. v219 audit: access belongs to the holder, not the open drawer ----------------
  w=boot({}); await sleep(2400); E=EVf(w);
  await enter(w, CODES.coach.code); await sleep(60);
  E('try{TOUR.live=false;}catch(e){} S.tour={done:true}; if(typeof ONB!=="undefined"){ONB().done=true;} S.discAck={v:DISC_V,d:localDate()}; save(); ROSTER.mode="coach"; rosterSave(); rosterAdd("Sam");'); await sleep(60);
  await E('rosterSwitch(ROSTER.athletes[0].id)'); await sleep(250);
  chk('inside an athlete\u2019s drawer the coach is still the coach', E('accessRole()')==='coach' && E('coachAllowed()')===true, 'role in drawer: '+E('accessRole()'));
  E('accessEnforce();');
  chk('a resume inside the drawer does not demote the roster', E('ROSTER.mode')==='coach', 'mode '+E('ROSTER.mode'));
  E('accessLegacy();');
  chk('no access is granted to the athlete\u2019s drawer itself', E('!S.access'), 'the drawer got an access record');
  E('if(typeof ONB!=="undefined"){ONB().done=true;} S.discAck={v:DISC_V,d:localDate()}; render();');   // a set-up drawer, so the header draws
  chk('the header chip still shows the holder\u2019s access inside the drawer', /Good till/.test(E('(document.querySelector("[data-accesshdr]")||{}).textContent||""')), 'chip missing in drawer');
  await E('rosterSwitch(null)'); await sleep(250);
  chk('back on the holder\u2019s card, still coach, roster still on', E('accessRole()')==='coach' && E('ROSTER.mode')==='coach', 'role '+E('accessRole()')+' mode '+E('ROSTER.mode'));
  // downgrade drops the pool key
  w=boot({}); await sleep(2400); E=EVf(w);
  await enter(w, CODES.admin.code); await sleep(60); E('bootAccess(true);'); await enter(w, CODES.athlete.code); await sleep(60);
  chk('an admin who enters a lesser code loses the pool key with the role', E('!S.poolKey') && E('(function(){ S.access.role="admin"; var p=!!adminPool(); S.access.role="athlete"; return !p; })()'), 'pool key survived a downgrade');
  // the Admin tab is a tab to the footer
  E('bootAccess(true);'); await enter(w, CODES.admin.code); await sleep(60);
  E('try{TOUR.live=false;}catch(e){} S.tour={done:true}; if(typeof ONB!=="undefined"){ONB().done=true;} S.discAck={v:DISC_V,d:localDate()}; save(); S.day="ADMIN"; S.view="rows"; render();');
  chk('the footer does not draw session controls on the Admin tab', E('!document.querySelector("#footer .fnav, #footer [data-fprev], #footer [data-fnext]")'), 'footer treats Admin as a training day');

  // ---- 5e. v224/v226: the key expires, and with a live server the server enforces it -------
  // His finding, 2026-09-09: a lapsed athlete could re-enter the same code for another 90 days.
  // v224 closed it locally (used-on-this-phone). v226 wires the card to the Worker, and once
  // there IS a server the reuse rule is the server's - it holds the key's hard expiry and its
  // one-device claim. So this section models the Worker actually enforcing both, which is what
  // ships. (An always-yes stub would let a lapsed re-entry through - and did, until this fix.)
  let SRV_EXPIRED = {};
  function srvBoot(store){ const d = boot(store); const w = d.window;
    w.fetch = async (u, o) => { let bd = {}; try { bd = JSON.parse(o.body); } catch(e){}
      if (/activate|check/.test(String(u)) && SRV_EXPIRED[bd.fp]) return { json: async () => ({ ok: false, reason: 'expired' }) };
      return { json: async () => ({ ok: true, role: 'athlete' }) }; };
    return d; }
  SRV_EXPIRED = {};
  w = srvBoot({}); await sleep(2400); E = EVf(w);
  const q4 = CODES.batches[0], q1 = CODES.batches[1];
  await enter(w, q4.athlete[0]); await sleep(60);
  chk('a batch key grants 90 days', E('accessRole()')==='athlete', 'role '+E('accessRole()'));
  SRV_EXPIRED[E('accessFp('+JSON.stringify(q4.athlete[0])+')')] = true;   // the server now knows this key is done
  E('S.access.until="2026-01-01"; save(); bootAccess(true);');
  await enter(w, q4.athlete[0]); await sleep(80);
  chk('once lapsed, the server refuses the same key even on the same phone', E('accessRole()')===null, 'role '+E('accessRole()'));
  chk('and the gate says the code has expired', /expired/.test(E('(document.getElementById("accessMsg")||{}).textContent||""')), E('(document.getElementById("accessMsg")||{}).textContent'));
  await enter(w, q4.athlete[1]); await sleep(60);
  chk('a different current key renews', E('accessRole()')==='athlete', 'role '+E('accessRole()'));
  // past the batch date, on any phone
  const w7=boot({}); await sleep(2400); const E7=EVf(w7);
  E7('window.shiftDate=function(){ return "2027-04-15"; };');
  await enter(w7, q4.athlete[2]); await sleep(60);
  chk('after its batch date a never-used key is refused on a fresh phone', E7('accessRole()')===null && E7('ACCESS_LAST')==='expired', 'role '+E7('accessRole()')+' reason '+E7('ACCESS_LAST'));
  chk('with the expired wording', /has expired/.test(E7('(document.getElementById("accessMsg")||{}).textContent||""')), E7('(document.getElementById("accessMsg")||{}).textContent'));
  await enter(w7, q1.athlete[0]); await sleep(60);
  chk('the next batch works, and the grant never outlives its key', E7('accessRole()')==='athlete' && E7('S.access.until')===q1.exp, 'until '+E7('S.access.until')+' vs batch '+q1.exp);
  chk('the original v214 codes carry a life too', E('ACCESS_CODES.slice(0,2).every(function(x){ return /^\\d{4}-\\d{2}-\\d{2}$/.test(x.exp||""); })'), 'the founding codes never expire');
  // the admin issues from the current batch, and the current batch moves with the date
  w=boot({}); await sleep(2400); E=EVf(w);
  await enter(w, CODES.admin.code); await sleep(60);
  chk('the admin issues from the earliest live batch', E('(function(){ var n=adminNext("athlete"); return n && n.b==="2026Q4"; })()'), JSON.stringify(E('adminNext("athlete")')));
  E('window.shiftDate=function(){ return "2027-05-01"; };');
  chk('once a batch has expired the admin issues from the next', E('(function(){ var n=adminNext("athlete"); return n && n.b==="2027Q1"; })()'), JSON.stringify(E('adminNext("athlete")')));
  chk('the share message tells the athlete how long the code itself lives', E('(function(){ var c=adminIssue("athlete","Lee"); return adminShareHref("sms", c, "athlete").indexOf(encodeURIComponent("valid until"))>-1; })()'), 'no key life in the message');

  // ---- 6. the codes are not in the file ---------------------------------------------------
  chk('neither code appears anywhere in the source', raw.indexOf(CODES.athlete.code)<0 && raw.indexOf(CODES.athlete.code.replace(/-/g,''))<0 && raw.indexOf(CODES.coach.code)<0 && raw.indexOf(CODES.coach.code.replace(/-/g,''))<0, 'a code is in the file in plain text');
  chk('the hash is the real thing', E('sha256hex("abc")')==='ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad', E('sha256hex("abc")'));

  chk('no runtime errors across the boots', errs.length===0, errs.slice(0,3).join(' | '));
  console.log(`\nproblems: ${bad}`);
  process.exit(bad? 1:0);
},100);
