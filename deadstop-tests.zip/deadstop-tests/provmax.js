// PROVISIONAL (TESTED) MAXES (2026-09-03, his spec).
// Test a real 1RM, enter it, train on it - but it is on trial. It must hold both ways: a tested
// max that the athlete proves becomes the standing number, and one he cannot train at walks back
// down in increments and STOPS at a load he already proved. A wrong max is a wrong weight on the
// bar, so every branch here is pinned.
const { JSDOM } = require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const dom=new JSDOM(fs.readFileSync(f,'utf8'),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/',
  beforeParse(w){
    w.AudioContext=function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
    w.alert=()=>{};
  }});
const w=dom.window,D=w.document,EV=e=>w.eval(e);
let bad=0; const chk=(l,ok,d)=>{ if(!ok) bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&d?'  <-- '+d:''}`); };
const tap=el=>el&&el.dispatchEvent(new w.MouseEvent('click',{bubbles:true}));
const base="S.maxes.bench=290; S.mxProv={}; S.e1rmH={bench:[]}; S.adLog=[]; S.day='MAX'; mxEdit=true; save(); render();";
// feed sessions of programmed work: clean=1 held it, clean=0 missed reps or ground it out
const feed=(n,clean,from)=>{ let js=''; for(let i=0;i<n;i++){ js+="S.e1rmH.bench.push({d:'2026-1"+(from+i<10?'0-0':'0-')+(from+i)+"',v:300,r:2,c:"+clean+"});"; } EV(js); };

setTimeout(async()=>{
  console.log(`\n--- ${L}: a tested max is trusted, then has to hold up ---`);
  EV('try{TOUR.live=false;}catch(e){} S.tour={done:true}; if(typeof ONB!=="undefined"){ONB().done=true;} S.discAck={v:DISC_V,d:localDate()}; storageOK=true; save();');
  EV(base);

  // --- entry -------------------------------------------------------------------
  chk('the tested-1RM field is there once maxes are unlocked', !!D.getElementById('tmbench'));
  D.getElementById('tmbench').value='325';
  tap(D.querySelector('[data-tmax="bench"]'));
  const pm=EV('S.maxes.bench');
  chk('a tested 1RM programs at the 95% haircut, rounded to the bar', pm===310, 'tested 325 gave a max of '+pm);
  chk('and it is on trial, with the max it replaced as the floor',
      EV('!!(S.mxProv||{}).bench') && EV('(S.mxProv.bench||{}).floor')===290,
      JSON.stringify(EV('JSON.stringify((S.mxProv||{}).bench||null)')));
  chk('the card says on screen that the lift is on trial', /on trial/i.test(D.body.textContent), 'no on-trial notice rendered');

  // --- the ramp hold -----------------------------------------------------------
  // A lift whose load is still climbing cannot be tested, so adaptRun must leave it alone.
  // The trend has to be REAL (adRateMove needs 4+ rising points inside 56 days) and it has to
  // sit BEFORE probation opened, or the same sessions graduate the lift and the hold is never
  // exercised. The first cut of this check fed six flat sessions after `since` and proved
  // nothing - it passed with the hold deleted.
  const today=EV('shiftDate()');
  const back=n=>EV("(function(){var d=new Date('"+today+"T12:00:00'); d.setDate(d.getDate()-"+n+"); return d.toISOString().slice(0,10);})()");
  let rise=''; [42,35,28,21,14,7].forEach((d,i)=>{ rise+="S.e1rmH.bench.push({d:'"+back(d)+"',v:"+(300+i*8)+",r:2,c:1});"; });
  EV(rise);
  EV("S.mxProv.bench.since='"+today+"'; S.adLast=null; S.adLog=[];");
  const beforeRamp=EV('S.maxes.bench');
  const wouldMove=EV('JSON.stringify(adRateMove("bench"))');
  chk('(fixture) the trend really would move this max if it were not on trial', wouldMove!=='null',
      'adRateMove returns null even unheld - this check would pass on a broken card');
  EV("(function(){ try{ adaptRun(true); }catch(e){} })();");
  chk('a lift on trial does not climb, however good the trend looks',
      EV('S.maxes.bench')===beforeRamp && !EV("(S.adLog||[]).some(function(a){return a.kind==='rate'&&a.lift==='bench';})"),
      'the rate mover moved it from '+beforeRamp+' to '+EV('S.maxes.bench')+' while it was on trial');

  // --- graduation --------------------------------------------------------------
  EV(base); D.getElementById('tmbench').value='325'; tap(D.querySelector('[data-tmax="bench"]'));
  EV("S.mxProv.bench.since='2026-09-30';");
  feed(3,1,1);
  EV('pvJudge();');
  chk('three clean sessions graduate it - the tested max becomes the standing number',
      !EV('!!(S.mxProv||{}).bench') && EV('S.maxes.bench')===310,
      'still on trial: '+EV('!!(S.mxProv||{}).bench')+', max '+EV('S.maxes.bench'));

  // --- the walk-down -----------------------------------------------------------
  EV(base); D.getElementById('tmbench').value='325'; tap(D.querySelector('[data-tmax="bench"]'));
  EV("S.mxProv.bench.since='2026-09-30';");
  feed(1,0,1);
  EV('pvJudge();');
  chk('one bad session is not enough - a bad day is sleep, not load', EV('S.maxes.bench')===310,
      'dropped to '+EV('S.maxes.bench')+' after a single session');
  feed(1,0,2);
  EV('pvJudge();');
  chk('two bad sessions step the max down', EV('S.maxes.bench')===300, 'max is '+EV('S.maxes.bench')+', wanted 300');
  chk('the step is logged so it can be undone', EV("(S.adLog||[]).filter(function(a){return a.kind==='prov';}).length")>=1);
  chk('and it is still on trial at the new load, not abandoned', EV('!!(S.mxProv||{}).bench'));

  // --- the floor ---------------------------------------------------------------
  // The floor must be one a single step OVERSHOOTS, or the clamp is never exercised: from 310 a
  // 2.5% step lands on 300, so a floor of 305 can only be held by the clamp. With a floor of 290
  // the walk-down happened to stop there by rounding (295 x 0.975 = 287.6 -> 290) and this check
  // passed with the clamp deleted.
  EV("S.maxes.bench=305; S.mxProv={}; S.e1rmH={bench:[]}; S.adLog=[]; mxEdit=true; render();");
  D.getElementById('tmbench').value='325'; tap(D.querySelector('[data-tmax="bench"]'));
  chk('(fixture) a single step from here would undershoot the floor',
      EV('S.maxes.bench')===310 && EV('(S.mxProv.bench||{}).floor')===305 && EV('pvRound(310*(1-PV_STEP))')<305,
      'max '+EV('S.maxes.bench')+', floor '+EV('(S.mxProv.bench||{}).floor')+', one step lands on '+EV('pvRound(310*(1-PV_STEP))'));
  let low=999;
  for(let r=0;r<14;r++){ if(!EV('!!(S.mxProv||{}).bench')) break;
    EV("S.mxProv.bench.since='2026-09-30'; S.e1rmH.bench=[];"); feed(2,0,1); EV('pvJudge();');
    low=Math.min(low, EV('S.maxes.bench')); }
  chk('the walk-down stops at the max already proven and never goes under it', low===305,
      'the lowest the max reached was '+low+' with a floor of 305');
  chk('and at the floor the trial ends, handing back to the normal stall rule',
      !EV('!!(S.mxProv||{}).bench'), 'still on trial at the floor');

  // --- refusing a bad entry ----------------------------------------------------
  EV(base);
  D.getElementById('tmbench').value='100';
  tap(D.querySelector('[data-tmax="bench"]'));
  chk('a tested number that would CUT every load is refused, not applied silently',
      EV('S.maxes.bench')===290 && !EV('!!(S.mxProv||{}).bench'),
      'a 100 entry moved the max to '+EV('S.maxes.bench'));

  // --- undo --------------------------------------------------------------------
  EV(base); D.getElementById('tmbench').value='325'; tap(D.querySelector('[data-tmax="bench"]'));
  EV("S.mxProv.bench.since='2026-09-30'; S.adLog=[];");
  feed(2,0,1); EV('var a=pvJudge(); S.adLog=(S.adLog||[]).concat(a);');
  const stepped=EV('S.maxes.bench');
  EV('adaptUndo();');
  chk('"Put it back" reverses a trial step-down', EV('S.maxes.bench')===310 && stepped===300,
      'stepped to '+stepped+', undo left it at '+EV('S.maxes.bench'));

  console.log('  problems:', bad); process.exit(bad?1:0);
},1500);
