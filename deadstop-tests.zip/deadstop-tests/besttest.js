// "Best logged" must inform without provoking. It belongs in history, and inline only when
// today is genuinely close to it - never during a deload, which is meant to be light.
const { JSDOM } = require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const dom=new JSDOM(fs.readFileSync(f,'utf8'),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/'});
const w=dom.window,EV=e=>w.eval(e);
w.AudioContext=w.AudioContext||function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
setTimeout(()=>{
  console.log(`\n--- ${L}: best logged ---`);
  let bad=0; const chk=(l,ok,d)=>{ if(!ok) bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&d?'  <-- '+d:''}`); };
  EV('try{TOUR.live=false;}catch(e){} try{S.tour={done:true};}catch(e){}');
  for(const fn of ['coachIdle','ONB_ACTIVE','isStartMode']) EV(`if(typeof ${fn}==="function") ${fn}=function(){return false;};`);
  EV('S.maxes={squat:327,bench:225,dead:405,ohp:145,pull:225}; render();');
  const i=EV(`(function(){var d=dayObj();for(var k=0;k<d.exercises.length;k++){if(d.exercises[k].loadNum!=null) return k;}return -1;})()`);
  const nm=EV(`(function(){var ex=dayObj().exercises[${i}],st=exState(${i},ex); return st.sub||ex.name;})()`);

  // a heavy-single day and a high-rep day: by weight the single wins, by estimate the reps do
  EV(`S.exHist={}; histPush(${JSON.stringify(nm)},{d:'2026-07-01',w:200,sets:[3],ws:[200],e1:220});
      histPush(${JSON.stringify(nm)},{d:'2026-07-15',w:170,sets:[10],ws:[170],e1:227});`);
  chk('heaviest is still the heavy single', EV(`histBest(${JSON.stringify(nm)}).w`)===200);
  chk('best is judged on estimated max', EV(`histBestE1(${JSON.stringify(nm)}).e1`)===227,
      'ranking by raw weight makes a rep block read as regression');

  // inline line: only when close, never when far, never in a deload
  const line=(weight,deload)=>EV(`(function(){
      isDeload=function(){ return ${deload?'true':'false'}; };
      try{
        if(isDeload()) return '';
        var bb=histBest(${JSON.stringify(nm)}); if(!bb||bb.w==null) return '';
        var w=${weight}; if(w>bb.w) return '';
        var r=w/bb.w; if(r<0.94) return '';
        return 'shown';
      }catch(e){ return 'threw'; }})()`);
  chk('silent when today is far off the best', line(150,false)==='', 'would nag on every light day');
  chk('speaks when the best is in reach', line(192,false)==='shown');
  chk('silent once today is past it', line(210,false)==='');
  chk('silent during a deload', line(192,true)==='', 'a deload is meant to be light');
  console.log('  problems:', bad);
  process.exit(bad?1:0);
},1500);
