// Two cards, one origin (field-caught 2026-09-02): the Session Card owns nova-sc-log: with no
// id segment; the Training Card owns tc-log: (personal) and nova-sc-log:<id>: (roster). No
// card may read, count, or ERASE a sister card's sessions - and the disclaimer, terms, and
// mail overlays must survive the day-lock tap guard that froze the gate in the field.
const {JSDOM}=require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const raw=fs.readFileSync(f,'utf8');
const d=new JSDOM(raw,{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/'});
const w=d.window,EV=e=>w.eval(e);
w.AudioContext=function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
let bad=0; const chk=(l,ok,dd)=>{ if(!ok)bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&dd?'  <-- '+dd:''}`);};
setTimeout(()=>{
  console.log(`\n--- ${L}: two cards, one origin ---`);
  EV('try{TOUR.live=false;}catch(e){} S.tour={done:true}; if(typeof ONB!=="undefined"){ONB().done=true;}');
  const isT=EV('typeof TLOGP')!=='undefined';
  // plant a sister-card session and a roster session
  EV(`localStorage.setItem('nsc:nova-sc-log:2026-08-30-A-W4B1', JSON.stringify({date:'2026-08-30',day:'A',week:4,report:'SISTER CARD SESSION'}));
      localStorage.setItem('nsc:nova-sc-log:ath42:2026-08-30-A-W4B1', JSON.stringify({date:'2026-08-30',day:'A',week:4,report:'ROSTER SESSION'}));`);
  if(isT){
    EV('localStorage.setItem("nsc:tc-log:2026-08-29-A-W4B1", JSON.stringify({date:"2026-08-29",day:"A",week:4,report:"OWN"}));');
    EV('return_refresh=refreshLogs();');
    setTimeout(()=>{
      chk('personal namespace is its own prefix', EV('curLOGP()')==='tc-log:', EV('curLOGP()'));
      chk('the sister card\'s sessions are invisible', EV('!logKeys.some(function(k){return k==="nova-sc-log:2026-08-30-A-W4B1";})'), EV('JSON.stringify(logKeys)'));
      chk('own sessions are seen', EV('logKeys.some(function(k){return k.indexOf("tc-log:")===0;})'), EV('JSON.stringify(logKeys)'));
      // wipe must not touch the sister card
      EV('storageOK=true; wipeEverything.__test=1;');
      EV('location.reload=function(){};');
      EV('wipeEverything();');
      setTimeout(()=>{
        chk('wipe leaves the sister card\'s history alone', EV('localStorage.getItem("nsc:nova-sc-log:2026-08-30-A-W4B1")!==null'), 'SISTER SESSION ERASED');
        chk('wipe erases its own personal logs', EV('localStorage.getItem("nsc:tc-log:2026-08-29-A-W4B1")===null'), 'own log survives');
        chk('wipe erases its roster logs', EV('localStorage.getItem("nsc:nova-sc-log:ath42:2026-08-30-A-W4B1")===null'), 'roster log survives');
        lockChecks();
      },800);
    },600);
  } else {
    EV('return_refresh=refreshLogs();');
    setTimeout(()=>{
      chk('the roster session is invisible to the Session Card', EV('!logKeys.some(function(k){return k.indexOf("ath42")>-1;})'), EV('JSON.stringify(logKeys)'));
      chk('its own plain-prefix session is seen', EV('logKeys.some(function(k){return k==="nova-sc-log:2026-08-30-A-W4B1";})'), EV('JSON.stringify(logKeys)'));
      lockChecks();
    },600);
  }
  function lockChecks(){
    // the day-lock guard vs the overlays: acknowledge THROUGH an engaged lock
    EV('delete S.discAck; S.locked=S.locked||{}; S.locked[cyc()+"|"+S.week+"|"+S.day]=true; save(); render(); bootDisc();');
    chk('the gate carries lockfree', EV('document.getElementById("discGate").className.indexOf("lockfree")>=0'), 'guard will eat it');
    EV('document.getElementById("discOk").click();');
    chk('I understand works on a banked day', EV('!document.getElementById("discGate") && S.discAck && S.discAck.v===DISC_V'), 'gate frozen');
    EV('mailShow();');
    chk('the mailbox opens on a banked day', EV('document.getElementById("mailGate").className.indexOf("lockfree")>=0'), 'guard will eat it');
    EV('document.getElementById("mailX").click(); termsShow();');
    chk('terms opens on a banked day', EV('document.getElementById("termsGate").className.indexOf("lockfree")>=0'), 'guard will eat it');
    EV('document.getElementById("termsX").click();');
    console.log('  problems: '+bad); process.exit(bad?1:0);
  }
},1500);
