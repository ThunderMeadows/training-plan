// BOUND IS NOT WORKING (2026-09-04).
//
// Written after four report buttons were found dead in the field by photograph. `deadsweep` walks
// every tappable on every screen - but it only REAL-TAPS the ones with NO handler, because its
// question is "is this wired up". The report senders were wired up. They ran, did nothing the
// athlete could see, and swallowed their own failure. Bound-but-inert is outside deadsweep's
// design, and it is the shape of most of what has been caught by photo this week.
//
// So: tap every control that IS bound, and require an OBSERVABLE effect. The trick is that a
// legitimate effect is often not in the DOM at all - it is a handoff to the phone. Everything the
// card can reach outward with is instrumented, so a mailto link, a share sheet, a clipboard write
// and a print all count as real. What does not count is a handler that runs and leaves no trace
// anywhere - which is precisely what an athlete experiences as a dead button.
//
// This runs the card as a HOME-SCREEN APP: location assignment is swallowed the way iOS swallows
// it in standalone. That is the environment the bug lived in and no harness had it.
const { JSDOM } = require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const SRC=fs.readFileSync(f,'utf8');
let bad=0; const chk=(l,ok,d)=>{ if(!ok) bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&d?'  <-- '+d:''}`); };

// ONE FRESH PAGE PER SCREEN. The first version shared a single DOM across every screen and the
// screens poisoned each other: bisecting proved the logged-day screen left state that made the
// report senders read as inert, while the same loop on the report screens ALONE found zero. I
// fixed one leak, another appeared, and that is the signal the design was wrong rather than the
// details. A screen now gets a page nothing else has touched, so an accusation is about the
// control and not about whatever ran before it. It costs a boot per screen and buys the only
// thing that matters here: when this harness says a button is dead, it is.
function boot(){
  return new Promise(resolve=>{
    const dom=new JSDOM(SRC,{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/',
      beforeParse(w){
        w.AudioContext=function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
        w.alert=()=>{}; w.confirm=()=>true; w.print=function(){ try{ w.__fx.push('print'); }catch(e){} };
      }});
    const w=dom.window, D=w.document, EV=e=>w.eval(e);
    setTimeout(()=>{
      EV('try{TOUR.live=false;}catch(e){} S.tour={done:true}; if(typeof ONB!=="undefined"){ONB().done=true;} S.discAck={v:DISC_V,d:localDate()}; storageOK=true; S.maxes={squat:327,bench:225,dead:405,ohp:145,row:170,pull:225}; S.sound=false; save();');
      // every way out of the phone, instrumented. location.href is deliberately NOT patched: in a
      // home-screen app that assignment does nothing, so leaving it unhandled models the real
      // failure - it records no effect and the control is correctly called inert.
      EV(`window.__fx=[];
        (function(){ HTMLAnchorElement.prototype.click=function(){ window.__fx.push('link:'+(this.getAttribute('href')||'').slice(0,20)); }; })();
        window.open=function(){ window.__fx.push('open'); return null; };
        navigator.share=function(){ window.__fx.push('share'); return Promise.resolve(); };
        navigator.clipboard={ writeText:function(){ window.__fx.push('clipboard'); return Promise.resolve(); } };`);
      resolve({w,D,EV,dom});
    },1500);
  });
}

const SKIP=/data-du=reset|wipe|erase|kill|restore|backup|data-setclose|data-rptclose|data-onbskip|data-nist|unlock|data-blk|data-adundo|data-volreset|data-seasonal|data-thm|data-light|data-font|data-tsize|data-fnt|data-tsz/i;
const key=el=>{ const d=[...el.attributes].filter(a=>/^data-/.test(a.name)).map(a=>a.name+(a.value&&a.value.length<12?'='+a.value:'')).join(' ');
  return (el.id?'#'+el.id+' ':'')+(d||'.'+String(el.className||'').split(/\s+/).filter(Boolean).slice(0,2).join('.'))+' "'+el.textContent.trim().slice(0,26).replace(/\s+/g,' ')+'"'; };
// A CLICK sweep may only judge controls that answer to a click. #sdate, #stime and the cardio
// mode picker are bound with onchange - clicking an input fires nothing, so a click sweep calls
// them dead when they are fine. They are swept separately, by dispatching the event they are
// actually bound to.
const boundClick=el=>!!(el.onclick||el.onpointerdown);
const boundChange=el=>!el.onclick && !el.onpointerdown && !!el.onchange;

(async()=>{
  console.log(`\n--- ${L}: a bound control that does nothing is a dead button ---`);
  const probe=await boot();
  const codes=JSON.parse(probe.EV('JSON.stringify(PLAN.days.map(function(d){return d.code;}))'));
  probe.dom.window.close();

  const screens=[];
  codes.slice(0,2).forEach(c=>screens.push(['day '+c, `S.day='${c}'; render();`, '#app']));
  ['MAX','RATE','CAL','PLAN','LIB'].forEach(t=>screens.push(['tab '+t, `S.day='${t}'; render();`, '#app']));
  screens.push(['MAX unlocked', "S.day='MAX'; mxEdit=true; render();", '#app']);
  screens.push(['logged day', "S.day=PLAN.days[0].code; S.locked=S.locked||{}; S.locked[dayKey()]=true; render();", '#app']);
  screens.push(['settings', "S.day=PLAN.days[0].code; render(); SET_OPEN=true; settingsSync();", '#setHost']);
  screens.push(['report, bug', "S.rptOpen=true; S.rptKind='bug'; S.rptMsg='test'; render();", '.rpt-wrap']);
  screens.push(['report, question', "S.rptOpen=true; S.rptKind='question'; S.rptMsg='test'; render();", '.rpt-wrap']);
  screens.push(['mail', "render(); try{ mailShow(); }catch(e){}", '#mailGate']);
  screens.push(['how-to', "S.day=PLAN.days[0].code; howEx=PLAN.days[0].exercises[0].name; render();", '.hw-wrap:not(.set-wrap)']);

  let inert=[], tested=0, opened=0, instrOK=true;
  const allPressed=[]; const deferred=[], boundary=[];
  for(const [name, setup, rootSel] of screens){
    const {w,D,EV,dom}=await boot();
    if(!EV('String(navigator.clipboard.writeText).indexOf("__fx")>-1')) instrOK=false;
    let root=null; try{ EV(setup); root=D.querySelector(rootSel); }catch(e){}
    if(!root){ console.log('  (did not open: '+name+')'); dom.window.close(); continue; }
    opened++;
    const n=[...root.querySelectorAll('*')].filter(boundClick).filter(el=>!SKIP.test(key(el))).length;
    // The whole of S, captured on a page nothing has touched. Re-running a screen's setup does
    // NOT undo what earlier taps on that screen wrote - after sixty presses the state has drifted
    // far enough that working controls read as dead. That was the last six false accusations:
    // #unitT, the calendar jump, Export, the disclaimer - each verified by hand to work.
    // Restored IN PLACE so every reference the card holds to S stays valid.
    const SNAP=EV('JSON.stringify(S)');
    const rewind=()=>{ try{ EV('(function(o){ Object.keys(S).forEach(function(k){ delete S[k]; }); Object.assign(S,o); })('+SNAP+')');
        EV('try{ SET_BUSY=false; }catch(e){} try{ mxEdit=false; howEx=null; }catch(e){}'); }catch(e){} };
    // If the page redraws on its own between taps, a whole-document compare would call every
    // control alive and this harness would find nothing ever. Measured, not assumed.
    { const a=D.documentElement.innerHTML+'|'+D.body.className;
      await new Promise(r=>setTimeout(r,60));
      if(D.documentElement.innerHTML+'|'+D.body.className !== a)
        console.log('  (note: '+name+' redraws on its own - findings here are weaker)'); }
    // The WHOLE page, not just #app. Every one of the eleven findings the first isolated run
    // produced was a false positive for this reason: print writes body.className, the calendar
    // jump and the units toggle redraw through hosts outside #app, Export and the disclaimer add
    // body-level nodes. A harness that only watches #app accuses half the card of being dead.
    const scope=()=>D.documentElement.innerHTML+'|'+D.body.className;
    for(let i=0;i<n;i++){
      // still reset within the page between taps - one screen's own controls can change what the
      // next tap starts from
      rewind();
      try{ EV(setup); }catch(e){ break; }
      const r2=D.querySelector(rootSel); if(!r2) break;
      const el=[...r2.querySelectorAll('*')].filter(boundClick).filter(x=>!SKIP.test(key(x)))[i];
      if(!el) continue;
      const k=key(el);
      D.querySelectorAll('.toast.show,#toast.show').forEach(t=>t.classList.remove('show'));
      EV('window.__fx=[];');
      const s0=EV('JSON.stringify(S)'), h0=scope(), o0=D.querySelectorAll('body > *').length, lbl0=el.textContent;
      tested++;
      try{ el.dispatchEvent(new w.MouseEvent('click',{bubbles:true})); }
      catch(e){ inert.push(name+': '+k+' THREW '+(e.message||e)); continue; }
      await new Promise(r=>setTimeout(r,40));
      let moved = EV('JSON.stringify(S)')!==s0 || scope()!==h0
        || D.querySelectorAll('body > *').length!==o0
        || !!D.querySelector('.toast.show,#toast.show')
        || el.textContent!==lbl0
        || EV('window.__fx.length')>0;
      // A control can be a legitimate no-op because of WHERE it starts: a week arrow already at
      // the last week, a chip already selected. Give it one more go from a different state -
      // press a sibling in its own row first. Only a control that does nothing from either
      // starting point is called dead.
      if(!moved){
        try{
          const sibs=el.parentElement? [...el.parentElement.children].filter(x=>x!==el && boundClick(x)) : [];
          if(sibs.length){
            sibs[0].dispatchEvent(new w.MouseEvent('click',{bubbles:true}));
            await new Promise(r=>setTimeout(r,30));
            const s1=EV('JSON.stringify(S)'), h1=scope(); EV('window.__fx=[];');
            const el2=D.querySelector(rootSel) && [...D.querySelector(rootSel).querySelectorAll('*')].filter(boundClick).filter(x=>!SKIP.test(key(x)))[i];
            if(el2){ el2.dispatchEvent(new w.MouseEvent('click',{bubbles:true}));
              await new Promise(r=>setTimeout(r,30));
              moved = EV('JSON.stringify(S)')!==s1 || scope()!==h1 || EV('window.__fx.length')>0; }
          }
        }catch(e){}
      }
      allPressed.push({screen:name, k:k, moved:moved});
      if(!moved) inert.push(name+': '+k);
    }
    // the onchange controls, swept with a change event
    try{
      rewind(); EV(setup);
      const r3=D.querySelector(rootSel);
      const ch=r3? [...r3.querySelectorAll('*')].filter(boundChange).filter(x=>!SKIP.test(key(x))) : [];
      for(let j=0;j<ch.length;j++){
        rewind(); try{ EV(setup); }catch(e){ break; }
        const r4=D.querySelector(rootSel); if(!r4) break;
        const el=[...r4.querySelectorAll('*')].filter(boundChange).filter(x=>!SKIP.test(key(x)))[j];
        if(!el) continue;
        EV('window.__fx=[];');
        const s0=EV('JSON.stringify(S)'), h0=scope();
        try{
          if(el.tagName==='SELECT' && el.options && el.options.length>1) el.selectedIndex=(el.selectedIndex+1)%el.options.length;
          else if(el.type==='date') el.value='2026-09-05';
          else if(el.type==='time') el.value='07:30';
          else el.value=(el.value||'')+'x';
          el.dispatchEvent(new w.Event('change',{bubbles:true}));
        }catch(e){ inert.push(name+': '+key(el)+' THREW '+(e.message||e)); continue; }
        tested++;
        await new Promise(r=>setTimeout(r,40));
        if(!(EV('JSON.stringify(S)')!==s0 || scope()!==h0 || EV('window.__fx.length')>0))
          inert.push(name+': '+key(el)+' (on change)');
      }
    }catch(e){}
    dom.window.close();
  }

  // Two allowances, both general rules rather than named buttons.
  //
  // 1. The settings sheet's launchers are DEFERRED, not excused. `setlaunch` presses every one by
  //    real click and asserts WHAT each opens and that it lands above the sheet - strictly better
  //    coverage than this sweep can give, because it knows what each is supposed to do. This
  //    sweep only knows "something changed", and the sheet's SET_BUSY wrapper suppresses the
  //    render it would see. Two harnesses, one job each.
  // 2. A control can be a genuine no-op because of where it STARTS - a reorder arrow on the first
  //    row cannot move up. Excused only if another control sharing its data-attribute (the same
  //    row of arrows, the same group of chips) DID do something. If the whole group is dead, the
  //    group is reported.
  const SETTINGS_LAUNCHERS=/#selfTestBtn|data-discshow|data-termsshow|#reportBtn|#backupBtn|#restoreBtn/;
  const attrOf=line=>{ const m=line.match(/data-([a-z]+)/); return m? m[1] : null; };
  const liveAttrs=new Set();
  screens.forEach(()=>{});
  allPressed.forEach(line=>{ const a=attrOf(line.k); if(a && line.moved) liveAttrs.add(line.screen+'|'+a); });
  inert = inert.filter(line=>{
    if(typeof line==='string' && SETTINGS_LAUNCHERS.test(line)){ deferred.push(line); return false; }
    const scr=String(line).split(':')[0], a=attrOf(String(line));
    if(a && liveAttrs.has(scr+'|'+a)){ boundary.push(String(line)); return false; }
    return true;
  });
  if(deferred.length){ console.log('  deferred to setlaunch, which checks what each one opens:');
    deferred.forEach(x=>console.log('     - '+x)); }
  if(boundary.length){ console.log('  no-op at its limit (a sibling sharing its attribute works):');
    boundary.forEach(x=>console.log('     - '+x)); }
  console.log('  screens opened: '+opened+'/'+screens.length+'   bound controls pressed: '+tested);
  inert.forEach(x=>console.log('     INERT  '+x));
  chk('(fixture) the phone\'s exits are instrumented on every page', instrOK, 'an override did not take');
  chk('(fixture) there were bound controls to press', tested>200, tested+' pressed');
  chk('every bound control does something observable when pressed', inert.length===0, inert.length+' bound but inert');
  console.log('  problems:', bad); process.exit(bad?1:0);
})();
