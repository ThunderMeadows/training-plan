// Every flavour must keep the bear's drop shadow. Amber (no filter) gets it from CSS;
// the tinted ones must compose it into their own filter or it is lost.
const { JSDOM } = require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3];
const dom=new JSDOM(fs.readFileSync(f,'utf8'),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://thundermeadows.github.io/'});
const w=dom.window,D=w.document,EV=e=>w.eval(e);
w.AudioContext=w.AudioContext||function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
setTimeout(()=>{
  console.log(`\n--- ${L}: shadow survives every flavour? ---`);
  const host=D.getElementById('gbHost');
  let bad=0;
  for(const id of ['amber','cherry','lime','raspberry','grape','clear']){
    EV(`S.gbFlav='${id}'; gbApplyFlavour();`);
    const eff=w.getComputedStyle(host).filter||'';
    const tint=EV('gbFlavour().f'), name=EV('gbFlavour().n');
    const hasShadow=/drop-shadow/.test(eff);
    const hasTint = tint==='none' ? true : eff.indexOf(tint.split(' ')[0])>-1;
    if(!hasShadow||!hasTint) bad++;
    console.log(`  ${name.padEnd(15)} shadow=${hasShadow?'yes':'LOST'}  tint=${hasTint?'ok':'LOST'}`);
  }
  console.log('  problems:', bad);
  process.exit(bad?1:0);
},1500);
