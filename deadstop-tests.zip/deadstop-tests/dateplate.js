// FOUND BY SECOND REVIEW 2026-09-10 (findings E, F, G).
//
// F. timeWeek() floored the millisecond gap between two LOCAL noon dates. Across a spring DST
//    change that gap is an hour short: America/New_York, anchor 2026-03-01, training date
//    2026-03-08 is 167 hours, floors to 6 days, returns week 1 instead of week 2. A training
//    week silently repeated - wrong loads, wrong reps - for every DST time zone, twice a year.
// G. The increment picker offers a 2.5 lb bar jump and plateRound() prescribed 47.5, but
//    platesFor() demanded a 5 lb grid and stopped at 2.5 lb plates, so it returned null. The
//    card named a weight it could not show you how to load.
// E. The service worker deleted every cache on the origin that was not its own, wiping any
//    other app hosted there. (Asserted separately against sw.js.)
//
// What this holds: the week is calendar arithmetic in every zone and across both DST edges;
// every load the card can prescribe at the athlete's chosen increment can also be drawn, with
// bar + 2x plates equalling the prescription exactly; and microplates are shown only to
// athletes who chose them.
const {JSDOM}=require('jsdom'); const fs=require('fs'); const path=require('path');
const f=process.argv[2], L=process.argv[3]||f;
const raw=fs.readFileSync(f,'utf8');
const AC=function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
let bad=0; const chk=(l,ok,d)=>{ if(ok!==true)bad++; if(typeof ok==='string'&&ok.slice(0,3)==='ERR') d=ok; console.log(`  ${ok===true?'ok  ':'FAIL'}  ${l}${ok!==true&&d?'  <-- '+d:''}`); };
function boot(){
  const w=new JSDOM(raw,{runScripts:'dangerously',pretendToBeVisual:true,url:'https://thundermeadows.github.io/',beforeParse(win){ win.AudioContext=AC; }}).window;
  return {w, E:e=>{try{return w.eval(e);}catch(err){return 'ERR '+err.message;}}};
}
(async()=>{
  console.log(`\n--- ${L}: dates, plates and cache ownership ---`);
  const c=boot(); await sleep(1900);
  c.E("for(var i=0,fs=['coachIdle','ONB_ACTIVE','isStartMode'];i<fs.length;i++){ try{ if(typeof window[fs[i]]==='function') window[fs[i]]=function(){return false;}; }catch(e){} }");
  c.E("try{TOUR.live=false;}catch(e){} S.tour={done:true}; S.access={role:'coach',until:'2027-12-31'};");

  // ---------- F ----------
  console.log('\n[F] the training week across daylight saving');
  // drive timeWeek through its two real inputs: blockAnchor() and shiftDate()
  const week=(anchor,today)=>c.E(`(function(){
    var A=window.blockAnchor, D=window.shiftDate;
    window.blockAnchor=function(){ return '${anchor}'; };
    window.shiftDate=function(){ return '${today}'; };
    var r; try{ r=timeWeek(); }catch(e){ r='ERR '+e.message; }
    window.blockAnchor=A; window.shiftDate=D; return r; })()`);
  chk('day 0 is week 1', week('2026-03-01','2026-03-01')===1, 'got '+week('2026-03-01','2026-03-01'));
  chk('day 6 is still week 1', week('2026-03-01','2026-03-07')===1, 'got '+week('2026-03-01','2026-03-07'));
  chk('SPRING FORWARD: 2026-03-01 -> 2026-03-08 is week 2', week('2026-03-01','2026-03-08')===2, 'got '+week('2026-03-01','2026-03-08'));
  chk('and 2026-03-01 -> 2026-03-15 is week 3', week('2026-03-01','2026-03-15')===3, 'got '+week('2026-03-01','2026-03-15'));
  chk('FALL BACK: 2026-10-25 -> 2026-11-01 is week 2', week('2026-10-25','2026-11-01')===2, 'got '+week('2026-10-25','2026-11-01'));
  chk('a six-week block reaches week 6 exactly', week('2026-02-22','2026-03-29')===6, 'got '+week('2026-02-22','2026-03-29'));
  chk('across a leap day: 2028-02-22 -> 2028-03-07 is week 3', week('2028-02-22','2028-03-07')===3, 'got '+week('2028-02-22','2028-03-07'));
  chk('across new year: 2026-12-28 -> 2027-01-04 is week 2', week('2026-12-28','2027-01-04')===2, 'got '+week('2026-12-28','2027-01-04'));
  chk('a date before the anchor never goes negative', week('2026-03-08','2026-03-01')===1, 'got '+week('2026-03-08','2026-03-01'));

  // ---------- G ----------
  console.log('\n[G] every prescribable load can be drawn');
  const sweep=c.E(`(function(){
    var out={};
    [[10,'10 lb'],[5,'5 lb'],[2.5,'2.5 lb']].forEach(function(j){
      S.unit='lb'; S.jump=j[0];
      var miss=[], wrong=[], n=0;
      for(var raw=45; raw<=600; raw+=0.5){
        var w=plateRound(raw);
        if(w<45) continue;
        n++;
        var p=platesFor(w);
        if(p===null){ if(miss.length<6) miss.push(w); continue; }
        var tot=45; for(var i=0;i<p.length;i++) tot+=2*p[i];
        if(Math.abs(tot-w)>1e-6 && wrong.length<6) wrong.push(w+' drew '+tot);
        for(var i=1;i<p.length;i++) if(p[i]>p[i-1]+1e-9){ if(wrong.length<6) wrong.push(w+' out of order'); break; }
      }
      out[j[1]]={checked:n, missing:miss, wrong:wrong};
    });
    return out; })()`);
  ['10 lb','5 lb','2.5 lb'].forEach(function(k){
    const r=sweep[k]||{};
    chk('at a '+k+' jump, every prescribed load has a plate diagram', (r.missing||[]).length===0, 'no diagram for '+JSON.stringify(r.missing));
    chk('at a '+k+' jump, bar + 2x plates equals the prescription, largest first', (r.wrong||[]).length===0, JSON.stringify(r.wrong));
  });
  chk('the reported case: 47.5 at a 2.5 lb jump now draws', c.E("(function(){ S.unit='lb'; S.jump=2.5; var p=platesFor(47.5); return p&&p.length===1&&Math.abs(p[0]-1.25)<1e-9; })()"), 'got '+c.E("(function(){ S.unit='lb'; S.jump=2.5; return JSON.stringify(platesFor(47.5)); })()"));
  chk('an athlete on the 5 lb grid is never shown a 1.25 plate', c.E("(function(){ S.unit='lb'; S.jump=5; for(var w=45;w<=400;w+=2.5){ var p=platesFor(w); if(p&&p.some(function(x){return x<2.5;})) return false; } return true; })()"), 'microplate offered on the 5 lb grid');
  chk('and 47.5 is refused on the 5 lb grid rather than drawn wrong', c.E("(function(){ S.unit='lb'; S.jump=5; return platesFor(47.5)===null; })()"), 'drew something');
  chk('every plate the diagram can emit has a colour and size', c.E("(function(){ S.unit='lb'; S.jump=2.5; var seen={}; for(var w=45;w<=600;w+=2.5){ var p=platesFor(w)||[]; p.forEach(function(x){ seen[x]=1; }); } return Object.keys(seen).every(function(k){ return !!PLATE_LB[k]; }); })()"), 'a plate has no PLATE_LB entry');

  // ---------- E ----------
  console.log('\n[E] the service worker deletes only its own caches');
  const sw=fs.readFileSync(path.join(path.dirname(f),'sw.js'),'utf8');
  chk('activate filters by an ownership test, not just "not mine"', /CACHE_OWNED|startsWith\(['"]card-|\^card-/.test(sw), 'no ownership filter in sw.js');
  const names=['card-v222-v200','card-old','other-app-v1','workbox-precache','someone-elses'];
  const sim=(()=>{ const m=/const CACHE_OWNED\s*=\s*(\/.*?\/);/.exec(sw); if(!m) return null;
    const re=new RegExp(m[1].slice(1,-1)); const CACHE='card-v222-v234';
    return names.filter(k=>k!==CACHE && re.test(k)); })();
  chk('it would delete this app\'s old caches', !!sim && sim.indexOf('card-v222-v200')>=0 && sim.indexOf('card-old')>=0, JSON.stringify(sim));
  chk('and leave every other app on the origin alone', !!sim && !sim.some(k=>/other-app|workbox|someone/.test(k)), JSON.stringify(sim));

  console.log('\nproblems: '+bad); process.exit(bad?1:0);
})();
