// End-to-end audit of everything built 2026-09-02: themes, repair, rhythm, repeat pass.
// Drives real flows in a real athlete state - not unit probes. Anything red is a finding.
const { JSDOM } = require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
function boot(seed){
  const dom=new JSDOM(fs.readFileSync(f,'utf8'),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/',
    beforeParse(win){
      win.AudioContext=function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
      if(seed) Object.keys(seed).forEach(k=>win.localStorage.setItem(k, seed[k]));
    }});
  return dom.window;
}
let bad=0; const chk=(l,ok,d)=>{ if(!ok) bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&d?'  <-- '+d:''}`); };
const athlete='try{TOUR.live=false;}catch(e){} S.tour={done:true}; if(typeof ONB!=="undefined"){ONB().done=true;} S.discAck={v:DISC_V,d:localDate()}; storageOK=true; S.maxes={squat:327,bench:225,dead:405,ohp:145,row:170,pull:225}; save();';

(async()=>{
  console.log(`\n--- ${L}: end-to-end audit ---`);
  // ================= A. LEGACY STATE LOADS INTO THIS BUILD =================
  // a c166-era card: Night theme, no light mode, no rhythm, an old stall cut still applied
  const w0=boot(null); await new Promise(r=>setTimeout(r,1500));
  const E0=e=>w0.eval(e);
  const skey=E0('(function(){ try{ return STATE_KEY||SKEY||null; }catch(e){ return null; } })()');
  E0(athlete);
  E0(`S.theme='night'; delete S.lightMode; delete S.splitMode; delete S.adFixStall; S.seenBuild='c160';
      S.maxes.bench=230; S.e1rmH={bench:[{d:'2026-08-10',v:250,r:5},{d:'2026-08-12',v:250,r:5},{d:'2026-08-14',v:250,r:5}]};
      S.adLog=[{kind:'stall',lift:'bench',from:250,to:230,d:'2026-08-14',why:'three sessions without progress'}]; save();`);
  const raw=E0('JSON.stringify(S)');
  const keys=JSON.parse(E0('JSON.stringify(Object.keys(localStorage))'));
  const stateKey=keys.find(k=>{ try{ return JSON.parse(w0.localStorage.getItem(k)).theme==='night'; }catch(e){ return false; } });
  chk('A. found the persisted state key to seed a legacy card', !!stateKey, keys.join(','));
  const w1=boot(stateKey? {[stateKey]:raw} : null); await new Promise(r=>setTimeout(r,2500));
  const E1=e=>w1.eval(e);
  console.log('     legacy card booted as: theme', E1('S.theme'), 'light', E1('S.lightMode'), 'rhythm', E1('S.splitMode||"(guided)"'), 'bench', E1('S.maxes&&S.maxes.bench'));
  chk('A. Night-theme athlete lands on Coach, still dark', E1('S.theme')==='coach' && E1('S.lightMode')==='night');
  chk('A. and the page actually painted dark', E1("document.documentElement.style.getPropertyValue('--bg')").trim().toUpperCase()==='#12151A');
  chk('A. rhythm defaults to Guided for an existing athlete', E1('splitOpen()')===false);
  chk('A. the old stall cut was repaired at boot', E1('S.maxes.bench')===250 && E1('(S.adFixed||[]).length')===1, 'bench='+E1('S.maxes.bench'));
  E1("S.day='PLAN'; render();");
  chk('A. and the notice is on the Plan tab, outside any fold', !!w1.document.getElementById('adFixedAck')
      && !w1.document.getElementById('adFixedAck').closest('.fold'));
  chk('A. second boot never repeats the repair', E1('adRepairStalls()')===0);

  // ================= B. THEMES THROUGH THE REAL CONTROLS =================
  E1("SET_OPEN=true; settingsSync();");
  const D1=w1.document; let thmBad=0;
  for(const light of ['day','night']){
    D1.querySelector('#setHost [data-lightmode="'+light+'"]').dispatchEvent(new w1.MouseEvent('click',{bubbles:true}));
    for(const c of [...D1.querySelectorAll('#setHost [data-thm]')]){
      c.dispatchEvent(new w1.MouseEvent('click',{bubbles:true}));
      const id=c.getAttribute('data-thm');
      const bg=E1("document.documentElement.style.getPropertyValue('--bg')").trim();
      const meta=D1.getElementById('themeColor').getAttribute('content');
      const expectBlank=(id==='coach'&&light==='day');
      if(expectBlank? bg!=='' : bg===''){ thmBad++; console.log('     '+id+'/'+light+' bg='+(bg||'blank')); }
      if(!expectBlank && meta.toUpperCase()!==bg.toUpperCase()){ thmBad++; console.log('     '+id+'/'+light+' status bar '+meta+' != '+bg); }
      if(E1("document.documentElement.getAttribute('data-light')")!==light){ thmBad++; console.log('     data-light wrong on '+id); }
    }
  }
  chk('B. all 10 themes x 2 lights apply through real taps and the status bar follows', thmBad===0, thmBad+' problems');
  chk('B. no theme in the picker is named after a light', ![...D1.querySelectorAll('#setHost [data-thm]')].some(c=>/^(night|daylight|night ops)$/i.test(c.textContent.trim())));
  E1("SET_OPEN=false; settingsSync();");

  // ================= C. OPEN: JUMP, BANK, ONE-A-DAY, REPEAT =================
  const w2=boot(null); await new Promise(r=>setTimeout(r,1500)); const E2=e=>w2.eval(e), D2=w2.document;
  E2(athlete);
  E2("__twR=timeWeek; __sdR=shiftDate; timeWeek=function(){return 1;}; S.week=1; S.splitMode='open'; S.wd=null; S.rePass=null; logKeys=[]; save();");
  const codes=JSON.parse(E2('JSON.stringify(PLAN.days.map(function(d){return d.code;}))'));
  E2(`S.day=${JSON.stringify(codes[2])}; render();`);                       // jump A -> C
  chk('C. jumped straight to '+codes[2]+' and it is live', E2('dayActiveNow()')===true && !D2.getElementById('app').classList.contains('is-preview'));
  chk('C. no preview bar on a live Open session', !D2.querySelector('.prevbar'));
  let banked=false; try{ banked=await E2('saveSessionLog(true)'); }catch(e){ console.log('     bank threw', e.message); }
  chk('C. banked '+codes[2]+' through the real path', banked===true);
  E2(`S.day=${JSON.stringify(codes[4])}; render();`);
  chk('C. after banking, another session today is closed (one a day)', E2('dayActiveNow()')===false && E2('isPreviewing()')===true);
  const bar=(D2.querySelector('.prevbar')||{}).textContent||'';
  chk('C. and the bar says WHY - one a night, unlocks 3 AM - not "next week"', /3:00 AM/.test(bar) && !/Next week/.test(bar), bar.slice(0,80));
  // tomorrow: every unlogged session is live again, the banked one is a document
  E2("shiftDate=function(){ return '2099-01-02'; }; S.when={date:'2099-01-02',time:'10:00'};");
  E2(`S.day=${JSON.stringify(codes[4])}; render();`);
  chk('C. next day, an unlogged session is live again', E2('dayActiveNow()')===true);
  E2(`S.day=${JSON.stringify(codes[2])}; render();`);
  chk('C. next day, the banked session is a document', E2('isVisiting()')===true && E2('dayActiveNow()')===false);
  chk('C. with the repeat-pass door offered', E2('canRePass()')===true && !!D2.querySelector('[data-repass]'));
  D2.querySelector('[data-repass]').dispatchEvent(new w2.MouseEvent('click',{bubbles:true}));
  chk('C. tapping it gives a live fresh card', E2('dayActiveNow()')===true && E2('isVisiting()')===false);
  let banked2=false; try{ banked2=await E2('saveSessionLog(true)'); }catch(e){ console.log('     rebank threw', e.message); }
  chk('C. the repeat pass banks under its own date', banked2===true && E2(`(logKeys||[]).filter(function(k){ return k.indexOf('-'+${JSON.stringify(codes[2])}+'-W1')>-1; }).length`)===2);
  // the day after THAT: the twice-banked cell must be a document again, not live forever
  E2("shiftDate=function(){ return '2099-01-03'; }; S.when={date:'2099-01-03',time:'10:00'};");
  E2(`S.day=${JSON.stringify(codes[2])}; render();`);
  chk('C. a banked repeat pass reads as a document the next day, not a live cell forever',
      E2('isVisiting()')===true && E2('dayActiveNow()')===false, 'rePass flag outlived the pass it opened');
  // ================= D. GUIDED IS UNTOUCHED, SAME STATE =================
  // clock still pinned to week 1 and the date back to a real one: with shiftDate left at 2099,
  // timeWeek() reads the block as long spent and nextSession() correctly returns null
  E2("shiftDate=__sdR; S.when={date:String(shiftDate()),time:'10:00'};");
  E2("S.splitMode='guided'; S.rePass=null; syncToNext(); render();");
  const nx=JSON.parse(E2('JSON.stringify(nextSession())'));
  console.log('     guided: S.day', E2('S.day'), 'S.week', E2('S.week'), 'next', JSON.stringify(nx), 'logs', E2('(logKeys||[]).length'));
  chk('D. Guided points at the next unlogged session in order', !!nx && E2('S.day')===nx.code && E2('S.week')===nx.week);
  E2(`S.day=${JSON.stringify(codes[5])}; render();`);
  chk('D. Guided still previews out-of-order', E2('isPreviewing()')===true && !!D2.querySelector('.prevbar') && /in order/.test(D2.querySelector('.prevbar').textContent));
  E2("timeWeek=__twR;");

  // ================= E. THE ROSTER =================
  if(E2("typeof ROSTER!=='undefined'")){
    const ok=E2(`(function(){ try{
      var before=S.splitMode;
      if(typeof rosterAdd==='function'){ rosterAdd('Audit Athlete'); } else return 'no rosterAdd';
      var ids=Object.keys((S.roster&&S.roster.list)||{}); if(!ids.length) return 'no athlete';
      var id=ids[ids.length-1];
      if(typeof rosterOpen==='function') rosterOpen(id); else return 'no rosterOpen';
      var a=splitOpen();                 // coached athlete defaults Guided
      S.splitMode='open'; save();
      var b=splitOpen();
      if(typeof rosterClose==='function') rosterClose(); else return 'no rosterClose';
      var c=S.splitMode;                 // coach's own card untouched
      return JSON.stringify({a:a,b:b,c:c,before:before});
    }catch(e){ return 'threw '+e.message; } })()`);
    console.log('     roster probe:', ok);
    if(/^\{/.test(ok)){ const r=JSON.parse(ok);
      chk('E. a coached athlete defaults to Guided', r.a===false);
      chk('E. the coach can hand that athlete the wheel', r.b===true);
      chk('E. and the coach\'s own card keeps its own rhythm', r.c===r.before);
    } else console.log('     (roster API differs - '+ok+' - covered by athleteflow/coachparity in the suite)');
  }

  // ================= F. SETUP FLOW ACROSS THE CONDITIONAL STEP =================
  if(E2("typeof ONB_STEPS_FULL!=='undefined'")){
    const w3=boot(null); await new Promise(r=>setTimeout(r,1500)); const E3=e=>w3.eval(e);
    E3("var o=ONB(); o.done=false; o.mode='full'; o.goal='build'; o.wt=200; o.exp='some'; o.sex='m'; o.days=6; o.res={}; o.prefs={}; o.rhythm='open'; o.wd=null; o.step=ONB_STEPS_FOR().indexOf('rhythm'); save(); render();");
    E3("var o=ONB(); o.step=Math.min(ONB_STEPS_FOR().length-1,o.step+1); save(); render();");
    chk('F. Open moves from rhythm into the weekday grid', E3('ONB_STEPS_FOR()[ONB().step]')==='weekdays');
    E3("var o=ONB(); o.step=Math.max(0,o.step-1); save(); render();");
    chk('F. and Back lands on rhythm, not somewhere else', E3('ONB_STEPS_FOR()[ONB().step]')==='rhythm');
    E3("var o=ONB(); o.rhythm='guided'; o.step=Math.min(ONB_STEPS_FOR().length-1,o.step+1); save(); render();");
    chk('F. Guided skips the grid and goes to length', E3('ONB_STEPS_FOR()[ONB().step]')==='length');
    E3("var o=ONB(); o.rhythm='open'; o.wd=['MO','TU','WE','TH','FR','SA']; o.done=false; ONB_build();");
    chk('F. building the program carries rhythm and days onto the card', E3('S.splitMode')==='open' && E3('(S.wd||[]).length')===6 && E3('!!schedMap()'));
  }

  console.log('  findings:', bad);
  process.exit(bad?1:0);
})();
