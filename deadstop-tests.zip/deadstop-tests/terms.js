// Terms & Privacy (2026-09-01): the depth layer under the four-line gate. Reachable from the
// gate and from Settings, read-only, and it must never quietly become a second acknowledgment.
const {JSDOM}=require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const raw=fs.readFileSync(f,'utf8');
const d=new JSDOM(raw,{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/'});
const w=d.window,EV=e=>w.eval(e);
w.AudioContext=function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
let bad=0; const chk=(l,ok,dd)=>{ if(!ok)bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&dd?'  <-- '+dd:''}`); };
setTimeout(()=>{
  console.log(`\n--- ${L}: terms & privacy ---`);
  EV('try{TOUR.live=false;}catch(e){} S.tour={done:true}; delete S.discAck; save();');
  const T=EV('termsHTML()');
  ['Training carries risk','not medical advice','numbers are estimates','stays on your phone',
   'Consumer health data','Other services involved','The card itself','Age','shop is separate',
   'may change or stop','If there is a dispute','does not hold','Reaching us']
    .forEach(sec=>chk('section present: '+sec, T.indexOf(sec)>=0, 'missing'));
  // headings must run 1..13 with no gap - a renumber that skips one is a live bug
  var hs=(T.match(/<h3>(\d+)/g)||[]).map(x=>+x.replace('<h3>',''));
  chk('sections numbered 1..13 with no gaps', hs.length===13 && hs.every((n,i)=>n===i+1), hs.join(','));
  chk('no raw unicode escapes leaked into the copy', T.indexOf('\\u')<0, 'escape visible');
  chk('the arbitration DECISION is flagged, not defaulted', /WHETHER to include binding arbitration/.test(T), 'arbitration silently added or dropped');
  chk('contact placeholder present', /\[CONTACT/.test(T), 'no contact section');
  chk('health-data collection stance stated', /does not collect your health data/.test(T), 'missing');
  chk('counsel markers left for a lawyer', (T.match(/counsel to supply/g)||[]).length>=7, (T.match(/counsel to supply/g)||[]).length+' markers');
  chk('YouTube caveat disclosed', T.indexOf('YouTube')>=0, 'missing');
  chk('storage-clearing caveat disclosed', T.indexOf('delete your training history')>=0, 'missing');
  chk('no Army or DoD reference', !/Army|Department of Defense|FM 7-22|H2F|doctrine/i.test(T), 'military reference present');
  // opened from the GATE, closes back to it
  EV('bootDisc();');
  chk('gate offers the terms link', EV('!!document.querySelector("#discGate [data-termsshow]")'), 'link absent');
  EV('document.querySelector("#discGate [data-termsshow]").click();');
  chk('terms opens above the gate', EV('!!document.getElementById("termsGate")'), 'did not open');
  chk('gate still waiting underneath', EV('!!document.getElementById("discGate")'), 'gate lost');
  const before=EV('JSON.stringify(S)');
  EV('document.getElementById("termsX").click();');
  chk('closes back to the gate', EV('!document.getElementById("termsGate") && !!document.getElementById("discGate")'), 'close wrong');
  chk('reading terms writes nothing to state', EV('JSON.stringify(S)')===before, 'state mutated');
  chk('reading terms is not an acknowledgment', EV('discPending()'), 'ack granted by reading');
  // and from settings, with the gate gone
  EV('document.getElementById("discOk").click();');
  chk('settings offers a terms entry', EV('settingsBodyHTML()').indexOf('data-termsshow')>=0, 'no settings entry');
  EV('termsShow();');
  chk('opens standalone from settings', EV('!!document.getElementById("termsGate")'), 'did not open');
  EV('document.getElementById("termsX").click();');
  chk('closes clean with no gate behind it', EV('!document.getElementById("termsGate") && !document.getElementById("discGate")'), 'residue');
  console.log('  problems: '+bad); process.exit(bad?1:0);
},1500);
