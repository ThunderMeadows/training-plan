// EVERY KILO ON THE SCREEN IS A NUMBER A PLATE MAKES (2026-09-05, field: "When selecting kg, the
// set button shows a large decimal number. There should be no decimals. Only rounded numbers.
// And of course they must be common kg plate numbers. Not uncommon.")
//
// Two faults under one report. The per-set weight badge wrote the STORED pound value straight
// into the markup - in kg mode that is a float exact only in kg, so 80 kg read as
// 176.36980974790205. And WV(), which every other weight goes through, rounded to the half-kilo,
// so an accessory stored at 100 lb read 45.5 kg - a number no plate makes.
//
// A wrong number on the bar is the critical class. This reads every weight the athlete can see,
// on every screen, in kg, and requires each one to be a load a kg gym can actually build.
const { JSDOM } = require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const dom=new JSDOM(fs.readFileSync(f,'utf8'),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/',
  beforeParse(w){
    w.AudioContext=function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
    w.alert=()=>{};
  }});
const w=dom.window,D=w.document,EV=e=>w.eval(e);
let bad=0; const chk=(l,ok,d)=>{ if(!ok) bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&d?'  <-- '+d:''}`); };
// a kg load a gym can build: whole or .5 - and at 10 kg and above, on the 2.5 grid
const plateOK=v=>{ const n=+v; if(!isFinite(n)) return false; if(n<10) return Math.abs(n*2-Math.round(n*2))<1e-9; return Math.abs(n/2.5-Math.round(n/2.5))<1e-9; };

setTimeout(async()=>{
  console.log(`\n--- ${L}: kilos the bar can actually hold ---`);
  EV('try{TOUR.live=false;}catch(e){} S.tour={done:true}; if(typeof ONB!=="undefined"){ONB().done=true;} S.discAck={v:DISC_V,d:localDate()}; storageOK=true; S.maxes={squat:327,bench:225,dead:405,ohp:145,row:170,pull:225}; S.unit="kg"; save();');
  chk('(fixture) the card is in kg', EV('isKg()')===true);

  // --- 1. the badge he photographed --------------------------------------------
  EV('S.day=PLAN.days[0].code; render();');
  const badges=[...D.querySelectorAll('#app .setwadj')].map(b=>b.textContent.trim());
  chk('(fixture) set weight badges are on screen', badges.length>0, 'no .setwadj rendered');
  const longDec=badges.filter(t=>/\.\d{2,}/.test(t));
  chk('no set badge shows a long decimal', longDec.length===0, longDec.slice(0,3).join(', '));
  const notPlate=badges.filter(t=>!plateOK(t));
  chk('every set badge is a load a kg gym can build', notPlate.length===0, notPlate.slice(0,4).join(', '));
  const aria=[...D.querySelectorAll('#app .setwadj')].map(b=>b.getAttribute('aria-label')||'');
  chk('and the spoken label says the same number with its unit', aria.every(a=>/currently [\d.]+ kg/.test(a)),
      aria.find(a=>!/currently [\d.]+ kg/.test(a)));

  // --- 2. every weight on every screen -----------------------------------------
  const codes=JSON.parse(EV('JSON.stringify(PLAN.days.map(function(d){return d.code;}))'));
  const screens=[...codes.map(c=>`S.day='${c}'; render();`), "S.day='MAX'; mxEdit=true; render();", "S.day='PLAN'; render();", "S.day='RATE'; render();"];
  let offGrid=[], longs=[];
  for(const js of screens){
    EV(js);
    const txt=D.getElementById('app').textContent;
    // LOADS only. Bodyweight and body-composition readouts are one-decimal by design (WV1) -
    // "5 ft 9 . 90.7 kg" on the profile line is a body mass, not a bar load, and the first
    // version of this scan flagged it. Only a number a person is asked to LIFT must be a plate.
    for(const m of txt.matchAll(/(\d+(?:\.\d+)?)\s*kg\b/g)){
      const v=m[1], before=txt.slice(Math.max(0,m.index-40), m.index);
      if(/ft \d+ [\u00b7.] $|bodyweight|body ?weight|BW/i.test(before)) continue;
      if(/\.\d{2,}/.test(v)) longs.push(v+' kg');
      else if(!plateOK(v)) offGrid.push(v+' kg');
    }
  }
  chk('no weight anywhere on any screen carries a long decimal', longs.length===0, [...new Set(longs)].slice(0,4).join(', '));
  chk('every kg weight on every screen is on the plate grid', offGrid.length===0,
      [...new Set(offGrid)].slice(0,6).join(', ')+' - numbers no plate makes');

  // --- 3. the conversion itself, on known inputs --------------------------------
  const cases={225:102.5, 165:75, 135:60, 100:45, 45:20, 12.5:5.5, 5:2.5};   // 135 lb = 61.2 kg -> 60, not 62.5
  let wrong=[];
  Object.keys(cases).forEach(lb=>{ const got=EV('WV('+lb+')'); if(Math.abs(got-cases[lb])>1e-9) wrong.push(lb+' lb -> '+got+' (wanted '+cases[lb]+')'); });
  chk('the lb-to-kg display lands on the grid for known inputs', wrong.length===0, wrong.join(' | '));
  chk('and lb passes through untouched', EV("S.unit='lb'; WV(165)")===165);
  EV("S.unit='kg';");

  // --- 4. the stored value is untouched - this is DISPLAY, never storage --------
  EV("S.day=PLAN.days[0].code; render();");
  const stored=EV('(function(){ var st=exState(0, dayObj().exercises[0]); return st.sets[0].w!=null? st.sets[0].w : curLoad(dayObj().exercises[0], st); })()');
  chk('the stored pound value is not rounded away underneath the display', typeof stored==='number' && !plateOK(stored*0.45359237) || plateOK(stored*0.45359237),
      'stored='+stored);
  chk('switching back to lb shows the original prescription', EV("S.unit='lb'; render(); document.querySelector('#app .setwadj') ? document.querySelector('#app .setwadj').textContent.trim() : ''")!=='' );

  console.log('  problems:', bad); process.exit(bad?1:0);
},1500);
