// FIELD 2026-09-02: he set records at banking and the prompt never appeared. Dismissing an
// earlier prompt that day set prHide=today, and new records did not clear it. This drives
// the real order: dismiss something, then bank a session that sets a record.
const {JSDOM}=require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const d=new JSDOM(fs.readFileSync(f,'utf8'),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/'});
const w=d.window,EV=e=>w.eval(e);
w.AudioContext=function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
let bad=0; const chk=(l,ok,dd)=>{ if(!ok)bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&dd?'  <-- '+dd:''}`);};
setTimeout(async ()=>{
  console.log(`\n--- ${L}: a record set at banking shows even after an earlier dismiss ---`);
  EV('try{TOUR.live=false;}catch(e){} S.tour={done:true}; if(typeof ONB!=="undefined"){ONB().done=true;} S.discAck={v:DISC_V,d:localDate()}; storageOK=true; S.maxes={squat:327,bench:225,dead:405,ohp:145,row:170,pull:225}; save(); render();');
  // prior history so today can beat it
  const nm=EV('dayObj().exercises[0].name');
  EV(`(function(){ var y=new Date(shiftDate()+'T12:00:00'); y.setDate(y.getDate()-7);
      var yi=new Date(y.getTime()-y.getTimezoneOffset()*60000).toISOString().slice(0,10);
      histPush(${JSON.stringify(nm)}, {d:yi, w:100, sets:[5,5,5], ws:[100,100,100], e1:117}); save(); })();`);
  // the athlete dismissed a prompt earlier today (the cardio recap, say)
  EV('S.prShow=null; S.prRecap=0; S.prHide=(S.when&&S.when.date)||localDate(); save();');
  chk('a prompt was dismissed earlier today', EV('!!S.prHide'), 'no hide flag');
  chk('and the banner is hidden right now', EV('prBannerHTML()')==='', 'banner showing early');
  // now train heavier than ever and bank
  EV(`(function(){ var dd=dayObj(); var st=exState(0,dd.exercises[0]); st.sets.forEach(function(s2){ s2.st='hit'; s2.reps=5; s2.rir=2; s2.w=140; }); 
      dd.exercises.forEach(function(ex,i){ if(i===0) return; var s3=exState(i,ex); s3.sets.forEach(function(s2){ s2.st='hit'; s2.reps=5; s2.rir=2; }); }); save(); })();`);
  await EV('saveSessionLog(true)');
  chk('a record was written to the ledger', EV('todayPRs().length')>0, EV('JSON.stringify(todayPRs())'));
  chk('and the prompt SHOWS despite the earlier dismiss', (EV('prBannerHTML()')||'').indexOf('Personal record')>=0, 'prompt still hidden');
  // dismissing THIS one still works
  EV('render(); var b=document.querySelector("[data-prclose]"); if(b) b.click();');
  chk('dismissing it hides it again', EV('prBannerHTML()')==='', 'dismiss broken');
  console.log('  problems: '+bad); process.exit(bad?1:0);
},1700);
