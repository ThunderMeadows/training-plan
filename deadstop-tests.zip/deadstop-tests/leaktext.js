// NOTHING LEAKS INTO THE TEXT (2026-09-03, field: the setup step for training rhythm was headed
// "undefined" - since c169, for every new athlete, and no harness noticed).
//
// The heading map had an entry for every setup step except the one added last. {map}[st] came
// back undefined and that is what was drawn. Nothing threw, nothing was missing from the DOM, the
// step worked - the screen just said "undefined" where a question should be. That is a whole
// class: a lookup that misses, a number that went NaN, an object stringified by accident. None
// of them crash. All of them are visible to the athlete and invisible to a test that only
// checks structure.
//
// So this reads what the athlete reads. Every setup step, every main screen, every overlay: the
// visible text must never contain undefined, NaN, null, or [object Object]. And the two tables
// that caused this one - the step list and the heading map - are held to each other directly.
const { JSDOM } = require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const dom=new JSDOM(fs.readFileSync(f,'utf8'),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/',
  beforeParse(w){
    w.AudioContext=function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
    w.alert=()=>{};
  }});
const w=dom.window,D=w.document,EV=e=>w.eval(e);
let bad=0; const chk=(l,ok,d)=>{ if(!ok) bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&d?'  <-- '+d:''}`); };
const LEAKS=/\b(undefined|NaN|null)\b|\[object Object\]/;
const visible=()=>{
  // what a person would read: skip script/style, and skip anything hidden
  const out=[];
  D.querySelectorAll('body *').forEach(el=>{
    if(/^(SCRIPT|STYLE|TEMPLATE)$/.test(el.tagName)) return;
    if(el.closest('[hidden]')) return;
    el.childNodes.forEach(n=>{ if(n.nodeType===3 && n.textContent.trim()) out.push(n.textContent.trim()); });
  });
  return out.join(' \u00b7 ');
};
const leaksIn=(txt)=>{ const m=txt.match(new RegExp('.{0,40}('+LEAKS.source+').{0,40}')); return m? m[0] : null; };

setTimeout(async()=>{
  console.log(`\n--- ${L}: the athlete never reads a JavaScript value by mistake ---`);
  EV('try{TOUR.live=false;}catch(e){} S.tour={done:true}; S.discAck={v:DISC_V,d:localDate()}; storageOK=true; S.maxes={squat:327,bench:225,dead:405,ohp:145,row:170,pull:225}; save();');

  // --- the two tables that caused this one -----------------------------------
  // Guarded: on a build without ONB_HEAD these must FAIL, not throw. A harness that dies on
  // the bug it exists to catch is the worst kind of red.
  const steps=JSON.parse(EV('JSON.stringify(ONB_STEPS_FULL)'));
  const hasHead=EV('typeof ONB_HEAD!=="undefined" && !!ONB_HEAD');
  const heads=hasHead? JSON.parse(EV('JSON.stringify(Object.keys(ONB_HEAD))')) : [];
  const noHead=steps.filter(s=>!heads.includes(s));
  const noStep=heads.filter(h=>!steps.includes(h));
  chk('every setup step has a heading', hasHead && noHead.length===0,
      hasHead? 'no heading for: '+noHead.join(', ') : 'headings are not declared beside the step list at all');
  chk('every heading belongs to a step that still exists', hasHead && noStep.length===0, 'headings for dead steps: '+noStep.join(', '));
  chk('no heading is empty', hasHead && steps.every(s=>EV('(ONB_HEAD['+JSON.stringify(s)+']||"").length')>0));

  // --- every setup step, drawn, under both rhythms ---------------------------
  // ONB_STEPS_FOR() is the list the card actually walks and it is shorter than ONB_STEPS_FULL
  // (Guided never sees weekdays). The first cut indexed the short list with positions from the
  // long one and read a blank heading at index 13 of 13 - a harness fault, not a card fault.
  let stepLeaks=[], drawn=0, expected=0;
  EV('if(typeof ONB!=="undefined"){ ONB().done=false; ONB().retest=false; }');
  for(const rhythm of ['guided','open']){
    EV('ONB().rhythm='+JSON.stringify(rhythm)+'; ONB().res=ONB().res||{};');
    const list=JSON.parse(EV('JSON.stringify(ONB_STEPS_FOR())'));
    expected+=list.length;
    list.forEach((st,i)=>{
      try{
        EV('ONB().step='+i+'; ONB().ramp=null; render();');
        drawn++;
        const h1=D.querySelector('#app h1');
        const head=h1? h1.textContent.trim() : '';
        if(!head || LEAKS.test(head)) stepLeaks.push('['+rhythm+'] step "'+st+'" heading reads "'+head+'"');
        const l=leaksIn(visible()); if(l) stepLeaks.push('['+rhythm+'] step "'+st+'": ...'+l+'...');
      }catch(e){ stepLeaks.push('['+rhythm+'] step "'+st+'" threw: '+(e.message||e)); }
    });
  }
  chk('(fixture) every setup step actually drew, under both rhythms', drawn===expected && expected>=steps.length, drawn+'/'+expected);
  chk('no setup step shows a leaked value anywhere in its text', stepLeaks.length===0, stepLeaks.slice(0,3).join(' | '));
  EV('ONB().done=true; ONB().step=0; save();');

  // --- every main screen and overlay ------------------------------------------
  const codes=JSON.parse(EV('JSON.stringify(PLAN.days.map(function(d){return d.code;}))'));
  const screens=[];
  codes.forEach(c=>screens.push(['day '+c, `S.rptOpen=false; SET_OPEN=false; settingsSync(); S.day='${c}'; render();`]));
  ['MAX','RATE','CAL','PLAN','LIB'].forEach(t=>screens.push(['tab '+t, `S.rptOpen=false; SET_OPEN=false; settingsSync(); S.day='${t}'; render();`]));
  screens.push(['MAX unlocked', "S.day='MAX'; mxEdit=true; render();"]);
  screens.push(['settings', "S.day=PLAN.days[0].code; render(); SET_OPEN=true; settingsSync();"]);
  screens.push(['report', "SET_OPEN=false; settingsSync(); S.rptOpen=true; S.rptKind='bug'; render();"]);
  screens.push(['mail', "S.rptOpen=false; render(); try{ mailShow(); }catch(e){}"]);
  screens.push(['terms', "try{ termsShow(); }catch(e){}"]);
  screens.push(['disclaimer', "try{ bootDisc(true); }catch(e){}"]);
  screens.push(['how-to', "S.day=PLAN.days[0].code; howEx=PLAN.days[0].exercises[0].name; render();"]);
  screens.push(['plan, folds open', "S.day='PLAN'; try{ foldOpenAll(); }catch(e){} render();"]);
  screens.push(['logged day', "S.day=PLAN.days[0].code; S.locked=S.locked||{}; S.locked[dayKey()]=true; render();"]);
  screens.push(['adapt panel live', "S.locked={}; S.adLog=[{kind:'rate',lift:'bench',from:220,to:225,d:'2026-09-01',why:'climbing'},{kind:'prov',lift:'ohp',from:150,to:145,d:'2026-09-02',why:'not holding'}]; S.day='PLAN'; render();"]);
  screens.push(['max on trial', "S.mxProv={bench:{tested:250,from:225,floor:225,since:'2026-09-01',start:240}}; S.day='MAX'; mxEdit=true; render();"]);
  let scrLeaks=[];
  for(const [name,js] of screens){
    try{ EV(js); const l=leaksIn(visible()); if(l) scrLeaks.push(name+': ...'+l+'...'); }
    catch(e){ scrLeaks.push(name+' threw: '+(e.message||e)); }
    D.querySelectorAll('#termsGate,#discGate,#mailGate,.hw-wrap:not(.set-wrap)').forEach(x=>x.remove());
    try{ EV('S.rptOpen=false; SET_OPEN=false; settingsSync(); howEx=null; S.mxProv={}; S.adLog=[];'); }catch(e){}
  }
  chk('no main screen or overlay shows a leaked value in its text', scrLeaks.length===0, scrLeaks.slice(0,3).join(' | '));

  console.log('  problems:', bad); process.exit(bad?1:0);
},1500);
