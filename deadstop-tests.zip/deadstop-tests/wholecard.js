// AUDIT 2026-09-08, "Run an audit and test all features in the card. No stone unturned."
// The two audits before this went at one system each. This one WALKS THE CARD: every tab, every
// day of every week in both views, every overlay, kg mode over all of it, the report, the share
// sheet, the print sheet, the backup payload, the block handoff, thirty days of mail, the views
// that draw the You/Rate/Plan tabs, the live day's controls by real tap, every calendar cell,
// the library, the deload week, bodyweight, the kg set buttons - on a card with three weeks of
// banked training it builds itself - and then a FRESH card through both gates, a session
// trained and banked, a coach drawer round trip, the self-test, and the deploy files. What it
// asserts is the floor under everything: nothing throws, nothing leaks undefined/NaN/null into
// text, and nothing contradicts itself. The first run of the probe this came from found two
// hardenings (printWeek without a week; the sheet host outliving its close) and nothing else.
const {JSDOM}=require('jsdom'); const fs=require('fs'); const path=require('path');
const f=process.argv[2], L=process.argv[3]||f;
const raw=fs.readFileSync(f,'utf8');
const depDir=path.dirname(f);
const codes=(function(){ try{ return JSON.parse(fs.readFileSync(path.join(__dirname,'access-codes.json'),'utf8')); }catch(e){ return null; } })();
const AC=function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const findings=[];
const F=(area,msg)=>{ findings.push(area+': '+msg); };
function boot(store){ const d=new JSDOM(raw,{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/',beforeParse(w){ Object.keys(store||{}).forEach(k=>w.localStorage.setItem(k,store[k])); w.AudioContext=AC; w.print=()=>{};
  w.fetch=async()=>({json:async()=>({ok:true, role:'athlete'})});   // v225: the gate asks the Worker
  w.AbortController=function(){ this.signal=null; this.abort=function(){}; };
 }}); d.__errs=[]; d.window.addEventListener('error',e=>d.__errs.push(String(e.message))); return d; }
const LEAK=/\bundefined\b|\bNaN\b|\[object |\bnull\b(?! )/;
function leaks(w, where){ try{ const t=Array.from(w.document.body.children).filter(el=>el.tagName!=='SCRIPT'&&el.tagName!=='STYLE').map(el=>el.textContent||'').join(' '); const m=t.match(LEAK); if(m){ const i=t.indexOf(m[0]); F(where, 'leak "'+m[0]+'" near: '+t.slice(Math.max(0,i-50),i+40).replace(/\s+/g,' ')); } }catch(e){} }
const tap=(w,sel)=>{ const el=w.document.querySelector(sel); if(!el) return false; el.dispatchEvent(new w.MouseEvent('click',{bubbles:true})); return true; };

(async()=>{
  // ===================== A CARD WITH THREE WEEKS OF TRAINING, BUILT HERE =====================
  let d=boot({}); await sleep(2400); let w=d.window, E=e=>{try{return w.eval(e)}catch(x){return 'ERR '+x.message}};
  E('accessTry('+JSON.stringify(codes.coach.code)+'); try{TOUR.live=false;}catch(e){} S.tour={done:true}; if(typeof ONB!=="undefined"){ONB().done=true;} S.discAck={v:DISC_V,d:localDate()}; storageOK=true; S.profileName="Walker"; save();');
  for(let i=0;i<18;i++){
    const ok=await E(`(async function(){ try{ var n=nextSession(); if(!n) return 'none'; S.day=n.code; S.week=n.week;
      var d0=new Date((PLAN.start||shiftDate())+'T12:00:00'); d0.setDate(d0.getDate()+${i}); var iso=d0.toISOString().slice(0,10); S.when={date:iso,time:'09:00'};
      var dd=dayObj(); dd.exercises.forEach(function(ex,j){ var st=exState(j,ex); st.sets.forEach(function(s2,k){ s2.st= k%3? 'hit':'done'; s2.reps=8; s2.rir=2; }); });
      var r=await saveSessionLog(true); await refreshLogs(); return r; }catch(e){ return 'ERR '+e.message; } })()`);
    if(ok!==true){ F('build card','bank '+i+' returned '+ok); break; }
  }
  const nLogs=E('(logKeys||[]).length'); if(nLogs<12) F('build card','only '+nLogs+' logs banked');
  const bkLogs={}; E('(logKeys||[])').forEach(k=>bkLogs[k]=1);
  const bk={logs:bkLogs, S:{maxes:E('JSON.parse(JSON.stringify(S.maxes))')}};
  const errsAt=(label)=>{ if(d.__errs.length){ F(label,'runtime error(s): '+d.__errs.slice(0,3).join(' | ')); d.__errs.length=0; } };
  errsAt('boot(real)');

  // every tab, both views, every week of the block
  for(const day of ['MAX','RATE','CAL','PLAN','LIB','ADMIN']){ E('S.day='+JSON.stringify(day)+'; render();'); leaks(w,'tab '+day); errsAt('tab '+day); }
  for(const c of ['A','B','C','D','E','F']) for(const wk of [1,2,3,4,5,6]) for(const v of ['deck','rows']){
    E(`S.day=${JSON.stringify(c)}; S.week=${wk}; S.view=${JSON.stringify(v)}; _docMemo=null; render();`); await sleep(5);
    leaks(w,`day ${c} W${wk} ${v}`); errsAt(`day ${c} W${wk} ${v}`);
  }
  // overlays
  const overlays=[['mail','mailShow()'],['settings','(function(){ var b=document.querySelector("[data-setopen]"); if(b) b.click(); else { SET_OPEN=true; settingsSync(); } })()'],['terms','termsShow()'],['disclaimer','bootDisc(true)'],['calc','(function(){ var b=document.getElementById("calcFab"); if(b) b.click(); })()'],['whatsnew','(function(){ S.seenBuild=""; whatsNewBoot(); })()'],['report','(function(){ var b=document.querySelector("[data-report],[data-reportopen],#reportBtn"); if(b) b.click(); })()'],['help','(function(){ var b=document.querySelector("#gbHost, [data-gbhelp]"); if(b) b.click(); })()'],['selftest','(function(){ var b=document.getElementById("selfTestBtn"); if(b) b.click(); })()'],['print','printWeek(S.week); (function(){ var b=document.querySelector("[data-sheetclose]"); if(b) b.click(); })()'],['history','(function(){ return histListHTML? histListHTML().length : 0; })()']];
  for(const [name,fn] of overlays){ E('try{ '+fn+' }catch(e){ window.__ovErr=e.message; }'); const ee=E('window.__ovErr||""'); if(ee) F('overlay '+name,'threw: '+ee); E('window.__ovErr=""'); leaks(w,'overlay '+name); errsAt('overlay '+name); }
  E('document.querySelectorAll("#mailGate,#termsGate,#discGate,#setHost .set-sheet,.calc-wrap,.wn-wrap,.rp-wrap,.hw-wrap").forEach(function(el){ try{ el.remove(); }catch(e){} });');

  // kg mode: every tab and day again
  E('S.units="kg"; save(); render();');
  for(const day of ['MAX','RATE','CAL','PLAN','LIB']){ E('S.day='+JSON.stringify(day)+'; render();'); leaks(w,'kg tab '+day); errsAt('kg tab '+day); }
  for(const c of ['A','B','C','D','E','F']){ E(`S.day=${JSON.stringify(c)}; S.week=3; S.view="rows"; _docMemo=null; render();`); leaks(w,'kg day '+c); const badKg=E(`(function(){ var t=document.getElementById("app").textContent; var m=t.match(/\\b\\d+\\.\\d{2,}\\s*kg/); return m? m[0] : ""; })()`); if(badKg) F('kg day '+c,'uncommon kg number shown: '+badKg); }
  E('S.units="lb"; save();');

  // report / share / print on a banked day and the live day
  E('S.day="E"; S.week=3; _docMemo=null; render();'); await sleep(300); E('_docMemo=null; render();');
  const rep=E('(function(){ try{ return report(); }catch(e){ return "ERR "+e.message; } })()'); if(/^ERR/.test(rep)) F('report(banked)', rep); if(LEAK.test(rep)) F('report(banked)','leak in report text');
  E('try{ if(typeof shareSheet==="function") shareSheet(); }catch(e){ window.__ovErr=e.message; }'); if(E('window.__ovErr||""')) F('share sheet','threw: '+E('window.__ovErr')); E('window.__ovErr=""');
  E('try{ if(typeof printPlan==="function") printPlan(); else if(typeof printWeek==="function") printWeek(); }catch(e){ window.__ovErr=e.message; }'); if(E('window.__ovErr||""')) F('print','threw: '+E('window.__ovErr')); E('window.__ovErr=""');
  errsAt('report/share/print');

  // backup -> restore round trip
  // backup round trip: build the payload the way backupAll does, restore it into a fresh card
  const payload=await E('(async function(){ const logs={}; for(const k of logKeys){ logs[k]=await stGet(k); } return JSON.stringify({v:1, exported:localDate(), S:S, logs:logs}); })()');
  try{ const o=JSON.parse(payload); if(Object.keys(o.logs).length!==Object.keys(bk.logs).length) F('backup','logs '+Object.keys(o.logs).length+' vs '+Object.keys(bk.logs).length);
  }catch(e){ F('backup','payload not JSON or restore failed: '+e.message); }

  // block roll: what happens when week 6 is done and a new block starts
  E('S.week=6; S.day="A"; save();');
  const roll=E('(function(){ try{ var before=JSON.stringify(S.maxes); var r=(typeof blockHandoff==="function")? blockHandoff() : "nofn"; return {r:String(r).slice(0,80), maxesBefore:before, maxesAfter:JSON.stringify(S.maxes), cyc:cyc(), week:S.week, genPlan:!!(S.genPlan&&S.genPlan.days), planWeeks:PLAN.weeks}; }catch(e){ return {err:e.message}; } })()');
  if(roll.err) F('block roll','threw: '+roll.err); else { if(roll.r==='nofn') F('block roll','no roll function found (blockRoll/rollBlock)'); const mb=JSON.parse(roll.maxesBefore), ma=JSON.parse(roll.maxesAfter); Object.keys(ma).forEach(k=>{ if(!isFinite(ma[k])||ma[k]<=0) F('block roll','max '+k+' became '+ma[k]); if(ma[k]>mb[k]*1.25) F('block roll','max '+k+' jumped '+mb[k]+'->'+ma[k]); }); }
  errsAt('block roll');

  // delete a log -> the day reopens; reset a day
  const delRes=E('(function(){ try{ var k=(logKeys||[]).slice().sort().pop(); if(!k) return "no logs"; var m=k.match(/-(\\w)-W(\\d+)B(\\d+)$/); var code=m[1], wk=+m[2]; S.day=code; S.week=wk; var lockedBefore=dayLocked(); return {lockedBefore:lockedBefore, key:k, hasBtn:!!document.querySelector("[data-logdel]")}; }catch(e){ return "ERR "+e.message; } })()');
  if(typeof delRes==='string') F('delete log', delRes);
  errsAt('delete log');

  // mail sweep across thirty simulated days: no letter should repeat, no tough letter carries a joke
  const mailRes=E(`(function(){ try{ var real=shiftDate, out={n:0,dupes:0,jokeOnTough:0,errs:0}; var seen={}; var t=new Date('2026-10-01T12:00:00');
    for(var i=0;i<30;i++){ var iso=new Date(t.getTime()+i*86400000).toISOString().slice(0,10); window.shiftDate=function(){ return iso; }; try{ mailSweep(); }catch(e){ out.errs++; } }
    window.shiftDate=real; (S.mail||[]).forEach(function(m){ out.n++; if(seen[m.id]) out.dupes++; seen[m.id]=1; if(m.face==='tough' && m.j) out.jokeOnTough++; }); return out; }catch(e){ return {err:e.message}; } })()`);
  if(mailRes.err) F('mail sweep','threw: '+mailRes.err); else { if(mailRes.dupes) F('mail sweep','duplicate letter ids: '+mailRes.dupes); if(mailRes.jokeOnTough) F('mail sweep','joke on a tough letter'); if(mailRes.errs) F('mail sweep','sweep threw on '+mailRes.errs+' days'); }

  // PR / history views on his data
  for(const fn of ['prBannerHTML','histListHTML','volumeHTML','fatigueHTML','calHTML','settingsBodyHTML','gbHelpHTML','blockEndHTML','printPlanHTML','shareQRHTML','selfTestHTML','reportHTML','whatsNewHTML']){ const r=E('(function(){ try{ return typeof '+fn+'==="function"? String('+fn+'()).length : -1; }catch(e){ return "ERR "+e.message; } })()'); if(/^ERR/.test(String(r))) F(fn, r); }
  errsAt('views');

  // ---- deeper: the live day's controls, by real tap ----
  E('var n=nextSession(); S.day=n.code; S.week=n.week; S.view="rows"; S.focus=0; render();');
  const ctl=E(`(function(){ var out={}; function T(sel){ var el=document.querySelector(sel); if(!el) return false; el.click(); return true; }
    out.readiness=T('[data-ready],[data-rdy]'); out.cardioOn=T('[data-cardio],[data-cardioon]'); out.fin=T('[data-fin],[data-finisher]'); out.rest=T('[data-rest],[data-reststart]'); out.set=T('[data-set]'); out.hit=T('[data-hit]'); out.addset=T('[data-addset]'); out.swap=T('[data-swap]'); out.notes=T('[data-notes],textarea');
    return out; })()`);
  leaks(w,'live day controls'); errsAt('live day controls');
  // calendar: tap every day cell
  E('S.day="CAL"; render();');
  const calTaps=E('(function(){ var n=0; document.querySelectorAll("[data-calday]").forEach(function(el){ el.click(); n++; }); return n; })()');
  if(!calTaps) F('calendar','no day cells to tap');
  leaks(w,'calendar taps'); errsAt('calendar taps');
  // library: open every group, search, add one, swap one
  E('S.day="LIB"; render();');
  const lib=E(`(function(){ var out={groups:0,rows:0}; document.querySelectorAll("[data-libgroup]").forEach(function(el){ el.click(); out.groups++; }); out.rows=document.querySelectorAll("[data-libadd],[data-libname]").length; var s=document.querySelector("#libSearch,[data-libsearch],input[type=search]"); if(s){ s.value="row"; s.dispatchEvent(new Event("input",{bubbles:true})); out.searched=true; } return out; })()`);
  if(!lib.groups) F('library','no groups opened');
  leaks(w,'library'); errsAt('library');
  // deload week and the block-end review
  E('S.day="A"; S.week=6; S.view="rows"; _docMemo=null; render();'); leaks(w,'deload week'); errsAt('deload week');
  const dl=E('(function(){ var dd=dayObj(); var st=exState(0,dd.exercises[0]); return {isDeload:isDeload(), sets:st.sets.length, load:baseLoad(dd.exercises[0]), wk1:dd.exercises[0].wk&&dd.exercises[0].wk[0]}; })()');
  if(dl.isDeload && dl.load>=dl.wk1) F('deload','deload load '+dl.load+' is not below week 1 load '+dl.wk1);
  const be=E('(function(){ try{ return String(blockEndHTML()).length; }catch(e){ return "ERR "+e.message; } })()'); if(/^ERR/.test(String(be))) F('block end', be);
  // bodyweight log and the PR path
  E('(function(){ try{ if(typeof bwLog==="function") bwLog(182.4); else if(S.weightLog) S.weightLog.push({d:shiftDate(), w:182.4}); save(); render(); }catch(e){ window.__ovErr=e.message; } })()');
  if(E('window.__ovErr||""')) F('bodyweight','threw: '+E('window.__ovErr')); E('window.__ovErr=""');
  leaks(w,'bodyweight'); errsAt('bodyweight');
  // kg mode on the SET BUTTONS specifically - the c204 rule
  E('S.units="kg"; var n=nextSession(); S.day=n.code; S.week=n.week; S.view="rows"; render();');
  const kgBtn=E('(function(){ var t=Array.from(document.querySelectorAll("[data-set],[data-hit],.setbtn,.set-w")).map(function(el){ return el.textContent; }).join(" | "); var m=t.match(/\d+\.\d{2,}/); return m? m[0]+" in: "+t.slice(0,80) : ""; })()');
  if(kgBtn) F('kg set buttons','uncommon number: '+kgBtn);
  E('S.units="lb";');

  // ===================== A FRESH CARD, END TO END =====================
  d=boot({}); await sleep(2400); w=d.window; E=e=>{try{return w.eval(e)}catch(x){return 'ERR '+x.message}};
  const errs2=(label)=>{ if(d.__errs.length){ F(label,'runtime error(s): '+d.__errs.slice(0,3).join(' | ')); d.__errs.length=0; } };
  errs2('boot(fresh)');
  // through the gates the way a new athlete would
  E('(function(){ var i=document.getElementById("accessIn"); i.value='+JSON.stringify(codes.athlete.code)+'; document.getElementById("accessOk").click(); })()');
  await sleep(200);   // v225: the gate awaits the server before it shows Done
  E('(function(){ var dn=document.getElementById("accessDone"); if(dn) dn.click(); })()'); await sleep(50);
  if(E('!!document.getElementById("accessGate")')) F('fresh: access gate','still up after the athlete code');
  tap(w,'#discOk'); await sleep(50);
  if(E('!!document.getElementById("discGate")')) F('fresh: disclaimer','still up after I understand');
  leaks(w,'fresh: after gates'); errs2('fresh: gates');
  // onboarding: is there a way through without the assessment? walk the ONB screens
  const onb=E('(function(){ try{ var seen=[]; for(var i=0;i<12;i++){ var t=document.getElementById("app").textContent.replace(/\\s+/g," ").slice(0,60); seen.push(t); var nx=document.querySelector("[data-onbnext],[data-onbgo],[data-onbstart],.onb-next,[data-onb]"); if(!nx) break; nx.click(); } return seen; }catch(e){ return "ERR "+e.message; } })()');
  if(typeof onb==='string') F('fresh: onboarding', onb);
  leaks(w,'fresh: onboarding'); errs2('fresh: onboarding');
  // skip setup the test way and train a full session, bank it, check the next day opens
  E('try{TOUR.live=false;}catch(e){} S.tour={done:true}; if(typeof ONB!=="undefined"){ONB().done=true;} S.discAck={v:DISC_V,d:localDate()}; storageOK=true; save(); render();');
  const sess=E(`(function(){ try{ var n=nextSession(); S.day=n.code; S.week=n.week; render();
    var dd=dayObj(); dd.exercises.forEach(function(ex,i){ var st=exState(i,ex); st.sets.forEach(function(s2){ s2.st='done'; s2.reps=5; s2.rir=2; }); });
    save(); return {code:n.code, week:n.week, ex:dd.exercises.length}; }catch(e){ return {err:e.message}; } })()`);
  if(sess.err) F('fresh: train', sess.err);
  let banked=null; try{ banked=await E('saveSessionLog(true)'); }catch(e){ F('fresh: bank','threw '+e.message); }
  if(banked!==true) F('fresh: bank','saveSessionLog returned '+banked);
  await E('refreshLogs()'); await sleep(80);
  const nxt=E('(function(){ var n=nextSession(); return n? n.code+"W"+n.week : null; })()');
  if(!nxt || nxt===sess.code+'W'+sess.week) F('fresh: next session','did not advance after banking: '+nxt);
  const hist=E('(function(){ try{ return String(histListHTML()).length; }catch(e){ return "ERR "+e.message; } })()'); if(/^ERR/.test(String(hist))) F('fresh: history', hist);
  leaks(w,'fresh: after banking'); errs2('fresh: bank');
  // coach flow on the fresh card
  E('accessTry('+JSON.stringify(codes.coach.code)+'); ROSTER.mode="coach"; rosterSave(); rosterAdd("Alex");'); await sleep(50);
  const own=E('JSON.stringify({maxes:S.maxes, logs:(logKeys||[]).length})');
  await E('rosterSwitch(ROSTER.athletes[0].id)'); await sleep(250);
  const inside=E('(function(){ try{ return {day:S.day, hasLogs:(logKeys||[]).filter(function(k){ return k.indexOf(curLOGP())===0; }).length, maxes:JSON.stringify(S.maxes||{})}; }catch(e){ return {err:e.message}; } })()');
  if(inside.err) F('coach: drawer', inside.err); else if(inside.hasLogs) F('coach: drawer','the athlete drawer sees the coach\'s logs');
  await E('rosterSwitch(null)'); await sleep(250);
  const back=E('JSON.stringify({maxes:S.maxes, logs:(logKeys||[]).length})');
  if(back!==own) F('coach: return','the coach\'s own state changed by visiting a drawer: '+own+' -> '+back);
  errs2('coach');
  // self-test
  const st=E('(function(){ try{ return typeof selfTestRun==="function"? "ran:"+String(selfTestRun()).slice(0,40) : "nofn"; }catch(e){ return "ERR "+e.message; } })()');
  if(/^ERR/.test(String(st))) F('self-test', st);
  errs2('self-test');

  // ===================== STATIC: the deploy files =====================
  if(fs.existsSync(path.join(depDir,'sw.js'))){
    try{
      const sw=fs.readFileSync(path.join(depDir,'sw.js'),'utf8'); const list=(sw.match(/\[([^\]]*)\]/)||['',''])[1];
      ['index.html','manifest.json','icon-192.png','icon-512.png'].forEach(fn=>{ if(list.indexOf(fn)<0) F('sw.js','precache list missing '+fn); });
      const man=JSON.parse(fs.readFileSync(path.join(depDir,'manifest.json'),'utf8'));
      if(!man.icons||!man.icons.length) F('manifest','no icons');
      (man.icons||[]).forEach(ic=>{ const p2=path.join(depDir, String(ic.src).replace(/^\.\//,'')); if(!fs.existsSync(p2)) F('manifest','icon file missing: '+ic.src); });
    }catch(e){ F('static','could not read deploy files: '+e.message); }
  }

  console.log(`\n--- ${L}: the whole card, walked ---`);
  console.log('    banked '+nLogs+' sessions to walk over');
  findings.forEach(x=>console.log('  FAIL  '+x));
  console.log('  '+(findings.length? 'FAIL':'ok  ')+'  every tab, day, week, view, overlay, mode and flow: nothing threw, nothing leaked, nothing contradicted itself');
  console.log('\nproblems: '+findings.length);
  process.exit(findings.length? 1:0);
})();
