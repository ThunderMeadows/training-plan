// FIELD 2026-09-05: "My overhead press working weight dropped from 115 to 85 on week 3? That is
// not right. I did 4 sets of 8 reps last week with 115 lbs."
//
// It had not stalled. His estimate history read 181 -> 162 -> 154 and the rule cut his max
// 150 -> 140, which put day D week 3 at 0.63333 x 140 = 85. The three points were:
//     135 x 8  @RIR2  =  181   (day A, heavy - eights)
//     110 x 10 @RIR2  =  162   (day D, volume - tens)
//     105 x 10 @RIR2  =  154   (day D, volume - tens)
// Same strength, different rep target. Ten reps estimates lower than eight off the same bar, by
// arithmetic. So every volume day following a heavy day looked like decline. The card already
// carried the warning - "volume days do not set maxes" above E1_MAXREPS - but that gate is
// reps>10 and his volume day prescribes exactly 10.
//
// Three things are pinned here: points carry their rep target, the stall rule compares only
// within one target, and the repair pass is versioned so a card that already ran the old pass
// is still eligible for one with better judgement.
const {JSDOM}=require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const raw=fs.readFileSync(f,'utf8');
const d=new JSDOM(raw,{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/'});
const w=d.window,EV=e=>w.eval(e);
const safe=(e,fb)=>{ try{ return EV(e); }catch(err){ return fb; } };
w.AudioContext=function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
let bad=0; const chk=(l,ok,dd)=>{ if(!ok)bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&dd?'  <-- '+dd:''}`);};
const errs=[]; w.addEventListener('error',e=>errs.push(String(e.message)));

setTimeout(()=>{
  console.log(`\n--- ${L}: a stall is decline in the SAME kind of session ---`);
  EV('try{TOUR.live=false;}catch(e){} S.tour={done:true}; if(typeof ONB!=="undefined"){ONB().done=true;} S.discAck={v:DISC_V,d:localDate()}; storageOK=true; save();');

  // ---- his exact history: alternating rep targets, strength flat ----------
  // The struggle flags are c:0 ON PURPOSE. Without them the c179 rule alone refuses the cut and
  // this check passes on the broken build too - which is exactly what the first draft did. His
  // own cut predates the struggle rule, so the honest fixture is the one where struggle is
  // present AND the session kinds are mixed: the old rule cuts, the new one must not.
  EV(`S.maxes=S.maxes||{}; S.maxes.ohp=150; S.adLog=[]; S.adLast=null; S.adFixStall=0;
      S.e1rmH={ohp:[
        {d:'2026-08-19',v:181,r:2,c:1,n:8},
        {d:'2026-08-26',v:162,r:2,c:0,n:10},
        {d:'2026-08-29',v:154,r:2,c:0,n:10}
      ]}; save();`);
  chk('(fixture) the history alternates rep targets and falls on the raw numbers',
      EV('S.e1rmH.ohp[0].v')===181 && EV('S.e1rmH.ohp[2].v')===154 && EV('S.e1rmH.ohp[0].n')!==EV('S.e1rmH.ohp[2].n'),
      'fixture not as described');
  let st=safe('JSON.stringify(adStalled())','[]');
  chk('an eight-rep day followed by ten-rep days is not a stall', st==='[]',
      'the rule reset a lift on mixed session kinds: '+st);

  // ---- a genuine like-for-like decline, with struggle, still stalls --------
  EV(`S.e1rmH={ohp:[
        {d:'2026-08-19',v:181,r:2,c:1,n:8},
        {d:'2026-08-26',v:170,r:2,c:0,n:8},
        {d:'2026-08-29',v:160,r:2,c:0,n:8}
      ]}; S.adLog=[]; save();`);
  st=safe('JSON.stringify(adStalled())','[]');
  chk('three struggling eight-rep days in a row IS a stall', /"lift":"ohp"/.test(st),
      'a real stall was missed: '+st);

  // ---- clean like-for-like flatness is still not a stall -------------------
  EV(`S.e1rmH={ohp:[
        {d:'2026-08-19',v:181,r:2,c:1,n:8},
        {d:'2026-08-26',v:181,r:2,c:1,n:8},
        {d:'2026-08-29',v:181,r:2,c:1,n:8}
      ]}; S.adLog=[]; save();`);
  chk('a flat estimate done as written is still not a stall', safe('JSON.stringify(adStalled())','[]')==='[]',
      'the c179 rule regressed');

  // ---- untagged legacy points are not judged at all ------------------------
  EV(`S.e1rmH={ohp:[
        {d:'2026-08-19',v:181,r:2,c:0},
        {d:'2026-08-26',v:162,r:2,c:0},
        {d:'2026-08-29',v:154,r:2,c:0}
      ]}; S.adLog=[]; save();`);
  chk('history with no rep target on it is not judged - no evidence, no cut',
      safe('JSON.stringify(adStalled())','[]')==='[]', 'cut a lift on untagged history');

  // ---- new points carry their rep target ----------------------------------
  EV(`S.e1rmH={}; S.week=1; S.day=PLAN.days[0].code; S.when={date:localDate(),time:'10:00'};
      (function(){ var dd=dayObj(); dd.exercises.forEach(function(ex,i){ if(!ex.maxKey) return;
        var s2=exState(i,ex); s2.sets.forEach(function(x){ x.st='hit'; x.rir=2; }); }); save(); })();
      updateE1RM();`);
  const tagged=safe(`(function(){ var ks=Object.keys(S.e1rmH||{}); if(!ks.length) return 'none';
      return ks.every(function(k){ return (S.e1rmH[k]||[]).every(function(x){ return x.n!=null; }); })? 'all':'some'; })()`,'none');
  chk('every estimate written now carries the rep target it came from', tagged==='all',
      'points written without a rep target: '+tagged);

  // ---- the repair pass is versioned ---------------------------------------
  chk('the repair pass is versioned, not a one-shot boolean', safe('typeof AD_FIX_VER','undefined')==='number',
      'AD_FIX_VER missing - a card that ran the old pass can never run a better one');
  EV(`S.maxes.ohp=140; S.adFixStall=1;
      S.adLog=[{kind:'stall',lift:'ohp',from:150,to:140,d:'2026-08-31'}];
      S.e1rmH={ohp:[
        {d:'2026-08-19',v:181,r:2},
        {d:'2026-08-26',v:162,r:2},
        {d:'2026-08-29',v:154,r:2}
      ]}; save();`);
  const fixedN=safe('adRepairStalls()',0);
  chk('a card that already ran the old pass is still eligible', fixedN>0,
      'returned '+fixedN+' - the old flag locked it out');
  chk('and the wrongly cut max is put back', EV('S.maxes.ohp')===150, 'ohp is '+EV('S.maxes.ohp'));
  chk('the entry leaves the change list', !/\"kind\":\"stall\"/.test(EV('JSON.stringify(S.adLog)')),
      'the stall entry is still listed as a change the card made');
  chk('and the athlete is told, in the put-back panel', /ohp/.test(EV('JSON.stringify(S.adFixed||[])')),
      'nothing shown to the athlete');

  // ---- an EARNED cut is not handed back ------------------------------------
  EV(`S.maxes.ohp=140; S.adFixStall=0;
      S.adLog=[{kind:'stall',lift:'ohp',from:150,to:140,d:'2026-08-31'}];
      S.e1rmH={ohp:[
        {d:'2026-08-19',v:181,r:2,c:0,n:8},
        {d:'2026-08-26',v:170,r:2,c:0,n:8},
        {d:'2026-08-29',v:160,r:2,c:1,n:8}
      ]}; S.adFixed=null; save();`);
  EV('adRepairStalls()');
  chk('a cut earned by struggle stays cut', EV('S.maxes.ohp')===140, 'handed back an earned cut');

  chk('nothing threw', errs.length===0, errs.join(' | '));
  console.log('  problems: '+bad); process.exit(bad?1:0);
},1700);
