// Destructive actions must be recoverable or deliberate. Restore is the sharpest one:
// it replaces the whole state from a file picker with no confirmation.
const { JSDOM } = require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const dom=new JSDOM(fs.readFileSync(f,'utf8'),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://thundermeadows.github.io/'});
const w=dom.window,D=w.document,EV=e=>w.eval(e);
w.AudioContext=w.AudioContext||function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
const click=el=>el&&el.dispatchEvent(new w.MouseEvent('click',{bubbles:true,cancelable:true,view:w}));
setTimeout(async ()=>{
  console.log(`\n--- ${L}: destructive actions are recoverable ---`);
  EV('try{TOUR.live=false;}catch(e){} try{S.tour={done:true};}catch(e){}');
  for(const fn of ['coachIdle','ONB_ACTIVE','isStartMode']) EV(`if(typeof ${fn}==="function") ${fn}=function(){return false;};`);
  EV('S.maxes={squat:327,bench:225,dead:405,ohp:145,pull:225}; S.notes="THIS SESSION\'S WORK"; save(); render();');
  let bad=0;
  // a backup from another day, with different contents
  const other=JSON.stringify({S:{week:4, day:'MAX', notes:'AN OLD BACKUP', maxes:{squat:100}, data:{}, sets:[]}});
  const fake={ text: async function(){ return other; } };
  console.log('  before restore, notes    :', EV('S.notes'));
  w.__fake = fake;
  await EV('restoreBackup(window.__fake)');
  await new Promise(r=>setTimeout(r,150));
  console.log('  after restore, notes     :', EV('S.notes'), EV('S.notes')==='AN OLD BACKUP'?'(restore worked)':'<-- restore did not apply');
  if(EV('S.notes')!=='AN OLD BACKUP') bad++;
  // a backup taken before a field existed must not leave the app in a broken shape
  const shape=EV('JSON.stringify({cardio: !!(S.cardio && typeof S.cardio.tacc!=="undefined"), when: !!S.when, outs: !!S.outs})');
  console.log('  restored into a safe shape:', shape);
  if(/false/.test(shape)){ console.log('    <-- a partial backup left the state missing sections'); bad++; }
  const undo=D.querySelector('#toast .toast-undo');
  console.log('  undo offered             :', !!undo, undo?'':'<-- NO WAY BACK from a full restore');
  if(!undo) bad++;
  if(undo){
    click(undo);
    await new Promise(r=>setTimeout(r,100));
    console.log('  after undo, notes        :', EV('S.notes'), EV('S.notes')==="THIS SESSION'S WORK"?'(everything back)':'<-- NOT restored');
    if(EV('S.notes')!=="THIS SESSION'S WORK") bad++;
    console.log('  maxes back too           :', EV('S.maxes && S.maxes.squat'), EV('(S.maxes&&S.maxes.squat)===327')?'':'<-- partial restore');
    if(EV('(S.maxes&&S.maxes.squat)')!==327) bad++;
  }
  // and a rescue copy must exist in storage, so it survives a reload too
  let keys=[]; try{ for(let i=0;i<w.localStorage.length;i++) keys.push(w.localStorage.key(i)); }catch(e){}
  const rescue=keys.filter(k=>/rescue/.test(k));
  console.log('  rescue copy in storage   :', rescue.length?rescue.join(', '):'<-- none written');
  if(!rescue.length) bad++;
  // the rescue copy must be REACHABLE, not just written - a safety net you cannot climb into
  EV('SET_OPEN=true; try{settingsSync();}catch(e){}');
  const link=D.querySelector('#rescueBtn');
  console.log('  rescue offered in settings:', !!link, link?'':'<-- written but unreachable');
  if(!link) bad++;
  if(link){
    // wreck the state, then take the offer
    EV('S.notes="WRECKED"; S.maxes={squat:1}; save(); render();');
    click(link);
    await new Promise(r=>setTimeout(r,250));
    const back = EV('S.notes');
    console.log('  taking the offer restores :', back, back==='AN OLD BACKUP'||back==="THIS SESSION'S WORK"?'(recovered)':'<-- did not recover');
    if(back==='WRECKED') bad++;
    console.log('  and that is undoable too  :', !!D.querySelector('#toast .toast-undo'));
    if(!D.querySelector('#toast .toast-undo')) bad++;
  }
  console.log('  problems:', bad);
  process.exit(bad?1:0);
},1500);
