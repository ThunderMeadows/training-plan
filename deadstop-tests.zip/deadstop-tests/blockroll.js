// Block rollover: the flow that arrives on its own schedule. He is in week 5 of 6 and this has
// never been executed by anyone. It applies new maxes, archives the block and resets the clock -
// a bug here corrupts the numbers every future session is computed from.
const {JSDOM}=require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const d=new JSDOM(fs.readFileSync(f,'utf8'),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/'});
const w=d.window,EV=e=>w.eval(e);
w.AudioContext=function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
let bad=0; const chk=(l,ok,dd)=>{ if(!ok)bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&dd?'  <-- '+dd:''}`);};
setTimeout(()=>{
  console.log(`\n--- ${L}: rolling into the next block ---`);
  EV('try{TOUR.live=false;}catch(e){} S.tour={done:true}; if(typeof ONB!=="undefined"){ONB().done=true;} S.discAck={v:DISC_V,d:localDate()}; storageOK=true; save();');
  // seed whatever lifts THIS card actually reviews - the two cards differ (the Training Card
  // assesses the row, the Session Card carries pull) and a missing max drops the key from JSON
  EV(`(function(){ var seed={squat:327,bench:225,dead:405,ohp:145,row:170,pull:225};
      var keys=(typeof MAXINFO!=='undefined')? MAXINFO.map(function(m){return m.k;}) : Object.keys(S.maxes||{});
      S.maxes={}; keys.forEach(function(k){ S.maxes[k]=seed[k]||200; });
      S.week=PLAN.weeks; S.cycle=1; S.cycleAck=0; save(); render(); })();`);
  const before=JSON.parse(EV('JSON.stringify(S.maxes)'));
  const cyc0=Number(EV('cyc()'));
  chk('the card is on the final week', Number(EV('S.week'))===Number(EV('PLAN.weeks')), EV('S.week'));
  // the review the athlete is offered
  const plan=JSON.parse(EV('JSON.stringify(maxPlan())'));
  chk('a max review is produced', Array.isArray(plan) && plan.length>0, 'no plan');
  chk('it covers the assessed lifts', plan.every(p=>p.k && p.name && 'cur' in p), JSON.stringify(plan[0]||{}));
  chk('every suggestion carries its reasoning', plan.every(p=>typeof p.why==='string' && p.why.length>0), 'a suggestion with no why');
  chk('no suggestion is silently BELOW the current max', plan.every(p=>p.sugg==null || p.sugg>=p.cur || /hold|down|deload|drop/i.test(p.why)), JSON.stringify(plan.filter(p=>p.sugg!=null&&p.sugg<p.cur)));
  // roll it
  let threw=null; try{ EV('startNextBlock(true);'); }catch(e){ threw=String(e&&e.message||e); }
  chk('the rollover runs without throwing', !threw, threw);
  chk('the block number advances by one', Number(EV('cyc()'))===cyc0+1, cyc0+' -> '+EV('cyc()'));
  chk('the clock resets to week 1', Number(EV('S.week'))===1, EV('S.week'));
  chk('and to the first day of the plan', EV('S.day')===EV('PLAN.days[0].code'), EV('S.day'));
  chk('the finished block is archived', Number(EV('(S.cycleLog||[]).length'))>=1, EV('(S.cycleLog||[]).length'));
  chk('the archive records the maxes it ended with', EV('!!(S.cycleLog[S.cycleLog.length-1].maxes && S.cycleLog[S.cycleLog.length-1].maxes.squat)'), 'no maxes archived');
  // maxes must never come back empty or nonsense - every future load is computed from these
  const after=JSON.parse(EV('JSON.stringify(S.maxes)'));
  chk('every lift still has a number', Object.keys(before).every(k=>typeof after[k]==='number' && after[k]>0), JSON.stringify(after));
  chk('no max silently dropped', Object.keys(before).every(k=>after[k]>=before[k]), JSON.stringify({before:before,after:after}));
  chk('the new block is not stuck offering the review again', EV('typeof blockEndDue==="function"? blockEndDue()===false : true'), 'review still due');
  // the fresh block must actually compute loads
  const loads=EV(`(function(){ var dd=dayObj(); return dd.exercises.filter(function(e){return e.maxKey;}).map(function(e){ return e.load; }).join('|'); })()`);
  chk('the new block prescribes real loads', loads.length>0 && !/NaN|undefined|null/.test(loads), loads.slice(0,60));
  chk('the day is unlocked for the new block', EV('dayLocked()')===false, 'still locked');
  console.log('  problems: '+bad); process.exit(bad?1:0);
},1700);
