// THE CALCULATOR BUTTON IS FIXED, AND STAYS THAT WAY (2026-09-04).
//
// It was draggable for six builds and it never worked on a real phone. c193 let every re-render
// yank it back mid-drag. The c198 "fix" moved the move/up listeners to the DOCUMENT so it could
// follow a finger past a 46px target - which meant that when iOS decided the gesture was a scroll
// and never delivered a pointerup, the drag stayed latched and every touch anywhere on the screen
// moved the button. He reported both, from the gym, after both passed a full suite here.
//
// The lesson is the one worth keeping: jsdom cannot reproduce iOS gesture handling, so a harness
// here can only ever agree with the code. Two "verified" fixes shipped broken because of it. The
// feature is gone rather than guessed at a third time.
//
// So this pins the ABSENCE: no drag wiring, and above all NO DOCUMENT-LEVEL POINTER LISTENERS,
// which is what made the whole screen respond to his finger.
const { JSDOM } = require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const SRC=fs.readFileSync(f,'utf8');
const dom=new JSDOM(SRC,{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/',
  beforeParse(w){
    w.AudioContext=function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
    w.alert=()=>{};
    // record anything the card binds to the document, so a drag cannot creep back in
    w.__docBinds=[];
    const od=w.document.addEventListener.bind(w.document);
    w.document.addEventListener=function(t){ w.__docBinds.push(t); return od.apply(w.document, arguments); };
  }});
const w=dom.window,D=w.document,EV=e=>w.eval(e);
let bad=0; const chk=(l,ok,d)=>{ if(!ok) bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&d?'  <-- '+d:''}`); };

setTimeout(async()=>{
  console.log(`\n--- ${L}: the calculator sits still ---`);
  EV('try{TOUR.live=false;}catch(e){} S.tour={done:true}; if(typeof ONB!=="undefined"){ONB().done=true;} S.discAck={v:DISC_V,d:localDate()}; storageOK=true; save(); S.day=PLAN.days[0].code; render();');
  const fab=()=>D.getElementById('calcFab');
  chk('(fixture) the button is on screen', !!fab());

  // --- nothing drags -----------------------------------------------------------
  // MOVE events only. The card legitimately binds pointerup/touchend on the document for
  // audioWake (passive, unrelated to dragging), and the first version of this check flagged that
  // as a leak - a false accusation of working code. What made the whole screen follow his finger
  // was a document-level MOVE handler; that is what may never come back.
  const bound=['pointermove','mousemove','touchmove'];
  const leaked=bound.filter(t=>EV('window.__docBinds').includes(t));
  chk('nothing listens to the whole screen for a finger moving - that is what dragged the page',
      leaked.length===0, 'document is listening for: '+leaked.join(', '));
  chk('the button itself has no drag wiring',
      !fab().onpointerdown && !fab().onpointermove && !fab().ontouchmove,
      'a pointer handler is still on the button');
  chk('and the drag machinery is gone from the source, not just unwired',
      !/calcDragWire|calcSnap|CALC_DRAGGING/.test(SRC), 'drag functions still present');

  // --- it holds position -------------------------------------------------------
  const spot=()=>{ const c=w.getComputedStyle(fab()); return [c.position,c.right,c.bottom,c.top].join('|'); };
  const before=spot();
  chk('it is fixed to the viewport', /^fixed/.test(before), before);
  EV("S.day='PLAN'; render(); S.day='MAX'; render(); S.day=PLAN.days[0].code; render();");
  chk('and three re-renders do not move it', spot()===before, before+' -> '+spot());
  chk('nothing writes an inline position onto it',
      !fab().style.left && !fab().style.top, 'inline: left='+fab().style.left+' top='+fab().style.top);

  // --- it is out of the way ----------------------------------------------------
  const css=(SRC.match(/\.calcfab\{[^}]*\}/)||[''])[0];
  chk('it sits on an edge, not over the middle of the screen', /right:\s*\d/.test(css), css.slice(0,90));
  chk('it is held clear of the bottom bar and the home indicator',
      /bottom:\s*calc\([^)]*safe-area-inset-bottom/.test(css), css.slice(0,140));
  chk('it does not override touch handling any more', !/touch-action\s*:\s*none/.test(css), css.slice(0,140));

  // --- a tap still opens it ----------------------------------------------------
  fab().dispatchEvent(new w.MouseEvent('click',{bubbles:true}));
  await new Promise(r=>setTimeout(r,40));
  chk('a tap opens the calculator', EV('CALC.open')===true && !!D.getElementById('calcPanel'));
  fab().dispatchEvent(new w.MouseEvent('click',{bubbles:true}));
  await new Promise(r=>setTimeout(r,40));
  chk('and a second tap closes it', EV('CALC.open')===false);

  // --- anyone stranded by the old drag is released -----------------------------
  EV("S.calcPos={edge:'left',at:0.06}; save(); calcPaint();");
  chk('a position saved by the old draggable version is cleared, not honoured',
      EV('!S.calcPos'), 'S.calcPos survived: '+EV('JSON.stringify(S.calcPos)'));
  chk('and the button is still where it belongs after that', spot()===before, spot());

  console.log('  problems:', bad); process.exit(bad?1:0);
},1500);
