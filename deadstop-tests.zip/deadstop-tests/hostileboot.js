// AUDIT 2026-09-06. The one failure class the card must never have: a saved state that stops
// it booting. Everything else can be undone from inside the card - a wrong max has "put it
// back", a bad log has delete, a broken plan has the PLAN tab. A white screen at boot has
// nothing, and it is holding the athlete's entire history hostage.
//
// Found on the first run: a generated plan whose day lacked an `exercises` array passed the
// `days.length` check, became PLAN, and the first dayObj() did `.concat` on undefined. Dead at
// boot. planUsable() now stands at every adoption site.
//
// The baseline here is a REAL-SHAPED state - a card that has onboarded, trained a day and
// banked it - so the mutations land on a card that has something to lose, not on an empty one.
const {JSDOM}=require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const raw=fs.readFileSync(f,'utf8');
const AC=function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
let bad=0; const chk=(l,ok,dd)=>{ if(!ok)bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&dd?'  <-- '+dd:''}`);};
const wait=ms=>new Promise(r=>setTimeout(r,ms));

function boot(seed, logs){
  const errs=[];
  const d=new JSDOM(raw,{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/',
    beforeParse(win){
      try{
        if(seed!==undefined) win.localStorage.setItem('nsc:training-card-v1', typeof seed==='string'? seed : JSON.stringify(seed));
        for(const k of Object.keys(logs||{})) win.localStorage.setItem('nsc:'+k, logs[k]);
        win.AudioContext=AC;
        win.addEventListener('error',e=>errs.push('window: '+String(e.message)));
        win.addEventListener('unhandledrejection',e=>errs.push('promise: '+String(e.reason&&e.reason.message||e.reason)));
      }catch(e){}
    }});
  const w=d.window;
  const EV=e=>{ try{ return w.eval(e); }catch(x){ return undefined; } };
  return {w,EV,errs,close:()=>{ try{ d.window.close(); }catch(e){} }};
}

(async ()=>{
  console.log(`\n--- ${L}: the card boots on hostile saved state ---`);

  // ---- build a real-shaped baseline: onboarded, one day trained and banked ----------------
  const b=boot(undefined,{}); await wait(1700);
  b.EV('try{TOUR.live=false;}catch(e){} S.tour={done:true}; if(typeof ONB!=="undefined"){ONB().done=true;} S.discAck={v:DISC_V,d:localDate()}; storageOK=true; save();');
  b.EV(`(function(){ S.week=1; S.day=PLAN.days[0].code; var dd=dayObj(); dd.exercises.forEach(function(ex,i){ var st=exState(i,ex);
      st.sets.forEach(function(s2){ s2.st='hit'; s2.reps=5; s2.rir=2; }); }); save(); })();`);
  await b.EV('saveSessionLog(true)'); await wait(200);
  const base=JSON.parse(b.EV('JSON.stringify(S)')||'{}');
  const logs={}; for(const k of JSON.parse(b.EV('JSON.stringify(logKeys||[])')||'[]')) logs[k]=b.EV(`localStorage.getItem("nsc:"+${JSON.stringify(k)})`);
  b.close();
  chk('(fixture) the baseline is a real card - onboarded, one session banked', !!base.maxes && Object.keys(logs).length===1,
      'maxes='+JSON.stringify(base.maxes)+' logs='+Object.keys(logs).length);

  const mut=(patch)=>JSON.stringify(Object.assign({},base,patch));
  const cases=[
    ['empty string',''],
    ['not JSON','{this is not json'],
    ['null','null'],
    ['a number','42'],
    ['an array','[1,2,3]'],
    ['empty object','{}'],
    ['schema v0 with nothing else','{"v":0}'],
    ['maxes as a string', mut({maxes:'305'})],
    ['maxes with garbage values', mut({maxes:{bench:'abc',ohp:null,squat:-5,dead:1e9,row:0}})],
    ['e1rmH with garbage points', mut({e1rmH:{ohp:[null,{},{d:'x',v:'y'},{d:'2026-01-01',v:null}]}})],
    ['adLog with garbage entries', mut({adLog:[null,{},{kind:'stall'},{kind:'stall',lift:'ohp',from:'a',to:'b'}]})],
    ['set states wiped', mut({data:null})],
    ['week 99, day ZZ', mut({week:99,day:'ZZ'})],
    ['week 0, day empty', mut({week:0,day:''})],
    ['cardio null', mut({cardio:null})],
    ['probation garbage', mut({mxProv:{ohp:null,bench:{floor:'x'}}})],
    ['locked/dbf as arrays', mut({locked:[],dbf:[]})],
    ['profile null', mut({profile:null})],
    ['units unknown', mut({units:'stone'})],
    ['theme and light unknown', mut({theme:'neon',lightMode:'x'})],
    ['when garbage', mut({when:{date:'yesterday'}})],
    ['generated plan half-built (the one that killed boot)', mut({genPlan:{days:[{code:'A'}]}})],
    ['generated plan with a day of garbage exercises', mut({genPlan:{weeks:6,maxes:{},days:[{code:'A',exercises:[null,{},{name:5}]}]}})],
    ['generated plan with zero weeks', mut({genPlan:{weeks:0,days:[{code:'A',exercises:[]}]}})],
    ['huge notes', mut({notes:'x'.repeat(200000)})],
    ['deep future date', mut({when:{date:'2099-12-31',time:'23:59'}})],
    ['ancient past date', mut({when:{date:'1999-01-01',time:'00:00'}})],
    ['mail garbage', mut({mail:[null,{},'x'],mailSent:'not-an-array'})],
    ['onb half-finished', mut({onb:{done:false,goal:null,days:'four'}})],
    ['roster garbage', mut({roster:{athletes:'x',active:42}})],
  ];
  for(const [label,seed] of cases){
    const h=boot(seed, logs); await wait(1600);
    const up=h.EV('typeof S==="object" && !!document.getElementById("app") && document.getElementById("app").children.length>0');
    chk('boots on: '+label, up===true && h.errs.length===0, (up?'':'no app rendered; ')+h.errs.slice(0,2).join(' | '));
    h.close();
  }
  // a corrupt log entry
  {
    const bl=Object.assign({},logs,{'nova-sc-log:2026-09-01-A-W3B1':'{not json','nova-sc-log:bad':'{}','nova-sc-log:2026-09-02-B-W3B1':'null'});
    const h=boot(base, bl); await wait(1800);
    const b0=h.errs.length; h.EV("S.day='CAL'; render(); S.day=PLAN.days[0].code; render();");
    chk('corrupt log entries do not take the calendar or the day down', h.errs.length===b0 && h.EV('!!document.getElementById("app")'), h.errs.slice(b0).join(' | '));
    h.close();
  }
  // the important half: a broken generated plan must not COST the athlete anything
  {
    const h=boot(mut({genPlan:{days:[{code:'A'}]}}), logs); await wait(1800);
    chk('a broken generated plan is left in place, not deleted', h.EV('!!(S.genPlan && S.genPlan.days)'), 'genPlan was wiped');
    chk('and the card runs the starter block instead', h.EV('!!(PLAN && PLAN.days && PLAN.days.length>1 && PLAN.days[0].exercises)'), 'PLAN is not usable');
    chk('and the banked session is still there', h.EV('(logKeys||[]).length')===1, 'logs='+h.EV('(logKeys||[]).length'));
    h.close();
  }

  console.log('  problems: '+bad); process.exit(bad?1:0);
})();
