// Block calendar / countdowns / .ics export / streak guard (2026-09-01). Everything runs off
// facts the card already keeps; nothing invents a schedule the athlete did not set or live.
const {JSDOM}=require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const d=new JSDOM(fs.readFileSync(f,'utf8'),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/'});
const w=d.window,EV=e=>w.eval(e);
w.AudioContext=function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
let bad=0; const chk=(l,ok,dd)=>{ if(!ok)bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&dd?'  <-- '+dd:''}`); };
setTimeout(()=>{
  console.log(`\n--- ${L}: block calendar suite ---`);
  EV('try{TOUR.live=false;}catch(e){} S.tour={done:true}; if(typeof ONB!=="undefined"){ONB().done=true;} S.maxes=S.maxes||{}; render();');
  // ground truth the tests control: three trained days, Mon/Wed/Fri pattern
  EV(`streakDayset=function(){ var ds={}, n=new Date(shiftDate()+'T12:00:00');
    [2,4,7].forEach(function(back){ var d2=new Date(n.getTime()); d2.setDate(d2.getDate()-back);
      ds[new Date(d2.getTime()-d2.getTimezoneOffset()*60000).toISOString().slice(0,10)]=true; });
    return ds; };
    S.trainDays=[1,3,5]; save();`);
  // HIS RULING 2026-09-02: the engine counts sessions, not days. No calendar end date exists.
  chk('no calendar block end is projected', EV('calEndIso()')===null && EV('calDaysLeft()')===null, 'projection survives');
  EV('S.week=3; S.day=PLAN.days[0].code; S.locked={}; save();');
  chk('sessions left = whole weeks remaining plus this week', Number(EV('sessLeft()'))===Number(EV('(PLAN.weeks-3)*PLAN.days.length + PLAN.days.length')), EV('sessLeft()'));
  EV('S.locked[cyc()+"|"+S.week+"|"+S.day]=true; save();');
  chk('banking today takes one off', Number(EV('sessLeft()'))===Number(EV('(PLAN.weeks-3)*PLAN.days.length + PLAN.days.length - 1')), EV('sessLeft()'));
  EV('S.locked={}; save();');
  chk('countdown strip says sessions left, never days', /sessions? left in the block/.test(EV('calCountHTML()')) && !/Block ends in/.test(EV('calCountHTML()')), EV('calCountHTML()').slice(0,100));
  // ONE calendar in the card: the pre-existing CAL tab. c138 built a second grid under it
  // without looking; c139 removed it. These checks now target the real renderer.
  chk('the duplicate grid renderer is gone', EV('typeof calGridHTML')==='undefined', 'calGridHTML survives');
  // calHTML reads its own calIndex, not streakDayset - seed the one it reads, then navigate
  // the grid to the month holding a seeded day
  EV(`calIndex=function(){ var ix={}; Object.keys(streakDayset()).forEach(function(k){ ix[k]={days:['A'],bw:null}; }); return ix; };`);
  EV(`(function(){ var k=Object.keys(streakDayset()).sort().pop(); S.calMonth=k.slice(0,7); })();`);
  chk('the CAL tab grid marks trained days', (EV('calHTML()').match(/background:var\(--green\)/g)||[]).length>=1, 'none marked in seeded month');
  EV('S.calMonth=shiftDate().slice(0,7);');
  chk('scheduled days ahead are outlined amber', EV('calHTML()').indexOf('1px solid var(--amber)')>=0, 'no scheduled marks');
  chk('no block-end star is projected onto the grid', EV('calHTML()').indexOf('block end')<0, 'projection in legend');
  chk('the dead pain outline is gone from calHTML', EV('String(calHTML)').indexOf('e.pain')<0, 'pain outline survives');
  // scan the rendered UI (#app), not body.innerHTML - the card's own source lives in the
  // body, so a code COMMENT about the removed feature was tripping the check
  chk('the legend stopped describing the pain flag', !/pain flag/i.test(EV('S.day="CAL", render(), document.getElementById("app").textContent')), 'stale legend');
  chk('the CAL tab carries training-day chips and the export', EV('document.body.innerHTML').indexOf('data-tday')>=0 && EV('document.body.innerHTML').indexOf('data-icsdl')>=0, 'controls missing');
  EV('S.day=dayObj().code||S.day;');
  // streak guard: fires ONLY at exactly six days of silence
  EV(`streakDayset=function(){ var ds={}, n=new Date(shiftDate()+'T12:00:00');
    var d2=new Date(n.getTime()); d2.setDate(d2.getDate()-6);
    ds[new Date(d2.getTime()-d2.getTimezoneOffset()*60000).toISOString().slice(0,10)]=true; return ds; };
    streakWeeks=function(){ return 3; };`);
  chk('streak banner fires on the last possible day', EV('calStreakRisk()')===3, EV('calStreakRisk()'));
  chk('and names the stake in the render', EV('calCountHTML()').indexOf('3-week streak ends tonight')>=0, 'copy missing');
  EV(`streakDayset=function(){ var ds={}, n=new Date(shiftDate()+'T12:00:00');
    var d2=new Date(n.getTime()); d2.setDate(d2.getDate()-3);
    ds[new Date(d2.getTime()-d2.getTimezoneOffset()*60000).toISOString().slice(0,10)]=true; return ds; };`);
  chk('quiet when the streak is safe', EV('calStreakRisk()')===null, EV('calStreakRisk()'));
  // ics export
  const ics=EV('icsForBlock()');
  chk('ics builds', !!ics, 'null');
  if(ics){
    chk('its own Deadstop calendar', ics.indexOf('X-WR-CALNAME:Deadstop')>=0, 'no calname');
    const evs=(ics.match(/BEGIN:VEVENT/g)||[]).length;
    chk('exactly the remaining SESSIONS are exported, on training days', evs===Number(EV('sessLeft()')), evs+' events vs '+EV('sessLeft()')+' left');
    chk('every event carries the phone-fired alarm', (ics.match(/BEGIN:VALARM/g)||[]).length===evs, 'alarm count mismatch');
    chk('durations are real minutes', /DURATION:PT\d+M/.test(ics) && !/DURATION:PT0M/.test(ics), 'bad duration');
    chk('floating local times, no Z suffix on starts', !/DTSTART:[0-9T]+Z/.test(ics), 'UTC start leaked');
    chk('every event lands on a chosen training day', (function(){ const td=JSON.parse(EV('JSON.stringify(calTrainDays())'));
      return (ics.match(/DTSTART:(\d{8})/g)||[]).every(m=>{ const d=m.slice(8); const dt=new Date(d.slice(0,4)+'-'+d.slice(4,6)+'-'+d.slice(6,8)+'T12:00:00'); return td.indexOf(dt.getDay())>-1; }); })(), 'event off a training day');
  }
  // no training days set and none in the log: export refuses instead of inventing a schedule
  EV('delete S.trainDays; streakDayset=function(){ return {}; }; save();');
  chk('no schedule is ever invented', EV('icsForBlock()')===null && EV('JSON.stringify(calTrainDays())')==='[]', 'schedule invented');
  EV('(function(){ var c=(PLAN.days&&PLAN.days[0]&&PLAN.days[0].code)||"A"; S.day=c; save(); })();');
  chk('the day screen carries the slim strip, not a second grid', EV('render(), !!document.getElementById("calStrip") && !document.getElementById("calBlock")'), 'wrong surface');
  chk('the strip links to the real tab', EV('document.body.innerHTML').indexOf('data-gocal')>=0, 'no link');
  // --- the athlete's own entries: notes, appointments, fitness tests, countdowns ---
  const fut=EV(`(function(){ var d=new Date(shiftDate()+'T12:00:00'); d.setDate(d.getDate()+12);
    return new Date(d.getTime()-d.getTimezoneOffset()*60000).toISOString().slice(0,10); })()`);
  chk('an entry needs a name', EV('calNoteAdd("'+fut+'", {t:"  ", k:"test", cd:true})')===false, 'blank accepted');
  chk('a fitness test can be added', EV('calNoteAdd("'+fut+'", {t:"ACFT", k:"test", tm:"06:30", cd:true})')===true, 'rejected');
  chk('a plain note can be added without a countdown', EV('calNoteAdd("'+fut+'", {t:"bring straps", k:"note", cd:false})')===true, 'rejected');
  const cds=JSON.parse(EV('JSON.stringify(calCountdownList(5))'));
  chk('the countdown counts to it', cds.length===1 && cds[0].t==='ACFT' && cds[0].days===12, JSON.stringify(cds));
  chk('the strip says so in words', EV('calCountHTML()').indexOf('ACFT in 12 days')>=0, EV('calCountHTML()').slice(0,120));
  chk('non-countdown entries stay off the strip', EV('calCountHTML()').indexOf('straps')<0, 'note leaked into countdowns');
  EV('S.calMonth="'+fut.slice(0,7)+'";');
  chk('the day wears typed dots', (EV('calHTML()').match(/width:5px;height:5px/g)||[]).length>=2, 'dots missing');
  EV('S.calSel="'+fut+'"; S.day="CAL"; render();');
  const app=EV('document.getElementById("app").textContent');
  chk('the detail panel lists both entries', app.indexOf('ACFT')>=0 && app.indexOf('bring straps')>=0, 'entries not listed');
  chk('countdown badge marks the right one', EV('document.getElementById("app").innerHTML').indexOf('COUNTDOWN')>=0, 'badge missing');
  chk('the pain remnant is gone from the detail panel', app.indexOf('Pain flagged')<0, 'remnant survives');
  EV('calNoteDel("'+fut+'", 0);');
  chk('delete removes exactly one', EV('(calNotes()["'+fut+'"]||[]).length')===1 && EV('calNotes()["'+fut+'"][0].t')==='bring straps', EV('JSON.stringify(calNotes()["'+fut+'"])'));
  EV('calNoteDel("'+fut+'", 0);');
  chk('an emptied day leaves no residue', EV('calNotes()["'+fut+'"]===undefined'), 'empty array lingers');
  EV('S.calSel=null; S.calMonth=shiftDate().slice(0,7); save();');
  console.log('  problems: '+bad); process.exit(bad?1:0);
},1500);
