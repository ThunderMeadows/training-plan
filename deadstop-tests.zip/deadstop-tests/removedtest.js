// His rule, 2026-09-08: "Make sure that if your removing a prescribed exercise and replacing it
// that it hides or doesnt show on the days training because it shows as skipped but its
// distracting and doesnt actually have to be there if the athlete is deciding to change their
// plan."
//
// A movement the athlete took out is not skipped work, it is a decision. It leaves the day: no
// SKIPPED row on the deck, no OUT row in the walk, and the focus walk does not step on it. It
// is not deleted - it is listed under REMOVED TODAY at the bottom, one tap from coming back
// (v213's lesson: a removal that cannot be undone is a one-way door), and the session report
// and the banked record are unchanged.
const {JSDOM}=require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const raw=fs.readFileSync(f,'utf8');
const AC=function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
let bad=0; const chk=(l,ok,dd)=>{ if(!ok)bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&dd?'  <-- '+dd:''}`);};
const errs=[]; const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const d=new JSDOM(raw,{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/',beforeParse(w){ w.AudioContext=AC; }});
const w=d.window, EV=e=>w.eval(e);
const safe=(e,fb)=>{ try{ return EV(e); }catch(err){ return (fb===undefined)?('ERR '+err.message):fb; } };
w.addEventListener('error',e=>errs.push(String(e.message)));
const txt=()=>String(safe('document.getElementById("app").textContent','')).replace(/\s+/g,' ');
const tap=sel=>safe(`(function(){ var el=document.querySelector(${JSON.stringify(sel)}); if(!el) return 'NO '+${JSON.stringify(sel)}; el.dispatchEvent(new window.MouseEvent('click',{bubbles:true})); return 'ok'; })()`);

setTimeout(async ()=>{
  console.log(`\n--- ${L}: a removed movement leaves the day ---`);
  EV('try{TOUR.live=false;}catch(e){} S.tour={done:true}; if(typeof ONB!=="undefined"){ONB().done=true;} S.discAck={v:DISC_V,d:localDate()}; storageOK=true; save();');
  const live=safe('(function(){ var n=nextSession(); S.day=n.code; S.week=n.week; S.outs={}; S.customs={}; S.order={}; S.data={}; save(); return {code:S.day, names:dayObj().exercises.map(function(e){return e.name;})}; })()',{});
  chk('(fixture) a live day with movements', live.names && live.names.length>=4, JSON.stringify(live));
  const victim=live.names[1], keeper=live.names[2];

  // remove it through the real control on the deck
  safe(`(function(){ S.view='deck'; render(); var d2=dayObj(), i=d2.exercises.findIndex(function(e){ return e.name===${JSON.stringify(victim)}; });
    var sel='[data-exout="'+i+'"]';
    document.querySelector(sel).dispatchEvent(new window.MouseEvent('click',{bubbles:true}));
    document.querySelector(sel).dispatchEvent(new window.MouseEvent('click',{bubbles:true}));
    render(); return 1; })()`);
  chk('(fixture) the movement was removed', safe(`isOut(${JSON.stringify(victim)})`,false)===true, 'removal did not take');

  // ---- the deck ----
  // the name DOES appear once more on the page - in the Removed today list at the bottom, which
  // is the point. Look only at the part of the day above that block.
  const above=()=>{ const t=txt(); const i=t.indexOf('REMOVED TODAY'); return i<0? t : t.slice(0,i); };
  chk('it is gone from the day \u2014 no SKIPPED row', !/SKIPPED/.test(txt()) && above().indexOf(victim)<0, 'still drawn on the deck');
  chk('the movements that remain are all still there', above().indexOf(keeper)>-1, 'a live movement vanished with it');
  chk('and it is listed under Removed today, with a way back', /REMOVED TODAY/.test(txt()) && safe(`!!document.querySelector('[data-restore="'+${JSON.stringify(victim)}+'"]')`,false), 'no restore path - a one-way door');

  // ---- the walk ----
  chk('the focus walk does not count it', safe('focusMax()')===live.names.length-1, 'focusMax '+safe('focusMax()')+' of '+live.names.length);
  const walked=safe(`(function(){ var out=[]; S.view='rows'; for(var i=0;i<focusMax();i++){ S.focus=i; render(); var nm=dayLive()[focusIdx()]; out.push(nm? nm.name : null); } return out; })()`,[]);
  chk('stepping through the session never lands on it', walked.indexOf(victim)<0 && walked.length===live.names.length-1 && walked.every(x=>x), JSON.stringify(walked));
  chk('and no row ever says OUT', !/\bOUT\b/.test(txt()), 'an OUT row still draws');

  // ---- the record is untouched ----
  chk('the session report leaves an untouched removed movement out entirely',
      safe(`(function(){ var r=report(); return r.indexOf(${JSON.stringify(victim)})<0; })()`,false), 'the report still lists it');
  chk('a removed movement contributes no sets to the day\u2019s load',
      safe(`(function(){ var v=dayLoad(); return v.ex===${live.names.length-1}; })()`,false), 'dayLoad counts '+safe('JSON.stringify(dayLoad())'));

  // ---- it comes back ----
  safe("S.view='deck'; render();");
  chk('tapping it under Removed today puts it back', tap(`[data-restore="${victim}"]`)==='ok' && safe(`!isOut(${JSON.stringify(victim)})`,false), 'restore failed');
  safe("render();");
  chk('and it is in the day again, in its own place', txt().indexOf(victim)>-1 && safe('dayObj().exercises.map(function(e){return e.name;})[1]')===victim, 'came back in the wrong place');
  chk('with the Removed today block gone', !/REMOVED TODAY/.test(txt()), 'empty block still drawn');

  // ---- a swap is not a removal: the substitute still shows under its own name ----
  chk('a substituted movement still appears (a swap is not a removal)',
      safe(`(function(){ var st=exState(1, dayObj().exercises[1]); st.sub='Machine Row'; save(); S.view='deck'; render();
        return document.getElementById('app').textContent.indexOf('Machine Row')>-1; })()`,false), 'a swapped movement vanished');

  chk('no runtime errors', errs.length===0, errs.slice(0,3).join(' | '));
  console.log(`\nproblems: ${bad}`);
  process.exit(bad? 1:0);
},2200);
