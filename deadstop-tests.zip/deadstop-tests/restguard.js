// A running rest must not be thrown away by a single stray tap - but once the rest is over,
// logging the next set is the normal flow and must stay a single tap.
const { JSDOM } = require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const dom=new JSDOM(fs.readFileSync(f,'utf8'),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://thundermeadows.github.io/'});
const w=dom.window,D=w.document,EV=e=>w.eval(e);
w.AudioContext=w.AudioContext||function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
const click=el=>el&&el.dispatchEvent(new w.MouseEvent('click',{bubbles:true,cancelable:true,view:w}));
const chip=(i,j)=>D.querySelector(`.set[data-ex="${i}"][data-set="${j}"]`);
const stOf=(i,j)=>EV(`exState(${i},dayObj().exercises[${i}]).sets[${j}].st`);
const restT=()=>EV('(function(){var b=lastCompletion();return b?b.t:null;})()');
setTimeout(async ()=>{
  console.log(`\n--- ${L}: a running rest survives a stray tap ---`);
  EV('try{TOUR.live=false;}catch(e){} try{S.tour={done:true};}catch(e){}');
  for(const fn of ['coachIdle','ONB_ACTIVE','isStartMode']) EV(`if(typeof ${fn}==="function") ${fn}=function(){return false;};`);
  EV('S.maxes={squat:327,bench:225,dead:405,ohp:145,pull:225}; render();');
  const i=EV(`(function(){var d=dayObj();for(var k=0;k<d.exercises.length;k++){if(d.exercises[k].loadNum!=null) return k;}return -1;})()`);
  if(i<0){ console.log('  (no numeric exercise)  problems: 0'); process.exit(0); }
  const reset=()=>EV(`(function(){var st=exState(${i},dayObj().exercises[${i}]);
    st.sets.forEach(function(s){s.st='pend';delete s.w;delete s.t;}); S.restExt=null; S.restDismiss=null;
    REST_ARM={k:null,t:0}; save(); render(); return 1;})()`);
  let bad=0;
  // set 1: no rest running, must log on a single tap
  reset(); click(chip(i,0)); EV('render();');
  console.log('  first set, single tap      :', stOf(i,0), stOf(i,0)==='hit'?'(logged)':'<-- should log immediately');
  if(stOf(i,0)!=='hit') bad++;
  const t0=restT();
  // now a stray tap on set 2 while resting: must NOT log, must NOT disturb the rest
  click(chip(i,1)); EV('render();');
  console.log('  stray tap while resting    :', stOf(i,1), stOf(i,1)==='pend'?'(not logged)':'<-- LOGGED, rest lost');
  if(stOf(i,1)!=='pend') bad++;
  console.log('  rest untouched             :', restT()===t0?'yes':'<-- RESTARTED');
  if(restT()!==t0) bad++;
  // The prompt must still be on screen long enough to READ - it used to run on the default
  // 1.5s toast while the window it describes is 5s, so it flashed and vanished while a second
  // tap would still have worked. Check it is alive well after the default would have expired.
  const toastLive = () => { const t=D.getElementById('toast'); return !!(t && t.classList.contains('show')); };
  console.log('  prompt visible immediately :', toastLive());
  await new Promise(r=>setTimeout(r,2200));
  console.log('  still readable after 2.2s  :', toastLive(), toastLive()?'':'<-- gone before it can be read');
  if(!toastLive()) bad++;
  // a deliberate second tap does log it
  click(chip(i,1)); EV('render();');
  console.log('  second tap logs it early   :', stOf(i,1), stOf(i,1)==='hit'?'(logged on purpose)':'<-- could not log early');
  if(stOf(i,1)!=='hit') bad++;
  // the arm must expire, so a much later stray tap asks again
  reset(); click(chip(i,0)); EV('render();');
  click(chip(i,1)); EV(`REST_ARM.t=Date.now()-9000;`); click(chip(i,1)); EV('render();');
  console.log('  arm expires after 5s       :', stOf(i,1), stOf(i,1)==='pend'?'(asks again)':'<-- stale arm still committed');
  if(stOf(i,1)!=='pend') bad++;
  // once the rest is over, a single tap logs with no prompt
  reset(); click(chip(i,0)); EV('render();');
  EV(`(function(){var st=exState(${i},dayObj().exercises[${i}]);
     st.sets[0].t=Date.now()-6*60*1000; save(); render(); return 1;})()`);   // rest long finished
  click(chip(i,1)); EV('render();');
  console.log('  rest over, single tap      :', stOf(i,1), stOf(i,1)==='hit'?'(no prompt, as it should be)':'<-- prompting when it should not');
  if(stOf(i,1)!=='hit') bad++;
  console.log('  problems:', bad);
  process.exit(bad?1:0);
},1500);
