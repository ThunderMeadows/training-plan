// COACHING, END TO END (2026-09-02, after "so the coaching side is 100%?" - it was not). Bank a
// session AS an athlete, prove it lands in their drawer and nowhere else, switch between two
// athletes with partial work, prove the coach's own card comes back intact, remove an athlete
// and prove their history survives removal and the coach's is untouched.
const {JSDOM}=require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const d=new JSDOM(fs.readFileSync(f,'utf8'),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/'});
const w=d.window,EV=e=>w.eval(e);
w.AudioContext=function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
let bad=0; const chk=(l,ok,dd)=>{ if(!ok)bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&dd?'  <-- '+dd:''}`);};
const wait=ms=>new Promise(r=>setTimeout(r,ms));
setTimeout(async ()=>{
  console.log(`\n--- ${L}: coaching end to end ---`);
  if(EV('typeof ROSTER')==='undefined'){ console.log('  ok    (no roster on this card)\n  problems: 0'); process.exit(0); }
  EV('try{TOUR.live=false;}catch(e){} S.tour={done:true}; ONB().done=true; S.discAck={v:DISC_V,d:localDate()}; storageOK=true; S.maxes={squat:327,bench:225,dead:405,ohp:145,row:170}; S.notes="COACH OWN NOTE"; save();');
  EV('ROSTER.mode="coach"; ROSTER.athletes=[]; ROSTER.active=null; save();');
  await EV('refreshLogs()'); const coachLogs0=Number(EV('logKeys.length'));
  const a=EV('rosterAdd("Manuel")'), b=EV('rosterAdd("Rosa")');
  // --- Manuel: build, start, bank ---
  EV('rosterSwitch("'+a+'");'); await wait(300);
  EV('var o=ONB(); o.goal="build"; o.wt=200; o.exp="some"; o.sex="m"; o.days=4; o.res={}; o.prefs={}; o.limits=[]; ONB_build(); ONB().done=true; S.tour={done:true}; S.discAck={v:DISC_V,d:localDate()}; save(); render();');
  chk('Manuel has his own plan', EV('!!(S.genPlan&&S.genPlan.days.length)') && EV('S.notes')!=='COACH OWN NOTE', 'plan or namespace wrong');
  EV(`(function(){ var dd=dayObj(); dd.exercises.forEach(function(ex,i){ var st=exState(i,ex); st.sets.forEach(function(s2){ s2.st='hit'; s2.reps=5; s2.rir=2; }); }); save(); })();`);
  const banked=await EV('saveSessionLog(true)');
  chk('a session banks as Manuel', banked===true, 'bank returned '+banked);
  const key=EV('curLOGP()+S.when.date+"-"+S.day+"-W"+S.week+"B"+cyc()');
  chk('the log carries his id', key.indexOf(a+':')>-1, key);
  chk('and is stored under his drawer', EV('localStorage.getItem("nsc:'+key+'")!==null'), 'not stored');
  await EV('refreshLogs()');
  chk('Manuel sees exactly his session', Number(EV('logKeys.length'))===1 && EV('logKeys[0]').indexOf(a)>-1, EV('JSON.stringify(logKeys)'));
  // --- Rosa: partial work, no bank ---
  EV('rosterSwitch("'+b+'");'); await wait(300);
  chk('switching to Rosa leaves Manuel behind', EV('!(S.genPlan&&S.genPlan.days.length)') || EV('S.notes')!=='MANUEL', 'Manuel bled into Rosa');
  EV('S.notes="ROSA WIP"; save();');
  await EV('refreshLogs()');
  chk('Rosa sees no sessions at all', Number(EV('logKeys.length'))===0, EV('JSON.stringify(logKeys)'));
  // --- back to Manuel: his banked day is still his ---
  EV('rosterSwitch("'+a+'");'); await wait(300); await EV('refreshLogs()');
  chk('Manuel\'s banked session is still there', Number(EV('logKeys.length'))===1, EV('logKeys.length'));
  chk('and his day is locked', EV('dayLocked()')===true, 'unlocked');
  chk('Rosa\'s note did not follow', EV('S.notes')!=='ROSA WIP', EV('S.notes'));
  // --- back to the coach: the coach's own card intact ---
  EV('rosterSwitch(null);'); await wait(300); await EV('refreshLogs()');
  chk('the coach\'s own state comes back', EV('S.notes')==='COACH OWN NOTE' && EV('S.maxes.squat')===327, EV('S.notes')+' / '+EV('S.maxes&&S.maxes.squat'));
  chk('the coach\'s own log is untouched', Number(EV('logKeys.length'))===coachLogs0, EV('logKeys.length')+' vs '+coachLogs0);
  chk('the coach never sees an athlete\'s session', EV('!logKeys.some(function(k){return k.indexOf(":")>-1;})'), EV('JSON.stringify(logKeys)'));
  // --- remove Manuel: off the roster, history preserved, coach untouched ---
  EV('rosterRemove("'+a+'");');
  chk('Manuel is off the roster', EV('!rosterAthlete("'+a+'")'), 'still listed');
  chk('his history survives removal (wipe is a separate act)', EV('localStorage.getItem("nsc:'+key+'")!==null'), 'history destroyed by removal');
  chk('the coach\'s card is still intact', EV('S.notes')==='COACH OWN NOTE', EV('S.notes'));
  // roster row after all that
  chk('Rosa\'s row reads needs-assessment (she never built)', EV('rosterProgress(rosterAthlete("'+b+'")).assessed')===false, 'wrong status');
  console.log('  problems: '+bad); process.exit(bad?1:0);
},1700);
