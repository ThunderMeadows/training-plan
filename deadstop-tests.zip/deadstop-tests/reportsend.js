// THE REPORT ACTUALLY SENDS (2026-09-04, field, with a photo: the kind chips worked, all four
// send buttons did nothing at all).
//
// Four separate silent failures behind one symptom:
//   - Email it / Text it assigned location.href a mailto:/sms: URL. An iOS app opened from the
//     home screen runs in standalone display mode, where that assignment is IGNORED - no
//     navigation, no throw, so the catch never fired and the copy fallback never ran.
//   - Share fell back to a toast, and .toast had NO z-index while the report panel sits at 240 -
//     the confirmation drew underneath the sheet he was reading.
//   - Copy did the same, and its last-ditch textarea was z-index 99: also buried.
//
// `setlaunch` proved these buttons were BOUND. Bound is not the same as working, which is the
// lesson: a handler that runs, does nothing the athlete can see, and swallows its own failure is
// indistinguishable from a dead button. Every one of them must now leave a visible mark ON
// ITSELF - inside the panel, above everything, whatever the stacking turns out to be.
const { JSDOM } = require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const dom=new JSDOM(fs.readFileSync(f,'utf8'),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/',
  beforeParse(w){
    w.AudioContext=function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
    w.alert=()=>{};
  }});
const w=dom.window,D=w.document,EV=e=>w.eval(e);
let bad=0; const chk=(l,ok,d)=>{ if(!ok) bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&d?'  <-- '+d:''}`); };
const tap=el=>el&&el.dispatchEvent(new w.MouseEvent('click',{bubbles:true}));
const wait=ms=>new Promise(r=>setTimeout(r,ms||60));

setTimeout(async()=>{
  console.log(`\n--- ${L}: a report can actually leave the phone, and says so ---`);
  EV('try{TOUR.live=false;}catch(e){} S.tour={done:true}; if(typeof ONB!=="undefined"){ONB().done=true;} S.discAck={v:DISC_V,d:localDate()}; storageOK=true; S.maxes={squat:327,bench:225,dead:405,ohp:145,row:170,pull:225}; save();');

  // A HOME-SCREEN APP: navigation by location assignment is ignored, exactly as iOS does it in
  // standalone. Anything that relies on it must be seen to fail here.
  EV(`window.__nav=[]; window.__standalone=true;
      (function(){ var d=Object.getOwnPropertyDescriptor(window.Location.prototype,'href');
        try{ Object.defineProperty(window.location,'href',{configurable:true,
          get:function(){ return 'https://x.io/'; },
          set:function(v){ window.__nav.push({how:'location',href:v}); /* standalone: ignored */ } }); }catch(e){}
      })();
      window.__clicks=[];
      (function(){ var orig=HTMLAnchorElement.prototype.click;
        HTMLAnchorElement.prototype.click=function(){ window.__clicks.push(this.getAttribute('href')||''); }; })();
      window.__copied=null;
      navigator.clipboard={ writeText:function(t){ window.__copied=t; return Promise.resolve(); } };`);

  // open the report on a LOGGED day - the state in his photo
  EV("S.day=PLAN.days[0].code; S.locked=S.locked||{}; S.locked[dayKey()]=true; S.rptOpen=true; S.rptKind='question'; S.rptMsg='Hi'; render();");
  chk('(fixture) the panel is open on a closed session, as in his photo', !!D.querySelector('.rpt-wrap') && EV('dayLocked()')===true);
  const box=D.getElementById('rptMsg'); if(box) box.value='Hi';

  // --- the four senders --------------------------------------------------------
  const label=id=>(D.getElementById(id)||{textContent:''}).textContent.trim();

  // Email
  EV('window.__clicks=[]; window.__nav=[]; window.__copied=null;');
  const mailWas=label('rptMail');
  tap(D.getElementById('rptMail')); await wait();
  chk('Email hands off through a link click, not a location assignment',
      EV('window.__clicks.length')===1 && /^mailto:/.test(EV('window.__clicks[0]||""')),
      'clicks='+EV('JSON.stringify(window.__clicks)')+' location-sets='+EV('JSON.stringify(window.__nav)'));
  chk('and it leaves the report on the clipboard too, so a blocked handoff is survivable',
      EV('window.__copied')!==null && /Hi/.test(EV('window.__copied||""')));
  chk('and the button says what it did', label('rptMail')!==mailWas, 'label unchanged: "'+label('rptMail')+'"');

  // Text
  EV('window.__clicks=[]; window.__nav=[]; window.__copied=null;');
  const smsWas=label('rptSms');
  tap(D.getElementById('rptSms')); await wait();
  chk('Text hands off through a link click too',
      EV('window.__clicks.length')===1 && /^sms:/.test(EV('window.__clicks[0]||""')),
      'clicks='+EV('JSON.stringify(window.__clicks)'));
  chk('and answers on the button', label('rptSms')!==smsWas, '"'+label('rptSms')+'"');

  // Copy
  EV('window.__copied=null;');
  const cpWas=label('rptCopy');
  tap(D.getElementById('rptCopy')); await wait(120);
  chk('Copy puts the report on the clipboard', /Hi/.test(EV('window.__copied||""')), 'copied: '+EV('JSON.stringify((window.__copied||"").slice(0,40))'));
  chk('and confirms it on the button', /copied/i.test(label('rptCopy')) && label('rptCopy')!==cpWas, '"'+label('rptCopy')+'"');

  // Share, with no share support at all - the fallback has to be visible
  EV('try{ delete navigator.share; }catch(e){} window.__copied=null;');
  const shWas=label('rptShare');
  tap(D.getElementById('rptShare')); await wait(120);
  chk('Share with no share sheet falls back to a copy the athlete can see',
      /Hi/.test(EV('window.__copied||""')) && label('rptShare')!==shWas, '"'+label('rptShare')+'"');

  // Share that the athlete cancels: still leaves it on the clipboard
  EV("navigator.share=function(){ return Promise.reject(new Error('AbortError')); }; window.__copied=null;");
  tap(D.getElementById('rptShare')); await wait(140);
  chk('a cancelled share still leaves the report on the clipboard', /Hi/.test(EV('window.__copied||""')));

  // --- nothing that confirms may render under the panel --------------------------
  // Read the z-index out of the raw stylesheet text. Going through cssRules and comparing
  // selectorText returned null on BOTH builds - the check could never fail, which is worse than
  // no check at all.
  const sheet=fs.readFileSync(f,'utf8');
  // the LAST z-index in a block is the one that applies - CSS takes the final declaration. The
  // first version of this reader took the FIRST, and reported 300 for a rule that ended in
  // z-index:70, i.e. it would have blessed the exact bug it exists to catch.
  const zOf=sel=>{ const b=sheet.match(new RegExp(sel.replace('.','\\.')+"\\{[^}]*\\}"));
    if(!b) return null; const all=[...b[0].matchAll(/z-index:\s*(\d+)/g)];
    return all.length? +all[all.length-1][1] : null; };
  const panelZ=zOf('.rpt-wrap'), toastZ=zOf('.toast');
  chk('(fixture) the report panel has a stacking level to clear', panelZ>0, 'rpt-wrap z='+panelZ);
  chk('the toast sits above the report panel, so a confirmation is visible',
      toastZ!==null && toastZ>panelZ, 'toast z='+toastZ+' vs panel z='+panelZ+' - a successful copy looks like a dead button');
  const fbm=sheet.match(/__errFallback[\s\S]{0,400}?z-index:(\d+)/);
  const fbZ=fbm? +fbm[1] : null;
  chk('and so does the last-ditch select-it-yourself box', fbZ!==null && fbZ>panelZ, 'fallback z='+fbZ+' vs panel z='+panelZ);

  console.log('  problems:', bad); process.exit(bad?1:0);
},1500);
