// STORED-STATE FUZZER (2026-09-02). Users upgrade in place every time a build is pushed, so the
// card boots against whatever an OLDER build left in storage: missing keys, extra keys, wrong
// types, half-written objects. The painLog crash was exactly this class. This boots the card
// against hundreds of mangled states and demands that load + render + a save never throw.
const {JSDOM}=require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const raw=fs.readFileSync(f,'utf8');
let bad=0; const chk=(l,ok,d)=>{ if(!ok)bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&d?'  <-- '+d:''}`);};
function boot(seedState, seedKey){
  return new Promise(res=>{
    const errs=[];
    const dom=new JSDOM(raw,{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/',
      beforeParse(w){
        w.AudioContext=function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
        if(seedState!==undefined) w.localStorage.setItem(seedKey, typeof seedState==='string'? seedState : JSON.stringify(seedState));
        w.addEventListener('error',e=>errs.push('error: '+e.message));
        w.addEventListener('unhandledrejection',e=>errs.push('rejection: '+(e.reason&&e.reason.message||e.reason)));
      }});
    const w=dom.window, EV=e=>w.eval(e);
    setTimeout(()=>{
      let phase='boot';
      try{
        phase='render'; EV('try{TOUR.live=false;}catch(e){} render();');
        phase='dayObj'; EV('dayObj(); sessionPct(); calCountHTML(); mailSweep();');
        phase='save'; EV('storageOK=true; save();');
        phase='report'; EV('report();');
        phase='settings'; EV('settingsBodyHTML(); provenanceHTML();');
        phase='cal'; EV('S.day="CAL"; render(); S.day=PLAN.days[0].code; render();');
      }catch(e){ errs.push(phase+': '+(e&&e.message||e)); }
      try{ w.close(); }catch(e){}
      res(errs);
    },1400);
  });
}
(async()=>{
  console.log(`\n--- ${L}: booting against mangled stored state ---`);
  // discover the storage key by booting once clean
  const probe=new JSDOM(raw,{runScripts:'dangerously',url:'https://x.io/'});
  probe.window.AudioContext=function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
  await new Promise(r=>setTimeout(r,1400));
  const key=probe.window.eval('"nsc:"+(typeof curSKEY==="function"? curSKEY():SKEY)');
  probe.window.eval('storageOK=true; S.maxes={squat:327,bench:225,dead:405,ohp:145,row:170,pull:225}; save();');
  const good=JSON.parse(probe.window.localStorage.getItem(key));
  probe.window.close();
  chk('a clean state was captured to mutate', !!good && typeof good==='object', 'no baseline');

  const cases=[];
  // 1. every top-level key deleted, one at a time (an older build never had it)
  Object.keys(good).forEach(k=>{ const c=JSON.parse(JSON.stringify(good)); delete c[k]; cases.push(['missing '+k, c]); });
  // 2. every top-level key set to a wrong type
  // wrong-type only for the keys code indexes INTO (a null there is a different failure
  // than a missing key); the rest are covered by the missing-key pass
  ['data','maxes','cardio','when','outs','locked','prs','mail','calNotes','sessManual','trainDays','onb','profile','e1rm','acLog'].forEach(k=>{ if(!(k in good)) return; const c=JSON.parse(JSON.stringify(good)); c[k]=null; cases.push(['null '+k, c]); });
  // 3. legacy keys from removed features, as an old build would have left them
  [['painLog',[{date:'2026-08-30',ex:'Bench',lv:4}]],['limits',['knee']],['onb',{limits:['back'],step:9}],['mail',[{id:'x',txt:'old'}]],['mailSent',null],['sessManual','bad'],['calNotes',[]],['discAck','yes'],['trainDays','mon'],['outs',['A']],['locked',[]],['data',[]]].forEach(([k,v])=>{ const c=JSON.parse(JSON.stringify(good)); c[k]=v; cases.push(['legacy '+k, c]); });
  // 4. raw garbage in the slot
  ['', '{', 'null', '[]', '"string"', '{"S":{}}', '{"week":"one"}', 'undefined'].forEach(g=>cases.push(['garbage '+JSON.stringify(g), g]));
  // 5. an exercise state with sets of the wrong shape
  { const c=JSON.parse(JSON.stringify(good)); c.data={}; c.data[Object.keys(good.data||{})[0]||'x']={sets:'notarray'}; cases.push(['sets not an array', c]); }
  { const c=JSON.parse(JSON.stringify(good)); c.data={}; c.data['1c|1|A|0']={sets:[null,{},{st:'hit'},{st:'pend',added:'yes'}]}; cases.push(['sets with holes', c]); }

  let start=+(process.argv[4]||0), count=+(process.argv[5]||cases.length);
  if(!process.argv[4]){
    // SUITE MODE: no chunk given. Sample every 5th case plus every legacy/garbage/sets case,
    // so the standing run stays under the runner's timeout; the full sweep is manual:
    //   node statefuzz.js <card> <label> 0 55 && node statefuzz.js <card> <label> 55 60
    const keep=cases.filter((c,i)=> i%5===0 || /^(legacy|garbage|sets)/.test(c[0]));
    cases.length=0; keep.forEach(c=>cases.push(c));
    start=0; count=cases.length;
    console.log('  suite mode: '+cases.length+' representative cases');
  }
  const outFile='/tmp/fuzz-'+L+'.json';
  let prior=[]; try{ prior=JSON.parse(fs.readFileSync(outFile,'utf8')); }catch(e){}
  if(start===0) prior=[];
  let failures=prior;
  const slice=cases.slice(start, start+count);
  console.log('  running cases '+start+'..'+(start+slice.length-1)+' of '+cases.length);
  for(const [label, state] of slice){
    const errs=await boot(state, key);
    if(errs.length) failures.push(label+' -> '+errs[0].slice(0,110));
  }
  fs.writeFileSync(outFile, JSON.stringify(failures));
  if(start+count<cases.length){ console.log('  (partial - '+failures.length+' failures so far)'); process.exit(0); }
  chk('cases were generated', cases.length>20, cases.length);
  chk('every mangled state boots, renders, saves and reports without throwing', failures.length===0,
      '\n        '+failures.slice(0,12).join('\n        ')+(failures.length>12? '\n        ...and '+(failures.length-12)+' more':''));
  console.log('  fuzzed '+cases.length+' stored states');
  console.log('  problems: '+bad); process.exit(bad?1:0);
})();
