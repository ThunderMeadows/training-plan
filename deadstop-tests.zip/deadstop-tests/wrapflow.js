// FIELD BUG 2026-09-02 (v190): he finished every movement he trained on day F, but #8 had been
// taken out of the day - and the progress count still included it, so the session sat at 7 of 8
// and the wrap-up was never offered. A movement that is not in today's session is not in the count.
const {JSDOM}=require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const d=new JSDOM(fs.readFileSync(f,'utf8'),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/'});
const w=d.window,EV=e=>w.eval(e);
w.AudioContext=function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
let bad=0; const chk=(l,ok,dd)=>{ if(!ok)bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&dd?'  <-- '+dd:''}`);};
setTimeout(()=>{
  console.log(`\n--- ${L}: finishing a day with a movement taken out ---`);
  EV('try{TOUR.live=false;}catch(e){} S.tour={done:true}; if(typeof ONB!=="undefined"){ONB().done=true;} S.discAck={v:DISC_V,d:localDate()}; storageOK=true; S.debriefDone=null; S.dbf={}; save(); render();');
  const n=Number(EV('dayObj().exercises.length'));
  chk('the day has several movements', n>=3, n);
  // take the LAST movement out, exactly as the UI does
  const outName=EV('dayObj().exercises['+(n-1)+'].name');
  EV(`(function(){ if(!S.outs[S.day]) S.outs[S.day]=[]; S.outs[S.day].push(`+JSON.stringify(outName)+`); save(); render(); })();`);
  chk('the card knows it is out', EV('isOut('+JSON.stringify(outName)+')'), 'not out');
  chk('the total drops by one', Number(EV('sessionPct().total'))===n-1, EV('JSON.stringify(sessionPct())'));
  // log every REMAINING movement
  EV(`(function(){ var d2=dayObj();
    for(var i=0;i<d2.exercises.length;i++){
      if(isOut(d2.exercises[i].name)) continue;
      var st=exState(i,d2.exercises[i]);
      st.sets.forEach(function(s2){ s2.st='hit'; s2.reps=5; s2.rir=2; });
    } save(); render(); })();`);
  const p=JSON.parse(EV('JSON.stringify(sessionPct())'));
  chk('every trained movement counts as done', p.done===n-1, JSON.stringify(p));
  chk('the session reads as COMPLETE', p.done===p.total && p.total>0, JSON.stringify(p));
  chk('the wrap-up is offered', (EV('debriefHTML()')||'').length>0, 'debrief still withheld');
  chk('and it is the high-five bar', /wrapup|\u270B/.test(EV('debriefHTML()')||''), 'wrong element');
  // sanity: an unfinished day must NOT offer it
  EV(`(function(){ var d2=dayObj(); var st=exState(0,d2.exercises[0]); st.sets[0].st='pend'; save(); render(); })();`);
  chk('an unfinished day still withholds the wrap-up', (EV('debriefHTML()')||'').length===0, 'offered too early');
  console.log('  problems: '+bad); process.exit(bad?1:0);
},1600);
