// The real guard: every flavour must produce an IDENTICAL filter function list, so any
// switch between any two is interpolable and WebKit repaints it. Also walks the full
// matrix - every flavour to every other flavour - not just the pairs someone happened to try.
const { JSDOM } = require('jsdom'); const fs=require('fs');
const file=process.argv[2], L=process.argv[3];
const dom=new JSDOM(fs.readFileSync(file,'utf8'),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://thundermeadows.github.io/'});
const w=dom.window,D=w.document,EV=e=>w.eval(e);
w.AudioContext=w.AudioContext||function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
const shape=s=>(s.match(/([a-z-]+)\(/g)||[]).join(',');
setTimeout(()=>{
  console.log(`\n--- ${L}: is every flavour switch interpolable? ---`);
  const ids=JSON.parse(EV('JSON.stringify(GB_FLAV.map(function(f){return f.id;}))'));
  const host=D.getElementById('gbHost');
  const shapes={}; let bad=0;
  for(const id of ids){
    EV(`S.gbFlav='${id}'; gbApplyFlavour();`);
    shapes[id]=shape(host.style.filter);
    console.log(`  ${EV('gbFlavour().n').padEnd(15)} ${shapes[id]}`);
  }
  const uniq=[...new Set(Object.values(shapes))];
  console.log('  distinct shapes:', uniq.length, uniq.length===1?'(all switches interpolable)':'<-- MISMATCH');
  if(uniq.length!==1) bad++;
  // full matrix, every from->to pair
  let pairs=0, broken=0;
  for(const a of ids) for(const b of ids){ if(a===b) continue; pairs++;
    if(shapes[a]!==shapes[b]) broken++; }
  console.log(`  pairs checked: ${pairs}, non-interpolable: ${broken}`);
  // and nothing may ever be empty
  for(const id of ids){ EV(`S.gbFlav='${id}'; gbApplyFlavour();`);
    if(!host.style.filter){ console.log('  EMPTY FILTER for', id); bad++; } }
  console.log('  problems:', bad+broken);
  process.exit((bad+broken)?1:0);
},1500);
