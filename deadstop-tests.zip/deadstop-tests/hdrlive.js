// THE HEADER NEVER LOCKS (2026-09-03, field: he switched the rhythm to "I pick", landed on a
// future day, and could not get back INTO settings to switch it back).
//
// The header identity bar is not part of any session. It is settings, mail from Bulk, the tour
// replay and his own photo - none of them touch the day on screen. All four carry .lockfree, and
// the LOGGED-day branch of lockGuard honours .lockfree, so they worked there. The FUTURE-PREVIEW
// branch deliberately does not honour .lockfree, because cardio and bodyweight edit TODAY's data
// and must stay shut while browsing - and the header went down with them. Settings is the way
// OUT of a state the athlete has put themselves in, so locking it is a trap, not a guard.
//
// lockaudit walks a banked day's session controls; it never looks at the header and never enters
// the preview state, which is how this shipped. This harness is the matrix: the header, in every
// state the card can be in.
const { JSDOM } = require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const dom=new JSDOM(fs.readFileSync(f,'utf8'),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/',
  beforeParse(w){
    w.AudioContext=function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
    w.alert=()=>{};
  }});
const w=dom.window,D=w.document,EV=e=>w.eval(e);
let bad=0; const chk=(l,ok,d)=>{ if(!ok) bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&d?'  <-- '+d:''}`); };
const tap=el=>el&&el.dispatchEvent(new w.MouseEvent('click',{bubbles:true,cancelable:true}));

setTimeout(async()=>{
  console.log(`\n--- ${L}: the way out is never locked ---`);
  EV('try{TOUR.live=false;}catch(e){} S.tour={done:true}; if(typeof ONB!=="undefined"){ONB().done=true;} S.discAck={v:DISC_V,d:localDate()}; storageOK=true; S.maxes={squat:327,bench:225,dead:405,ohp:145,row:170,pull:225}; save();');

  const live = "S.splitMode='guided'; S.locked={}; S.day=PLAN.days[0].code; S.week=timeWeek(); S.visit=null; SET_OPEN=false; settingsSync(); render();";
  // a LOGGED day: the session is banked and read-only
  const logged = live + " S.locked=S.locked||{}; S.locked[dayKey()]=true; render();";
  // FUTURE days being previewed. Guided: anything past the next in sequence. Open + pinned
  // weekdays: a session pinned to a weekday that is not today - the state he was actually in
  // when he could not get back into settings.
  const prevGuided = "S.splitMode='guided'; S.wd=null; S.locked={}; S.data={}; S.week=timeWeek(); S.day=PLAN.days[PLAN.days.length-1].code; SET_OPEN=false; settingsSync(); render();";
  // His exact state: Open rhythm, weekdays pinned, and a session already banked today - which is
  // what gates the rest ("one session a night"). Everything else in the week becomes Coming up.
  const prevOpen = "S.splitMode='open'; S.locked={}; S.data={}; S.week=timeWeek();"
    + " S.wd=splitDefaultDays((PLAN.days||[]).length||4).slice();"
    + " try{ logKeys.push(curLOGP()+shiftDate()+'-'+PLAN.days[0].code+'-W'+S.week+'B'+cyc()); }catch(e){}"
    + " S.day=PLAN.days[PLAN.days.length-1].code; SET_OPEN=false; settingsSync(); render();";

  const states=[['a live training day',live],['a logged session',logged],
                ['a future preview, card picks',prevGuided],['a future preview, athlete picks',prevOpen]];

  for(const [name,setup] of states){
    EV(setup);
    const inPrev = EV('(typeof isPreviewing==="function") && isPreviewing()');
    const inLock = EV('dayLocked()');
    console.log(`  [${name}]  previewing=${inPrev}  locked=${inLock}`);
    if(name.indexOf('preview')>-1)
      chk(`(fixture) ${name} really is a preview`, inPrev===true,
          'isPreviewing() is false - this row would pass on a card with no guard at all');
    if(name.indexOf('logged')>-1)
      chk(`(fixture) ${name} really is locked`, inLock===true, 'dayLocked() is false');

    // the gear is the way out - it must OPEN, not just exist
    EV('SET_OPEN=false; settingsSync();');
    const gear=D.querySelector('.hdr-id [data-setopen]');
    chk(`${name}: the settings gear is in the header`, !!gear);
    if(gear){ tap(gear); await new Promise(r=>setTimeout(r,40));
      chk(`${name}: tapping the gear actually opens settings`, EV('SET_OPEN')===true,
          'SET_OPEN stayed '+EV('SET_OPEN')+' - the athlete cannot reach settings from here');
      EV('SET_OPEN=false; settingsSync(); render();'); }

    // mail from Bulk
    const mail=D.querySelector('.hdr-id [data-mailopen]');
    chk(`${name}: mail from Bulk is in the header`, !!mail);
    if(mail){ tap(mail); await new Promise(r=>setTimeout(r,40));
      chk(`${name}: tapping mail opens the inbox`, !!D.querySelector('#mailGate'),
          'no mail overlay opened');
      D.querySelectorAll('#mailGate').forEach(x=>x.remove()); EV('render();'); }

  }

  // and the thing the guard IS for still works: a preview must not let session data be edited
  EV(prevGuided);
  const sess=D.querySelector('#app .ex .set, #app .ex input, #app .savelog');
  if(sess){
    const ev=new w.MouseEvent('click',{bubbles:true,cancelable:true});
    let stopped=false; const orig=ev.stopPropagation.bind(ev);
    ev.stopPropagation=function(){ stopped=true; return orig(); };
    sess.dispatchEvent(ev);
    chk('a future preview still refuses to let session data be touched', stopped,
        'the guard let a tap through to the session on a previewed day - the fix went too far');
  } else {
    chk('a future preview still refuses to let session data be touched', false,
        'no session control found to test the guard against');
  }

  console.log('  problems:', bad); process.exit(bad?1:0);
},1500);
