// The eyes must glow, and must NOT be dimmed with the body when he poses. The bug this guards
// is subtle: adding .gb-eyes to the pose dimming rule would blank them again and everything
// else would still look fine.
const { JSDOM } = require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const src=fs.readFileSync(f,'utf8');
const dom=new JSDOM(src,{runScripts:'dangerously',pretendToBeVisual:true,url:'https://thundermeadows.github.io/'});
const w=dom.window,D=w.document,EV=e=>w.eval(e);
w.AudioContext=w.AudioContext||function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
setTimeout(()=>{
  console.log(`\n--- ${L}: the bear's eyes ---`);
  let bad=0; const chk=(l,ok,d)=>{ if(!ok) bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&d?'  <-- '+d:''}`); };
  EV('try{TOUR.live=false;}catch(e){} try{S.tour={done:true};}catch(e){} render();');
  const host=D.getElementById('gbHost');
  chk('bear built', !!host);
  const layers=D.querySelectorAll('#gbHost .gb-eyes');
  chk('an eye layer exists per view with eyes', layers.length>=3, 'found '+layers.length);
  const dots=D.querySelectorAll('#gbHost .gb-eye');
  chk('eye glows drawn', dots.length>=6, 'found '+dots.length);
  // every eye glow must sit on a lid centre - a glow floating off the face is worse than none
  (function(){
    const views=JSON.parse(EV('JSON.stringify(Object.keys(GB_EYES))'));
    let off=0;
    views.forEach(v=>{
      const n=JSON.parse(EV(`JSON.stringify((GB_EYES[${JSON.stringify(v)}]||[]).length)`));
      const box=D.querySelector(`#gbHost [data-gbv="${v}"]`);
      if(!box) return;
      const lids=[...box.querySelectorAll('.gb-lid')], gl=[...box.querySelectorAll('.gb-eye')];
      if(gl.length !== lids.length*2) { off++; return; }   // drawn twice for luminance
      lids.forEach((l,i)=>{
        const g=gl[i];
        if(l.getAttribute('cx')!==g.getAttribute('cx') || l.getAttribute('cy')!==g.getAttribute('cy')) off++;
      });
    });
    chk('every glow sits on its eye', off===0, off+' mismatched');
  })();
  // the layer order matters: a blink has to close OVER the glow
  (function(){
    const box=D.querySelector('#gbHost [data-gbv="front"]');
    const kids=[...box.children].map(e=>e.className);
    const ie=kids.findIndex(c=>/gb-eyes/.test(c)), il=kids.findIndex(c=>/gb-lids/.test(c));
    chk('eyes sit under the blink lids', ie>-1 && il>-1 && ie<il, `eyes@${ie} lids@${il}`);
  })();
  // and the pose dimming must not include them
  (function(){
    const rule=/#gbHost\.gb-pose \.gb-base,[\s\S]{0,200}?filter:brightness/.exec(src);
    const block=rule? rule[0] : '';
    chk('pose dimming does not touch the eyes', !/gb-eyes/.test(block),
        'the eye layer is being dimmed with the body');
    chk('pose lights the eyes', /#gbHost\.gb-pose \.gb-eyes\{opacity:1/.test(src));
  })();
  console.log(`  runtime errors: ${EV('(typeof ERR_LOG!=="undefined"?ERR_LOG.length:"n/a")')}`);
  console.log('  problems:', bad);
  process.exit(bad?1:0);
},1500);
