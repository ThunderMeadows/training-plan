// His ask, 2026-09-06: "Can you have Bulk spill out funny jokes in his emails? A large joke
// library... Something new almost everyday. Some repeats occasionally depending on the humor.
// He gets dry after a few. Also, give him a better personality."
//
// "Dry after a few" was measurable: MAIL_GREET held four lines indexed by date-of-month % 4, so
// an athlete saw all of Bulk inside a fortnight and then watched it loop in the same order every
// month. What this file holds:
//   - the library is big, has no duplicates, and every line is short enough to read on a phone
//   - a joke is FIXED for the day: reopening the card cannot reroll it, or a letter read twice
//     shows two punchlines and Bulk reads as several different bears
//   - across two months it is nearly all new, and it never repeats two days running
//   - only letters already in a good mood carry one. A punchline under "your max came down" or
//     "back up or lose everything" is not a joke, it is a card that does not know what it said
//   - and the content rules hold: nothing about weak, fat, slow, skipping meals or drugs. The
//     card is friendly and forgiving, and a joke aimed at the athlete is not a joke.
const {JSDOM}=require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const d=new JSDOM(fs.readFileSync(f,'utf8'),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/'});
const w=d.window,EV=e=>w.eval(e);
const safe=(e,fb)=>{ try{ return EV(e); }catch(err){ return (fb===undefined)?('ERR '+err.message):fb; } };
w.AudioContext=function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
let bad=0; const chk=(l,ok,dd)=>{ if(!ok)bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&dd?'  <-- '+dd:''}`);};

setTimeout(()=>{
  console.log(`\n--- ${L}: Bulk has material ---`);
  EV('try{TOUR.live=false;}catch(e){} S.tour={done:true}; if(typeof ONB!=="undefined"){ONB().done=true;} S.discAck={v:DISC_V,d:localDate()}; storageOK=true; save();');

  // ---- the library itself ----------------------------------------------------
  const N=safe('BULK_JOKES.length',0);
  chk('the library is large enough to last a year of training days', N>=150, N+' jokes');
  chk('every entry has text and a tag',
      safe('BULK_JOKES.every(function(x){ return x && typeof x.j==="string" && x.j.length>10 && typeof x.t==="string" && x.t; })',false),
      'malformed entry');
  chk('no duplicate jokes',
      safe('(new Set(BULK_JOKES.map(function(x){ return x.j.toLowerCase().replace(/[^a-z]/g,""); }))).size===BULK_JOKES.length',false),
      safe('BULK_JOKES.length-(new Set(BULK_JOKES.map(function(x){return x.j.toLowerCase().replace(/[^a-z]/g,"")}))).size')+' repeats in the book');
  chk('every joke fits a phone line',
      safe('BULK_JOKES.every(function(x){ return x.j.length<=170; })',false),
      JSON.stringify(safe('(BULK_JOKES.filter(function(x){return x.j.length>170})[0]||{}).j')));
  chk('nothing in the book can inject markup',
      safe('BULK_JOKES.every(function(x){ return x.j.indexOf("<")<0; })',false), 'a joke carries a tag character');
  // the content rules. Aimed at the athlete, or at their food, or at drugs = not shipping.
  const banned=safe(`(function(){
    var re=/(steroid|\\btren\\b|\\bgear\\b|starv|skip (a )?meal|skip breakfast|cheat day|purge|too fat|\\blazy\\b|\\bugly body|\\bskinny\\b|\\bfatty\\b|\\bexcuses? are\\b)/i;
    return BULK_JOKES.filter(function(x){ return re.test(x.j); }).map(function(x){ return x.j; });
  })()`,[]);
  chk('nothing about drugs, food restriction, or the athlete\u2019s body', banned.length===0, JSON.stringify(banned.slice(0,2)));
  chk('enough keepers to allow the occasional repeat, not so many it is a rerun',
      safe('(function(){ var k=BULK_JOKES.filter(function(x){return x.k}).length; return k>=15 && k<=BULK_JOKES.length*0.45; })()',false),
      safe('BULK_JOKES.filter(function(x){return x.k}).length')+' keepers of '+N);
  chk('the day-kind tags the picker asks for all exist in the book',
      safe('["general","leg","pull","push","core","deload"].every(function(t){ return BULK_JOKES.some(function(x){ return x.t===t; }); })',false),
      'a tag jokeTagToday() can return has no jokes behind it');

  // ---- one joke per day, and the same one all day -----------------------------
  const twice=safe('(function(){ S.jokeH=[]; S.jokeToday=null; var a=bulkJoke(); var b=bulkJoke(); return a===b && !!a; })()',false);
  chk('the day\u2019s joke does not change when the card is reopened', twice===true,
      'two reads of the same day gave different punchlines');

  // ---- across two months: nearly all new, never twice running -----------------
  const run=safe(`(function(){
    S.jokeH=[]; S.jokeToday=null;
    var real=shiftDate, out=[], t=new Date('2026-01-01T12:00:00');
    for(var i=0;i<60;i++){
      var iso=new Date(t.getTime()+i*86400000).toISOString().slice(0,10);
      window.shiftDate=function(){ return iso; };
      out.push(bulkJoke());
    }
    window.shiftDate=real;
    var back=0; for(var k=1;k<out.length;k++) if(out[k]===out[k-1]) back++;
    return {n:out.length, distinct:(new Set(out)).size, backToBack:back, blank:out.filter(function(x){return !x;}).length};
  })()`,{});
  console.log(`    60 days: ${run.distinct} different jokes, ${run.backToBack} back-to-back repeats`);
  chk('two months of jokes are almost entirely new material', run.distinct>=55, JSON.stringify(run));
  chk('never the same joke two days running', run.backToBack===0, JSON.stringify(run));
  chk('never a blank punchline', run.blank===0, JSON.stringify(run));
  chk('the history ring does not grow forever',
      safe('(S.jokeH||[]).length<=JOKE_WINDOW*2',false), safe('(S.jokeH||[]).length')+' entries');

  // ---- a repeat, when it comes, is one of the good ones -----------------------
  const rep=safe(`(function(){
    S.jokeH=[]; S.jokeToday=null;
    var real=shiftDate, seen={}, repeats=[], t=new Date('2026-01-01T12:00:00');
    for(var i=0;i<420;i++){
      var iso=new Date(t.getTime()+i*86400000).toISOString().slice(0,10);
      window.shiftDate=function(){ return iso; };
      var j=bulkJoke();
      if(seen[j]) repeats.push(j); seen[j]=1;
    }
    window.shiftDate=real;
    var keeper=BULK_JOKES.filter(function(x){ return x.k; }).map(function(x){ return x.j; });
    var offBook=repeats.filter(function(j){ return keeper.indexOf(j)<0; });
    return {repeats:repeats.length, offBook:offBook.length, sample:offBook[0]||null};
  })()`,{});
  console.log(`    over 420 days: ${rep.repeats} repeats, ${rep.offBook} of them not keepers`);
  chk('over a year it does repeat - he asked for that', rep.repeats>0, 'no repeat ever, the book is being rationed');

  // ---- who gets a punchline and who does not ---------------------------------
  const letters=safe(`(function(){
    S.mail=[]; S.mailSent={}; S.jokeH=[]; S.jokeToday=null;
    mailPush('t-greet-x', 'Training day.', 'playful', bulkJoke());
    mailPush('t-risk-x', 'Six days quiet. Train today or the streak dies tonight.', 'tough');
    mailPush('t-bkp-x', 'Your whole log lives on this one phone.', 'tough');
    var m=mailBox();
    return m.map(function(x){ return {id:x.id, joke:!!x.j}; });
  })()`,[]);
  chk('a good-mood letter carries the day\u2019s joke',
      letters.some(x=>x.id==='t-greet-x' && x.joke), JSON.stringify(letters));
  chk('the streak warning does not tell a joke',
      letters.some(x=>x.id==='t-risk-x' && !x.joke), JSON.stringify(letters));
  chk('neither does the backup warning',
      letters.some(x=>x.id==='t-bkp-x' && !x.joke), JSON.stringify(letters));

  // and by the real sweep, not a hand-made call
  const swept=safe(`(function(){
    S.mail=[]; S.mailSent={}; S.jokeH=[]; S.jokeToday=null;
    try{ mailSweep(); }catch(e){ return 'THREW '+e.message; }
    var m=mailBox();
    return {n:m.length, joked:m.filter(function(x){ return !!x.j; }).map(function(x){ return x.id; }),
            serious:m.filter(function(x){ return x.face==='tough' && x.j; }).map(function(x){ return x.id; })};
  })()`,{});
  chk('the real sweep never puts a punchline on a tough letter',
      swept && swept.serious && swept.serious.length===0, JSON.stringify(swept));

  // ---- the mailbox itself ----------------------------------------------------
  const box=safe(`(function(){
    try{ document.getElementById('mailGate') && document.getElementById('mailGate').remove(); }catch(e){}
    S.mail=[]; S.mailSent={};
    mailShow();
    var el=document.getElementById('mailGate');
    var t=el? el.textContent : '';
    try{ el.remove(); }catch(e){}
    return t;
  })()`,'');
  chk('an empty mailbox still has a joke in it - a quiet day, no badge, no letter',
      /JOKE OF THE DAY/.test(box) && box.length>120, 'quiet day gave the athlete nothing');
  chk('the mailbox leaks no value into the joke line',
      !/undefined|NaN|null|\[object/.test(box), box.slice(0,160));

  // ---- the wider voice -------------------------------------------------------
  chk('the greeting pool is wide enough not to loop inside a month',
      safe('MAIL_GREET.length>=20',false), safe('MAIL_GREET.length')+' greetings');
  chk('the done pool too', safe('MAIL_DONE.length>=16',false), safe('MAIL_DONE.length')+' lines');
  chk('no duplicates in either pool',
      safe('(new Set(MAIL_GREET)).size===MAIL_GREET.length && (new Set(MAIL_DONE)).size===MAIL_DONE.length',false),
      'a line is in there twice');
  // The old picker was date-of-month % pool, so every consecutive day stepped one along the
  // pool and the whole personality arrived in a fixed order, month after month. Measured over
  // 200 consecutive days: a picker that walks in order scores 100%, chance is about 1-in-pool.
  // Anything under a quarter is not a cycle anybody will ever notice.
  const cyc=safe(`(function(){
    var seq=[], t=new Date('2026-03-01T12:00:00');
    for(var i=0;i<200;i++){ var iso=new Date(t.getTime()+i*86400000).toISOString().slice(0,10);
      seq.push(jokeSeed(iso)%MAIL_GREET.length); }
    var asc=0, same=0;
    for(var k=1;k<seq.length;k++){
      if(seq[k]===(seq[k-1]+1)%MAIL_GREET.length) asc++;
      if(seq[k]===seq[k-1]) same++;
    }
    return {asc:asc, same:same, n:seq.length-1, distinct:(new Set(seq)).size};
  })()`,{});
  console.log(`    greeting picks over 200 days: ${cyc.distinct}/${safe('MAIL_GREET.length')} lines used, ${cyc.asc} steps in order`);
  chk('greetings are not picked by a visible cycle',
      cyc.asc/cyc.n < 0.25 && cyc.distinct>=Math.floor(safe('MAIL_GREET.length',24)*0.8),
      JSON.stringify(cyc)+' - the pool is being walked in order, which is what the old %4 did');

  console.log(`\nproblems: ${bad}`);
  process.exit(bad? 1:0);
},2600);
