// AUDIT 2026-09-10. "not even i know why my program is making me deload?"
//
// Two dead ends found in one sweep:
//
// 1. The layoff rule never fired for a real athlete. It only ran inside adaptRun, which only runs
//    after a bank - and by then the session just saved was the latest, so the break measured 0.
//    The first session back was prescribed at full pre-break loads. Now the break is judged at
//    boot, once the logs are in, so the first session back already carries the ease-back; and
//    adLayoffDays measures the gap INTO the latest session when that session is today.
// 2. Every adaptation action carries a `why`, and S.adNew was counted on every pass - and read
//    by nothing. The only place a change was ever drawn was volumeHTML(), PLAN tab, "Weekly work"
//    fold, under the anatomy map. A max moved and the athlete met the new number with no reason.
//    Now: a toast at bank naming what moved, a toast at boot for the ease-back, and a one-line
//    cue on the exercise itself for a week after its max moved.
//
// What this holds: both layoff sequences (bank path and reopen path) ease the maxes exactly
// once; the toast at bank names the change; the exercise card carries the reason; and the cue
// disappears after a week and after an undo.
const {JSDOM}=require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const raw=fs.readFileSync(f,'utf8');
const AC=function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
let bad=0; const chk=(l,ok,d)=>{ if(ok!==true)bad++; if(typeof ok==='string'&&ok.slice(0,3)==='ERR') d=ok; console.log(`  ${ok===true?'ok  ':'FAIL'}  ${l}${ok!==true&&d?'  <-- '+d:''}`); };
function boot(store){
  const d=new JSDOM(raw,{runScripts:'dangerously',pretendToBeVisual:true,url:'https://thundermeadows.github.io/',
    beforeParse(win){ win.AudioContext=AC; if(store) Object.keys(store).forEach(k=>win.localStorage.setItem(k,store[k])); }});
  const w=d.window;
  return {w, E:e=>{try{return w.eval(e);}catch(err){return 'ERR '+err.message;}}, A:async e=>{try{return await w.eval('(async()=>{'+e+'})()');}catch(err){return 'ERR '+err.message;}}};
}
const neutral=c=>{ c.E("for(var i=0,fs=['coachIdle','ONB_ACTIVE','isStartMode'];i<fs.length;i++){ try{ if(typeof window[fs[i]]==='function') window[fs[i]]=function(){return false;}; }catch(e){} }"); c.E("try{TOUR.live=false;}catch(e){} S.tour={done:true}; S.access={role:'coach',until:'2027-12-31'};"); };
const fresh=c=>c.E("S.genPlan=null; S.mode=null; S.profile={goal:'block1'}; S.onb={exp:'some'}; S.week=1; S.maxes={row:170,bench:210,squat:220,dead:250,ohp:105}; S.e1rmH={}; S.acLog=[]; S.adLog=[]; S.adLast=null; S.adNew=0; S.data={}; save();");
const daysAgo=(c,n)=>c.E(`(function(){var t=new Date(shiftDate()+'T12:00:00'); t.setDate(t.getDate()-${n}); return t.toISOString().slice(0,10);})()`);
async function train(c,day,date,w_,rir,n,week,quiet){
  c.E(`S.week=${week}; S.day='${day}'; S.when=S.when||{}; S.when.date='${date}';`);
  c.E(`(function(){ var k=exKey(0); S.data[k]={sets:[]}; for(var i=0;i<${n};i++) S.data[k].sets.push({st:'hit', w:${w_}, rir:${rir}}); save(); })()`);
  return await c.A(`return await saveSessionLog(${quiet===false?'false':'true'});`);
}
// bank a session ON its own day: shiftDate() reads the real clock, so a back-dated key banked
// "now" reads as a 30-day gap immediately and the layoff fires on the wrong bank. Pin the
// clock to the session date for the duration of that one bank, then release it.
async function trainOn(c,day,date,w_,rir,n,week){
  c.E(`window.__sd=shiftDate; shiftDate=function(){ return '${date}'; };`);
  const r=await train(c,day,date,w_,rir,n,week);
  c.E("shiftDate=window.__sd;");
  return r;
}
const toast=c=>c.E("(document.getElementById('toast')||{}).textContent||''");
const cardText=c=>c.E("(function(){ render(); var b=document.body.cloneNode(true); Array.prototype.slice.call(b.querySelectorAll('script')).forEach(function(s){s.parentNode.removeChild(s);}); return b.textContent||''; })()");

(async()=>{
  console.log(`\n--- ${L}: the athlete is told what moved ---`);

  console.log('\n[1] layoff, bank path');
  let c=boot(); await sleep(1900); neutral(c); fresh(c);
  await trainOn(c,'E',daysAgo(c,30),115,2,3,1);
  chk('fixture: nothing eased yet after a session banked on its own day', c.E("!(S.adLog||[]).length && S.maxes.row===170"), 'adLog '+JSON.stringify(c.E("(S.adLog||[]).map(function(a){return a.kind;})")));
  c.E("S.adLast='"+daysAgo(c,30)+"'; save();");
  await train(c,'B',daysAgo(c,0),135,2,4,2,false);      // NOT quiet: the toast must fire
  chk('layoff fired on the first bank back', c.E("(S.adLog||[]).some(function(a){return a.kind==='layoff';})"), JSON.stringify(c.E("(S.adLog||[]).map(function(a){return a.kind;})")));
  chk('row 170 -> 155, bench 210 -> 190', c.E("S.maxes.row===155 && S.maxes.bench===190"), 'row '+c.E('S.maxes.row')+' bench '+c.E('S.maxes.bench'));
  const t1=toast(c);
  chk('the save toast names the change, not just "Session saved"', /eased/.test(t1) && /days away/.test(t1), 'toast: "'+t1+'"');
  await train(c,'E',daysAgo(c,0),115,2,3,2);
  chk('a second bank does not cut again', c.E('S.maxes.row')===155, 'row '+c.E('S.maxes.row'));

  console.log('\n[2] layoff, reopen path - the first session back is already lighter');
  c=boot(); await sleep(1900); neutral(c); fresh(c);
  await trainOn(c,'E',daysAgo(c,30),115,2,3,1);
  c.E("S.week=2; S.day='B'; S.data={}; save();");
  const store={}; const ls=c.w.localStorage; for(let i=0;i<ls.length;i++){ const k=ls.key(i); store[k]=ls.getItem(k); }
  const c2=boot(store); await sleep(4300); neutral(c2);
  chk('eased at boot before any session', c2.E("(S.adLog||[]).some(function(a){return a.kind==='layoff';}) && S.maxes.row===155"), 'row '+c2.E('S.maxes.row')+' log '+JSON.stringify(c2.E("(S.adLog||[]).map(function(a){return a.kind;})")));
  const rx=c2.E("(S.week=2, S.day='B', baseLoad(dayObj().exercises[0]))");
  chk('first session back prescribed off 155 (.78333 x 155 -> 120)', rx===c2.E('plateRound(0.78333*155)'), 'got '+rx);
  const t2=toast(c2);
  chk('a welcome-back toast is showing', /Welcome back/.test(t2) && /eased/.test(t2), 'toast: "'+t2+'"');
  const txt=cardText(c2);
  chk('the Row card itself says the max moved and why', /this max moved 170/.test(txt) && /days away/.test(txt), 'no cue on the exercise card');
  await train(c2,'B',daysAgo(c2,0),120,2,4,2);
  chk('banking the first session back does not cut twice', c2.E('S.maxes.row')===155 && c2.E("(S.adLog||[]).filter(function(a){return a.kind==='layoff'&&a.lift==='row';}).length")===1, 'row '+c2.E('S.maxes.row'));

  console.log('\n[3] the cue follows the change, and only the change');
  c=boot(); await sleep(1900); neutral(c); fresh(c);
  chk('no cue on a card whose max has not moved', !/this max moved/.test(cardText(c)), 'cue shown with empty adLog');
  // a stall drop, filed today
  c.E("S.adLog=[{kind:'stall', lift:'row', from:170, to:155, d:shiftDate(), why:'three sessions without progress'}]; S.maxes.row=155; save();");
  c.E("S.week=1; S.day='B';");
  let tx=cardText(c);
  chk('a stall drop on row shows on the Row card', /this max moved 170 \u2192 155/.test(tx) && /three sessions/.test(tx), 'cue missing');
  c.E("S.day='A';");   // a day without a row max
  tx=cardText(c);
  chk('and NOT on a card for a different lift', !/this max moved 170 \u2192 155/.test(tx), 'cue leaked to another lift');
  // eight days old: gone
  c.E("S.adLog[0].d='"+daysAgo(c,8)+"'; save(); S.day='B';");
  chk('the cue expires after a week', !/this max moved/.test(cardText(c)), 'cue still showing at 8 days');
  // undone: gone
  c.E("S.adLog[0].d=shiftDate(); S.adLog[0].undone=shiftDate(); save();");
  chk('an undone change shows no cue', !/this max moved/.test(cardText(c)), 'cue showing for an undone action');

  console.log('\n[4] the summary line reads right');
  chk('calibration up', c.E("adSummaryLine([{kind:'calib',lift:'row',from:170,to:180}])")==='Row max up to 180 from your sets', c.E("adSummaryLine([{kind:'calib',lift:'row',from:170,to:180}])"));
  chk('stall', c.E("adSummaryLine([{kind:'stall',lift:'squat',from:220,to:200}])")==='Squat backed off to 200', c.E("adSummaryLine([{kind:'stall',lift:'squat',from:220,to:200}])"));
  chk('layoff summarises as one line, not five', c.E("adSummaryLine([{kind:'layoff',lift:'row',from:170,to:155,days:30},{kind:'layoff',lift:'bench',from:210,to:190,days:30}])")==='2 maxes eased 9% \u2014 30 days away', c.E("adSummaryLine([{kind:'layoff',lift:'row',from:170,to:155,days:30},{kind:'layoff',lift:'bench',from:210,to:190,days:30}])"));
  chk('undone actions are left out', c.E("adSummaryLine([{kind:'stall',lift:'squat',from:220,to:200,undone:'x'}])")==='', 'included an undone action');

  console.log('\nproblems: '+bad); process.exit(bad?1:0);
})();
