// FOUND BY THE ORPHAN SCAN 2026-09-02: when another copy of the card saves after this one,
// save() silently stops writing and the banner's two exits were dead. This drives the flow:
// trip the warning, prove saves are dropped, take each exit, prove the card recovers.
const {JSDOM}=require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const d=new JSDOM(fs.readFileSync(f,'utf8'),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/'});
const w=d.window,EV=e=>w.eval(e);
w.AudioContext=function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
let bad=0; const chk=(l,ok,dd)=>{ if(!ok)bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&dd?'  <-- '+dd:''}`);};
setTimeout(()=>{
  console.log(`\n--- ${L}: another copy saved after this one ---`);
  EV('try{TOUR.live=false;}catch(e){} S.tour={done:true}; if(typeof ONB!=="undefined"){ONB().done=true;} S.discAck={v:DISC_V,d:localDate()}; storageOK=true; SYNC_READY=true; save(); render();');
  const key=EV('"nsc:"+(typeof curSKEY==="function"? curSKEY():SKEY)');
  // another copy writes a NEWER stamp with a different tab id
  EV(`(function(){ var o=JSON.parse(localStorage.getItem(${JSON.stringify(key)})); o._w={id:'other-tab', t:Date.now()+5000}; o.maxes=o.maxes||{}; o.maxes.squat=999; localStorage.setItem(${JSON.stringify(key)}, JSON.stringify(o)); })();`);
  EV('S.notes="typed after the other copy saved"; save();');
  chk('the warning trips', EV('STALE_WARNED')===true, 'not warned');
  chk('and saves are dropped while it is up', EV(`(function(){ var o=JSON.parse(localStorage.getItem(${JSON.stringify(key)})); return o.notes!=="typed after the other copy saved"; })()`), 'save went through anyway');
  EV('render();');
  chk('the banner offers both choices', EV('!!document.querySelector("[data-stalekeep]") && !!document.querySelector("[data-staleuse]")'), 'choices missing');
  chk('the banner survives a banked day (lockfree)', EV('document.querySelector(".stale-bar").className.indexOf("lockfree")>=0'), 'guard would eat it');
  // EXIT 1: keep this one
  EV('document.querySelector("[data-stalekeep]").click();');
  chk('Keep this one clears the warning', EV('STALE_WARNED')===false, 'still warned');
  chk('and writes THIS copy over the other', EV(`(function(){ var o=JSON.parse(localStorage.getItem(${JSON.stringify(key)})); return o.notes==="typed after the other copy saved" && o.maxes.squat!==999; })()`), 'other copy survived');
  EV('S.notes="and saves keep working"; save();');
  chk('saves keep working afterwards', EV(`(function(){ var o=JSON.parse(localStorage.getItem(${JSON.stringify(key)})); return o.notes==="and saves keep working"; })()`), 'saves still dropped');
  chk('the banner is gone', EV('render(), !document.querySelector(".stale-bar")'), 'banner lingers');
  // EXIT 2: load the other copy = reload
  EV(`(function(){ var o=JSON.parse(localStorage.getItem(${JSON.stringify(key)})); o._w={id:'other-tab-2', t:Date.now()+9000}; localStorage.setItem(${JSON.stringify(key)}, JSON.stringify(o)); })();`);
  EV('S.notes="lost on purpose"; save(); render();');
  chk('a second foreign save trips it again', EV('STALE_WARNED')===true, 'not re-warned');
  EV('window.__reloaded=false; hardReload=function(){ window.__reloaded=true; };');
  EV('document.querySelector("[data-staleuse]").click();');
  chk('Load the other copy reloads into the stored state', EV('window.__reloaded')===true, 'no reload');
  console.log('  problems: '+bad); process.exit(bad?1:0);
},1700);
