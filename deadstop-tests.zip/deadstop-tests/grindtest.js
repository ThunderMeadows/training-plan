// Walks the rir x grind matrix on a real accessory. Rules being enforced:
//   - rir is the precise reading and decides where it exists
//   - a set called a grind NEVER earns the double step
//   - grind holds the weight only when no rir was reported
//   - the stall escape is deliberately NOT blocked by a grind
const { JSDOM } = require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3];
const dom=new JSDOM(fs.readFileSync(f,'utf8'),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://thundermeadows.github.io/'});
const w=dom.window,EV=e=>w.eval(e);
w.AudioContext=w.AudioContext||function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
setTimeout(()=>{
  console.log(`\n--- ${L}: does a grind change the next prescription? ---`);
  const NAME='DB Romanian Deadlift', W=200;
  const setup=(rir,g)=>EV(`(function(){
    S.maxes={squat:327,bench:225,dead:405,ohp:145,pull:225};
    S.stall={};
    S.lastPerf={}; S.lastPerf[${JSON.stringify(NAME)}]={d:'2026-08-01',w:${W},r:'12,12,12',rir:${rir===null?'null':rir},g:${!!g}};
    return 1;})()`);
  // a real accessory carries a weekly load ladder; without one accLoad returns the anchor
  // before the effort block is ever reached, which is what made the first run all-holds
  EV('S.week=2;');
  const EXJS = `{name:${JSON.stringify(NAME)}, reps:'8-12', wk:[${W},${W+5},${W+10},${W+15}]}`;
  const load=()=>EV(`(function(){ try{ return accLoad(${EXJS}); }catch(e){ return 'THREW '+e.message; } })()`);
  const exists=EV(`!!libRow(${JSON.stringify(NAME)})`);
  if(!exists){ console.log('  (exercise not in library on this card — skipping)'); process.exit(0); }
  console.log(`  anchor: last logged ${W} lb, reps topped\n`);
  console.log('  rir   grind | next load | expected');
  console.log('  ------------|-----------|---------');
  const rows=[[3,false,'double step'],[3,true,'single step (grind blocks double)'],
              [1,false,'single step'],[1,true,'single step'],
              [0,false,'hold'],[0,true,'hold'],
              [null,false,'single step'],[null,true,'hold (grind, no rir)']];
  let bad=0;
  for(const [rir,g,want] of rows){
    setup(rir,g); const out=load();
    // at this anchor a single step is +5 and a double is +10, both inside the 10% cap -
    // at a light anchor the cap legitimately refuses the double, which is not a grind result
    const isHold=out===W, isDouble=out>=W+10, isSingle=out>W && out<W+10;
    let got = isHold?'hold' : isDouble?'double step' : isSingle?'single step' : 'other('+out+')';
    const ok = want.indexOf(got)===0 || want===got || (want.startsWith(got));
    if(!ok) bad++;
    console.log(`  ${String(rir).padEnd(5)} ${String(!!g).padEnd(5)} | ${String(out).padEnd(9)} | ${want} ${ok?'':'  <-- MISMATCH ('+got+')'}`);
  }
  // stall escape must still fire despite a grind
  EV(`S.stall={}; S.stall[${JSON.stringify(NAME)}]={w:${W},n:3,d:'2026-08-01'};`);
  setup(null,true); EV(`S.stall[${JSON.stringify(NAME)}]={w:${W},n:3,d:'2026-08-01'};`);
  const esc=load();
  console.log(`\n  stall escape after 3 stuck sessions, with a grind flagged: ${esc} ${esc>W?'(still escapes - correct)':'(BLOCKED - wrong)'}`);
  if(!(esc>W)) bad++;
  console.log('  problems:', bad);
  process.exit(bad?1:0);
},1500);
