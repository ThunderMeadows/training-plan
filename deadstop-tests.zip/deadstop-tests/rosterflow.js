// FIELD BUG 2026-09-02 (v191): tapping an athlete card did nothing. He had banked the day, and
// the day-lock tap guard - built to protect a logged session's set rows - was eating taps on
// the whole coaching screen. Same class as the frozen disclaimer gate in c144.
const {JSDOM}=require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const d=new JSDOM(fs.readFileSync(f,'utf8'),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/'});
const w=d.window,EV=e=>w.eval(e);
w.AudioContext=function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
let bad=0; const chk=(l,ok,dd)=>{ if(!ok)bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&dd?'  <-- '+dd:''}`);};
setTimeout(()=>{
  console.log(`\n--- ${L}: coaching a roster ---`);
  if(EV('typeof ROSTER')==='undefined'){ console.log('  ok    (no roster on this card - nothing to test)\n  problems: 0'); process.exit(0); }
  EV('try{TOUR.live=false;}catch(e){} S.tour={done:true}; if(typeof ONB!=="undefined"){ONB().done=true;} S.discAck={v:DISC_V,d:localDate()}; storageOK=true; save();');
  EV('ROSTER.mode="coach"; ROSTER.athletes=[]; ROSTER.active=null; save();');
  const id=EV('rosterAdd("Manuel")');
  chk('an athlete can be added', !!id, 'rosterAdd returned nothing');
  EV('rosterSwitch(null); S.day=(PLAN.days&&PLAN.days[0]&&PLAN.days[0].code)||S.day; render();');
  // THE FIELD CONDITION: today's session is banked, so the day is locked
  EV('S.locked=S.locked||{}; S.locked[cyc()+"|"+S.week+"|"+S.day]=true; save(); render();');
  chk('the day is locked, as it was in the field', EV('dayLocked()')===true, 'not locked');
  // the roster must still be reachable and its rows must be exempt from the tap guard
  const html=EV('(typeof rosterHTML==="function")? rosterHTML() : ""');
  chk('the roster screen renders', html.indexOf('data-ros=')>=0, 'no athlete rows');
  chk('the roster is on the lockfree allowlist', /class="block lockfree"><h3>Roster/.test(html), 'guard will eat every tap');
  // click the athlete row exactly as a thumb would, through the guard
  EV('(function(){ var host=document.getElementById("app"); host.innerHTML=rosterHTML(); rosterWire(); })();');
  const row=EV('!!document.querySelector("[data-ros]")');
  chk('an athlete card is on screen', row, 'no card rendered');
  EV('document.querySelector("[data-ros]").click();');
  chk('tapping the card opens the athlete', EV('ROSTER.active')===id, 'active='+EV('JSON.stringify(ROSTER.active)'));
  chk('and the card is now in that athlete\'s namespace', EV('curLOGP()').indexOf(id)>-1, EV('curLOGP()'));
  // and back out
  EV('rosterSwitch(null);');
  chk('closing returns to the coach\'s own card', EV('ROSTER.active')===null && EV('curLOGP()')==='tc-log:', EV('curLOGP()'));
  // the guard itself: simulate the real listener path on a locked day
  EV(`(function(){ var host=document.getElementById("app"); host.innerHTML=rosterHTML(); rosterWire();
      window.__eaten=false; var el=document.querySelector('[data-ros]');
      var t=el; var exempt = !!(t.closest('.lockfree')); window.__eaten=!exempt; })();`);
  chk('the tap guard exempts the athlete card', EV('window.__eaten')===false, 'guard still swallows it');
  // FIELD 2026-09-02: build the athlete's plan and come back WITHOUT tapping the review's
  // start button - the roster must read that as assessed, not "needs the assessment"
  EV('rosterSwitch("'+id+'");');
  EV('var o=ONB(); o.goal="build"; o.wt=200; o.exp="some"; o.sex="m"; o.days=4; o.res={}; o.prefs={}; o.limits=[]; ONB_build();');
  chk('the athlete\'s plan is built', EV('!!(S.genPlan&&S.genPlan.days&&S.genPlan.days.length)'), 'no plan');
  EV('rosterSwitch(null);');
  const p=JSON.parse(EV('JSON.stringify(rosterProgress(rosterAthlete("'+id+'")))'));
  chk('the roster reads a built plan as assessed', p.assessed===true, JSON.stringify(p));
  chk('and knows they have not started yet', p.started===false && p.sessions===0, JSON.stringify(p));
  chk('the row says so in words', EV('rosterHTML()').indexOf('plan built')>=0 && EV('rosterHTML()').indexOf('needs the assessment')<0, 'wrong label');
  // after the athlete taps start on the review, it reads as started
  EV('rosterSwitch("'+id+'"); ONB().done=true; save(); rosterSwitch(null);');
  chk('tapping start on the review marks them started', EV('rosterProgress(rosterAthlete("'+id+'")).started')===true, 'not started');
  console.log('  problems: '+bad); process.exit(bad?1:0);
},1600);
