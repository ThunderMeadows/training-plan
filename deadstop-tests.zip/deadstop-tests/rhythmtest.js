// Training rhythm: Guided vs Open.
//
// Guided is a playlist - the card holds your next session and a missed day shifts everything
// right. Open is a timetable - you pick, in any order, optionally fixed to weekdays, and a
// missed day stays missed instead of dragging the rest of the week along.
//
// The risk in adding Open is not that jumping fails. It is that "fewer restrictions" quietly
// takes down restrictions that were never about sequence:
//   - the INTEGRITY lock, which closes a logged day against a stray thumb. Different job from
//     the sequence lock, and the only reason the card can be trusted with a finished session.
//   - one session per day.
//   - the week boundary. No rhythm reaches next week's loads - his August ruling.
//   - Guided itself, which is what every existing athlete is running.
// Most of what follows is therefore about what Open must NOT be able to do.
const { JSDOM } = require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const dom=new JSDOM(fs.readFileSync(f,'utf8'),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/'});
const w=dom.window,D=w.document,EV=e=>w.eval(e);
w.AudioContext=w.AudioContext||function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};

setTimeout(()=>{
  console.log(`\n--- ${L}: training rhythm (guided / open) ---`);
  let bad=0; const chk=(l,ok,d)=>{ if(!ok) bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&d?'  <-- '+d:''}`); };

  EV("S.tour={done:true}; if(typeof TOUR!=='undefined') TOUR.live=false;");
  const codes=JSON.parse(EV('JSON.stringify(PLAN.days.map(function(d){return d.code;}))'));
  console.log('  split codes:', codes.join(' '), '  time week:', EV('timeWeek()'));
  const tw=EV('timeWeek()');

  // ---- the default is untouched ----
  EV("S.splitMode=null; S.wd=null;");
  chk('a card with no answer is Guided', EV('splitOpen()')===false);
  chk('and Guided exposes no weekday map', EV('schedMap()')===null);

  // ---- GUIDED still refuses a jump ----
  // This is the behaviour every existing athlete has. If Open leaks into Guided, they lose the
  // rail they chose without ever being asked.
  EV(`S.week=${tw}; S.day=${JSON.stringify(codes[0])};`);
  const guidedFirst=EV('dayActiveNow()');
  EV(`S.day=${JSON.stringify(codes[codes.length-1])};`);
  const guidedJump=EV('dayActiveNow()');
  chk('Guided: the session in sequence is live', guidedFirst===true);
  chk('Guided: a session out of sequence is still a preview', guidedJump===false,
      'the sequence rail is gone for everyone, not just the athletes who asked');
  chk('Guided: and it renders as a preview', EV('isPreviewing()')===true);

  // ---- OPEN lets him jump ----
  EV(`S.splitMode='open'; S.wd=null; S.week=${tw};`);
  let jumpBad=0;
  codes.forEach(c=>{ EV(`S.day=${JSON.stringify(c)};`); if(EV('dayActiveNow()')!==true) jumpBad++; });
  chk('Open: every session this week is live, in any order', jumpBad===0, jumpBad+' still locked');
  EV(`S.day=${JSON.stringify(codes[codes.length-1])};`);
  chk('Open: nothing renders as a sequence preview', EV('isPreviewing()')===false);

  // ---- what Open must NOT do ----
  // 1. next week. Loads change with the week; a rhythm is not a time machine.
  EV(`S.week=${tw+1}; S.day=${JSON.stringify(codes[0])};`);
  chk('Open cannot reach into next week', EV('dayActiveNow()')===false,
      'the athlete just pulled next week\'s loads forward');
  chk('and next week still reads as a preview', EV('isPreviewing()')===true);
  EV(`S.week=${tw};`);

  // 2. a second session in one day.
  EV(`S.day=${JSON.stringify(codes[0])};`);
  const before=EV('dayActiveNow()');
  EV(`(function(){ var p=curLOGP(), t=String(shiftDate());
       logKeys=(logKeys||[]).concat([p+t+'-'+${JSON.stringify(codes[0])}+'-W'+S.week+'B'+cyc()]); })();`);
  chk('one session a day still holds in Open', before===true && EV('loggedToday()')===true
      && codes.every(c=>{ EV(`S.day=${JSON.stringify(c)};`); return EV('dayActiveNow()')===false; }),
      'Open turned into unlimited sessions per day');
  EV('logKeys=(logKeys||[]).slice(0,-1);');

  // 3. the integrity lock on a banked session. Sequence and integrity are different locks and
  //    only the sequence one is Open's business.
  EV(`S.day=${JSON.stringify(codes[0])}; S.locked=S.locked||{}; S.locked[dayKey()]=1;`);
  chk('a banked day stays locked in Open', EV('dayLocked()')===true,
      'Open took down the lock that protects finished work');
  EV('delete S.locked[dayKey()];');

  // ---- the weekday map ----
  EV(`S.splitMode='open'; S.wd=['MO','TU','WE','TH','FR','SA'];`);
  const map=JSON.parse(EV('JSON.stringify(schedMap())'));
  console.log('  weekday map:', Object.keys(map||{}).map(k=>k+'->'+map[k]).join(' '));
  chk('a map is built from the chosen days', !!map && Object.keys(map).length===6);
  chk('codes are dealt in week order, not tap order',
      !!map && map.MO===codes[0] && map.TU===codes[1%codes.length] && map.WE===codes[2%codes.length]);
  // his tester: push Mon/Thu, pull Tue/Fri, legs Wed/Sat. With a 3-code split that is exactly
  // the rotation repeating, and it must NOT drift when a day is missed.
  if(codes.length===3)
    chk('a 3-day split over 6 days lands his exact week',
        map.MO===map.TH && map.TU===map.FR && map.WE===map.SA, JSON.stringify(map));
  else {
    // Neither shipped card has a 3-code split, and his tester's case is exactly a 3-code split
    // over 6 days. Prove it on a stubbed plan rather than skipping the case the feature is for.
    const stub=JSON.parse(EV(`(function(){ var keep=PLAN.days;
      PLAN.days=[{code:'A',title:'Push'},{code:'B',title:'Pull'},{code:'C',title:'Legs'}];
      S.splitMode='open'; S.wd=['MO','TU','WE','TH','FR','SA'];
      var m=schedMap(); PLAN.days=keep; return JSON.stringify(m); })()`));
    console.log('  3-code split over 6 days:', Object.keys(stub).map(k=>k+'->'+stub[k]).join(' '));
    chk('his tester\'s week: push Mon/Thu, pull Tue/Fri, legs Wed/Sat',
        stub.MO==='A'&&stub.TH==='A'&&stub.TU==='B'&&stub.FR==='B'&&stub.WE==='C'&&stub.SA==='C',
        JSON.stringify(stub));
    EV(`S.wd=['MO','TU','WE','TH','FR','SA'];`);
  }

  // tap order must not change the answer
  EV(`S.wd=['SA','MO','WE','TU','FR','TH'];`);
  chk('picking the days in a different order builds the same map',
      JSON.stringify(JSON.parse(EV('JSON.stringify(schedMap())')))===JSON.stringify(map));

  // the map is Open's alone
  EV("S.splitMode='guided';");
  chk('switching back to Guided retires the map', EV('schedMap()')===null,
      'a Guided athlete would start being routed by weekday');
  chk('and schedTodayCode goes quiet with it', EV('schedTodayCode()')===null);

  // ---- switching rhythm costs no history ----
  const keysBefore=EV('(logKeys||[]).length'), logBefore=EV('JSON.stringify(S.adLog||[])');
  EV("S.splitMode='open'; S.wd=['MO','WE','FR']; save(); S.splitMode='guided'; S.wd=null; save();");
  chk('switching rhythm touches no logs', EV('(logKeys||[]).length')===keysBefore
      && EV('JSON.stringify(S.adLog||[])')===logBefore);

  // ---- volume adaptation is advisory, which is what makes Open safe for it ----
  // Open lets an athlete run three push days in a week. That is only safe because the volume
  // rule REPORTS and never reshapes the plan - if it ever starts applying, this check fails
  // and the cadence question has to be answered before Open ships.
  const volApplies=EV(`(function(){ var s=String(adaptRun);
      return /kind:'volume'/.test(s) && /(S\\.vol|applyVolume|volAdj)/.test(s); })()`);
  chk('a volume adaptation still only advises, never reshapes the plan', volApplies===false,
      'Open would let cadence drive real set changes');

  // ---- FIELD 2026-09-02: locked out while BEHIND the calendar ----
  // The first cut gated Open on S.week!==timeWeek(), so an athlete who had not trained for a
  // week found every session locked - the report was "still getting the lock under I run it".
  // Being behind the calendar must never gate anything. Only the future is closed.
  EV("S.splitMode='open'; S.wd=null; __tw=timeWeek; timeWeek=function(){return 4;};");
  EV(`S.week=2; S.day=${JSON.stringify(codes[0])};`);
  chk('behind the calendar in Open is still live, not locked', EV('dayActiveNow()')===true,
      'an athlete who missed a week is locked out of their own card');
  chk('and it does not render as a preview', EV('isPreviewing()')===false);
  EV("S.week=5;");
  chk('but the future is still closed', EV('dayActiveNow()')===false);
  EV("S.week=2; syncToNext();");
  chk('opening the card brings a stale week up to the calendar', EV('S.week')===4,
      'logs would be written into a week that is already spent');
  EV("timeWeek=__tw;");
  EV(`S.week=${tw}; S.day=${JSON.stringify(codes[0])};`);

  // ---- FIELD 2026-09-02: setup step routing ----
  // 'weekdays' is only asked of Open, so the step list is CONDITIONAL. Anything indexing the
  // static full array instead desyncs from step 7 on - Back and skip land on the wrong screen,
  // which is what "what happened to choosing your split" was.
  if(EV('typeof ONB_STEPS_FULL')!=='undefined'){
    // Scan every function the card defines, not just wire(): the offending line sat in the
    // onboarding wiring, and a check that looks in one place found nothing on a broken copy.
    const srcBad=EV(`(function(){
        var src='', seen={};
        Object.getOwnPropertyNames(window).forEach(function(n){
          try{ var v=window[n];
            if(typeof v==='function' && !seen[n]){ seen[n]=1; src+=String(v); } }catch(e){}
        });
        return /ONB_STEPS\\s*\\[/.test(src) || /ONB_STEPS\\s*\\.(length|indexOf)/.test(src); })()`);
    chk('no step navigation indexes the static step list', srcBad===false,
        'a conditional step desyncs Back, skip and the review jump');
    EV("var __o3=ONB(); __o3.rhythm='guided';");
    const forS=JSON.parse(EV('JSON.stringify(ONB_STEPS_FOR())'));
    chk('choosing your split is still in the flow for both rhythms', forS.indexOf('schedule')>-1);
    EV("var __o4=ONB(); __o4.rhythm='open';");
    chk('and still there in Open', JSON.parse(EV('JSON.stringify(ONB_STEPS_FOR())')).indexOf('schedule')>-1);
  }

  // ---- FIELD 2026-09-02: the whole week logged, and Open had no door left ----
  // Guided reopens the cell on its own when the rotation comes round. Open never did, so an
  // athlete who trained their whole week early was locked out until the calendar rolled.
  // read the week LIVE rather than reusing a number captured at boot - timeWeek() is derived
  // from the block start date and can move under a long-running harness
  // pin the week ONCE: timeWeek() is derived from the block start date and moved under this
  // harness between two calls a line apart, which made the fixture disagree with itself
  // call it twice on purpose: the first call runs before the block start date is settled and
  // reports the wrong week, which made this fixture build logs for a week the card was not in
  // pin the clock outright for this block. timeWeek() is derived from the block start date and
  // is genuinely unstable in a fresh fixture - it reported 1, then 2, a line apart - so the
  // fixture kept disagreeing with the card about which week it was in. Stub it, like the
  // behind-the-calendar block above does, and the state under test is unambiguous.
  EV("__twR=timeWeek; timeWeek=function(){return 2;};");
  EV(`__W=timeWeek(); (function(){ var p=curLOGP(), C=cyc();
      logKeys=PLAN.days.map(function(d){ return p+'2026-08-20-'+d.code+'-W'+__W+'B'+C; }); })();
      S.splitMode='open'; S.wd=null; S.week=__W; S.day=${JSON.stringify(codes[1])}; S.rePass=null;`);
  chk('a finished session reads as a document, not a live one', EV('isVisiting()')===true);
  chk('and the repeat-pass door is offered', EV('canRePass()')===true,
      'the athlete has trained every session this week and has nowhere to go');
  chk('the door is worded as a choice, not a warning',
      /Train this again/.test(EV('reviewBarHTML()')) && /still counts/.test(EV('reviewBarHTML()')));
  const logsBefore=EV('(logKeys||[]).length');
  EV('rePassGo();');
  chk('taking it makes the session live again', EV('dayActiveNow()')===true && EV('isVisiting()')===false);
  chk('the finished session is NOT deleted', EV('(logKeys||[]).length')===logsBefore,
      'a repeat pass destroyed the work it was repeating');
  chk('and the door closes behind it', EV('canRePass()')===false);
  // the limits still hold
  EV(`(function(){ var p=curLOGP(), t=String(shiftDate());
      logKeys=(logKeys||[]).concat([p+t+'-'+${JSON.stringify(codes[2])}+'-W'+S.week+'B'+cyc()]); })();`);
  EV(`S.day=${JSON.stringify(codes[1])}; S.week=__W; S.rePass=null;`);
  chk('no repeat pass once something is logged today', EV('canRePass()')===false,
      'one session a day is gone');
  EV('logKeys=(logKeys||[]).slice(0,-1);');
  EV("S.splitMode='guided'; S.rePass=null;");
  chk('Guided is never shown the door - it reopens on its own', EV('canRePass()')===false);
  EV(`S.splitMode='open'; S.week=__W+1;`);
  chk('and no repeat pass into another week', EV('canRePass()')===false);
  EV("timeWeek=__twR;");
  EV(`S.week=timeWeek(); S.rePass=null; logKeys=[];`);

  // ---- the control is on screen and bound ----
  if(EV('typeof SET_OPEN')!=='undefined'){
    EV("S.splitMode='guided'; S.wd=null; SET_OPEN=true; settingsSync();");
    const chips=[...D.querySelectorAll('#setHost [data-splitmode]')].map(c=>c.getAttribute('data-splitmode'));
    chk('the rhythm control offers both rhythms', ['guided','open'].every(v=>chips.indexOf(v)>-1),
        'found: '+chips.join(','));
    chk('the weekday grid is hidden while Guided', D.querySelectorAll('#setHost [data-setwd]').length===0,
        'Guided is being shown a timetable it does not use');
    const openChip=D.querySelector('#setHost [data-splitmode="open"]');
    openChip.dispatchEvent(new w.MouseEvent('click',{bubbles:true}));
    chk('tapping it switches rhythm', EV('S.splitMode')==='open');
    chk('and the weekday grid appears with it', D.querySelectorAll('#setHost [data-setwd]').length===7);
    chk('Open arrives with sensible days already chosen', (EV('(S.wd||[]).length'))>0);
    const wdBtn=D.querySelector('#setHost [data-setwd="SU"]');
    const had=EV("(S.wd||[]).indexOf('SU')>-1");
    wdBtn.dispatchEvent(new w.MouseEvent('click',{bubbles:true}));
    chk('a weekday toggles', EV("(S.wd||[]).indexOf('SU')>-1")!==had);
    chk('the settings sheet survives all of it', !!D.querySelector('#setHost .set-sheet'));
    const back=D.querySelector('#setHost [data-splitmode="guided"]');
    back.dispatchEvent(new w.MouseEvent('click',{bubbles:true}));
    chk('going back to Guided clears the map', EV('S.splitMode')==='guided' && !EV('S.wd'));
  }

  // ---- setup asks the question, in words, and only asks about weekdays if it matters ----
  if(EV('typeof ONB_STEPS_FULL')!=='undefined'){
    chk('setup asks which rhythm', EV("ONB_STEPS_FULL.indexOf('rhythm')")>-1);
    EV("var __o=ONB(); __o.rhythm='guided';");
    chk('Guided is never asked for weekdays', EV("ONB_STEPS_FOR().indexOf('weekdays')")===-1);
    EV("var __o2=ONB(); __o2.rhythm='open';");
    chk('Open is', EV("ONB_STEPS_FOR().indexOf('weekdays')")>-1);
    const html=EV("(function(){ try{ var o=ONB(); o.step=ONB_STEPS_FOR().indexOf('rhythm'); return (typeof ONB_HTML==='function')? ONB_HTML() : ''; }catch(e){ return ''; } })()");
    if(html) chk('the question explains what a missed day costs, not just the setting',
        /Miss a day/.test(html) && /weekday/i.test(html), 'the copy is the whole feature here');
  } else {
    console.log('  (no setup generator on this card - the settings control is the front door)');
  }

  console.log('  problems:', bad);
  process.exit(bad?1:0);
},1500);
