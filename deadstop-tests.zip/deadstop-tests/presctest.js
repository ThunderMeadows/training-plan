// The day's prescription must be immutable from the rest screen. What the athlete adjusts
// there is the weight actually put on the bar for that set - and THAT anchors the next session.
//
// Drives the real controls: taps "tap to adjust" on the rest chip, then the real -/+ buttons.
// An earlier version reimplemented the stepper inside the harness and so could not have
// caught a regression in it.
const { JSDOM } = require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const dom=new JSDOM(fs.readFileSync(f,'utf8'),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://thundermeadows.github.io/'});
const w=dom.window,D=w.document,EV=e=>w.eval(e);
w.AudioContext=w.AudioContext||function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
const click=el=>el.dispatchEvent(new w.MouseEvent('click',{bubbles:true,cancelable:true,view:w}));

setTimeout(()=>{
  console.log(`\n--- ${L}: the rest screen must not edit the prescription ---`);
  EV('try{TOUR.live=false;}catch(e){} try{S.tour={done:true};}catch(e){}');
  for(const fn of ['coachIdle','ONB_ACTIVE','isStartMode']) EV(`if(typeof ${fn}==="function") ${fn}=function(){return false;};`);
  EV('S.maxes={squat:327,bench:225,dead:405,ohp:145,pull:225}; render();');
  const idx=EV(`(function(){var d=dayObj();for(var i=0;i<d.exercises.length;i++){if(d.exercises[i].loadNum!=null) return i;}return -1;})()`);
  if(idx<0){ console.log('  (no numeric exercise on this day)  problems: 0'); process.exit(0); }
  const info=JSON.parse(EV(`JSON.stringify((function(){
    var ex=dayObj().exercises[${idx}], st=exState(${idx},ex);
    delete st.w; st.sets.forEach(function(s){ s.st='pend'; delete s.w; });
    st.sets[0].st='hit'; st.sets[0].reps=5; st.sets[0].t=Date.now()-30000; save();
    return {plan: baseLoad(ex), name: ex.name};})())`));
  console.log(`  exercise: ${info.name}, prescribed ${info.plan} lb`);

  EV('paintRest(true);');
  let bad=0;
  const adj=D.querySelector('[data-rwadj]');
  if(!adj){ console.log('  no weight control on the rest screen  problems: 1'); process.exit(1); }
  click(adj);                                   // open the stepper
  const downs=[...D.querySelectorAll('[data-rwe]')].filter(b=>+b.dataset.rwe<0);
  if(!downs.length){ console.log('  stepper did not open  problems: 1'); process.exit(1); }
  click(downs[0]); EV('paintRest(true);');
  click([...D.querySelectorAll('[data-rwe]')].filter(b=>+b.dataset.rwe<0)[0]);

  const plan2=EV(`(function(){return baseLoad(dayObj().exercises[${idx}]);})()`);
  const stw  =EV(`(function(){var st=exState(${idx},dayObj().exercises[${idx}]);return st.w==null?'unset':st.w;})()`);
  const sw   =EV(`(function(){var st=exState(${idx},dayObj().exercises[${idx}]);return st.sets[1].w==null?'unset':st.sets[1].w;})()`);
  console.log('  set 2 performed wt  :', sw);
  console.log('  prescription still  :', plan2, plan2===info.plan?'(unchanged)':'<-- PRESCRIPTION EDITED');
  console.log('  exercise override   :', stw, stw==='unset'?'(untouched)':'<-- PRESCRIPTION EDITED');
  if(plan2!==info.plan) bad++;
  if(stw!=='unset') bad++;
  if(sw==='unset') { console.log('  the adjustment was not recorded on the set'); bad++; }

  // what carries forward must be the performed weight, not the plan
  EV(`(function(){var st=exState(${idx},dayObj().exercises[${idx}]);
    st.sets.forEach(function(s){ if(s.st==='pend'){ s.st='hit'; s.reps=5; } }); return 1;})()`);
  EV('S.lastPerf={}; S.when={date:"2026-08-28",time:""}; recordPerf();');
  const carried=EV(`(function(){var lp=S.lastPerf[${JSON.stringify(info.name)}]; return lp? lp.w : null;})()`);
  const wantCarry = (sw==='unset')? info.plan : sw;
  console.log('  carried to next time:', carried, carried===wantCarry?'(the performed weight)':'<-- wanted '+wantCarry);
  if(carried!==wantCarry) bad++;
  console.log('  problems:', bad);
  process.exit(bad?1:0);
},1500);
