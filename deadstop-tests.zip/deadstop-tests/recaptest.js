// The finish prompt must carry a share button, must describe what was actually logged, and
// must come back after cardio or an extra lift - not only after the programmed work.
const { JSDOM } = require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const dom=new JSDOM(fs.readFileSync(f,'utf8'),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://thundermeadows.github.io/'});
const w=dom.window,D=w.document,EV=e=>w.eval(e);
w.AudioContext=w.AudioContext||function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
const click=el=>el&&el.dispatchEvent(new w.MouseEvent('click',{bubbles:true,cancelable:true,view:w}));
setTimeout(async ()=>{
  console.log(`\n--- ${L}: the finish prompt ---`);
  let bad=0; const chk=(l,ok,d)=>{ if(!ok) bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&d?'  <-- '+d:''}`); };
  EV('try{TOUR.live=false;}catch(e){} try{S.tour={done:true};}catch(e){}');
  for(const fn of ['coachIdle','ONB_ACTIVE','isStartMode']) EV(`if(typeof ${fn}==="function") ${fn}=function(){return false;};`);
  EV('S.maxes={squat:327,bench:225,dead:405,ohp:145,pull:225}; S.prShow=null; S.prRecap=0; render();');
  chk('no prompt before anything is done', !D.querySelector('.prbar'));
  // log a full session
  EV(`(function(){var d=dayObj(); d.exercises.forEach(function(ex,i){ var st=exState(i,ex);
      st.sets.forEach(function(s){ if(s.st==='pend'){ stampPerf(ex,st,s); s.st='hit'; s.t=Date.now(); } }); });
      save(); return 1;})()`);
  // the recap text must reflect LOGGED work
  const txt=EV('sessionRecapText()');
  chk('recap lists what was logged', /x\s?\d/.test(txt) && /sets/.test(txt), txt.slice(0,60));
  chk('recap counts volume', /moved/.test(txt));
  // banner with a record
  EV(`S.prs=[{d:(S.when&&S.when.date)||localDate(),ex:'Bench Press',kind:'weight',val:200,prev:190}];
       S.prShow=[{ex:'Bench Press',kind:'weight',val:200,prev:190}]; S.prHide=0; save(); render();`);
  chk('records prompt appears', !!D.querySelector('.prbar'));
  chk('share button present', !!D.querySelector('[data-prshare]'));
  chk('records listed in the share text', /PERSONAL RECORD/.test(EV('sessionRecapText()')));
  // sharing without navigator.share must fall back to the clipboard, not fail silently
  let copied=null;
  w.navigator.share=undefined;
  Object.defineProperty(w.navigator,'clipboard',{value:{writeText:t=>{copied=t;return Promise.resolve();}},configurable:true});
  // Force the no-canvas condition rather than relying on the environment lacking one: whether
  // jsdom can draw depends on whether the optional canvas package happens to be installed, and
  // a test that changes meaning with the machine is not a test.
  const realCreate=D.createElement.bind(D);
  D.createElement=function(t){ const el=realCreate(t); if(t==='canvas') el.getContext=function(){ return null; }; return el; };
  click(D.querySelector('[data-prshare]'));
  await new Promise(r=>setTimeout(r,1800));  // art has a 1.5s deadline before the card gives up
  chk('falls back to copying when there is no canvas', copied && copied.length>20, 'nothing copied');
  D.createElement=realCreate;
  // the day's records must survive a dismiss - same day, same records
  EV(`S.prs=[{d:(S.when&&S.when.date)||localDate(),ex:'Bench Press',kind:'weight',val:200,prev:190}];`);
  chk('todayPRs reads the day ledger', EV('todayPRs().length')===1);
  // dismiss, then finish cardio: it must come back WITH the records still on it
  click(D.querySelector('[data-prclose]')); EV('render();');
  chk('dismiss clears it', !D.querySelector('.prbar'));
  EV('recapAgain(); render();');
  chk('comes back after cardio or an extra lift', !!D.querySelector('.prbar'),
      'recapAgain did not re-open the prompt');
  chk('and still offers the share', !!D.querySelector('[data-prshare]'));
  chk('still shows the day\u2019s record after cardio',
      /Bench Press/.test(D.querySelector('.prbar').textContent),
      'the record vanished because the prompt reopened');
  chk('a designed image is what gets shared', EV('typeof shareRecapImage')==='function');
  // the shared bear must wear the athlete's chosen flavour, not the amber original
  chk('the share card reads the chosen flavour',
      /gbFlavour\(\)/.test(EV('String(shareCardPaint)')), 'the bear would always post as Amber');
  chk('and tints the sprite itself rather than trusting ctx.filter',
      /tintSprite/.test(EV('String(shareCardPaint)')) && EV('typeof tintSprite')==='function',
      'ctx.filter can read as supported and still do nothing to drawImage');
  chk('and it falls back to text when canvas is unavailable',
      /shareRecap\(\);/.test(EV('String(shareRecapImage)')), 'no fallback path');
  console.log(`  runtime errors: ${EV('(typeof ERR_LOG!=="undefined"?ERR_LOG.length:"n/a")')}`);
  console.log('  problems:', bad);
  process.exit(bad?1:0);
},1500);
