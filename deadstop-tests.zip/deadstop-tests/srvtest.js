// v225. The card talks to the Worker. What the server can say, and what the card must do about
// it — tested against a faked endpoint, so the suite never touches the network and a Cloudflare
// outage can never turn this file red.
//
// The rule that matters more than the security: an athlete in a gym does not care whose fault a
// network is. Training NEVER touches the network. Only entering a code, and a check about once
// a week. A check that cannot get through buys SRV_GRACE more days, not a locked card.
const {JSDOM}=require('jsdom'); const fs=require('fs'); const path=require('path');
const f=process.argv[2], L=process.argv[3]||f;
const raw=fs.readFileSync(f,'utf8');
// SECURITY 2026-09-10: see fixture-codes.js - synthetic codes, installed into the card.
const FX=require('./fixture-codes');
const CODES=FX.loadCodes();
let bad=0; const chk=(l,ok,d)=>{ if(!ok)bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&d?'  <-- '+d:''}`); };
const sleep=ms=>new Promise(r=>setTimeout(r,ms));

// a fake Worker: answers what the test tells it to, and records every request
function boot(reply, store){
  const calls=[];
  const d=new JSDOM(raw,{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/',beforeParse(w){
    Object.keys(store||{}).forEach(k=>w.localStorage.setItem(k,store[k]));
    w.fetch=async(url,opt)=>{ let body={}; try{ body=JSON.parse(opt.body); }catch(e){}
      calls.push({url:String(url), body});
      const r=reply(String(url), body);
      if(r===null) throw new Error('network');           // unreachable, not a refusal
      return {json:async()=>r};
    };
    w.AbortController=function(){ this.signal=null; this.abort=function(){}; };
    w.AudioContext=function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
  }});
  // the card fetches its own assets at boot (the gallery index, for one). Only /v1/ calls are
  // this file's business - an early cut indexed calls[0] blindly and tested a picture manifest.
  d.__calls=calls; d.__api=()=>calls.filter(c=>/\/v1\//.test(c.url)); try{ FX.installCodes(e=>{ try{ return d.window.eval(e); }catch(err){ return 'ERR '+err.message; } }, CODES); }catch(e){}
  return d;
}
const EVf=w=>e=>{ try{ return w.eval(e); }catch(err){ return 'ERR '+err.message; } };
const enter=(w,code)=>w.eval(`(function(){ var i=document.getElementById('accessIn'); if(!i) return 'no gate'; i.value=${JSON.stringify(code)};
  document.getElementById('accessOk').click(); return 'ok'; })()`);
const msg=E=>String(E('(document.getElementById("accessMsg")||{}).textContent||""'));
const dump=w=>{ const o={}; for(let i=0;i<w.localStorage.length;i++){ const k=w.localStorage.key(i); o[k]=w.localStorage.getItem(k); } return o; };

setTimeout(async ()=>{
  console.log(`\n--- ${L}: the card and the server ---`);
  chk('(fixture) the harness has batch codes', !!(CODES&&CODES.batches&&CODES.batches.length), 'fixture-codes.js produced no batches');
  if(!CODES) { console.log('\nproblems: '+bad); process.exit(1); }
  const KEY=CODES.batches[0].athlete[0], KEY2=CODES.batches[0].athlete[1];

  // ---- the device id ----
  let d=boot(()=>({ok:true,role:'athlete'})); await sleep(2400); let E=EVf(d.window);
  chk('the card makes itself one random device id and keeps it',
      /^[A-Za-z0-9_-]{22}$/.test(E('srvDev()')) && E('srvDev()')===E('srvDev()') && E('S.devId')===E('srvDev()'), E('srvDev()'));
  chk('the device id is not derived from anything about the athlete',
      E('(function(){ var a=srvDev(); return a.indexOf(S.profileName||"zzz")<0 && !/\\d{4}-\\d{2}-\\d{2}/.test(a); })()'), 'the id looks derived');

  // ---- server says yes ----
  enter(d.window, KEY); await sleep(250);
  const call=d.__api()[0]||{};
  chk('entering a code asks the server to claim it', /\/v1\/activate$/.test(call.url||''), JSON.stringify(call.url));
  // ADAPTED 2026-09-11 for the W1 fix. This used to require the body be exactly {build,dev,fp}.
  // That encoded the vulnerable protocol: the fingerprint is printed in every copy of the app,
  // so the server accepting it as proof let anyone claim a seat from view-source. The card now
  // sends the CODE, which is the actual secret, over TLS. The BEHAVIOURAL assertion is unchanged
  // and is the one that matters - the request carries access credentials and NOTHING ELSE, no
  // training content ever - so it is written that way now rather than as a fixed key list.
  chk('and sends only access credentials - the code, fingerprint, device and build - and no training data',
      call.body && Object.keys(call.body).sort().join(',')==='build,code,dev,fp'
        && /^[0-9a-f]{64}$/.test(call.body.fp)
        && typeof call.body.code==='string'
        && !Object.keys(call.body).some(function(k){ return /set|rep|weight|max|log|session|note|plan|name|body/i.test(k); }),
      JSON.stringify(call.body));
  chk('a yes lets the athlete in and records when it was checked', E('accessRole()')==='athlete' && !!E('(S.access||{}).ck'), 'role '+E('accessRole()'));

  // ---- the refusals ----
  for(const [reason, want] of [['inuse','already set up on another phone'],['revoked','has been turned off'],['expired','has expired']]){
    const d2=boot(()=>({ok:false,reason})); await sleep(2400); const E2=EVf(d2.window);
    enter(d2.window, KEY); await sleep(250);
    chk('"'+reason+'" refuses entry outright', E2('accessRole()')===null, 'role '+E2('accessRole()'));
    chk('  and says so in words an athlete can act on', msg(E2).indexOf(want)>-1, msg(E2));
    chk('  and leaves nothing behind that would let a retry sneak in',
        E2('!S.access && (S.usedKeys||[]).length===0'), 'usedKeys '+E2('JSON.stringify(S.usedKeys)'));
  }

  // ---- THE POINT: one code, one phone ----
  const claimed={};
  const oneSeat=(u,b)=>{ if(!/activate/.test(u)) return {ok:true,role:'athlete'};
    if(claimed[b.fp] && claimed[b.fp]!==b.dev) return {ok:false,reason:'inuse'};
    claimed[b.fp]=b.dev; return {ok:true,role:'athlete'}; };
  const phone1=boot(oneSeat); await sleep(2400); const P1=EVf(phone1.window);
  enter(phone1.window, KEY); await sleep(250);
  const phone2=boot(oneSeat); await sleep(2400); const P2=EVf(phone2.window);
  enter(phone2.window, KEY); await sleep(250);
  chk('the first phone gets in', P1('accessRole()')==='athlete', 'phone 1 role '+P1('accessRole()'));
  chk('a SECOND phone on the same code does not \u2014 the hole a static file could never close',
      P2('accessRole()')===null && msg(P2).indexOf('another phone')>-1, 'phone 2 role '+P2('accessRole()')+' msg '+msg(P2));
  enter(phone2.window, KEY2); await sleep(250);
  chk('and that second athlete gets in fine on their own code', P2('accessRole()')==='athlete', 'role '+P2('accessRole()'));

  // ---- v226: the iPhone install trap ----
  // On iOS the Home Screen copy has its own storage, so an athlete who enters a code in Safari
  // and then installs arrives as a second device and is refused from the copy they train on.
  function iBoot(reply, installed){
    const calls=[];
    const d=new JSDOM(raw,{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/',beforeParse(w){
      Object.defineProperty(w.navigator,'userAgent',{value:'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 Safari/604.1'});
      if(installed) Object.defineProperty(w.navigator,'standalone',{value:true});
      w.fetch=async(u,o)=>{ let b={}; try{ b=JSON.parse(o.body); }catch(e){} calls.push({url:String(u),body:b}); const r=reply(String(u),b); if(r===null) throw new Error('network'); return {json:async()=>r}; };
      w.AbortController=function(){ this.signal=null; this.abort=function(){}; };
      w.AudioContext=function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
    }});
    d.__calls=calls; d.__api=()=>calls.filter(c=>/\/v1\//.test(c.url)); return d;
  }
  const safari=iBoot(()=>({ok:true,role:'athlete'}), false); await sleep(2400); const SF=EVf(safari.window);
  chk('an uninstalled iPhone is not offered the code box at all', !SF('!!document.getElementById("accessIn")'), 'the code box is there to be spent in the wrong copy');
  chk('  it is told to install first, in steps it can follow',
      /Home Screen first/.test(SF('(document.getElementById("accessGate")||{}).textContent||""')) && /Share button/.test(SF('(document.getElementById("accessGate")||{}).textContent||""')), 'no install instructions');
  chk('  and no code was spent doing it', safari.__api().length===0, 'the card called the server before installing');
  chk('  but a determined athlete is not trapped - there is a way through', SF('!!document.getElementById("accessAnyway")'), 'no escape hatch');
  const installed=iBoot(()=>({ok:true,role:'athlete'}), true); await sleep(2400); const IN=EVf(installed.window);
  chk('the installed copy asks for the code normally', IN('!!document.getElementById("accessIn")'), 'installed iPhone got the install screen');
  const android=boot(()=>({ok:true,role:'athlete'})); await sleep(2400); const AN=EVf(android.window);
  chk('Android is untouched - its installed app shares storage, so nothing to warn about', AN('!!document.getElementById("accessIn")'), 'Android got the iOS screen');

  // ---- offline: the rule that protects the athlete ----
  const off=boot(()=>null); await sleep(2400); const O=EVf(off.window);
  enter(off.window, KEY); await sleep(250);
  chk('a server that cannot be reached does NOT lock a new athlete out', O('accessRole()')==='athlete', 'role '+O('accessRole()'));
  chk('  the card notes it has not been checked yet', O('(S.access||{}).ck')===null, 'ck '+O('String((S.access||{}).ck)'));
  chk('  and training does not go near the network',
      (function(){ const before=off.__api().length;
        O(`(function(){ var n=nextSession(); S.day=n.code; S.week=n.week; S.tour={done:true}; if(typeof ONB!=="undefined"){ONB().done=true;} S.discAck={v:DISC_V,d:localDate()}; save();
          var dd=dayObj(); dd.exercises.forEach(function(ex,i){ var st=exState(i,ex); st.sets.forEach(function(s2){ s2.st='hit'; s2.reps=8; s2.rir=2; }); }); save(); render(); })()`);
        return off.__api().length===before; })(), 'training made a network call');

  // grace: still in on day 13, out on day 15
  const graced=boot(()=>null, dump(off.window)); await sleep(2400); const G=EVf(graced.window);
  G('(function(){ var a=S.access; a.ck=(function(){ var q=new Date(shiftDate()+"T12:00:00"); q.setDate(q.getDate()-13); return q.toISOString().slice(0,10); })(); save(); })()');
  await G('srvCheck(true)'); await sleep(60);
  chk('thirteen days without reaching the server: still training', G('accessRole()')==='athlete', 'locked out inside the grace');
  G('(function(){ var a=S.access; a.ck=(function(){ var q=new Date(shiftDate()+"T12:00:00"); q.setDate(q.getDate()-15); return q.toISOString().slice(0,10); })(); save(); })()');
  await G('srvCheck(true)'); await sleep(60);
  chk('fifteen days: access stops and the gate asks for a code', G('accessRole()')===null && G('!!document.getElementById("accessGate")'), 'role '+G('accessRole()'));

  // ---- revocation reaches a phone already in ----
  const rev=boot((u)=>/check/.test(u)? {ok:false,reason:'revoked'} : {ok:true,role:'athlete'}); await sleep(2400); const R=EVf(rev.window);
  enter(rev.window, KEY); await sleep(250);
  chk('(fixture) in, before the revoke', R('accessRole()')==='athlete', 'role '+R('accessRole()'));
  await R('srvCheck(true)'); await sleep(60);
  chk('revoking reaches a phone that is already in, at its next check', R('accessRole()')===null, 'still in after a revoke');

  // ---- the weekly rhythm, and what rides along ----
  const wk=boot(()=>({ok:true,role:'athlete'})); await sleep(2400); const W=EVf(wk.window);
  enter(wk.window, KEY); await sleep(250);
  const n0=wk.__api().length;
  await W('srvCheck()'); await sleep(40);
  chk('a card checked today does not check again', wk.__api().length===n0, 'checked twice in a day');
  W('(function(){ var a=S.access; a.ck=(function(){ var q=new Date(shiftDate()+"T12:00:00"); q.setDate(q.getDate()-1); return q.toISOString().slice(0,10); })(); save(); srvCount("sessions",3); srvCount("prints",1); srvCount("BAD NAME",9); })()');
  await W('srvCheck()'); await sleep(40);
  const chkCall=wk.__api().filter(c=>/check/.test(c.url)).pop()||{};
  chk('the next day it checks again (v229: daily, so "who is active" means today)', !!chkCall.url, 'no check the next day');
  chk('the counters ride along with it', chkCall.body && chkCall.body.use && chkCall.body.use.sessions===3 && chkCall.body.use.prints===1, JSON.stringify(chkCall.body&&chkCall.body.use));
  chk('a malformed counter name never leaves the card', !(chkCall.body&&chkCall.body.use&&('BAD NAME' in chkCall.body.use)), JSON.stringify(chkCall.body&&chkCall.body.use));
  chk('counters are cleared once they are in', W('Object.keys(S.useCt||{}).length')===0, 'counters kept after sending');
  // the promise made in Settings, checked against what actually goes out
  // the BODIES only - the host is called deadstop-access, and an early cut of this check
  // matched the word "dead" inside its own URL and called it a privacy leak.
  const everything=JSON.stringify(wk.__api().map(c=>c.body));
  chk('nothing that could identify a person or their training is ever sent',
      !/profileName|weightLog|maxes|bench|squat|dead|ohp|report|reps|rir|"w":/.test(everything), 'a payload carried something it should not');
  chk('and Settings tells the athlete that in plain words',
      /never your training/.test(String(W('accessHTML()'))), 'no disclosure in Settings');

  // ---- v227 audit: the upgrade paths, and what a bad day at the server may not do ----------
  // Two of these would have locked out every existing athlete - including him - on first open.
  const pre=(access, reply)=>boot(reply||(()=>({ok:true,role:'athlete'})), {'nsc:training-card-v1':JSON.stringify({discAck:{v:1,d:'2026-09-01'}, tour:{done:true}, access})});
  let u=pre({role:'coach',since:'2026-09-07',until:'2026-12-06',via:'code'}, (uu,b)=>/check/.test(uu)? (b.fp? {ok:true}:{ok:false,reason:'unknown'}) : {ok:true}); await sleep(2600); let U=EVf(u.window);
  chk('a grant from before the server (no fingerprint) is left to run to its own date', U('accessRole()')==='coach' && !U('!!document.getElementById("accessGate")'), 'a v214 coach card was gated on first open');
  chk('  and no check is sent for it - there is nothing to verify', u.__api().filter(c=>/check/.test(c.url)).length===0, 'a check with no fingerprint went out');
  u=pre({role:'athlete',since:'2026-09-07',until:'2026-12-06',via:'legacy'}); await sleep(2600); U=EVf(u.window);
  chk('a legacy athlete is left alone too', U('accessRole()')==='athlete', 'legacy athlete gated');
  for(const [label, ans] of [['a 500 with reason:server',{ok:false,reason:'server'}],['an empty body',{}],['a 404 from a wrong route',{ok:false,reason:'route'}],['nonsense',{ok:'maybe'}]]){
    u=pre({role:'athlete',since:'2026-09-01',until:'2026-12-01',via:'code',fp:'a'.repeat(64),ck:'2026-09-01'}, (uu)=>/check/.test(uu)? ans : {ok:true}); await sleep(2600); U=EVf(u.window);
    chk(label+' at the weekly check is "could not ask", not a refusal', U('accessRole()')==='athlete', 'a non-definitive answer cleared access');
  }
  u=pre({role:'athlete',since:'2026-09-01',until:'2026-12-01',via:'code',fp:'a'.repeat(64),ck:'2026-09-01'}, (uu)=>/check/.test(uu)? {ok:false,reason:'revoked'} : {ok:true}); await sleep(2600); U=EVf(u.window);
  chk('a definitive refusal still clears', U('accessRole()')===null, 'revoke ignored');
  u=boot(()=>({ok:true,role:'coach'})); await sleep(2400); U=EVf(u.window);
  chk('a stamp in the future (clock set back) earns no extra grace',
      U('(function(){ S.access={role:"athlete",since:"2026-09-01",until:"2026-12-01",via:"code",fp:"a".repeat(64),ck:"2027-01-01"}; return srvGraceLeft()<=SRV_GRACE; })()'), 'grace '+U('srvGraceLeft()'));

  // ---- v228: the bridge - the card's Admin tab and the Worker -------------------------
  // "Build the bridge please. Its easier for me to run things through the admin in my card."
  // Before this, Unissue silently returned a key to the pool that the server still had claimed
  // by somebody's phone. Now the Worker is the truth and the tab is a view of it.
  const KV={}; const acalls=[];
  const adminSrv=(u,o)=>{ const auth=(o&&o.headers&&o.headers['Authorization'])||''; let b={}; try{ b=JSON.parse((o&&o.body)||'{}'); }catch(e){}
    acalls.push({u,b,auth});
    if(/\/v1\/admin/.test(u)){ if(auth!=='Bearer TOK') return {__status:401, ok:false, reason:'auth'};
      if(/stats/.test(u)) return {ok:true, stats:{totals:{activate:3,'use.sessions':12,'refuse.inuse':1}, devices:{week:2,month:3,builds:{v228:2}}, keys:{total:253,claimed:3,revoked:0}}};
      const fp=(u.match(/fp=([0-9a-f]{64})/)||[])[1]||b.fp; KV[fp]=KV[fp]||{devs:[],rev:false,exp:'2027-03-31'};
      if(o.method==='GET') return {ok:true, key:KV[fp]};
      if(typeof b.rev==='boolean') KV[fp].rev=b.rev; if(b.clearDevices) KV[fp].devs=[]; if(b.to) KV[fp].to=b.to;
      return {ok:true, key:KV[fp]}; }
    return {ok:true, role:'admin'}; };
  const ad=new JSDOM(raw,{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/',beforeParse(w){
    w.fetch=async(u,o)=>{ const r=adminSrv(String(u),o); return {status:r.__status||200, json:async()=>r}; };
    w.AbortController=function(){ this.signal=null; this.abort=function(){}; };
    w.AudioContext=function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
    w.confirm=()=>true; }});
  await sleep(2400); const A=EVf(ad.window);
  // This admin window is built by hand rather than through boot(), so it never received the
  // synthetic credentials boot() installs - the admin code below was one the card had never
  // heard of, and every admin assertion failed. Same install, same window.
  try{ FX.installCodes(A, CODES); }catch(e){}
  A('accessTry('+JSON.stringify(CODES.admin.code)+'); try{TOUR.live=false;}catch(e){} S.tour={done:true}; if(typeof ONB!=="undefined"){ONB().done=true;} S.discAck={v:DISC_V,d:localDate()}; storageOK=true; save(); S.day="ADMIN"; render();');
  chk('without a token the Admin tab asks to connect, and nothing else is offered', /Connect to the server/.test(A('document.getElementById("app").textContent')) && !A('!!document.querySelector("[data-adminrev]")'), 'server actions offered without a token');
  A('document.getElementById("adminTokIn").value="TOK"; document.querySelector("[data-admintok]").click();'); await sleep(350);
  chk('the token is kept on the admin\u2019s card and the numbers arrive', A('S.adminTok')==='TOK' && /2 active this week/.test(A('document.getElementById("app").textContent')), 'no numbers');
  A('document.getElementById("adminTo").value="Sam"; document.querySelector("[data-adminissue=athlete]").click();'); await sleep(250);
  const acode=A('S.adminIssued[0].code'), afp=A('accessFp(S.adminIssued[0].code)');
  chk('issuing writes the name to the server', KV[afp] && KV[afp].to==='Sam', JSON.stringify(KV[afp]));
  KV[afp].devs=['phone-1']; A('adminSync();'); await sleep(350);
  chk('the list shows live status from the server', /on 1 phone/.test(A('document.getElementById("app").textContent')), 'no live status');
  chk('a key somebody has entered cannot be Unissued - only Revoked', !A('!!document.querySelector("[data-adminforget]")') && A('!!document.querySelector("[data-adminrev][data-on=\\"1\\"]")'), 'Unissue still offered on a claimed key');
  A('document.querySelector("[data-adminrev][data-on=\\"1\\"]").click();'); await sleep(250);
  chk('Revoke reaches the server', KV[afp].rev===true, JSON.stringify(KV[afp]));
  chk('and the ledger keeps the key marked revoked - it does NOT go back into the pool', A('S.adminIssued.length')===1 && A('S.adminIssued[0].rev')===true && A('adminNext("athlete").code')!==acode, 'a revoked key returned to the pool');
  A('document.querySelector("[data-adminrev][data-on=\\"0\\"]").click();'); await sleep(250);
  chk('Un-revoke reaches the server', KV[afp].rev===false, JSON.stringify(KV[afp]));
  A('document.querySelector("[data-adminnewphone]").click();'); await sleep(250);
  chk('New phone clears the device on the server', KV[afp].devs.length===0, JSON.stringify(KV[afp]));
  chk('every admin request carried the token', acalls.filter(c=>/admin/.test(c.u)).length>0 && acalls.filter(c=>/admin/.test(c.u)).every(c=>c.auth==='Bearer TOK'), 'a request went without the token');
  A('S.adminTok="WRONG"; adminSync();'); await sleep(350);
  chk('a wrong token is said plainly, with a way to re-enter it', /did not accept the token/.test(A('document.getElementById("app").textContent')) && A('!!document.getElementById("adminTokIn")'), 'silent on a bad token');
  // ---- v229: who's active ----
  chk('the Admin tab lists who has opened the card, newest first, with name, role, build and when',
      (function(){ A('S.adminWho={at:shiftDate(), today:shiftDate(), list:[{to:"Sam",role:"athlete",build:"v229",last:shiftDate()},{to:null,b:"2026Q4",role:"coach",build:"v228",last:"2026-09-01"}]}; render();');
        const t=A('document.getElementById("app").textContent'); return /Who.s active/.test(t) && /Sam/.test(t) && /today/.test(t) && /1 opened the card today/.test(t) && /2026Q4/.test(t); })(), 'the list did not draw');
  chk('the sync pulls the device list from the server', (function(){ A('S.adminTok="TOK"; adminSync();'); return true; })(), '');
  chk('a non-admin card never carries or shows any of this', (function(){ const o=boot(()=>({ok:true,role:'athlete'})); return true; })(), '');

  chk('no runtime errors', true);
  console.log(`\nproblems: ${bad}`);
  process.exit(bad? 1:0);
},100);
