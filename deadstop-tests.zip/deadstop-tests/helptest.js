// The help card appears when Gummy is posed in the middle, answers open and close,
// and it leaves with him. Guards the panel never outliving the pose.
const { JSDOM } = require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const dom=new JSDOM(fs.readFileSync(f,'utf8'),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://thundermeadows.github.io/'});
const w=dom.window,D=w.document,EV=e=>w.eval(e);
w.AudioContext=w.AudioContext||function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
const click=el=>el&&el.dispatchEvent(new w.MouseEvent('click',{bubbles:true,cancelable:true,view:w}));
setTimeout(()=>{
  console.log(`\n--- ${L}: Gummy's help card ---`);
  let bad=0;
  const chk=(l,ok,d)=>{ if(!ok) bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&d?'  <-- '+d:''}`); };
  EV('try{TOUR.live=false;}catch(e){} try{S.tour={done:true};}catch(e){} render();');
  chk('no card while docked', !D.getElementById('gbHelp'));
  EV('gbPose();');
  const el=D.getElementById('gbHelp');
  chk('card appears when posed', !!el, 'gbHelpSync not called from gbPose');
  if(el){
    const qs=el.querySelectorAll('[data-ghq]');
    chk('questions listed', qs.length>=30, 'only '+qs.length);
    chk('grouped into sections', el.querySelectorAll('.gh-sec').length>=5,
        'sections: '+el.querySelectorAll('.gh-sec').length);
    chk('every question has an answer', [...el.querySelectorAll('[data-ghq]')]
        .every(b=>{ const it=JSON.parse(EV('JSON.stringify(gbHelpItems()['+b.dataset.ghq+'])'));
                    return it && it[1] && it[1].length>20; }), 'an entry has no answer text');
    chk('answers start collapsed', el.querySelectorAll('.gh-a').length===0);
    // indices are positions in the whole list, and section headers occupy some of them -
    // never assume the first entry is a question
    const firstIdx=qs[0].dataset.ghq;
    click(qs[0]);
    const el2=D.getElementById('gbHelp');
    chk('tapping a question opens its answer', el2.querySelectorAll('.gh-a').length===1);
    click(el2.querySelector('[data-ghq="'+firstIdx+'"]'));
    chk('tapping again closes it', D.getElementById('gbHelp').querySelectorAll('.gh-a').length===0);
    // jsdom has no layout, so overlap has to be checked as ARITHMETIC on the boxes we set.
    // The first version of this check only asserted that a left value existed, which is why a
    // card sitting directly underneath the bear passed and shipped.
    (function(){
      const p=D.getElementById('gbHelp');
      const c=JSON.parse(EV('JSON.stringify(gbCenter())'));
      const bx=c.x, by=c.y, bw=114, bh=195;
      const px=parseFloat(p.style.left), py=parseFloat(p.style.top), pw=parseFloat(p.style.width);
      const ph=parseFloat(p.style.maxHeight)||200;
      const overlap = px < bx+bw && px+pw > bx && py < by+bh && py+ph > by;
      chk('card does not overlap the bear', !overlap,
          `card ${px},${py} ${pw}x${ph} vs bear ${bx},${by} 114x195`);
      const vw=w.innerWidth||360;
      chk('card stays on screen', px>=0 && px+pw<=vw+1, `${px}+${pw} vs ${vw}`);
    })();
    // z-order: the bear must not paint over the card
    (function(){
      const zc=parseInt(EV(`(function(){var e=document.getElementById('gbHelp');
        return window.getComputedStyle(e).zIndex||'0';})()`),10);
      const zb=parseInt(EV(`(function(){var e=document.getElementById('gbHost');
        return window.getComputedStyle(e).zIndex||'0';})()`),10);
      chk('card sits above the bear', zc>zb, `help z=${zc}, bear z=${zb}`);
    })();
  }
  // the tick must reconcile the card against the pose, whatever path posed him
  EV("GB.host.classList.add('gb-pose'); var h=document.getElementById('gbHelp'); if(h) h.remove();");
  EV('gbHelpSync();');
  chk('card recovers if it goes missing while posed', !!D.getElementById('gbHelp'));
  // A LOCKED day is the state the athlete is most often in when they go looking for help,
  // and lockGuard swallows taps on anything not explicitly exempt. Untested, this shipped
  // with every question dead on a logged day.
  (function(){
    EV('try{ dayLock(true); }catch(e){}');
    const p=D.getElementById('gbHelp');
    const q0=p && p.querySelector('[data-ghq]');
    if(q0){ click(q0);
      chk('questions still answer on a locked day',
          D.getElementById('gbHelp').querySelectorAll('.gh-a').length===1,
          'lockGuard is eating taps on the help card');
      click(D.getElementById('gbHelp').querySelector('[data-ghq]'));
    } else chk('question present on a locked day', false);
    EV('try{ dayLock(false); }catch(e){}');
  })();
  EV('gbDock();');
  chk('card leaves when he goes back', !D.getElementById('gbHelp'), 'panel outlived the pose');
  EV('gbPose();');
  const cl=D.getElementById('gbHelp') && D.getElementById('gbHelp').querySelector('[data-ghx]');
  chk('Close button present', !!cl);
  if(cl){ click(cl); chk('Close sends him back and clears it', !D.getElementById('gbHelp')); }
  console.log(`  runtime errors: ${EV('(typeof ERR_LOG!=="undefined"?ERR_LOG.length:"n/a")')}`);
  if(EV('(typeof ERR_LOG!=="undefined"?ERR_LOG.length:0)')>0) bad++;
  console.log('  problems:', bad);
  process.exit(bad?1:0);
},1500);
