// The game is a guest on the rest screen. It must be summoned, never automatic; it must die
// when the rest it borrowed ends; and closing it must leave the session exactly as it was.
const { JSDOM } = require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const dom=new JSDOM(fs.readFileSync(f,'utf8'),{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/'});
const w=dom.window,D=w.document,EV=e=>w.eval(e);
w.AudioContext=w.AudioContext||function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
const click=el=>el&&el.dispatchEvent(new w.MouseEvent('click',{bubbles:true,cancelable:true,view:w}));
setTimeout(()=>{
  console.log(`\n--- ${L}: Bulk Run on the rest screen ---`);
  let bad=0; const chk=(l,ok,d)=>{ if(!ok) bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&d?'  <-- '+d:''}`); };
  EV('try{TOUR.live=false;}catch(e){} try{S.tour={done:true};}catch(e){}');
  for(const fn of ['coachIdle','ONB_ACTIVE','isStartMode']) EV(`if(typeof ${fn}==="function") ${fn}=function(){return false;};`);
  EV('S.maxes={squat:327,bench:225,dead:405,ohp:145,pull:225}; render();');
  chk('never opens on its own', !D.getElementById('grunHost'));
  // put a rest on the clock and check the invitation appears
  const i=EV(`(function(){var d=dayObj();for(var k=0;k<d.exercises.length;k++){if(d.exercises[k].loadNum!=null) return k;}return -1;})()`);
  EV(`(function(){var ex=dayObj().exercises[${i}],st=exState(${i},ex);
      st.sets.forEach(function(s){s.st='pend';delete s.t;});
      st.sets[0].st='hit'; st.sets[0].t=Date.now()-5000; save(); return 1;})()`);
  EV('paintRest(true);');
  const btn=D.querySelector('[data-grungo]');
  chk('offered on the rest screen', !!btn, 'no way in');
  // it must not exist until asked for
  chk('still not open until tapped', !D.getElementById('grunHost'));
  EV('grunOpen();');
  chk('opens when summoned', !!D.getElementById('grunHost'));
  chk('canvas built', !!D.getElementById('grunC'));
  // BEHAVIOUR, not the guard's source text. This used to grep lockGuard for the string
  // "grunHost", so when the guard was rewritten in c201 to exempt overlays by WHAT THEY ARE - any
  // body child that is not #app - rather than by a list of names, this failed on a card that was
  // working perfectly. A test that pins an implementation detail blocks the fix that removes it.
  {
    const st=EV('JSON.stringify({d:S.day,l:JSON.stringify(S.locked||{})})');
    EV("S.locked=S.locked||{}; S.locked[dayKey()]=true;");
    const host=D.getElementById('grunHost');
    const target=(host && (host.querySelector('*')||host));
    let stopped=false;
    if(target){
      const ev=new w.MouseEvent('click',{bubbles:true,cancelable:true});
      const orig=ev.stopPropagation.bind(ev);
      ev.stopPropagation=function(){ stopped=true; return orig(); };
      target.dispatchEvent(ev);
    }
    const reallyLocked=EV('dayLocked()');
    chk('(fixture) the day really is locked for this check', reallyLocked===true,
        'dayLocked() is false - this check would pass on a card that locks the game');
    chk('exempt from the lock guard', !!target && !stopped, 'taps inside the game are swallowed on a locked day');
    const back=JSON.parse(st); EV('S.locked='+back.l+'; S.day='+JSON.stringify(back.d)+';');
  }
  // closing leaves nothing behind and does not disturb the session
  const before=EV('JSON.stringify({d:S.day,w:S.week,sets:JSON.stringify(S.data)})');
  EV('grunClose();');
  chk('closes cleanly', !D.getElementById('grunHost'));
  chk('no animation frame left running', EV('GRUN.raf')===null);
  chk('the session is untouched', EV('JSON.stringify({d:S.day,w:S.week,sets:JSON.stringify(S.data)})')===before);
  // and it lets go when the rest runs out
  EV('grunOpen();');
  EV(`(function(){var st=exState(${i},dayObj().exercises[${i}]);
      st.sets[0].t=Date.now()-9*60*1000; save(); return 1;})()`);
  EV('(function(){ var b=lastCompletion(); if(!b||(Date.now()-b.t)/1000>b.target) grunClose(); })()');
  chk('hands the screen back when the rest ends', !D.getElementById('grunHost'));
  chk('saves no score anywhere', !/grunScore|S\.grun/.test(EV('String(grunStart)')+EV('String(grunOpen)')));
  // a crash must cost the run, not the screen - and must never look like an injury
  const src=fs.readFileSync(f,'utf8');
  const game=src.slice(src.indexOf('function grunStart'), src.indexOf('function restExtRow'));
  chk('a crash starts the run over', /score=0/.test(game) && /spd=6\.2/.test(game), 'no consequence to hitting one');
  chk('but never closes the game', !/grunClose\(\)/.test(game.slice(game.indexOf('function crash'), game.indexOf('function crash')+700)));
  chk('nothing red on impact', !/E04A3C/.test(game), 'red spatter reads as blood on a gummy bear');
  chk('one hit per stumble', /hurt>0\) return/.test(game), 'a single obstacle would hit every frame');
  // Field-caught: crash() replaced the items array while the collision loop was walking it by
  // index, so the next iteration read past the end and threw. It must only ever raise a flag.
  const crashFn=game.slice(game.indexOf('function crash'), game.indexOf('function spawn'));
  chk('crash does not swap the array it is called from',
      !/items\s*=\s*items\.filter/.test(crashFn), 'throws on the next loop iteration');
  chk('the sweep happens outside the loop', /clearAhead\)\{\s*clearAhead=false/.test(game));
  // the improvements verified in the standalone must actually be present here - the two copies
  // silently diverged once already, and only a harness caught it
  const g2=src.slice(src.indexOf('function grunStart'), src.indexOf('function restExtRow'));
  chk('pace builds with time survived', /floorSpd/.test(g2), 'a full rest would end at walking pace');
  chk('obstacle gap scales with pace', /spd\/7\.5/.test(g2), 'two obstacles inside one reaction at speed');
  chk('backdrop gradients built once', /BG=x\.createLinearGradient/.test(g2), 'rebuilt 60x a second');
  chk('particle pool is capped', /FX_MAX/.test(g2), 'particles accumulate under repeated impacts');
  // the exit must be reachable: out of the swipe zone, no centring transform to shift it,
  // and it must survive the canvas claiming pointer gestures
  // slice exactly the .grun-x rule - a fixed window spilled into .grun-tip and read its bottom:
  const cssStart=src.indexOf('.grun-x{');
  const css=src.slice(cssStart, src.indexOf('}', cssStart));
  chk('exit sits near the top', /top:\s*\d+px/.test(css) && !/bottom:/.test(css), 'still in the swipe zone');
  chk('no centring transform to shift it', !/translateX/.test(css), 'shifts when pressed');
  chk('has a real tap target', /min-height:\s*4[0-9]px/.test(css));
  // put a live rest back first: the previous check deliberately expired it, and the game
  // correctly refuses to stay open without one
  EV(`(function(){var st=exState(${i},dayObj().exercises[${i}]);
      st.sets[0].st='hit'; st.sets[0].t=Date.now()-3000; save();})()`);
  EV('grunClose(); grunOpen();');
  const xb=D.querySelector('[data-grunx]');
  chk('exit present', !!xb);
  if(xb){ xb.dispatchEvent(new w.MouseEvent('pointerdown',{bubbles:true}));
    xb.dispatchEvent(new w.MouseEvent('pointerup',{bubbles:true}));
    chk('a press-and-release closes it', !D.getElementById('grunHost'), 'the canvas ate the tap'); }
  console.log(`  runtime errors: ${EV('(typeof ERR_LOG!=="undefined"?ERR_LOG.length:"n/a")')}`);
  console.log('  problems:', bad);
  process.exit(bad?1:0);
},1500);
