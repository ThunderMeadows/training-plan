// 2026-09-01 ruling: the card never asks what hurts and never adapts training to an injury
// claim. Neutral tools (Swap) carry that job. This test keeps the pattern out for good.
const {JSDOM}=require('jsdom'); const fs=require('fs');
const f=process.argv[2], L=process.argv[3]||f;
const raw=fs.readFileSync(f,'utf8');
const d=new JSDOM(raw,{runScripts:'dangerously',pretendToBeVisual:true,url:'https://x.io/'});
const w=d.window,EV=e=>w.eval(e);
w.AudioContext=function(){return{state:'running',resume(){},createOscillator(){return{connect(){},start(){},stop(){},frequency:{value:0,setValueAtTime(){}}}},createGain(){return{connect(){},gain:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}}}},destination:{},currentTime:0};};
let bad=0; const chk=(l,ok,dd)=>{ if(!ok)bad++; console.log(`  ${ok?'ok  ':'FAIL'}  ${l}${!ok&&dd?'  <-- '+dd:''}`); };
setTimeout(()=>{
  console.log(`\n--- ${L}: no medical intake, no injury adaptation ---`);
  EV('try{TOUR.live=false;}catch(e){} S.tour={done:true}; S.maxes={squat:327,bench:225,dead:405,ohp:145,pull:225}; render();');
  chk('no pain question in the set UI', EV('document.querySelectorAll("[data-pain]").length')===0, 'buttons rendered');
  chk('no pain log survives in state and boot cleanup exists', EV('S.painLog===undefined') && raw.indexOf('delete S.painLog')>=0, 'painLog present or cleanup missing');
  chk('no injury step in onboarding', EV('typeof ONB_STEPS_FULL==="undefined" || (ONB_STEPS_FULL.indexOf("limits")<0 && ONB_STEPS_START.indexOf("pain")<0)'), 'injury step present');
  chk('nothing renders an injury question', !/data-onblim|data-onbpain/.test(raw), 'onboarding injury handlers in source');
  chk('help copy is neutral and non-medical', raw.indexOf('never asks why')>=0 && raw.indexOf('see a qualified professional')>=0, 'neutral copy missing');
  chk('adaptation engine no longer reads pain', !/pain flags in the last/.test(raw), 'pain signal in source');
  // c144 field crash: a removed feature left FOUR readers behind over three sweeps. The only
  // reliable guard is source-wide - the boot cleanup is the single legal mention.
  // strip the boot-cleanup lines (the only legal mentions), then nothing may remain
  const swept=raw.split('\n').filter(l=>!/delete S\.painLog|delete st\.pain/.test(l)).join('\n');
  chk('no code anywhere still reads the pain log', !/S\.painLog/.test(swept), (swept.match(/.{0,60}S\.painLog.{0,40}/)||[''])[0]);
  chk('no code still reads a per-set pain field', !/\bst\.pain\b/.test(swept), (swept.match(/.{0,60}st\.pain.{0,30}/)||[''])[0]);
  chk('the boot cleanup itself is still there', /delete S\.painLog/.test(raw), 'cleanup lost');
  // the c145 rule, learned the hard way: feature removal is a SOURCE-WIDE property, not a
  // surface sweep. Exactly one painLog reference may exist - the boot line that deletes it.
  var plRefs=(raw.match(/S\.painLog/g)||[]).length;
  chk('the only painLog reference left is its own deletion', plRefs===2 && /if\(S\.painLog!==undefined\) delete S\.painLog;/.test(raw), plRefs+' refs');
  // the disclaimer gate (2026-09-01): shown before first training, acknowledged once per
  // version, never silently skipped
  chk('fresh boot shows the disclaimer gate', EV('!!document.getElementById("discGate")'), 'gate absent');
  chk('gate copy says training tool, not medical advice', EV('(document.getElementById("discGate")||{innerHTML:""}).innerHTML').indexOf('not medical advice')>=0, 'copy missing');
  EV('document.getElementById("discOk").click();');
  chk('acknowledging stores the version and closes the gate', EV('S.discAck && S.discAck.v===DISC_V && !document.getElementById("discGate")'), EV('JSON.stringify(S.discAck||null)'));
  EV('bootDisc();');
  chk('acknowledged gate does not return on reboot', EV('!document.getElementById("discGate")'), 'gate re-shown');
  EV('bootDisc(true);');
  chk('settings can re-open it read-only', EV('!!document.getElementById("discGate")'), 'force-show failed');
  EV('document.getElementById("discOk").click();');
  chk('re-read close does not rewrite the ack date', EV('S.discAck.v===DISC_V'), 'ack disturbed');
  console.log('  problems: '+bad); process.exit(bad?1:0);
},1500);
